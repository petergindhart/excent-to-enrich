SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AcademicPlanGenSubject_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AcademicPlanGenSubject_InsertRecord]
GO

 /*
<summary>
Inserts a new record into the AcademicPlanGenSubject table with the specified values
</summary>
<param name="generatorId">Value to assign to the GeneratorID field of the record</param>
<param name="subjectId">Value to assign to the SubjectID field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE dbo.AcademicPlanGenSubject_InsertRecord
	@generatorId uniqueidentifier, 
	@subjectId uniqueidentifier
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
	
	INSERT INTO AcademicPlanGenSubject
	(
		Id, 
		GeneratorId, 
		SubjectId
	)
	VALUES
	(
		@id, 
		@generatorId, 
		@subjectId
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

