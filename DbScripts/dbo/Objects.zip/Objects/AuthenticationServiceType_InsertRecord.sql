SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AuthenticationServiceType_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AuthenticationServiceType_InsertRecord]
GO

 /*
<summary>
Inserts a new record into the AuthenticationServiceType table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<param name="description">Value to assign to the Description field of the record</param>
<param name="authenticatorTypeName">Value to assign to the AuthenticatorTypeName field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Char" />
*/
CREATE PROCEDURE dbo.AuthenticationServiceType_InsertRecord 
	@id char(1),
	@name varchar(50),
	@description varchar(1000),
	@authenticatorTypeName varchar(500)
AS
INSERT INTO AuthenticationServiceType
	(

		ID,
		Name,
		Description,
		AuthenticatorTypeName
	)
	VALUES
	(

		@id,
		@name,
		@description,
		@authenticatorTypeName
	)
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

