SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FormInputFlagValue_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[FormInputFlagValue_InsertRecord]
GO

 /*
<summary>
Inserts a new record into the FormInputFlagValue table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="value">Value to assign to the Value field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE dbo.FormInputFlagValue_InsertRecord	
	@id uniqueidentifier, 
	@value bit
AS
	
	INSERT INTO FormInputFlagValue
	(
		Id, 
		Value
	)
	VALUES
	(
		@id, 
		@value
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

