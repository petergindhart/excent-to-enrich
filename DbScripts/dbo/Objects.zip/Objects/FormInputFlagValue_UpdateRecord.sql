SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FormInputFlagValue_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[FormInputFlagValue_UpdateRecord]
GO

 /*
<summary>
Updates a record in the FormInputFlagValue table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="value">Value to assign to the Value field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.FormInputFlagValue_UpdateRecord
	@id uniqueidentifier, 
	@value bit
AS
	UPDATE FormInputFlagValue
	SET
		Value = @value
	WHERE 
		Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

