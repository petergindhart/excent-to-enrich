SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FormInstanceBatch_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[FormInstanceBatch_UpdateRecord]
GO

 /*
<summary>
Updates a record in the FormInstanceBatch table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<param name="formTemplateTypeId">Value to assign to the FormTemplateTypeId field of the record</param>
<param name="currentIntervalId">Value to assign to the CurrentIntervalId field of the record</param>
<param name="intervalSeriesId">Value to assign to the IntervalSeriesId field of the record</param>
<param name="inProgress">Value to assign to the InProgress field of the record</param>
<param name="applyDuringSisImport">Value to assign to the ApplyDuringSisImport field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.FormInstanceBatch_UpdateRecord
	@id uniqueidentifier, 
	@name varchar(100), 
	@formTemplateTypeId uniqueidentifier, 
	@currentIntervalId uniqueidentifier, 
	@intervalSeriesId uniqueidentifier, 
	@inProgress bit, 
	@applyDuringSisImport bit
AS
	UPDATE FormInstanceBatch
	SET
		Name = @name, 
		FormTemplateTypeId = @formTemplateTypeId, 
		CurrentIntervalId = @currentIntervalId, 
		IntervalSeriesId = @intervalSeriesId, 
		InProgress = @inProgress, 
		ApplyDuringSisImport = @applyDuringSisImport
	WHERE 
		Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

