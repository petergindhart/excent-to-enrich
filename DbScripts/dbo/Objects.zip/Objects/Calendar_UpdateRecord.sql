SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Calendar_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Calendar_UpdateRecord]
GO

 /*
<summary>
Updates a record in the Calendar table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<param name="firstDate">Value to assign to the FirstDate field of the record</param>
<param name="lastDate">Value to assign to the LastDate field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.Calendar_UpdateRecord
	@id uniqueidentifier, 
	@name varchar(80), 
	@firstDate datetime, 
	@lastDate datetime
AS
	UPDATE Calendar
	SET
		Name = @name, 
		FirstDate = @firstDate, 
		LastDate = @lastDate
	WHERE 
		ID = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

