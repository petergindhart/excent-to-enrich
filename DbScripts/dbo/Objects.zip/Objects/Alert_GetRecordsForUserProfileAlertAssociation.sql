SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Alert_GetRecordsForUserProfileAlertAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Alert_GetRecordsForUserProfileAlertAssociation]
GO

 /*
<summary>
Gets records from the Alert table for the specified association 
</summary>
<param name="ids">Ids of the UserProfile(s) </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.Alert_GetRecordsForUserProfileAlertAssociation
	@ids uniqueidentifierarray
AS
	SELECT ab.UserProfileId, a.*
	FROM
		UserProfileAlert ab INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON ab.UserProfileId = Keys.Id INNER JOIN
		Alert a ON ab.AlertId = a.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

