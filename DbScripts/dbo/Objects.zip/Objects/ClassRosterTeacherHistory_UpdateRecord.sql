SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ClassRosterTeacherHistory_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ClassRosterTeacherHistory_UpdateRecord]
GO

 /*
<summary>
Updates a record in the ClassRosterTeacherHistory table with the specified values
</summary>
<param name="classRosterId">Value to assign to the ClassRosterID field of the record</param>
<param name="teacherId">Value to assign to the TeacherID field of the record</param>
<param name="startDate">Value to assign to the StartDate field of the record</param>
<param name="endDate">Value to assign to the EndDate field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ClassRosterTeacherHistory_UpdateRecord
	@classRosterId uniqueidentifier, 
	@teacherId uniqueidentifier, 
	@startDate datetime, 
	@endDate datetime
AS
	UPDATE ClassRosterTeacherHistory
	SET
		EndDate = @endDate
	WHERE 
		ClassRosterID = @classRosterId AND 
		TeacherID = @teacherId AND 
		StartDate = @startDate
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

