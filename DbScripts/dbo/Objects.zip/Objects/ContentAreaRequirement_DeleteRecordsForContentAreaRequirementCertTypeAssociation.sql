SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ContentAreaRequirement_DeleteRecordsForContentAreaRequirementCertTypeAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ContentAreaRequirement_DeleteRecordsForContentAreaRequirementCertTypeAssociation]
GO

 /*
<summary>
Deletes records from the ContentAreaRequirementCertType table for the specified ids 
</summary>
<param name="certificationTypeId">The id of the associated EnumValue</param>
<param name="ids">The ids of the ContentAreaRequirement's to delete</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ContentAreaRequirement_DeleteRecordsForContentAreaRequirementCertTypeAssociation
	@certificationTypeId uniqueidentifier, 
	@ids uniqueidentifierarray
AS
	DELETE ContentAreaRequirementCertType
	FROM 
		ContentAreaRequirementCertType ab INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON ab.ContentAreaRequirementId = Keys.Id
	WHERE
		ab.CertificationTypeId = @certificationTypeId
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

