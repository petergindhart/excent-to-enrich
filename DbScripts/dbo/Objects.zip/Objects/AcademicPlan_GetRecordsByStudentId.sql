SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AcademicPlan_GetRecordsByStudentId]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AcademicPlan_GetRecordsByStudentId]
GO

 /*
<summary>
Gets records from the AcademicPlan table for the specified ids 
</summary>
<param name="ids">Ids of the Student's </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.AcademicPlan_GetRecordsByStudentId 
	@ids uniqueidentifierarray
AS
	SELECT a.StudentID, a.*
	FROM
		AcademicPlan a INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON a.StudentID = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

