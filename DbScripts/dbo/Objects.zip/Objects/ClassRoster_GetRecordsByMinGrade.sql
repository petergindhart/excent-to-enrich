SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ClassRoster_GetRecordsByMinGrade]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ClassRoster_GetRecordsByMinGrade]
GO

 /*
<summary>
Gets records from the ClassRoster table with the specified ids
</summary>
<param name="ids">Ids of the GradeLevel(s) to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ClassRoster_GetRecordsByMinGrade
	@ids	uniqueidentifierarray
AS
	SELECT c.MinGradeId, c.*
	FROM
		ClassRoster c INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON c.MinGradeId = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

