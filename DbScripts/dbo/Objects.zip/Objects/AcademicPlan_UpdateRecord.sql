SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AcademicPlan_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AcademicPlan_UpdateRecord]
GO

 /*
<summary>
Updates a record in the AcademicPlan table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="studentId">Value to assign to the StudentID field of the record</param>
<param name="rosterYearId">Value to assign to the RosterYearID field of the record</param>
<param name="schoolId">Value to assign to the SchoolID field of the record</param>
<param name="gradeLevelId">Value to assign to the GradeLevelID field of the record</param>
<param name="reasonId">Value to assign to the ReasonID field of the record</param>
<param name="street">Value to assign to the Street field of the record</param>
<param name="city">Value to assign to the City field of the record</param>
<param name="state">Value to assign to the State field of the record</param>
<param name="zipCode">Value to assign to the ZipCode field of the record</param>
<param name="phoneNumber">Value to assign to the PhoneNumber field of the record</param>
<param name="detailedReason">Value to assign to the DetailedReason field of the record</param>
<param name="generatorId">Value to assign to the GeneratorID field of the record</param>
<param name="templateId">Value to assign to the TemplateID field of the record</param>
<param name="translationId">Value to assign to the TranslationID field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE [dbo].[AcademicPlan_UpdateRecord]
	@id uniqueidentifier, 
	@studentId uniqueidentifier, 
	@rosterYearId uniqueidentifier, 
	@schoolId uniqueidentifier, 
	@gradeLevelId uniqueidentifier, 
	@reasonId uniqueidentifier, 
	@street varchar(100), 
	@city varchar(50), 
	@state char(2), 
	@zipCode varchar(10), 
	@phoneNumber varchar(40), 
	@detailedReason varchar(200), 
	@generatorId uniqueidentifier, 
	@templateId uniqueidentifier, 
	@translationId int
AS
	UPDATE AcademicPlan
	SET
		StudentID = @studentId, 
		RosterYearID = @rosterYearId, 
		SchoolID = @schoolId, 
		GradeLevelID = @gradeLevelId, 
		ReasonID = @reasonId, 
		Street = @street, 
		City = @city, 
		State = @state, 
		ZipCode = @zipCode, 
		PhoneNumber = @phoneNumber, 
		DetailedReason = @detailedReason, 
		GeneratorID = @generatorId, 
		TemplateID = @templateId, 
		TranslationID = @translationId
	WHERE 
		ID = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

