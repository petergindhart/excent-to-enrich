SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Alert_DeleteRecordsForAlertRuleAlertAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Alert_DeleteRecordsForAlertRuleAlertAssociation]
GO

 /*
<summary>
Deletes records from the AlertRuleAlert table for the specified ids 
</summary>
<param name="alertRuleId">The id of the associated AlertRule</param>
<param name="ids">The ids of the Alert's to delete</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.Alert_DeleteRecordsForAlertRuleAlertAssociation
	@alertRuleId uniqueidentifier, 
	@ids uniqueidentifierarray
AS
	DELETE AlertRuleAlert
	FROM 
		AlertRuleAlert ab INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON ab.AlertId = Keys.Id
	WHERE
		ab.AlertRuleId = @alertRuleId
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

