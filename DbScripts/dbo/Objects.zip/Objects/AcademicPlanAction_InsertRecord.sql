SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AcademicPlanAction_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AcademicPlanAction_InsertRecord]
GO

 /*
<summary>
Inserts a new record into the AcademicPlanAction table with the specified values
</summary>
<param name="isSelected">Value to assign to the IsSelected field of the record</param>
<param name="academicPlanID">Value to assign to the AcademicPlanID field of the record</param>
<param name="actionID">Value to assign to the ActionID field of the record</param>
<returns>The id of the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE dbo.AcademicPlanAction_InsertRecord 
	@isSelected bit,
	@academicPlanID uniqueidentifier,
	@actionID uniqueidentifier
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()

	INSERT INTO AcademicPlanAction
	(
		Id,
		IsSelected,
		AcademicPlanID,
		ActionID
	)
	VALUES
	(
		@id,
		@isSelected,
		@academicPlanID,
		@actionID
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

