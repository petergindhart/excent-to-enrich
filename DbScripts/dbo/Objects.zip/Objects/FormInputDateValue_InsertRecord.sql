SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FormInputDateValue_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[FormInputDateValue_InsertRecord]
GO

 /*
<summary>
Inserts a new record into the FormInputDateValue table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="value">Value to assign to the Value field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.FormInputDateValue_InsertRecord
	@id uniqueidentifier, 
	@value datetime
AS
	INSERT INTO FormInputDateValue
	(
		Id, 
		Value
	)
	VALUES
	(
		@id, 
		@value
	)
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

