SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FormInputDateValue_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[FormInputDateValue_UpdateRecord]
GO

 /*
<summary>
Updates a record in the FormInputDateValue table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="value">Value to assign to the Value field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.FormInputDateValue_UpdateRecord
	@id uniqueidentifier, 
	@value datetime
AS
	UPDATE FormInputDateValue
	SET
		Value = @value
	WHERE 
		ID = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

