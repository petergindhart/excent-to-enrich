SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FormInterval_InsertRecordsForFormTemplateControlFormIntervalAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[FormInterval_InsertRecordsForFormTemplateControlFormIntervalAssociation]
GO

 /*
<summary>
Insert records in the FormTemplateControlFormInterval table for the specified ids 
</summary>
<param name="controlId">The id of the associated FormTemplateControl</param>
<param name="ids">The ids of the FormInterval's to insert</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.FormInterval_InsertRecordsForFormTemplateControlFormIntervalAssociation
	@controlId uniqueidentifier, 
	@ids uniqueidentifierarray
AS
	INSERT INTO FormTemplateControlFormInterval ( ControlId, IntervalId)
	SELECT @controlId, Keys.* FROM
		GetUniqueidentifiers(@ids) AS Keys
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

