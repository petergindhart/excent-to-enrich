SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AcademicPlanGen_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AcademicPlanGen_UpdateRecord]
GO

 /*
<summary>
Updates a record in the AcademicPlanGen table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="generatedById">Value to assign to the GeneratedByID field of the record</param>
<param name="generatedDate">Value to assign to the GeneratedDate field of the record</param>
<param name="batchName">Value to assign to the BatchName field of the record</param>
<param name="sendEmail">Value to assign to the SendEmail field of the record</param>
<param name="emailFromAddress">Value to assign to the EmailFromAddress field of the record</param>
<param name="emailSubject">Value to assign to the EmailSubject field of the record</param>
<param name="emailBody">Value to assign to the EmailBody field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.AcademicPlanGen_UpdateRecord
	@id uniqueidentifier, 
	@generatedById uniqueidentifier, 
	@generatedDate datetime, 
	@batchName varchar(400), 
	@sendEmail bit, 
	@emailFromAddress varchar(200), 
	@emailSubject text, 
	@emailBody text
AS
	UPDATE AcademicPlanGen
	SET
		GeneratedByID = @generatedById, 
		GeneratedDate = @generatedDate, 
		BatchName = @batchName, 
		SendEmail = @sendEmail, 
		EmailFromAddress = @emailFromAddress, 
		EmailSubject = @emailSubject, 
		EmailBody = @emailBody
	WHERE 
		ID = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

