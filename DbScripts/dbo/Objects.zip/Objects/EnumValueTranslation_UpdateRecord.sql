SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[EnumValueTranslation_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[EnumValueTranslation_UpdateRecord]
GO

 /*
<summary>
Updates a record in the EnumValueTranslation table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="originalId">Value to assign to the OriginalID field of the record</param>
<param name="languageId">Value to assign to the LanguageID field of the record</param>
<param name="displayValue">Value to assign to the DisplayValue field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.EnumValueTranslation_UpdateRecord
	@id uniqueidentifier, 
	@originalId uniqueidentifier, 
	@languageId int, 
	@displayValue nvarchar(2048)
AS
	UPDATE EnumValueTranslation
	SET
		OriginalID = @originalId, 
		LanguageID = @languageId, 
		DisplayValue = @displayValue
	WHERE 
		ID = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

