SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ClassRosterTeacherHistory_GetRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ClassRosterTeacherHistory_GetRecords]
GO

 /*
<summary>
Gets records from the ClassRosterTeacherHistory table with the specified id's
</summary>
<param name="ids">Ids of the records to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ClassRosterTeacherHistory_GetRecords
	@ids	uniqueidentifieruniqueidentifierdatetimearray
AS
	SELECT c.*
	FROM
		ClassRosterTeacherHistory c INNER JOIN
		GetUniqueidentifierUniqueidentifierDatetimes(@ids) AS Keys ON c.ClassRosterId = Keys.Id0 AND c.TeacherId = Keys.Id1 AND c.StartDate = Keys.Id2
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

