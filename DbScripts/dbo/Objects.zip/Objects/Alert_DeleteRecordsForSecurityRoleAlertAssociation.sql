SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Alert_DeleteRecordsForSecurityRoleAlertAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Alert_DeleteRecordsForSecurityRoleAlertAssociation]
GO

 /*
<summary>
Deletes records from the SecurityRoleAlert table for the specified ids 
</summary>
<param name="securityRoleId">The id of the associated SecurityRole</param>
<param name="ids">The ids of the Alert's to delete</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.Alert_DeleteRecordsForSecurityRoleAlertAssociation
	@securityRoleId uniqueidentifier, 
	@ids uniqueidentifierarray
AS
	DELETE SecurityRoleAlert
	FROM 
		SecurityRoleAlert ab INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON ab.AlertId = Keys.Id
	WHERE
		ab.SecurityRoleId = @securityRoleId
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

