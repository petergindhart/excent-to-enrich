SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AcademicPlanTemplateLetter_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AcademicPlanTemplateLetter_InsertRecord]
GO

 /*
<summary>
Inserts a new record into the AcademicPlanTemplateLetter table with the specified values
</summary>
<param name="templateId">Value to assign to the TemplateID field of the record</param>
<param name="htmlText">Value to assign to the HtmlText field of the record</param>
<param name="title">Value to assign to the Title field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE dbo.AcademicPlanTemplateLetter_InsertRecord
	@templateId uniqueidentifier, 
	@htmlText text, 
	@title varchar(75)
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
	
	INSERT INTO AcademicPlanTemplateLetter
	(
		Id, 
		TemplateId, 
		HtmlText, 
		Title
	)
	VALUES
	(
		@id, 
		@templateId, 
		@htmlText, 
		@title
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

