SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FileData_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[FileData_UpdateRecord]
GO

 /*
<summary>
Updates a record in the FileData table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="originalName">Value to assign to the OriginalName field of the record</param>
<param name="receivedDate">Value to assign to the ReceivedDate field of the record</param>
<param name="mimeType">Value to assign to the MimeType field of the record</param>
<param name="content">Value to assign to the Content field of the record</param>
<param name="isTemporary">Value to assign to the IsTemporary field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE [dbo].[FileData_UpdateRecord]
	@id uniqueidentifier, 
	@originalName varchar(1024), 
	@receivedDate datetime, 
	@mimeType varchar(50), 
	@content image, 
	@isTemporary bit
AS
	UPDATE FileData
	SET
		OriginalName = @originalName, 
		ReceivedDate = @receivedDate, 
		MimeType = @mimeType, 
		Content = @content, 
		IsTemporary = @isTemporary
	WHERE 
		ID = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

