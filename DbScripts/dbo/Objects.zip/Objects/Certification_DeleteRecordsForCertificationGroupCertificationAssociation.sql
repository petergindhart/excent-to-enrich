SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Certification_DeleteRecordsForCertificationGroupCertificationAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Certification_DeleteRecordsForCertificationGroupCertificationAssociation]
GO

 /*
<summary>
Deletes records from the CertificationGroupCertification table for the specified ids 
</summary>
<param name="certificationGroupId">The id of the associated CertificationGroup</param>
<param name="ids">The ids of the Certification's to delete</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.Certification_DeleteRecordsForCertificationGroupCertificationAssociation
	@certificationGroupId uniqueidentifier, 
	@ids uniqueidentifierarray
AS
	DELETE CertificationGroupCertification
	FROM 
		CertificationGroupCertification ab INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON ab.CertificationId = Keys.Id
	WHERE
		ab.CertificationGroupId = @certificationGroupId
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

