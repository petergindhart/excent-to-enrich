SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[CertificationExam_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[CertificationExam_UpdateRecord]
GO

 /*
<summary>
Updates a record in the CertificationExam table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<param name="code">Value to assign to the Code field of the record</param>
<param name="descriptionUrl">Value to assign to the DescriptionUrl field of the record</param>
<param name="familyId">Value to assign to the FamilyID field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.CertificationExam_UpdateRecord
	@id uniqueidentifier, 
	@name varchar(200), 
	@code varchar(10), 
	@descriptionUrl varchar(500), 
	@familyId uniqueidentifier
AS
	UPDATE CertificationExam
	SET
		Name = @name, 
		Code = @code, 
		DescriptionUrl = @descriptionUrl, 
		FamilyID = @familyId
	WHERE 
		ID = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

