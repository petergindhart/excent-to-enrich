SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ChangeHistory_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ChangeHistory_InsertRecord]
GO

 /*
<summary>
Inserts a new record into the ChangeHistory table with the specified values
</summary>
<param name="changeDate">Value to assign to the ChangeDate field of the record</param>
<param name="academicPlanID">Value to assign to the AcademicPlanID field of the record</param>
<param name="userID">Value to assign to the UserID field of the record</param>
<returns>The id of the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE dbo.ChangeHistory_InsertRecord 
	@changeDate datetime,
	@academicPlanID uniqueidentifier,
	@userID uniqueidentifier
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()

	INSERT INTO ChangeHistory
	(
		Id,
		ChangeDate,
		AcademicPlanID,
		UserID
	)
	VALUES
	(
		@id,
		@changeDate,
		@academicPlanID,
		@userID
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

