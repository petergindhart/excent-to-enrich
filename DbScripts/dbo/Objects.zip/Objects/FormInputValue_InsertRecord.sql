SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FormInputValue_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[FormInputValue_InsertRecord]
GO

 /*
<summary>
Inserts a new record into the FormInputValue table with the specified values
</summary>
<param name="intervalId">Value to assign to the IntervalId field of the record</param>
<param name="inputFieldId">Value to assign to the InputFieldId field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE [dbo].[FormInputValue_InsertRecord]	
	@intervalId uniqueidentifier, 
	@inputFieldId uniqueidentifier
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
	
	INSERT INTO FormInputValue
	(
		Id, 
		IntervalId, 
		InputFieldId
	)
	VALUES
	(
		@id, 
		@intervalId, 
		@inputFieldId
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

