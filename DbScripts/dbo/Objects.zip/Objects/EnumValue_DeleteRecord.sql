SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[EnumValue_DeleteRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[EnumValue_DeleteRecord]
GO

 /*
<summary>
Deletes a EnumValue record
</summary>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.EnumValue_DeleteRecord
	@id uniqueidentifier
AS
	DELETE FROM 
		EnumValue
	WHERE
		Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

