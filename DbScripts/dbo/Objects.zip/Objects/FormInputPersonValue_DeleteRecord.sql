SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FormInputPersonValue_DeleteRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[FormInputPersonValue_DeleteRecord]
GO



 /*
<summary>
Deletes a FormInputPersonValue record
</summary>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE [dbo].[FormInputPersonValue_DeleteRecord]
	@id uniqueidentifier
AS
	DELETE FROM 
		FormInputPersonValue
	WHERE
		Id = @id

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

