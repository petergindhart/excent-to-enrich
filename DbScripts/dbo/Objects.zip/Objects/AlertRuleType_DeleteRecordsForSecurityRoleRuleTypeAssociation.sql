SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AlertRuleType_DeleteRecordsForSecurityRoleRuleTypeAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AlertRuleType_DeleteRecordsForSecurityRoleRuleTypeAssociation]
GO

 /*
<summary>
Deletes records from the SecurityRoleRuleType table for the specified ids 
</summary>
<param name="roleId">The id of the associated SecurityRole</param>
<param name="ids">The ids of the AlertRuleType's to delete</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.AlertRuleType_DeleteRecordsForSecurityRoleRuleTypeAssociation
	@roleId uniqueidentifier, 
	@ids uniqueidentifierarray
AS
	DELETE SecurityRoleRuleType
	FROM 
		SecurityRoleRuleType ab INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON ab.RoleId = Keys.Id
	WHERE
		ab.RoleId = @roleId
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

