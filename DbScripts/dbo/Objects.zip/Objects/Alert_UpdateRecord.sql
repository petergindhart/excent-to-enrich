SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Alert_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Alert_UpdateRecord]
GO

 /*
<summary>
Updates a record in the Alert table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="recipientsExpr">Value to assign to the RecipientsExpr field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<param name="description">Value to assign to the Description field of the record</param>
<param name="emailSubject">Value to assign to the EmailSubject field of the record</param>
<param name="emailMessage">Value to assign to the EmailMessage field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.Alert_UpdateRecord
	@id uniqueidentifier, 
	@recipientsExpr varchar(200), 
	@name varchar(50), 
	@description varchar(1000), 
	@emailSubject varchar(500), 
	@emailMessage text
AS
	UPDATE Alert
	SET
		RecipientsExpr = @recipientsExpr, 
		Name = @name, 
		Description = @description, 
		EmailSubject = @emailSubject, 
		EmailMessage = @emailMessage
	WHERE 
		ID = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

