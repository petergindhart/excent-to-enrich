SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ClassRosterTeacherHistory_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ClassRosterTeacherHistory_InsertRecord]
GO

 /*
<summary>
Inserts a new record into the ClassRosterTeacherHistory table with the specified values
</summary>
<param name="classRosterId">Value to assign to the ClassRosterID field of the record</param>
<param name="teacherId">Value to assign to the TeacherID field of the record</param>
<param name="startDate">Value to assign to the StartDate field of the record</param>
<param name="endDate">Value to assign to the EndDate field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ClassRosterTeacherHistory_InsertRecord
	@classRosterId uniqueidentifier, 
	@teacherId uniqueidentifier, 
	@startDate datetime, 
	@endDate datetime
AS
	INSERT INTO ClassRosterTeacherHistory
	(
		ClassRosterId, 
		TeacherId, 
		StartDate, 
		EndDate
	)
	VALUES
	(
		@classRosterId, 
		@teacherId, 
		@startDate, 
		@endDate
	)
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

