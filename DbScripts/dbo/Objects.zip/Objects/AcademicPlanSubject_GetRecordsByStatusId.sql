SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AcademicPlanSubject_GetRecordsByStatusId]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AcademicPlanSubject_GetRecordsByStatusId]
GO

 /*
<summary>
Gets records from the AcademicPlanSubject table with the specified ids
</summary>
<param name="ids">Ids of the EnumValue(s) to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.AcademicPlanSubject_GetRecordsByStatusId
	@ids	uniqueidentifierarray
AS
	SELECT a.StatusId, a.*
	FROM
		AcademicPlanSubject a INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON a.StatusId = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

