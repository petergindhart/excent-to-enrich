SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ContentAreaCertification_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ContentAreaCertification_InsertRecord]
GO

 /*
<summary>
Inserts a new record into the ContentAreaCertification table with the specified values
</summary>
<param name="certificationId">Value to assign to the CertificationID field of the record</param>
<param name="levelId">Value to assign to the LevelID field of the record</param>
<param name="contentAreaId">Value to assign to the ContentAreaID field of the record</param>
<param name="startDate">Value to assign to the StartDate field of the record</param>
<param name="endDate">Value to assign to the EndDate field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE dbo.ContentAreaCertification_InsertRecord
	@certificationId uniqueidentifier, 
	@levelId uniqueidentifier, 
	@contentAreaId uniqueidentifier, 
	@startDate datetime, 
	@endDate datetime
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
	
	INSERT INTO ContentAreaCertification
	(
		Id, 
		CertificationId, 
		LevelId, 
		ContentAreaId, 
		StartDate, 
		EndDate
	)
	VALUES
	(
		@id, 
		@certificationId, 
		@levelId, 
		@contentAreaId, 
		@startDate, 
		@endDate
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

