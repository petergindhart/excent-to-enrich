SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ContentAreaCertification_DeleteRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ContentAreaCertification_DeleteRecord]
GO

 /*
<summary>
Deletes a ContentAreaCertification record
</summary>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ContentAreaCertification_DeleteRecord
	@id uniqueidentifier
AS
	DELETE FROM 
		ContentAreaCertification
	WHERE
		Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

