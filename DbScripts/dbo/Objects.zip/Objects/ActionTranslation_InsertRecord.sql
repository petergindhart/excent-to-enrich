SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ActionTranslation_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ActionTranslation_InsertRecord]
GO

 /*
<summary>
Inserts a new record into the ActionTranslation table with the specified values
</summary>
<param name="originalId">Value to assign to the OriginalID field of the record</param>
<param name="languageId">Value to assign to the LanguageID field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE dbo.ActionTranslation_InsertRecord
	@originalId uniqueidentifier, 
	@languageId int, 
	@name nvarchar(2000)
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
	
	INSERT INTO ActionTranslation
	(
		Id, 
		OriginalId, 
		LanguageId, 
		Name
	)
	VALUES
	(
		@id, 
		@originalId, 
		@languageId, 
		@name
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

