SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Certification_GetRecordsForContentAreaRequirementCertificationAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Certification_GetRecordsForContentAreaRequirementCertificationAssociation]
GO

 /*
<summary>
Gets records from the Certification table for the specified association 
</summary>
<param name="ids">Ids of the ContentAreaRequirement(s) </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.Certification_GetRecordsForContentAreaRequirementCertificationAssociation
	@ids uniqueidentifierarray
AS
	SELECT ab.ContentAreaRequirementId, a.*
	FROM
		ContentAreaRequirementCertification ab INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON ab.ContentAreaRequirementId = Keys.Id INNER JOIN
		Certification a ON ab.CertificationId = a.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

