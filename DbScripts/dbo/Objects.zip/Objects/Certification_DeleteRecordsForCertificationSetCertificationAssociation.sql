SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Certification_DeleteRecordsForCertificationSetCertificationAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Certification_DeleteRecordsForCertificationSetCertificationAssociation]
GO

 /*
<summary>
Deletes records from the CertificationSetCertification table for the specified ids 
</summary>
<param name="certificationSetId">The id of the associated CertificationSet</param>
<param name="ids">The ids of the Certification's to delete</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.Certification_DeleteRecordsForCertificationSetCertificationAssociation
	@certificationSetId uniqueidentifier, 
	@ids uniqueidentifierarray
AS
	DELETE CertificationSetCertification
	FROM 
		CertificationSetCertification ab INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON ab.CertificationId = Keys.Id
	WHERE
		ab.CertificationSetId = @certificationSetId
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

