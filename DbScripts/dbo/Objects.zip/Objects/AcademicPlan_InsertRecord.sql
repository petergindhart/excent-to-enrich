SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AcademicPlan_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AcademicPlan_InsertRecord]
GO

 /*
<summary>
Inserts a new record into the AcademicPlan table with the specified values
</summary>
<param name="studentId">Value to assign to the StudentID field of the record</param>
<param name="rosterYearId">Value to assign to the RosterYearID field of the record</param>
<param name="schoolId">Value to assign to the SchoolID field of the record</param>
<param name="gradeLevelId">Value to assign to the GradeLevelID field of the record</param>
<param name="reasonId">Value to assign to the ReasonID field of the record</param>
<param name="street">Value to assign to the Street field of the record</param>
<param name="city">Value to assign to the City field of the record</param>
<param name="state">Value to assign to the State field of the record</param>
<param name="zipCode">Value to assign to the ZipCode field of the record</param>
<param name="phoneNumber">Value to assign to the PhoneNumber field of the record</param>
<param name="detailedReason">Value to assign to the DetailedReason field of the record</param>
<param name="generatorId">Value to assign to the GeneratorID field of the record</param>
<param name="templateId">Value to assign to the TemplateID field of the record</param>
<param name="translationId">Value to assign to the TranslationID field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE [dbo].[AcademicPlan_InsertRecord]	
	@studentId uniqueidentifier, 
	@rosterYearId uniqueidentifier, 
	@schoolId uniqueidentifier, 
	@gradeLevelId uniqueidentifier, 
	@reasonId uniqueidentifier, 
	@street varchar(100), 
	@city varchar(50), 
	@state char(2), 
	@zipCode varchar(10), 
	@phoneNumber varchar(40), 
	@detailedReason varchar(200), 
	@generatorId uniqueidentifier, 
	@templateId uniqueidentifier, 
	@translationId int
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
	
	INSERT INTO AcademicPlan
	(
		Id, 
		StudentId, 
		RosterYearId, 
		SchoolId, 
		GradeLevelId, 
		ReasonId, 
		Street, 
		City, 
		State, 
		ZipCode, 
		PhoneNumber, 
		DetailedReason, 
		GeneratorId, 
		TemplateId, 
		TranslationId
	)
	VALUES
	(
		@id, 
		@studentId, 
		@rosterYearId, 
		@schoolId, 
		@gradeLevelId, 
		@reasonId, 
		@street, 
		@city, 
		@state, 
		@zipCode, 
		@phoneNumber, 
		@detailedReason, 
		@generatorId, 
		@templateId, 
		@translationId
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

