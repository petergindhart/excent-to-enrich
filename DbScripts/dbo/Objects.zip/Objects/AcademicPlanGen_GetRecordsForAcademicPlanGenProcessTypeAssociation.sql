SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AcademicPlanGen_GetRecordsForAcademicPlanGenProcessTypeAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AcademicPlanGen_GetRecordsForAcademicPlanGenProcessTypeAssociation]
GO

 /*
<summary>
Gets records from the AcademicPlanGen table for the specified association 
</summary>
<param name="ids">Ids of the ProcessType(s) </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.AcademicPlanGen_GetRecordsForAcademicPlanGenProcessTypeAssociation
	@ids uniqueidentifierarray
AS
	SELECT ab.ProcessId, a.*
	FROM
		AcademicPlanGenProcessType ab INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON ab.ProcessId = Keys.Id INNER JOIN
		AcademicPlanGen a ON ab.GeneratorId = a.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

