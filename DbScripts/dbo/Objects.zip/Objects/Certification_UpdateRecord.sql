SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Certification_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Certification_UpdateRecord]
GO

 /*
<summary>
Updates a record in the Certification table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<param name="code">Value to assign to the Code field of the record</param>
<param name="typeId">Value to assign to the TypeID field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.Certification_UpdateRecord
	@id uniqueidentifier, 
	@name varchar(100), 
	@code varchar(10), 
	@typeId uniqueidentifier
AS
	UPDATE Certification
	SET
		Name = @name, 
		Code = @code, 
		TypeID = @typeId
	WHERE 
		ID = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

