SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[CertificationGroup_DeleteRecordsForCertificationSetCertificationGroupAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[CertificationGroup_DeleteRecordsForCertificationSetCertificationGroupAssociation]
GO

 /*
<summary>
Deletes records from the CertificationSetCertificationGroup table for the specified ids 
</summary>
<param name="certificationSetId">The id of the associated CertificationSet</param>
<param name="ids">The ids of the CertificationGroup's to delete</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.CertificationGroup_DeleteRecordsForCertificationSetCertificationGroupAssociation
	@certificationSetId uniqueidentifier, 
	@ids uniqueidentifierarray
AS
	DELETE CertificationSetCertificationGroup
	FROM 
		CertificationSetCertificationGroup ab INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON ab.CertificationGroupId = Keys.Id
	WHERE
		ab.CertificationSetId = @certificationSetId
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

