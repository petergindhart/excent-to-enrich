SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Comment_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Comment_UpdateRecord]
GO

 /*
<summary>
Updates a record in the Comment table with the specified values
</summary>
<param name="id">Identifies the record to update</param><param name="commentDate">Value to assign to the CommentDate field of the record</param>
<param name="text">Value to assign to the Text field of the record</param>
<param name="academicPlan">Value to assign to the AcademicPlan field of the record</param>
<param name="userID">Value to assign to the UserID field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.Comment_UpdateRecord 
	@id uniqueidentifier,
	@commentDate datetime,
	@text text,
	@academicPlan uniqueidentifier,
	@userID uniqueidentifier
AS
	UPDATE Comment
	SET
		CommentDate = @commentDate,
		Text = @text,
		AcademicPlan = @academicPlan,
		UserID = @userID
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

