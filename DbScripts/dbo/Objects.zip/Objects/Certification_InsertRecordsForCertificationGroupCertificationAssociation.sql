SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Certification_InsertRecordsForCertificationGroupCertificationAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Certification_InsertRecordsForCertificationGroupCertificationAssociation]
GO

 /*
<summary>
Insert records in the CertificationGroupCertification table for the specified ids 
</summary>
<param name="certificationGroupId">The id of the associated CertificationGroup</param>
<param name="ids">The ids of the Certification's to insert</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.Certification_InsertRecordsForCertificationGroupCertificationAssociation
	@certificationGroupId uniqueidentifier, 
	@ids uniqueidentifierarray
AS
	INSERT INTO CertificationGroupCertification ( CertificationGroupId, CertificationId)
	SELECT @certificationGroupId, Keys.* FROM
		GetUniqueidentifiers(@ids) AS Keys
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

