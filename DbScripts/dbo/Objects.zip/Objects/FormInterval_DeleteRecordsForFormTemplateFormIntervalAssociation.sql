SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FormInterval_DeleteRecordsForFormTemplateFormIntervalAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[FormInterval_DeleteRecordsForFormTemplateFormIntervalAssociation]
GO

 /*
<summary>
Deletes records from the FormTemplateFormInterval table for the specified ids 
</summary>
<param name="templateId">The id of the associated FormTemplate</param>
<param name="ids">The ids of the FormInterval's to delete</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.FormInterval_DeleteRecordsForFormTemplateFormIntervalAssociation
	@templateId uniqueidentifier, 
	@ids uniqueidentifierarray
AS
	DELETE FormTemplateFormInterval
	FROM 
		FormTemplateFormInterval ab INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON ab.IntervalId = Keys.Id
	WHERE
		ab.TemplateId = @templateId
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

