SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AcademicPlanGenSubjectRule_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AcademicPlanGenSubjectRule_UpdateRecord]
GO

 /*
<summary>
Updates a record in the AcademicPlanGenSubjectRule table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="generatorSubjectId">Value to assign to the GeneratorSubjectID field of the record</param>
<param name="criteriaId">Value to assign to the CriteriaID field of the record</param>
<param name="sequence">Value to assign to the Sequence field of the record</param>
<param name="statusId">Value to assign to the StatusID field of the record</param>
<param name="secondYear">Value to assign to the SecondYear field of the record</param>
<param name="reason">Value to assign to the Reason field of the record</param>
<param name="detailedReason">Value to assign to the DetailedReason field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.AcademicPlanGenSubjectRule_UpdateRecord
	@id uniqueidentifier, 
	@generatorSubjectId uniqueidentifier, 
	@criteriaId uniqueidentifier, 
	@sequence int, 
	@statusId uniqueidentifier, 
	@secondYear bit, 
	@reason uniqueidentifier, 
	@detailedReason varchar(200)
AS
	UPDATE AcademicPlanGenSubjectRule
	SET
		GeneratorSubjectID = @generatorSubjectId, 
		CriteriaID = @criteriaId, 
		Sequence = @sequence, 
		StatusID = @statusId, 
		SecondYear = @secondYear, 
		Reason = @reason, 
		DetailedReason = @detailedReason
	WHERE 
		ID = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

