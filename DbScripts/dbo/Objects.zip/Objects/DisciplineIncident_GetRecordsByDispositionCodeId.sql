SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DisciplineIncident_GetRecordsByDispositionCodeId]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[DisciplineIncident_GetRecordsByDispositionCodeId]
GO

 /*
<summary>
Gets records from the DisciplineIncident table
with the specified ids
</summary>
<param name="ids">Ids of the EnumValue(s) to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.DisciplineIncident_GetRecordsByDispositionCodeId
	@ids	uniqueidentifierarray
AS
	SELECT
		d.DispositionCodeId,
		d.*
	FROM
		DisciplineIncident d INNER JOIN
		GetUniqueidentifiers(@ids) Keys ON d.DispositionCodeId = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

