SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Certification_DeleteRecordsForContentAreaRequirementCertificationAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Certification_DeleteRecordsForContentAreaRequirementCertificationAssociation]
GO

 /*
<summary>
Deletes records from the ContentAreaRequirementCertification table for the specified ids 
</summary>
<param name="contentAreaRequirementId">The id of the associated ContentAreaRequirement</param>
<param name="ids">The ids of the Certification's to delete</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.Certification_DeleteRecordsForContentAreaRequirementCertificationAssociation
	@contentAreaRequirementId uniqueidentifier, 
	@ids uniqueidentifierarray
AS
	DELETE ContentAreaRequirementCertification
	FROM 
		ContentAreaRequirementCertification ab INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON ab.CertificationId = Keys.Id
	WHERE
		ab.ContentAreaRequirementId = @contentAreaRequirementId
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

