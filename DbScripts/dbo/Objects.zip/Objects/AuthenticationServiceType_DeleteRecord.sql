SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AuthenticationServiceType_DeleteRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AuthenticationServiceType_DeleteRecord]
GO

 /*
<summary>
Deletes a AuthenticationServiceType record
</summary>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.AuthenticationServiceType_DeleteRecord 
	@id char(1)
AS
	DELETE FROM AuthenticationServiceType
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

