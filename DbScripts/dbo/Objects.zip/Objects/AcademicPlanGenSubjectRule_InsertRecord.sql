SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AcademicPlanGenSubjectRule_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AcademicPlanGenSubjectRule_InsertRecord]
GO

 /*
<summary>
Inserts a new record into the AcademicPlanGenSubjectRule table with the specified values
</summary>
<param name="generatorSubjectId">Value to assign to the GeneratorSubjectID field of the record</param>
<param name="criteriaId">Value to assign to the CriteriaID field of the record</param>
<param name="sequence">Value to assign to the Sequence field of the record</param>
<param name="statusId">Value to assign to the StatusID field of the record</param>
<param name="secondYear">Value to assign to the SecondYear field of the record</param>
<param name="reason">Value to assign to the Reason field of the record</param>
<param name="detailedReason">Value to assign to the DetailedReason field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE dbo.AcademicPlanGenSubjectRule_InsertRecord
	@generatorSubjectId uniqueidentifier, 
	@criteriaId uniqueidentifier, 
	@sequence int, 
	@statusId uniqueidentifier, 
	@secondYear bit, 
	@reason uniqueidentifier, 
	@detailedReason varchar(200)
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
	
	INSERT INTO AcademicPlanGenSubjectRule
	(
		Id, 
		GeneratorSubjectId, 
		CriteriaId, 
		Sequence, 
		StatusId, 
		SecondYear, 
		Reason, 
		DetailedReason
	)
	VALUES
	(
		@id, 
		@generatorSubjectId, 
		@criteriaId, 
		@sequence, 
		@statusId, 
		@secondYear, 
		@reason, 
		@detailedReason
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

