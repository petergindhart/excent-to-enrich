SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AuditLogEntry_DeleteRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AuditLogEntry_DeleteRecord]
GO

 /*
<summary>
Deletes a AuditLogEntry record
</summary>
<param name="id">Id of the record to delete</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.AuditLogEntry_DeleteRecord 
	@id uniqueidentifier
AS
	DELETE FROM AuditLogEntry
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

