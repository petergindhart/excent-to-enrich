SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FormInstanceInterval_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[FormInstanceInterval_UpdateRecord]
GO

 /*
<summary>
Updates a record in the FormInstanceInterval table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="instanceId">Value to assign to the InstanceId field of the record</param>
<param name="intervalId">Value to assign to the IntervalId field of the record</param>
<param name="completedBy">Value to assign to the CompletedBy field of the record</param>
<param name="completedDate">Value to assign to the CompletedDate field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.FormInstanceInterval_UpdateRecord
	@id uniqueidentifier, 
	@instanceId uniqueidentifier, 
	@intervalId uniqueidentifier, 
	@completedBy uniqueidentifier, 
	@completedDate datetime
AS
	UPDATE FormInstanceInterval
	SET
		InstanceId = @instanceId, 
		IntervalId = @intervalId, 
		CompletedBy = @completedBy, 
		CompletedDate = @completedDate
	WHERE 
		Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

