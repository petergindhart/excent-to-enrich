SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AnnouncementViewing_GetRecordsForUser]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AnnouncementViewing_GetRecordsForUser]
GO

 /*
<summary>
Inserts a new record into the UserProfile table with the specified values
</summary>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.DataReader" />
*/
CREATE PROCEDURE dbo.AnnouncementViewing_GetRecordsForUser	
	@userId uniqueidentifier, 
	@announcementIds text
AS
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

