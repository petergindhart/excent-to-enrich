SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FormInputPersonValue_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[FormInputPersonValue_UpdateRecord]
GO


 /*
<summary>
Updates a record in the FormInputPersonValue table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="valueId">Value to assign to the ValueID field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE [dbo].[FormInputPersonValue_UpdateRecord]
	@id uniqueidentifier, 
	@valueId uniqueidentifier
AS
	UPDATE FormInputPersonValue
	SET
		ValueID = @valueId
	WHERE 
		Id = @id

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

