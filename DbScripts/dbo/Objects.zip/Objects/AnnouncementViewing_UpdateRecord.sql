SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AnnouncementViewing_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AnnouncementViewing_UpdateRecord]
GO

 /*
<summary>
Updates a record in the AnnouncementViewing table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="userId">Value to assign to the UserID field of the record</param>
<param name="announcementId">Value to assign to the AnnouncementID field of the record</param>
<param name="dateSeen">Value to assign to the DateSeen field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE [dbo].[AnnouncementViewing_UpdateRecord]
	@id uniqueidentifier, 
	@userId uniqueidentifier, 
	@announcementId varchar(100), 
	@dateSeen datetime,
	@dateDismissed datetime
AS
	UPDATE AnnouncementViewing
	SET
		UserID = @userId, 
		AnnouncementID = @announcementId, 
		DateSeen = @dateSeen,
		DateDismissed = @dateDismissed
	WHERE 
		ID = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

