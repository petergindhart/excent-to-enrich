SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AcademicPlanGen_GetRecordsByGeneratedBy]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AcademicPlanGen_GetRecordsByGeneratedBy]
GO

 /*
<summary>
Gets records from the AcademicPlanGen table with the specified ids
</summary>
<param name="ids">Ids of the UserProfile(s) to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.AcademicPlanGen_GetRecordsByGeneratedBy
	@ids	uniqueidentifierarray
AS
	SELECT a.GeneratedById, a.*
	FROM
		AcademicPlanGen a INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON a.GeneratedById = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

