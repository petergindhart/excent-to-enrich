SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Calendar_InsertRecordsForSchoolCalendarAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Calendar_InsertRecordsForSchoolCalendarAssociation]
GO

 /*
<summary>
Insert records in the SchoolCalendar table for the specified ids 
</summary>
<param name="schoolId">The id of the associated School</param>
<param name="ids">The ids of the Calendar's to insert</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.Calendar_InsertRecordsForSchoolCalendarAssociation
	@schoolId uniqueidentifier, 
	@ids uniqueidentifierarray
AS
	INSERT INTO SchoolCalendar ( SchoolId, CalendarId)
	SELECT @schoolId, Keys.* FROM
		GetUniqueidentifiers(@ids) AS Keys
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

