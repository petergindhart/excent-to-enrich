SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[CertificationGroup_GetRecordsForCertificationGroupCertificationAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[CertificationGroup_GetRecordsForCertificationGroupCertificationAssociation]
GO

 /*
<summary>
Gets records from the CertificationGroup table for the specified association 
</summary>
<param name="ids">Ids of the Certification(s) </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.CertificationGroup_GetRecordsForCertificationGroupCertificationAssociation
	@ids uniqueidentifierarray
AS
	SELECT ab.CertificationId, a.*
	FROM
		CertificationGroupCertification ab INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON ab.CertificationId = Keys.Id INNER JOIN
		CertificationGroup a ON ab.CertificationGroupId = a.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

