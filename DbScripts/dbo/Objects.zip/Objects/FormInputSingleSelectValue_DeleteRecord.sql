SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FormInputSingleSelectValue_DeleteRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[FormInputSingleSelectValue_DeleteRecord]
GO

 /*
<summary>
Deletes a FormInputSingleSelectValue record
</summary>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.FormInputSingleSelectValue_DeleteRecord
	@id uniqueidentifier
AS
	DELETE FROM 
		FormInputSingleSelectValue
	WHERE
		Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

