SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FormInputTextValue_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[FormInputTextValue_UpdateRecord]
GO

 /*
<summary>
Updates a record in the FormInputTextValue table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="value">Value to assign to the Value field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE [dbo].[FormInputTextValue_UpdateRecord]
	@id uniqueidentifier, 
	@value text
AS
	UPDATE FormInputTextValue
	SET
		Value = @value
	WHERE 
		Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

