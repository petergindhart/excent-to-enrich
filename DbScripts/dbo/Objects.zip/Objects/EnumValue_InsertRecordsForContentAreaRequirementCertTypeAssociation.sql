SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[EnumValue_InsertRecordsForContentAreaRequirementCertTypeAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[EnumValue_InsertRecordsForContentAreaRequirementCertTypeAssociation]
GO

 /*
<summary>
Insert records in the ContentAreaRequirementCertType table for the specified ids 
</summary>
<param name="contentAreaRequirementId">The id of the associated ContentAreaRequirement</param>
<param name="ids">The ids of the EnumValue's to insert</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.EnumValue_InsertRecordsForContentAreaRequirementCertTypeAssociation
	@contentAreaRequirementId uniqueidentifier, 
	@ids uniqueidentifierarray
AS
	INSERT INTO ContentAreaRequirementCertType ( ContentAreaRequirementId, CertificationTypeId)
	SELECT @contentAreaRequirementId, Keys.* FROM
		GetUniqueidentifiers(@ids) AS Keys
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

