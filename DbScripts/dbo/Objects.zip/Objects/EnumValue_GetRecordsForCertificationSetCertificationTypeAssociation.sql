SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[EnumValue_GetRecordsForCertificationSetCertificationTypeAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[EnumValue_GetRecordsForCertificationSetCertificationTypeAssociation]
GO

 /*
<summary>
Gets records from the EnumValue table for the specified association 
</summary>
<param name="ids">Ids of the CertificationSet(s) </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.EnumValue_GetRecordsForCertificationSetCertificationTypeAssociation
	@ids uniqueidentifierarray
AS
	SELECT ab.CertificationSetId, a.*
	FROM
		CertificationSetCertificationType ab INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON ab.CertificationSetId = Keys.Id INNER JOIN
		EnumValue a ON ab.CertificationTypeId = a.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

