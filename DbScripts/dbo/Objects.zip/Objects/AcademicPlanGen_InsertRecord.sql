SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AcademicPlanGen_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AcademicPlanGen_InsertRecord]
GO

 /*
<summary>
Inserts a new record into the AcademicPlanGen table with the specified values
</summary>
<param name="generatedById">Value to assign to the GeneratedByID field of the record</param>
<param name="generatedDate">Value to assign to the GeneratedDate field of the record</param>
<param name="batchName">Value to assign to the BatchName field of the record</param>
<param name="sendEmail">Value to assign to the SendEmail field of the record</param>
<param name="emailFromAddress">Value to assign to the EmailFromAddress field of the record</param>
<param name="emailSubject">Value to assign to the EmailSubject field of the record</param>
<param name="emailBody">Value to assign to the EmailBody field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE dbo.AcademicPlanGen_InsertRecord
	@generatedById uniqueidentifier, 
	@generatedDate datetime, 
	@batchName varchar(400), 
	@sendEmail bit, 
	@emailFromAddress varchar(200), 
	@emailSubject text, 
	@emailBody text
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
	
	INSERT INTO AcademicPlanGen
	(
		Id, 
		GeneratedById, 
		GeneratedDate, 
		BatchName, 
		SendEmail, 
		EmailFromAddress, 
		EmailSubject, 
		EmailBody
	)
	VALUES
	(
		@id, 
		@generatedById, 
		@generatedDate, 
		@batchName, 
		@sendEmail, 
		@emailFromAddress, 
		@emailSubject, 
		@emailBody
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

