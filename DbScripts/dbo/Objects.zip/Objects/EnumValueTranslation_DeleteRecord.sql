SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[EnumValueTranslation_DeleteRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[EnumValueTranslation_DeleteRecord]
GO

 /*
<summary>
Deletes a EnumValueTranslation record
</summary>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.EnumValueTranslation_DeleteRecord
	@id uniqueidentifier
AS
	DELETE FROM 
		EnumValueTranslation
	WHERE
		Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

