SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AbsenceSchoolRule_GetRecordsByReason]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AbsenceSchoolRule_GetRecordsByReason]
GO

 /*
<summary>
Gets records from the AbsenceSchoolRule table
with the specified ids
</summary>
<param name="ids">Ids of the AbsenceReason(s) to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.AbsenceSchoolRule_GetRecordsByReason
	@ids	uniqueidentifierarray
AS
	SELECT
		a.ReasonId,
		a.*
	FROM
		AbsenceSchoolRule a INNER JOIN
		GetUniqueidentifiers(@ids) Keys ON a.ReasonId = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

