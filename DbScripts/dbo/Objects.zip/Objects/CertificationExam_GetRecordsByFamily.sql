SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[CertificationExam_GetRecordsByFamily]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[CertificationExam_GetRecordsByFamily]
GO

 /*
<summary>
Gets records from the CertificationExam table with the specified ids
</summary>
<param name="ids">Ids of the CertificationExamFamily(s) to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.CertificationExam_GetRecordsByFamily
	@ids	uniqueidentifierarray
AS
	SELECT c.FamilyId, c.*
	FROM
		CertificationExam c INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON c.FamilyId = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

