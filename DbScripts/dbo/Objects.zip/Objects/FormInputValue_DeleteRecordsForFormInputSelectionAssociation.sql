SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FormInputValue_DeleteRecordsForFormInputSelectionAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[FormInputValue_DeleteRecordsForFormInputSelectionAssociation]
GO

 /*
<summary>
Deletes records from the FormInputSelection table for the specified ids 
</summary>
<param name="optionId">The id of the associated FormTemplateInputSelectFieldOption</param>
<param name="ids">The ids of the FormInputValue's to delete</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.FormInputValue_DeleteRecordsForFormInputSelectionAssociation
	@optionId uniqueidentifier, 
	@ids uniqueidentifierarray
AS
	DELETE FormInputSelection
	FROM 
		FormInputSelection ab INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON ab.ValueId = Keys.Id
	WHERE
		ab.OptionId = @optionId
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

