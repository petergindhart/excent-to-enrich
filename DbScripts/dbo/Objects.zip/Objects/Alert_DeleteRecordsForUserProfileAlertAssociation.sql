SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Alert_DeleteRecordsForUserProfileAlertAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Alert_DeleteRecordsForUserProfileAlertAssociation]
GO

 /*
<summary>
Deletes records from the UserProfileAlert table for the specified ids 
</summary>
<param name="userProfileId">The id of the associated UserProfile</param>
<param name="ids">The ids of the Alert's to delete</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.Alert_DeleteRecordsForUserProfileAlertAssociation
	@userProfileId uniqueidentifier, 
	@ids uniqueidentifierarray
AS
	DELETE UserProfileAlert
	FROM 
		UserProfileAlert ab INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON ab.AlertId = Keys.Id
	WHERE
		ab.UserProfileId = @userProfileId
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

