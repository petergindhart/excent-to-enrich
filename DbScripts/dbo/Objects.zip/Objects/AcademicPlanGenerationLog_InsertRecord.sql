SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AcademicPlanGenerationLog_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AcademicPlanGenerationLog_InsertRecord]
GO

 /*
<summary>
Inserts a new record into the AcademicPlanGenerationLog table with the specified values
</summary>
<param name="isComplete">Value to assign to the IsComplete field of the record</param>
<param name="isNotified">Value to assign to the IsNotified field of the record</param>
<param name="rosterYearID">Value to assign to the RosterYearID field of the record</param>
<param name="userProfileID">Value to assign to the UserProfileID field of the record</param>
<returns>The id of the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE dbo.AcademicPlanGenerationLog_InsertRecord 
	@isComplete bit,
	@isNotified bit,
	@rosterYearID uniqueidentifier,
	@userProfileID uniqueidentifier
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()

	INSERT INTO AcademicPlanGenerationLog
	(
		Id,
		IsComplete,
		IsNotified,
		RosterYearID,
		UserProfileID
	)
	VALUES
	(
		@id,
		@isComplete,
		@isNotified,
		@rosterYearID,
		@userProfileID
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

