SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AuditLogEntry_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AuditLogEntry_UpdateRecord]
GO

 /*
<summary>
Updates a record in the AuditLogEntry table with the specified values
</summary>
<param name="id">Identifies the record to update</param><param name="eventTime">Value to assign to the EventTime field of the record</param>
<param name="ipAddress">Value to assign to the IpAddress field of the record</param>
<param name="message">Value to assign to the Message field of the record</param>
<param name="userProfileId">Value to assign to the UserProfileID field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE [dbo].[AuditLogEntry_UpdateRecord] 
	@id uniqueidentifier,
	@eventTime datetime,
	@ipAddress varchar(50),
	@message varchar(2000),
	@userProfileId uniqueidentifier
AS
	UPDATE AuditLogEntry
	SET
		EventTime = @eventTime,
		IpAddress = @ipAddress,
		Message = @message,
		UserProfileID = @userProfileId
	WHERE ID = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

