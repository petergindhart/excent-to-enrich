SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AcademicPlanSubject_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AcademicPlanSubject_InsertRecord]
GO

 /*
<summary>
Inserts a new record into the AcademicPlanSubject table with the specified values
</summary>
<param name="academicPlanId">Value to assign to the AcademicPlanID field of the record</param>
<param name="subjectId">Value to assign to the SubjectID field of the record</param>
<param name="statusId">Value to assign to the StatusID field of the record</param>
<param name="endOfYearConsequenceId">Value to assign to the EndOfYearConsequenceID field of the record</param>
<param name="endOfSummerSchoolConsequenceId">Value to assign to the EndOfSummerSchoolConsequenceID field of the record</param>
<param name="secondYear">Value to assign to the SecondYear field of the record</param>
<param name="isSelected">Value to assign to the IsSelected field of the record</param>
<param name="supersededByIep">Value to assign to the SupersededByIep field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE dbo.AcademicPlanSubject_InsertRecord
	@academicPlanId uniqueidentifier, 
	@subjectId uniqueidentifier, 
	@statusId uniqueidentifier, 
	@endOfYearConsequenceId uniqueidentifier, 
	@endOfSummerSchoolConsequenceId uniqueidentifier, 
	@secondYear bit, 
	@isSelected bit,
	@supersededByIep bit
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
	
	INSERT INTO AcademicPlanSubject
	(
		Id, 
		AcademicPlanId, 
		SubjectId, 
		StatusId, 
		EndOfYearConsequenceId, 
		EndOfSummerSchoolConsequenceId, 
		SecondYear, 
		IsSelected,
		SupersededByIep
	)
	VALUES
	(
		@id, 
		@academicPlanId, 
		@subjectId, 
		@statusId, 
		@endOfYearConsequenceId, 
		@endOfSummerSchoolConsequenceId, 
		@secondYear, 
		@isSelected,
		@supersededByIep
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

