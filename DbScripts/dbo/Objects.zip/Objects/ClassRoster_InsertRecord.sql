SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ClassRoster_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ClassRoster_InsertRecord]
GO

 /*
<summary>
Inserts a new record into the ClassRoster table with the specified values
</summary>
<param name="schoolId">Value to assign to the SchoolID field of the record</param>
<param name="rosterYearId">Value to assign to the RosterYearID field of the record</param>
<param name="sectionName">Value to assign to the SectionName field of the record</param>
<param name="className">Value to assign to the ClassName field of the record</param>
<param name="contentAreaId">Value to assign to the ContentAreaID field of the record</param>
<param name="courseCode">Value to assign to the CourseCode field of the record</param>
<param name="minGradeId">Value to assign to the MinGradeID field of the record</param>
<param name="maxGradeId">Value to assign to the MaxGradeID field of the record</param>
<param name="gradeBitMask">Value to assign to the GradeBitMask field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE [dbo].[ClassRoster_InsertRecord]
	@schoolId uniqueidentifier, 
	@rosterYearId uniqueidentifier, 
	@sectionName varchar(30), 
	@className varchar(80), 
	@contentAreaId uniqueidentifier, 
	@courseCode varchar(20), 
	@minGradeId uniqueidentifier, 
	@maxGradeId uniqueidentifier, 
	@gradeBitMask int
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
	
	INSERT INTO ClassRoster
	(
		Id, 
		SchoolId, 
		RosterYearId, 
		SectionName, 
		ClassName, 
		ContentAreaId, 
		CourseCode, 
		MinGradeId, 
		MaxGradeId, 
		GradeBitMask
	)
	VALUES
	(
		@id, 
		@schoolId, 
		@rosterYearId, 
		@sectionName, 
		@className, 
		@contentAreaId, 
		@courseCode, 
		@minGradeId, 
		@maxGradeId, 
		@gradeBitMask
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

