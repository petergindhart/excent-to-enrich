SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FormInstance_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[FormInstance_UpdateRecord]
GO

 /*
<summary>
Updates a record in the FormInstance table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="templateId">Value to assign to the TemplateId field of the record</param>
<param name="formInstanceBatchId">Value to assign to the FormInstanceBatchId field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.FormInstance_UpdateRecord
	@id uniqueidentifier, 
	@templateId uniqueidentifier, 
	@formInstanceBatchId uniqueidentifier
AS
	UPDATE FormInstance
	SET
		TemplateId = @templateId, 
		FormInstanceBatchId = @formInstanceBatchId
	WHERE 
		Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

