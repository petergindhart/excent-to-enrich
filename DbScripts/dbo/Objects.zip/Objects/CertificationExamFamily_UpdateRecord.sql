SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[CertificationExamFamily_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[CertificationExamFamily_UpdateRecord]
GO

 /*
<summary>
Updates a record in the CertificationExamFamily table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.CertificationExamFamily_UpdateRecord
	@id uniqueidentifier, 
	@name varchar(100)
AS
	UPDATE CertificationExamFamily
	SET
		Name = @name
	WHERE 
		ID = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

