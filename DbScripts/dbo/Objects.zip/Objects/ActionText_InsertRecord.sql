SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ActionText_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ActionText_InsertRecord]
GO

 /*
<summary>
Inserts a new record into the ActionText table with the specified values
</summary>
<param name="token">Value to assign to the Token field of the record</param>
<param name="text">Value to assign to the Text field of the record</param>
<param name="gradeLevelID">Value to assign to the GradeLevelID field of the record</param>
<returns>The id of the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE dbo.ActionText_InsertRecord 
	@token varchar(100),
	@text text,
	@gradeLevelID uniqueidentifier
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()

	INSERT INTO ActionText
	(
		Id,
		Token,
		Text,
		GradeLevelID
	)
	VALUES
	(
		@id,
		@token,
		@text,
		@gradeLevelID
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

