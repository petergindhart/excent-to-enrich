SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FormInstanceBatch_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[FormInstanceBatch_InsertRecord]
GO

 /*
<summary>
Inserts a new record into the FormInstanceBatch table with the specified values
</summary>
<param name="name">Value to assign to the Name field of the record</param>
<param name="formTemplateTypeId">Value to assign to the FormTemplateTypeId field of the record</param>
<param name="currentIntervalId">Value to assign to the CurrentIntervalId field of the record</param>
<param name="intervalSeriesId">Value to assign to the IntervalSeriesId field of the record</param>
<param name="inProgress">Value to assign to the InProgress field of the record</param>
<param name="applyDuringSisImport">Value to assign to the ApplyDuringSisImport field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE dbo.FormInstanceBatch_InsertRecord	
	@name varchar(100), 
	@formTemplateTypeId uniqueidentifier, 
	@currentIntervalId uniqueidentifier, 
	@intervalSeriesId uniqueidentifier, 
	@inProgress bit, 
	@applyDuringSisImport bit
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
	
	INSERT INTO FormInstanceBatch
	(
		Id, 
		Name, 
		FormTemplateTypeId, 
		CurrentIntervalId, 
		IntervalSeriesId, 
		InProgress, 
		ApplyDuringSisImport
	)
	VALUES
	(
		@id, 
		@name, 
		@formTemplateTypeId, 
		@currentIntervalId, 
		@intervalSeriesId, 
		@inProgress, 
		@applyDuringSisImport
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

