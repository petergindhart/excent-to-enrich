SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FormInstanceInterval_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[FormInstanceInterval_InsertRecord]
GO

 /*
<summary>
Inserts a new record into the FormInstanceInterval table with the specified values
</summary>
<param name="instanceId">Value to assign to the InstanceId field of the record</param>
<param name="intervalId">Value to assign to the IntervalId field of the record</param>
<param name="completedBy">Value to assign to the CompletedBy field of the record</param>
<param name="completedDate">Value to assign to the CompletedDate field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE dbo.FormInstanceInterval_InsertRecord	
	@instanceId uniqueidentifier, 
	@intervalId uniqueidentifier, 
	@completedBy uniqueidentifier, 
	@completedDate datetime
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
	
	INSERT INTO FormInstanceInterval
	(
		Id, 
		InstanceId, 
		IntervalId, 
		CompletedBy, 
		CompletedDate
	)
	VALUES
	(
		@id, 
		@instanceId, 
		@intervalId, 
		@completedBy, 
		@completedDate
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

