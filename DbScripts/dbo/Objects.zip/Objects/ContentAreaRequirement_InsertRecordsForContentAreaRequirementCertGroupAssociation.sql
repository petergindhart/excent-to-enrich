SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ContentAreaRequirement_InsertRecordsForContentAreaRequirementCertGroupAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ContentAreaRequirement_InsertRecordsForContentAreaRequirementCertGroupAssociation]
GO

 /*
<summary>
Insert records in the ContentAreaRequirementCertGroup table for the specified ids 
</summary>
<param name="certificationGroupId">The id of the associated CertificationGroup</param>
<param name="ids">The ids of the ContentAreaRequirement's to insert</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ContentAreaRequirement_InsertRecordsForContentAreaRequirementCertGroupAssociation
	@certificationGroupId uniqueidentifier, 
	@ids uniqueidentifierarray
AS
	INSERT INTO ContentAreaRequirementCertGroup ( CertificationGroupId, ContentAreaRequirementId)
	SELECT @certificationGroupId, Keys.* FROM
		GetUniqueidentifiers(@ids) AS Keys
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

