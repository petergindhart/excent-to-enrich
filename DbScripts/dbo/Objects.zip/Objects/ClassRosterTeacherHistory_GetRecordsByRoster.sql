SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ClassRosterTeacherHistory_GetRecordsByRoster]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ClassRosterTeacherHistory_GetRecordsByRoster]
GO

 /*
<summary>
Gets records from the ClassRosterTeacherHistory table with the specified ids
</summary>
<param name="ids">Ids of the ClassRoster(s) to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ClassRosterTeacherHistory_GetRecordsByRoster
	@ids	uniqueidentifierarray
AS
	SELECT c.ClassRosterId, c.*
	FROM
		ClassRosterTeacherHistory c INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON c.ClassRosterId = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

