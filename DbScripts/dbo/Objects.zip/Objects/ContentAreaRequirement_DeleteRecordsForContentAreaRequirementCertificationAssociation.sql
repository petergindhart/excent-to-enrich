SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ContentAreaRequirement_DeleteRecordsForContentAreaRequirementCertificationAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ContentAreaRequirement_DeleteRecordsForContentAreaRequirementCertificationAssociation]
GO

 /*
<summary>
Deletes records from the ContentAreaRequirementCertification table for the specified ids 
</summary>
<param name="certificationId">The id of the associated Certification</param>
<param name="ids">The ids of the ContentAreaRequirement's to delete</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ContentAreaRequirement_DeleteRecordsForContentAreaRequirementCertificationAssociation
	@certificationId uniqueidentifier, 
	@ids uniqueidentifierarray
AS
	DELETE ContentAreaRequirementCertification
	FROM 
		ContentAreaRequirementCertification ab INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON ab.ContentAreaRequirementId = Keys.Id
	WHERE
		ab.CertificationId = @certificationId
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

