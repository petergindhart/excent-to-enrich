SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[EnumValue_DeleteRecordsForCertificationSetCertificationTypeAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[EnumValue_DeleteRecordsForCertificationSetCertificationTypeAssociation]
GO

 /*
<summary>
Deletes records from the CertificationSetCertificationType table for the specified ids 
</summary>
<param name="certificationSetId">The id of the associated CertificationSet</param>
<param name="ids">The ids of the EnumValue's to delete</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.EnumValue_DeleteRecordsForCertificationSetCertificationTypeAssociation
	@certificationSetId uniqueidentifier, 
	@ids uniqueidentifierarray
AS
	DELETE CertificationSetCertificationType
	FROM 
		CertificationSetCertificationType ab INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON ab.CertificationTypeId = Keys.Id
	WHERE
		ab.CertificationSetId = @certificationSetId
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

