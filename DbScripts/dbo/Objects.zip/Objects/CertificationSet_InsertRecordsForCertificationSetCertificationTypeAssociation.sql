SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[CertificationSet_InsertRecordsForCertificationSetCertificationTypeAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[CertificationSet_InsertRecordsForCertificationSetCertificationTypeAssociation]
GO

 /*
<summary>
Insert records in the CertificationSetCertificationType table for the specified ids 
</summary>
<param name="certificationTypeId">The id of the associated EnumValue</param>
<param name="ids">The ids of the CertificationSet's to insert</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.CertificationSet_InsertRecordsForCertificationSetCertificationTypeAssociation
	@certificationTypeId uniqueidentifier, 
	@ids uniqueidentifierarray
AS
	INSERT INTO CertificationSetCertificationType ( CertificationTypeId, CertificationSetId)
	SELECT @certificationTypeId, Keys.* FROM
		GetUniqueidentifiers(@ids) AS Keys
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

