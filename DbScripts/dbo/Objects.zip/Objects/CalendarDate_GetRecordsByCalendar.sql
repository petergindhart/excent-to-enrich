SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[CalendarDate_GetRecordsByCalendar]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[CalendarDate_GetRecordsByCalendar]
GO

 /*
<summary>
Gets records from the CalendarDate table
with the specified ids
</summary>
<param name="ids">Ids of the Calendar(s) to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.CalendarDate_GetRecordsByCalendar
	@ids	uniqueidentifierarray
AS
	SELECT
		c.CalendarId,
		c.*
	FROM
		CalendarDate c INNER JOIN
		GetUniqueidentifiers(@ids) Keys ON c.CalendarId = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

