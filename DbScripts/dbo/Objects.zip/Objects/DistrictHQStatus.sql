SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DistrictHQStatus]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[DistrictHQStatus]
GO

 /*
<summary>
Gets records from the Feature table with the specified id's
</summary>
<param name="ids">Ids of the records to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/


CREATE PROCEDURE dbo.DistrictHQStatus
(@StartDate datetime,
@EndDate datetime)
as 

Begin

set nocount on

	select d.Date, s.Status, [Count] = isnull(totals.Count, 0)
	from 
	(
		select @startDate Date union all
		select @endDate
	) d cross join
	(
		select 'HQ Met' 'Status' union all
		select 'HQ Not Met' union all
		select 'N/A' union all
		select 'Unknown'
	) s left join
	(
		select
			[Date] = @startDate,
			Status,
			[Count] = count(*)
		from dbo.GetHqStatusDetail(@startdate)
		group by Status
		union all
		select
			[Date] = @enddate,
			Status,
			[Count] = count(*)
		from dbo.GetHqStatusDetail(@enddate)
		group by Status
	) totals on totals.Status = s.Status and totals.Date = d.Date
--
--select
--	Status,
--	StartDate	= sum(case when [Date]=@startDate then [Count] else 0 end),
--	EndDate		= sum(case when [Date]=@endDate then [Count] else 0 end)
--from
--(
--	select
--		[Date] = @startDate,
--		Status,
--		[Count] = count(*)
--	from dbo.GetHqStatusDetail(@startdate)
--	group by Status
--	union all
--	select
--		[Date] = @enddate,
--		Status,
--		[Count] = count(*)
--	from dbo.GetHqStatusDetail(@enddate)
--	group by Status
--	union all
--	select null, 'HQ Met', 0
--	union all
--	select null, 'HQ Not Met', 0
--	union all
--	select null, 'N/A', 0
--) totals
--group by Status


--Select *
--into #Starting
--From dbo.GetHqStatusDetail(@StartDate)
--
--Select *
--into #Ending
--From GetHqStatusDetail(@EndDate)
--
--
--set nocount off
--Select 	'HQMet' 'Status',
--	(Select count(Status) From #Starting Where status = 1) StartDate,
--	(Select count(Status) From #Ending Where status = 1) EndDate
--union
--Select 	'HQNotMet',
--	(Select count(Status) From #Starting Where status = 0),
--	(Select count(Status) From #Ending Where status = 0)
--union
--Select 	'N/A',
--	(Select count(Status) From #Starting Where status = 2),
--	(Select count(Status) From #Ending Where status = 2)


end
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

