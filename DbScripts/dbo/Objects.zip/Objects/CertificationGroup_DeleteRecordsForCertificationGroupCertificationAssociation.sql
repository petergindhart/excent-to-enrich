SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[CertificationGroup_DeleteRecordsForCertificationGroupCertificationAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[CertificationGroup_DeleteRecordsForCertificationGroupCertificationAssociation]
GO

 /*
<summary>
Deletes records from the CertificationGroupCertification table for the specified ids 
</summary>
<param name="certificationId">The id of the associated Certification</param>
<param name="ids">The ids of the CertificationGroup's to delete</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.CertificationGroup_DeleteRecordsForCertificationGroupCertificationAssociation
	@certificationId uniqueidentifier, 
	@ids uniqueidentifierarray
AS
	DELETE CertificationGroupCertification
	FROM 
		CertificationGroupCertification ab INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON ab.CertificationGroupId = Keys.Id
	WHERE
		ab.CertificationId = @certificationId
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

