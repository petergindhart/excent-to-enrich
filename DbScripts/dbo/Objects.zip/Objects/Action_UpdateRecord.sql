SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Action_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Action_UpdateRecord]
GO

 /*
<summary>
Updates a record in the Action table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="actionCategoryId">Value to assign to the ActionCategoryID field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<param name="abbreviation">Value to assign to the Abbreviation field of the record</param>
<param name="text">Value to assign to the Text field of the record</param>
<param name="isDefault">Value to assign to the IsDefault field of the record</param>
<param name="isCustom">Value to assign to the IsCustom field of the record</param>
<param name="templateId">Value to assign to the TemplateID field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.Action_UpdateRecord
	@id uniqueidentifier, 
	@actionCategoryId uniqueidentifier, 
	@name varchar(1000), 
	@abbreviation varchar(8), 
	@text text, 
	@isDefault bit, 
	@isCustom bit, 
	@templateId uniqueidentifier
AS
	UPDATE Action
	SET
		ActionCategoryID = @actionCategoryId, 
		Name = @name, 
		Abbreviation = @abbreviation, 
		Text = @text, 
		IsDefault = @isDefault, 
		IsCustom = @isCustom, 
		TemplateID = @templateId
	WHERE 
		ID = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

