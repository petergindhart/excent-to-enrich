SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[CertificationGroup_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[CertificationGroup_InsertRecord]
GO

 /*
<summary>
Inserts a new record into the CertificationGroup table with the specified values
</summary>
<param name="description">Value to assign to the Description field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE dbo.CertificationGroup_InsertRecord
	@description varchar(50)
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
	
	INSERT INTO CertificationGroup
	(
		Id, 
		Description
	)
	VALUES
	(
		@id, 
		@description
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

