SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[EnumValue_DeleteRecordsForContentAreaRequirementCertTypeAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[EnumValue_DeleteRecordsForContentAreaRequirementCertTypeAssociation]
GO

 /*
<summary>
Deletes records from the ContentAreaRequirementCertType table for the specified ids 
</summary>
<param name="contentAreaRequirementId">The id of the associated ContentAreaRequirement</param>
<param name="ids">The ids of the EnumValue's to delete</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.EnumValue_DeleteRecordsForContentAreaRequirementCertTypeAssociation
	@contentAreaRequirementId uniqueidentifier, 
	@ids uniqueidentifierarray
AS
	DELETE ContentAreaRequirementCertType
	FROM 
		ContentAreaRequirementCertType ab INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON ab.CertificationTypeId = Keys.Id
	WHERE
		ab.ContentAreaRequirementId = @contentAreaRequirementId
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

