SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AcademicPlanAction_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AcademicPlanAction_UpdateRecord]
GO

 /*
<summary>
Updates a record in the AcademicPlanAction table with the specified values
</summary>
<param name="id">Identifies the record to update</param><param name="isSelected">Value to assign to the IsSelected field of the record</param>
<param name="academicPlanID">Value to assign to the AcademicPlanID field of the record</param>
<param name="actionID">Value to assign to the ActionID field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.AcademicPlanAction_UpdateRecord 
	@id uniqueidentifier,
	@isSelected bit,
	@academicPlanID uniqueidentifier,
	@actionID uniqueidentifier
AS
	UPDATE AcademicPlanAction
	SET
		IsSelected = @isSelected,
		AcademicPlanID = @academicPlanID,
		ActionID = @actionID
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

