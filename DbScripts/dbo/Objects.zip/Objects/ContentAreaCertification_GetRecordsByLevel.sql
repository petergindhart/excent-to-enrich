SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ContentAreaCertification_GetRecordsByLevel]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ContentAreaCertification_GetRecordsByLevel]
GO

 /*
<summary>
Gets records from the ContentAreaCertification table with the specified ids
</summary>
<param name="ids">Ids of the EnumValue(s) to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ContentAreaCertification_GetRecordsByLevel
	@ids	uniqueidentifierarray
AS
	SELECT c.LevelId, c.*
	FROM
		ContentAreaCertification c INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON c.LevelId = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

