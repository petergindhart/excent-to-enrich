SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AnnouncementViewing_GetUserHistory]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AnnouncementViewing_GetUserHistory]
GO

 /*
<summary>
Inserts a new record into the UserProfile table with the specified values
</summary>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.AnnouncementViewing_GetUserHistory
	@userId uniqueidentifier, 
	@announcementIds text
AS
	select *
	from
		AnnouncementViewing av
	where
		UserId = @userId and
		AnnouncementId in (select Item from dbo.Split(@announcementIds, '|'))
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

