SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[CertificationSet_DeleteRecordsForCertificationSetCertificationTypeAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[CertificationSet_DeleteRecordsForCertificationSetCertificationTypeAssociation]
GO

 /*
<summary>
Deletes records from the CertificationSetCertificationType table for the specified ids 
</summary>
<param name="certificationTypeId">The id of the associated EnumValue</param>
<param name="ids">The ids of the CertificationSet's to delete</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.CertificationSet_DeleteRecordsForCertificationSetCertificationTypeAssociation
	@certificationTypeId uniqueidentifier, 
	@ids uniqueidentifierarray
AS
	DELETE CertificationSetCertificationType
	FROM 
		CertificationSetCertificationType ab INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON ab.CertificationSetId = Keys.Id
	WHERE
		ab.CertificationTypeId = @certificationTypeId
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

