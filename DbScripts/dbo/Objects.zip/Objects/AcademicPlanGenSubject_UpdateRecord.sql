SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AcademicPlanGenSubject_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AcademicPlanGenSubject_UpdateRecord]
GO

 /*
<summary>
Updates a record in the AcademicPlanGenSubject table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="generatorId">Value to assign to the GeneratorID field of the record</param>
<param name="subjectId">Value to assign to the SubjectID field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.AcademicPlanGenSubject_UpdateRecord
	@id uniqueidentifier, 
	@generatorId uniqueidentifier, 
	@subjectId uniqueidentifier
AS
	UPDATE AcademicPlanGenSubject
	SET
		GeneratorID = @generatorId, 
		SubjectID = @subjectId
	WHERE 
		ID = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

