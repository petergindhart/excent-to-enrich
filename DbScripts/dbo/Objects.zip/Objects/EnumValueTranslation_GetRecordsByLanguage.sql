SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[EnumValueTranslation_GetRecordsByLanguage]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[EnumValueTranslation_GetRecordsByLanguage]
GO

 /*
<summary>
Gets records from the EnumValueTranslation table with the specified ids
</summary>
<param name="ids">Ids of the ResourceLanguage(s) to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.EnumValueTranslation_GetRecordsByLanguage
	@ids	intarray
AS
	SELECT e.LanguageId, e.*
	FROM
		EnumValueTranslation e INNER JOIN
		GetInts(@ids) AS Keys ON e.LanguageId = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

