SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[EnumType_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[EnumType_UpdateRecord]
GO

 /*
<summary>
Updates a record in the EnumType table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="type">Value to assign to the Type field of the record</param>
<param name="isCustom">Value to assign to the IsCustom field of the record</param>
<param name="isEditable">Value to assign to the IsEditable field of the record</param>
<param name="displayName">Value to assign to the DisplayName field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.EnumType_UpdateRecord
	@id uniqueidentifier, 
	@type varchar(50), 
	@isCustom bit, 
	@isEditable bit, 
	@displayName varchar(100)
AS
	UPDATE EnumType
	SET
		Type = @type, 
		IsCustom = @isCustom, 
		IsEditable = @isEditable, 
		DisplayName = @displayName
	WHERE 
		ID = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

