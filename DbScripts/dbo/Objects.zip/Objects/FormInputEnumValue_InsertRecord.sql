SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FormInputEnumValue_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[FormInputEnumValue_InsertRecord]
GO

 /*
<summary>
Inserts a new record into the FormInputEnumValue table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="enumValueId">Value to assign to the EnumValueId field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE [dbo].[FormInputEnumValue_InsertRecord]	
	@id uniqueidentifier, 
	@enumValueId uniqueidentifier
AS
	
	INSERT INTO FormInputEnumValue
	(
		Id, 
		EnumValueId
	)
	VALUES
	(
		@id, 
		@enumValueId
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

