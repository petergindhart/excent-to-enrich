SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[CommentTranslation_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[CommentTranslation_InsertRecord]
GO

 /*
<summary>
Inserts a new record into the CommentTranslation table with the specified values
</summary>
<param name="originalId">Value to assign to the OriginalID field of the record</param>
<param name="languageId">Value to assign to the LanguageID field of the record</param>
<param name="text">Value to assign to the Text field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE dbo.CommentTranslation_InsertRecord
	@originalId uniqueidentifier, 
	@languageId int, 
	@text ntext
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
	
	INSERT INTO CommentTranslation
	(
		Id, 
		OriginalId, 
		LanguageId, 
		Text
	)
	VALUES
	(
		@id, 
		@originalId, 
		@languageId, 
		@text
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

