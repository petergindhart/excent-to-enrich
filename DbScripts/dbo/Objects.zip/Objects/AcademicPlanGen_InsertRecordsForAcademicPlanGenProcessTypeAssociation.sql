SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AcademicPlanGen_InsertRecordsForAcademicPlanGenProcessTypeAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AcademicPlanGen_InsertRecordsForAcademicPlanGenProcessTypeAssociation]
GO

 /*
<summary>
Insert records in the AcademicPlanGenProcessType table for the specified ids 
</summary>
<param name="processId">The id of the associated ProcessType</param>
<param name="ids">The ids of the AcademicPlanGen's to insert</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.AcademicPlanGen_InsertRecordsForAcademicPlanGenProcessTypeAssociation
	@processId uniqueidentifier, 
	@ids uniqueidentifierarray
AS
	INSERT INTO AcademicPlanGenProcessType ( ProcessId, GeneratorId)
	SELECT @processId, Keys.* FROM
		GetUniqueidentifiers(@ids) AS Keys
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

