SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ContentAreaRequirement_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ContentAreaRequirement_InsertRecord]
GO

 /*
<summary>
Inserts a new record into the ContentAreaRequirement table with the specified values
</summary>
<param name="contentAreaId">Value to assign to the ContentAreaID field of the record</param>
<param name="certificationSetId">Value to assign to the CertificationSetID field of the record</param>
<param name="startDate">Value to assign to the StartDate field of the record</param>
<param name="endDate">Value to assign to the EndDate field of the record</param>
<param name="minGradeId">Value to assign to the MinGradeID field of the record</param>
<param name="maxGradeId">Value to assign to the MaxGradeID field of the record</param>
<param name="gradeBitMask">Value to assign to the GradeBitMask field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE dbo.ContentAreaRequirement_InsertRecord
	@contentAreaId uniqueidentifier, 
	@certificationSetId uniqueidentifier, 
	@startDate datetime, 
	@endDate datetime, 
	@minGradeId uniqueidentifier, 
	@maxGradeId uniqueidentifier, 
	@gradeBitMask int
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
	
	INSERT INTO ContentAreaRequirement
	(
		Id, 
		ContentAreaId, 
		CertificationSetId, 
		StartDate, 
		EndDate, 
		MinGradeId, 
		MaxGradeId, 
		GradeBitMask
	)
	VALUES
	(
		@id, 
		@contentAreaId, 
		@certificationSetId, 
		@startDate, 
		@endDate, 
		@minGradeId, 
		@maxGradeId, 
		@gradeBitMask
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

