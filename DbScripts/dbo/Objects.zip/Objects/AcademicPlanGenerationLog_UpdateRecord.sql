SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AcademicPlanGenerationLog_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AcademicPlanGenerationLog_UpdateRecord]
GO

 /*
<summary>
Updates a record in the AcademicPlanGenerationLog table with the specified values
</summary>
<param name="id">Identifies the record to update</param><param name="isComplete">Value to assign to the IsComplete field of the record</param>
<param name="isNotified">Value to assign to the IsNotified field of the record</param>
<param name="rosterYearID">Value to assign to the RosterYearID field of the record</param>
<param name="userProfileID">Value to assign to the UserProfileID field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.AcademicPlanGenerationLog_UpdateRecord 
	@id uniqueidentifier,
	@isComplete bit,
	@isNotified bit,
	@rosterYearID uniqueidentifier,
	@userProfileID uniqueidentifier
AS
	UPDATE AcademicPlanGenerationLog
	SET
		IsComplete = @isComplete,
		IsNotified = @isNotified,
		RosterYearID = @rosterYearID,
		UserProfileID = @userProfileID
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

