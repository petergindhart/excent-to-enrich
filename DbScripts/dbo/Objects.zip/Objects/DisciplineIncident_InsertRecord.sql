SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DisciplineIncident_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[DisciplineIncident_InsertRecord]
GO

 /*
<summary>
Inserts a new record into the DisciplineIncident table with the specified values
</summary>
<param name="studentId">Value to assign to the StudentID field of the record</param>
<param name="rosterYearId">Value to assign to the RosterYearID field of the record</param>
<param name="date">Value to assign to the Date field of the record</param>
<param name="dispositionCodeId">Value to assign to the DispositionCodeID field of the record</param>
<param name="comments">Value to assign to the Comments field of the record</param>
<param name="incidentLocationId">Value to assign to the IncidentLocationID field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE dbo.DisciplineIncident_InsertRecord	
	@studentId uniqueidentifier, 
	@rosterYearId uniqueidentifier, 
	@date datetime, 
	@dispositionCodeId uniqueidentifier, 
	@comments varchar(8000), 
	@incidentLocationId uniqueidentifier
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
	
	INSERT INTO DisciplineIncident
	(
		Id, 
		StudentId, 
		RosterYearId, 
		Date, 
		DispositionCodeId, 
		Comments, 
		IncidentLocationId
	)
	VALUES
	(
		@id, 
		@studentId, 
		@rosterYearId, 
		@date, 
		@dispositionCodeId, 
		@comments, 
		@incidentLocationId
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

