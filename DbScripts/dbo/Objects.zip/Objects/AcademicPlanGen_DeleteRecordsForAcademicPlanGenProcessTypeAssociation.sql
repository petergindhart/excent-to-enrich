SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AcademicPlanGen_DeleteRecordsForAcademicPlanGenProcessTypeAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AcademicPlanGen_DeleteRecordsForAcademicPlanGenProcessTypeAssociation]
GO

 /*
<summary>
Deletes records from the AcademicPlanGenProcessType table for the specified ids 
</summary>
<param name="processId">The id of the associated ProcessType</param>
<param name="ids">The ids of the AcademicPlanGen's to delete</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.AcademicPlanGen_DeleteRecordsForAcademicPlanGenProcessTypeAssociation
	@processId uniqueidentifier, 
	@ids uniqueidentifierarray
AS
	DELETE AcademicPlanGenProcessType
	FROM 
		AcademicPlanGenProcessType ab INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON ab.GeneratorId = Keys.Id
	WHERE
		ab.ProcessId = @processId
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

