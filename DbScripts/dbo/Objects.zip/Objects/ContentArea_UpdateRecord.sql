SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ContentArea_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ContentArea_UpdateRecord]
GO

 /*
<summary>
Updates a record in the ContentArea table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<param name="subjectId">Value to assign to the SubjectID field of the record</param>
<param name="maxCertificationLevelId">Value to assign to the MaxCertificationLevelID field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ContentArea_UpdateRecord
	@id uniqueidentifier, 
	@name varchar(100), 
	@subjectId uniqueidentifier, 
	@maxCertificationLevelId uniqueidentifier
AS
	UPDATE ContentArea
	SET
		Name = @name, 
		SubjectID = @subjectId, 
		MaxCertificationLevelID = @maxCertificationLevelId
	WHERE 
		ID = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

