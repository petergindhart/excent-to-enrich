SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ExtendedPropertyDefinition_GetRecordsByViewTask]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ExtendedPropertyDefinition_GetRecordsByViewTask]
GO

 /*
<summary>
Gets records from the ExtendedPropertyDefinition table
with the specified ids
</summary>
<param name="ids">Ids of the SecurityTask(s) to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE [dbo].[ExtendedPropertyDefinition_GetRecordsByViewTask]
	@ids	uniqueidentifierarray
AS
	SELECT
		e.ViewTaskId,
		e.*
	FROM
		ExtendedPropertyDefinition e INNER JOIN
		GetUniqueidentifiers(@ids) Keys ON e.ViewTaskId = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

