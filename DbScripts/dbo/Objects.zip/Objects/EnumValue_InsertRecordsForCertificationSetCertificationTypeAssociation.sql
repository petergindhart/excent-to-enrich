SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[EnumValue_InsertRecordsForCertificationSetCertificationTypeAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[EnumValue_InsertRecordsForCertificationSetCertificationTypeAssociation]
GO

 /*
<summary>
Insert records in the CertificationSetCertificationType table for the specified ids 
</summary>
<param name="certificationSetId">The id of the associated CertificationSet</param>
<param name="ids">The ids of the EnumValue's to insert</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.EnumValue_InsertRecordsForCertificationSetCertificationTypeAssociation
	@certificationSetId uniqueidentifier, 
	@ids uniqueidentifierarray
AS
	INSERT INTO CertificationSetCertificationType ( CertificationSetId, CertificationTypeId)
	SELECT @certificationSetId, Keys.* FROM
		GetUniqueidentifiers(@ids) AS Keys
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

