SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Calendar_GetRecordsForSchoolCalendarAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Calendar_GetRecordsForSchoolCalendarAssociation]
GO

 /*
<summary>
Gets records from the Calendar table for the specified association 
</summary>
<param name="ids">Ids of the School(s) </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.Calendar_GetRecordsForSchoolCalendarAssociation
	@ids uniqueidentifierarray
AS
	SELECT ab.SchoolId, a.*
	FROM
		SchoolCalendar ab INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON ab.SchoolId = Keys.Id INNER JOIN
		Calendar a ON ab.CalendarId = a.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

