SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Certification_InsertRecordsForCertificationSetCertificationAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Certification_InsertRecordsForCertificationSetCertificationAssociation]
GO

 /*
<summary>
Insert records in the CertificationSetCertification table for the specified ids 
</summary>
<param name="certificationSetId">The id of the associated CertificationSet</param>
<param name="ids">The ids of the Certification's to insert</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.Certification_InsertRecordsForCertificationSetCertificationAssociation
	@certificationSetId uniqueidentifier, 
	@ids uniqueidentifierarray
AS
	INSERT INTO CertificationSetCertification ( CertificationSetId, CertificationId)
	SELECT @certificationSetId, Keys.* FROM
		GetUniqueidentifiers(@ids) AS Keys
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

