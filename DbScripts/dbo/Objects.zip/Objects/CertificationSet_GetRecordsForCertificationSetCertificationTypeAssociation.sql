SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[CertificationSet_GetRecordsForCertificationSetCertificationTypeAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[CertificationSet_GetRecordsForCertificationSetCertificationTypeAssociation]
GO

 /*
<summary>
Gets records from the CertificationSet table for the specified association 
</summary>
<param name="ids">Ids of the EnumValue(s) </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.CertificationSet_GetRecordsForCertificationSetCertificationTypeAssociation
	@ids uniqueidentifierarray
AS
	SELECT ab.CertificationTypeId, a.*
	FROM
		CertificationSetCertificationType ab INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON ab.CertificationTypeId = Keys.Id INNER JOIN
		CertificationSet a ON ab.CertificationSetId = a.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

