SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[CommentTranslation_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[CommentTranslation_UpdateRecord]
GO

 /*
<summary>
Updates a record in the CommentTranslation table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="originalId">Value to assign to the OriginalID field of the record</param>
<param name="languageId">Value to assign to the LanguageID field of the record</param>
<param name="text">Value to assign to the Text field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.CommentTranslation_UpdateRecord
	@id uniqueidentifier, 
	@originalId uniqueidentifier, 
	@languageId int, 
	@text ntext
AS
	UPDATE CommentTranslation
	SET
		OriginalID = @originalId, 
		LanguageID = @languageId, 
		Text = @text
	WHERE 
		ID = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

