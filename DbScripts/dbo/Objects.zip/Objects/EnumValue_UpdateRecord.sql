SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[EnumValue_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[EnumValue_UpdateRecord]
GO

 /*
<summary>
Updates a record in the EnumValue table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="type">Value to assign to the Type field of the record</param>
<param name="displayValue">Value to assign to the DisplayValue field of the record</param>
<param name="code">Value to assign to the Code field of the record</param>
<param name="isActive">Value to assign to the IsActive field of the record</param>
<param name="sequence">Value to assign to the Sequence field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.EnumValue_UpdateRecord
	@id uniqueidentifier, 
	@type uniqueidentifier, 
	@displayValue varchar(512), 
	@code varchar(8), 
	@isActive bit, 
	@sequence int
AS
	UPDATE EnumValue
	SET
		Type = @type, 
		DisplayValue = @displayValue, 
		Code = @code, 
		IsActive = @isActive, 
		Sequence = @sequence
	WHERE 
		ID = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

