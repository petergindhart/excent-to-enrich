SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FormInstanceBatchRule_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[FormInstanceBatchRule_InsertRecord]
GO

 /*
<summary>
Inserts a new record into the FormInstanceBatchRule table with the specified values
</summary>
<param name="formInstanceBatchId">Value to assign to the FormInstanceBatchId field of the record</param>
<param name="criteriaId">Value to assign to the CriteriaId field of the record</param>
<param name="templateId">Value to assign to the TemplateId field of the record</param>
<param name="sequence">Value to assign to the Sequence field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE dbo.FormInstanceBatchRule_InsertRecord	
	@formInstanceBatchId uniqueidentifier, 
	@criteriaId uniqueidentifier, 
	@templateId uniqueidentifier, 
	@sequence int
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
	
	INSERT INTO FormInstanceBatchRule
	(
		Id, 
		FormInstanceBatchId, 
		CriteriaId, 
		TemplateId, 
		Sequence
	)
	VALUES
	(
		@id, 
		@formInstanceBatchId, 
		@criteriaId, 
		@templateId, 
		@sequence
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

