SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ClassRosterContentAreaRule_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ClassRosterContentAreaRule_UpdateRecord]
GO

 /*
<summary>
Updates a record in the ClassRosterContentAreaRule table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="sectionNamePattern">Value to assign to the SectionNamePattern field of the record</param>
<param name="rosterYearId">Value to assign to the RosterYearID field of the record</param>
<param name="contentAreaId">Value to assign to the ContentAreaID field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE  PROCEDURE dbo.ClassRosterContentAreaRule_UpdateRecord
	@id uniqueidentifier, 
	@courseCodePattern varchar(50), 
	@rosterYearId uniqueidentifier, 
	@contentAreaId uniqueidentifier
AS
	UPDATE ClassRosterContentAreaRule
	SET
		CourseCodePattern = @courseCodePattern, 
		RosterYearID = @rosterYearId, 
		ContentAreaID = @contentAreaId
	WHERE 
		ID = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

