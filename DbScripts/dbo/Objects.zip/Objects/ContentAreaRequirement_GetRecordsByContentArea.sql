SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ContentAreaRequirement_GetRecordsByContentArea]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ContentAreaRequirement_GetRecordsByContentArea]
GO

 /*
<summary>
Gets records from the ContentAreaRequirement table with the specified ids
</summary>
<param name="ids">Ids of the ContentArea(s) to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ContentAreaRequirement_GetRecordsByContentArea
	@ids	uniqueidentifierarray
AS
	SELECT c.ContentAreaId, c.*
	FROM
		ContentAreaRequirement c INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON c.ContentAreaId = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

