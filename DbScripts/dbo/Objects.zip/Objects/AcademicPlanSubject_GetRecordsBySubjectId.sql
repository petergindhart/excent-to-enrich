SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AcademicPlanSubject_GetRecordsBySubjectId]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AcademicPlanSubject_GetRecordsBySubjectId]
GO

 /*
<summary>
Gets records from the AcademicPlanSubject table with the specified ids
</summary>
<param name="ids">Ids of the Subject(s) to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.AcademicPlanSubject_GetRecordsBySubjectId
	@ids	uniqueidentifierarray
AS
	SELECT a.SubjectId, a.*
	FROM
		AcademicPlanSubject a INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON a.SubjectId = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

