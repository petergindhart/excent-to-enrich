SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ClassRoster_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ClassRoster_UpdateRecord]
GO

 /*
<summary>
Updates a record in the ClassRoster table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="schoolId">Value to assign to the SchoolID field of the record</param>
<param name="rosterYearId">Value to assign to the RosterYearID field of the record</param>
<param name="sectionName">Value to assign to the SectionName field of the record</param>
<param name="className">Value to assign to the ClassName field of the record</param>
<param name="contentAreaId">Value to assign to the ContentAreaID field of the record</param>
<param name="courseCode">Value to assign to the CourseCode field of the record</param>
<param name="minGradeId">Value to assign to the MinGradeID field of the record</param>
<param name="maxGradeId">Value to assign to the MaxGradeID field of the record</param>
<param name="gradeBitMask">Value to assign to the GradeBitMask field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE [dbo].[ClassRoster_UpdateRecord]
	@id uniqueidentifier, 
	@schoolId uniqueidentifier, 
	@rosterYearId uniqueidentifier, 
	@sectionName varchar(30), 
	@className varchar(80), 
	@contentAreaId uniqueidentifier, 
	@courseCode varchar(20), 
	@minGradeId uniqueidentifier, 
	@maxGradeId uniqueidentifier, 
	@gradeBitMask int
AS
	UPDATE ClassRoster
	SET
		SchoolID = @schoolId, 
		RosterYearID = @rosterYearId, 
		SectionName = @sectionName, 
		ClassName = @className, 
		ContentAreaID = @contentAreaId, 
		CourseCode = @courseCode, 
		MinGradeID = @minGradeId, 
		MaxGradeID = @maxGradeId, 
		GradeBitMask = @gradeBitMask
	WHERE 
		ID = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

