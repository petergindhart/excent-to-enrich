SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ClassRosterTeacherHistory_GetRecordsByDate]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ClassRosterTeacherHistory_GetRecordsByDate]
GO

 /*
<summary>
Gets records from the ClassRosterTeacherHistory table within a specific date range
</summary>
<param name="startdate">start date of the interval</param>
<param name="enddate">end date of the interval</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ClassRosterTeacherHistory_GetRecordsByDate
	@teacherid 	uniqueidentifier,
	@startdate	datetime,
	@enddate	datetime
AS
	SELECT c.*
	FROM
		ClassRosterTeacherHistory c  WHERE
		( dbo.DateRangesOverlap(@startdate, @enddate, c.startDate, c.EndDate, getdate() )  = 1) AND
		(  c.TeacherId = @teacherid )
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

