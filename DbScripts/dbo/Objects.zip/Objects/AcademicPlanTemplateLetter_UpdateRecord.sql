SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AcademicPlanTemplateLetter_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AcademicPlanTemplateLetter_UpdateRecord]
GO

 /*
<summary>
Updates a record in the AcademicPlanTemplateLetter table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="templateId">Value to assign to the TemplateID field of the record</param>
<param name="htmlText">Value to assign to the HtmlText field of the record</param>
<param name="title">Value to assign to the Title field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.AcademicPlanTemplateLetter_UpdateRecord
	@id uniqueidentifier, 
	@templateId uniqueidentifier, 
	@htmlText text, 
	@title varchar(75)
AS
	UPDATE AcademicPlanTemplateLetter
	SET
		TemplateID = @templateId, 
		HtmlText = @htmlText, 
		Title = @title
	WHERE 
		ID = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

