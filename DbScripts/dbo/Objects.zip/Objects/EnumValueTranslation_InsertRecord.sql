SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[EnumValueTranslation_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[EnumValueTranslation_InsertRecord]
GO

 /*
<summary>
Inserts a new record into the EnumValueTranslation table with the specified values
</summary>
<param name="originalId">Value to assign to the OriginalID field of the record</param>
<param name="languageId">Value to assign to the LanguageID field of the record</param>
<param name="displayValue">Value to assign to the DisplayValue field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE dbo.EnumValueTranslation_InsertRecord
	@originalId uniqueidentifier, 
	@languageId int, 
	@displayValue nvarchar(2048)
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
	
	INSERT INTO EnumValueTranslation
	(
		Id, 
		OriginalId, 
		LanguageId, 
		DisplayValue
	)
	VALUES
	(
		@id, 
		@originalId, 
		@languageId, 
		@displayValue
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

