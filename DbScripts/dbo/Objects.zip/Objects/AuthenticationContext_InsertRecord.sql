SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AuthenticationContext_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AuthenticationContext_InsertRecord]
GO

 /*
<summary>
Inserts a new record into the AuthenticationContext table with the specified values
</summary>
<param name="name">Value to assign to the Name field of the record</param>
<param name="isEnabled">Value to assign to the IsEnabled field of the record</param>
<param name="serviceId">Value to assign to the ServiceID field of the record</param>
<param name="schoolId">Value to assign to the SchoolID field of the record</param>
<param name="defaultTeacherRoleId">Value to assign to the DefaultTeacherRoleID field of the record</param>
<param name="defaultUnknownRoleId">Value to assign to the DefaultUnknownRoleID field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="IDataReader" />
*/
CREATE PROCEDURE dbo.AuthenticationContext_InsertRecord 
	@name varchar(100),
	@isEnabled bit,
	@serviceId uniqueidentifier,
	@schoolId uniqueidentifier,
	@defaultTeacherRoleId uniqueidentifier,
	@defaultUnknownRoleId uniqueidentifier
AS


DECLARE @id as uniqueidentifier
SET @id = NewID()

INSERT INTO AuthenticationContext
	(

		ID,
		Name,
		IsEnabled,
		ServiceID,
		SchoolID,
		DefaultTeacherRoleID,
		DefaultUnknownRoleID
	)
	VALUES
	(

		@id,
		@name,
		@isEnabled,
		@serviceId,
		@schoolId,
		@defaultTeacherRoleId,
		@defaultUnknownRoleId
	)

select @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

