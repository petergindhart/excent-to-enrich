SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AcademicPlanReasonTranslation_GetRecordsByOriginal]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AcademicPlanReasonTranslation_GetRecordsByOriginal]
GO

 /*
<summary>
Gets records from the AcademicPlanReasonTranslation table with the specified ids
</summary>
<param name="ids">Ids of the AcademicPlanReason(s) to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.AcademicPlanReasonTranslation_GetRecordsByOriginal
	@ids	uniqueidentifierarray
AS
	SELECT a.OriginalId, a.*
	FROM
		AcademicPlanReasonTranslation a INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON a.OriginalId = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

