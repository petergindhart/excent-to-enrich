SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ContentAreaRequirement_InsertRecordsForContentAreaRequirementCertificationAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ContentAreaRequirement_InsertRecordsForContentAreaRequirementCertificationAssociation]
GO

 /*
<summary>
Insert records in the ContentAreaRequirementCertification table for the specified ids 
</summary>
<param name="certificationId">The id of the associated Certification</param>
<param name="ids">The ids of the ContentAreaRequirement's to insert</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ContentAreaRequirement_InsertRecordsForContentAreaRequirementCertificationAssociation
	@certificationId uniqueidentifier, 
	@ids uniqueidentifierarray
AS
	INSERT INTO ContentAreaRequirementCertification ( CertificationId, ContentAreaRequirementId)
	SELECT @certificationId, Keys.* FROM
		GetUniqueidentifiers(@ids) AS Keys
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

