SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Absence_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Absence_UpdateRecord]
GO

 /*
<summary>
Updates a record in the Absence table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="studentId">Value to assign to the StudentID field of the record</param>
<param name="date">Value to assign to the Date field of the record</param>
<param name="reasonId">Value to assign to the ReasonID field of the record</param>
<param name="rosterYearId">Value to assign to the RosterYearID field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.Absence_UpdateRecord
	@id uniqueidentifier, 
	@studentId uniqueidentifier, 
	@date datetime, 
	@reasonId uniqueidentifier, 
	@rosterYearId uniqueidentifier
AS
	UPDATE Absence
	SET
		StudentID = @studentId, 
		Date = @date, 
		ReasonID = @reasonId, 
		RosterYearID = @rosterYearId
	WHERE 
		ID = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

