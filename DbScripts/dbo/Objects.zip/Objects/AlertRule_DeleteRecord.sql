SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AlertRule_DeleteRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AlertRule_DeleteRecord]
GO

 /*
<summary>
Deletes a AlertRule record
</summary>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.AlertRule_DeleteRecord
	@id uniqueidentifier
AS
	DELETE FROM 
		AlertRule
	WHERE
		Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

