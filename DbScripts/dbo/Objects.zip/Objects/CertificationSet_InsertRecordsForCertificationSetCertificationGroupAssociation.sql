SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[CertificationSet_InsertRecordsForCertificationSetCertificationGroupAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[CertificationSet_InsertRecordsForCertificationSetCertificationGroupAssociation]
GO

 /*
<summary>
Insert records in the CertificationSetCertificationGroup table for the specified ids 
</summary>
<param name="certificationGroupId">The id of the associated CertificationGroup</param>
<param name="ids">The ids of the CertificationSet's to insert</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.CertificationSet_InsertRecordsForCertificationSetCertificationGroupAssociation
	@certificationGroupId uniqueidentifier, 
	@ids uniqueidentifierarray
AS
	INSERT INTO CertificationSetCertificationGroup ( CertificationGroupId, CertificationSetId)
	SELECT @certificationGroupId, Keys.* FROM
		GetUniqueidentifiers(@ids) AS Keys
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

