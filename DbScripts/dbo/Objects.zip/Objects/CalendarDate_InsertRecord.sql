SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[CalendarDate_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[CalendarDate_InsertRecord]
GO

 /*
<summary>
Inserts a new record into the CalendarDate table with the specified values
</summary>
<param name="calendarId">Value to assign to the CalendarID field of the record</param>
<param name="date">Value to assign to the Date field of the record</param>
<param name="isSchoolDay">Value to assign to the IsSchoolDay field of the record</param>
<param name="elapsedSchoolDays">Value to assign to the ElapsedSchoolDays field of the record</param>
<param name="elapsedCalendarDays">Value to assign to the ElapsedCalendarDays field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE dbo.CalendarDate_InsertRecord	
	@calendarId uniqueidentifier, 
	@date datetime, 
	@isSchoolDay bit, 
	@elapsedSchoolDays int, 
	@elapsedCalendarDays int
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
	
	INSERT INTO CalendarDate
	(
		Id, 
		CalendarId, 
		Date, 
		IsSchoolDay, 
		ElapsedSchoolDays, 
		ElapsedCalendarDays
	)
	VALUES
	(
		@id, 
		@calendarId, 
		@date, 
		@isSchoolDay, 
		@elapsedSchoolDays, 
		@elapsedCalendarDays
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

