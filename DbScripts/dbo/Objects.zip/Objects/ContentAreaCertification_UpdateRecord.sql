SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ContentAreaCertification_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ContentAreaCertification_UpdateRecord]
GO

 /*
<summary>
Updates a record in the ContentAreaCertification table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="certificationId">Value to assign to the CertificationID field of the record</param>
<param name="levelId">Value to assign to the LevelID field of the record</param>
<param name="contentAreaId">Value to assign to the ContentAreaID field of the record</param>
<param name="startDate">Value to assign to the StartDate field of the record</param>
<param name="endDate">Value to assign to the EndDate field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ContentAreaCertification_UpdateRecord
	@id uniqueidentifier, 
	@certificationId uniqueidentifier, 
	@levelId uniqueidentifier, 
	@contentAreaId uniqueidentifier, 
	@startDate datetime, 
	@endDate datetime
AS
	UPDATE ContentAreaCertification
	SET
		CertificationID = @certificationId, 
		LevelID = @levelId, 
		ContentAreaID = @contentAreaId, 
		StartDate = @startDate, 
		EndDate = @endDate
	WHERE 
		ID = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

