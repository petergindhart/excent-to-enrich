SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Action_GetRecordsByActionCategoryID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Action_GetRecordsByActionCategoryID]
GO

 /*
<summary>
Gets records from the Action table for the specified ActionCategoryIDs 
</summary>
<param name="ids">Ids of the ActionCategory's </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.Action_GetRecordsByActionCategoryID 
	@ids uniqueidentifierarray
AS
	SELECT a.ActionCategoryID, a.*
	FROM
		Action a INNER JOIN
		GetIds(@ids) AS Keys ON a.ActionCategoryID = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

