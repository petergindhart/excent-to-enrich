SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ActionText_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ActionText_UpdateRecord]
GO

 /*
<summary>
Updates a record in the ActionText table with the specified values
</summary>
<param name="id">Identifies the record to update</param><param name="token">Value to assign to the Token field of the record</param>
<param name="text">Value to assign to the Text field of the record</param>
<param name="gradeLevelID">Value to assign to the GradeLevelID field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ActionText_UpdateRecord 
	@id uniqueidentifier,
	@token varchar(100),
	@text text,
	@gradeLevelID uniqueidentifier
AS
	UPDATE ActionText
	SET
		Token = @token,
		Text = @text,
		GradeLevelID = @gradeLevelID
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

