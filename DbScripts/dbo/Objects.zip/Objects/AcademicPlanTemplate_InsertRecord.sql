SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AcademicPlanTemplate_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AcademicPlanTemplate_InsertRecord]
GO

 /*
<summary>
Inserts a new record into the AcademicPlanTemplate table with the specified values
</summary>
<param name="primaryTestTypeId">Value to assign to the PrimaryTestTypeID field of the record</param>
<param name="predictorTestTypeId">Value to assign to the PredictorTestTypeID field of the record</param>
<param name="predictorTestGoalTypeId">Value to assign to the PredictorTestGoalTypeID field of the record</param>
<param name="predictorChartTitle">Value to assign to the PredictorChartTitle field of the record</param>
<param name="enableSecondYear">Value to assign to the EnableSecondYear field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE dbo.AcademicPlanTemplate_InsertRecord
	@primaryTestTypeId uniqueidentifier, 
	@predictorTestTypeId uniqueidentifier, 
	@predictorTestGoalTypeId uniqueidentifier, 
	@predictorChartTitle varchar(100), 
	@enableSecondYear bit
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
	
	INSERT INTO AcademicPlanTemplate
	(
		Id, 
		PrimaryTestTypeId, 
		PredictorTestTypeId, 
		PredictorTestGoalTypeId, 
		PredictorChartTitle, 
		EnableSecondYear
	)
	VALUES
	(
		@id, 
		@primaryTestTypeId, 
		@predictorTestTypeId, 
		@predictorTestGoalTypeId, 
		@predictorChartTitle, 
		@enableSecondYear
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

