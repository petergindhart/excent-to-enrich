SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FormInputValue_InsertRecordsForFormInputSelectionAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[FormInputValue_InsertRecordsForFormInputSelectionAssociation]
GO

 /*
<summary>
Insert records in the FormInputSelection table for the specified ids 
</summary>
<param name="optionId">The id of the associated FormTemplateInputSelectFieldOption</param>
<param name="ids">The ids of the FormInputValue's to insert</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.FormInputValue_InsertRecordsForFormInputSelectionAssociation
	@optionId uniqueidentifier, 
	@ids uniqueidentifierarray
AS
	INSERT INTO FormInputSelection ( OptionId, ValueId)
	SELECT @optionId, Keys.* FROM
		GetUniqueidentifiers(@ids) AS Keys
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

