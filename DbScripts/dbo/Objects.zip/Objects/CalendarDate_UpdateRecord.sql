SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[CalendarDate_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[CalendarDate_UpdateRecord]
GO

 /*
<summary>
Updates a record in the CalendarDate table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="calendarId">Value to assign to the CalendarID field of the record</param>
<param name="date">Value to assign to the Date field of the record</param>
<param name="isSchoolDay">Value to assign to the IsSchoolDay field of the record</param>
<param name="elapsedSchoolDays">Value to assign to the ElapsedSchoolDays field of the record</param>
<param name="elapsedCalendarDays">Value to assign to the ElapsedCalendarDays field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.CalendarDate_UpdateRecord
	@id uniqueidentifier, 
	@calendarId uniqueidentifier, 
	@date datetime, 
	@isSchoolDay bit, 
	@elapsedSchoolDays int, 
	@elapsedCalendarDays int
AS
	UPDATE CalendarDate
	SET
		CalendarID = @calendarId, 
		Date = @date, 
		IsSchoolDay = @isSchoolDay, 
		ElapsedSchoolDays = @elapsedSchoolDays, 
		ElapsedCalendarDays = @elapsedCalendarDays
	WHERE 
		ID = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

