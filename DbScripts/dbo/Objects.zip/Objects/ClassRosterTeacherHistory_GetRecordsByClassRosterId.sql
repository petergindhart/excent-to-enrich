SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ClassRosterTeacherHistory_GetRecordsByClassRosterId]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ClassRosterTeacherHistory_GetRecordsByClassRosterId]
GO

 /*
<summary>
Gets records from the ClassRosterTeacherHistory table for the specified ids 
</summary>
<param name="ids">Ids of the ClassRoster's </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ClassRosterTeacherHistory_GetRecordsByClassRosterId 
	@ids uniqueidentifierarray
AS
	SELECT c.ClassRosterID, c.*
	FROM
		ClassRosterTeacherHistory c INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON c.ClassRosterID = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

