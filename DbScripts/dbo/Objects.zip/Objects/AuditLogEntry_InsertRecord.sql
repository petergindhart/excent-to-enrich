SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AuditLogEntry_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AuditLogEntry_InsertRecord]
GO

 /*
<summary>
Inserts a new record into the AuditLogEntry table with the specified values
</summary>
<param name="eventTime">Value to assign to the EventTime field of the record</param>
<param name="ipAddress">Value to assign to the IpAddress field of the record</param>
<param name="message">Value to assign to the Message field of the record</param>
<param name="userProfileId">Value to assign to the UserProfileID field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE [dbo].[AuditLogEntry_InsertRecord] 
	@eventTime datetime,
	@ipAddress varchar(50),
	@message varchar(2000),
	@userProfileId uniqueidentifier
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
INSERT INTO AuditLogEntry
	(

		ID,
		EventTime,
		IpAddress,
		Message,
		UserProfileID
	)
	VALUES
	(

		@id,
		@eventTime,
		@ipAddress,
		@message,
		@userProfileId
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

