SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AlertRule_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AlertRule_InsertRecord]
GO

 /*
<summary>
Inserts a new record into the AlertRule table with the specified values
</summary>
<param name="className">Value to assign to the ClassName field of the record</param>
<param name="property">Value to assign to the Property field of the record</param>
<param name="value">Value to assign to the Value field of the record</param>
<param name="typeId">Value to assign to the TypeID field of the record</param>
<param name="description">Value to assign to the Description field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE dbo.AlertRule_InsertRecord
	@className varchar(300), 
	@property varchar(200), 
	@value varchar(1000), 
	@typeId uniqueidentifier, 
	@description varchar(200)
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
	
	INSERT INTO AlertRule
	(
		Id, 
		ClassName, 
		Property, 
		Value, 
		TypeId, 
		Description
	)
	VALUES
	(
		@id, 
		@className, 
		@property, 
		@value, 
		@typeId, 
		@description
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

