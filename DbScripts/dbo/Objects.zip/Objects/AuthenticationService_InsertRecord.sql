SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AuthenticationService_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AuthenticationService_InsertRecord]
GO

 /*
<summary>
Inserts a new record into the AuthenticationService table with the specified values
</summary>
<param name="typeId">Value to assign to the TypeID field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE dbo.AuthenticationService_InsertRecord 
	@typeId char(1)
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
INSERT INTO AuthenticationService
	(

		ID,
		TypeID
	)
	VALUES
	(

		@id,
		@typeId
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

