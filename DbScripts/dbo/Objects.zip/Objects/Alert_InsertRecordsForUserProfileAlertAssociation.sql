SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Alert_InsertRecordsForUserProfileAlertAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Alert_InsertRecordsForUserProfileAlertAssociation]
GO

 /*
<summary>
Insert records in the UserProfileAlert table for the specified ids 
</summary>
<param name="userProfileId">The id of the associated UserProfile</param>
<param name="ids">The ids of the Alert's to insert</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.Alert_InsertRecordsForUserProfileAlertAssociation
	@userProfileId uniqueidentifier, 
	@ids uniqueidentifierarray
AS
	INSERT INTO UserProfileAlert ( UserProfileId, AlertId)
	SELECT @userProfileId, Keys.* FROM
		GetUniqueidentifiers(@ids) AS Keys
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

