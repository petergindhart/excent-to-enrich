SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AcademicPlan_GetRecordsByTemplate]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AcademicPlan_GetRecordsByTemplate]
GO

 /*
<summary>
Gets records from the AcademicPlan table
with the specified ids
</summary>
<param name="ids">Ids of the AcademicPlanTemplate(s) to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE [dbo].[AcademicPlan_GetRecordsByTemplate]
	@ids	uniqueidentifierarray
AS
	SELECT
		a.TemplateId,
		a.*
	FROM
		AcademicPlan a INNER JOIN
		GetUniqueidentifiers(@ids) Keys ON a.TemplateId = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

