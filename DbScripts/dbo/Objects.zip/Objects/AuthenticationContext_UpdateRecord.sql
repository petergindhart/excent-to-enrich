SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AuthenticationContext_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AuthenticationContext_UpdateRecord]
GO

 /*
<summary>
Updates a record in the AuthenticationContext table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<param name="isEnabled">Value to assign to the IsEnabled field of the record</param>
<param name="serviceId">Value to assign to the ServiceID field of the record</param>
<param name="schoolId">Value to assign to the SchoolID field of the record</param>
<param name="defaultTeacherRoleId">Value to assign to the DefaultTeacherRoleID field of the record</param>
<param name="defaultUnknownRoleId">Value to assign to the DefaultUnknownRoleID field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.AuthenticationContext_UpdateRecord 
	@id uniqueidentifier,
	@name varchar(100),
	@isEnabled bit,
	@serviceId uniqueidentifier,
	@schoolId uniqueidentifier,
	@defaultTeacherRoleId uniqueidentifier,
	@defaultUnknownRoleId uniqueidentifier
AS
	UPDATE AuthenticationContext
	SET
		Name = @name,
		IsEnabled = @isEnabled,
		ServiceID = @serviceId,
		SchoolID = @schoolId,
		DefaultTeacherRoleID = @defaultTeacherRoleId,
		DefaultUnknownRoleID = @defaultUnknownRoleID
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

