SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FormInputValue_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[FormInputValue_UpdateRecord]
GO

 /*
<summary>
Updates a record in the FormInputValue table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="intervalId">Value to assign to the IntervalId field of the record</param>
<param name="inputFieldId">Value to assign to the InputFieldId field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE [dbo].[FormInputValue_UpdateRecord]
	@id uniqueidentifier, 
	@intervalId uniqueidentifier, 
	@inputFieldId uniqueidentifier
AS
	UPDATE FormInputValue
	SET
		IntervalId = @intervalId, 
		InputFieldId = @inputFieldId
	WHERE 
		Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

