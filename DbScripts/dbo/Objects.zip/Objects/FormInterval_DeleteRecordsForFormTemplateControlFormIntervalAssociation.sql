SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FormInterval_DeleteRecordsForFormTemplateControlFormIntervalAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[FormInterval_DeleteRecordsForFormTemplateControlFormIntervalAssociation]
GO

 /*
<summary>
Deletes records from the FormTemplateControlFormInterval table for the specified ids 
</summary>
<param name="controlId">The id of the associated FormTemplateControl</param>
<param name="ids">The ids of the FormInterval's to delete</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.FormInterval_DeleteRecordsForFormTemplateControlFormIntervalAssociation
	@controlId uniqueidentifier, 
	@ids uniqueidentifierarray
AS
	DELETE FormTemplateControlFormInterval
	FROM 
		FormTemplateControlFormInterval ab INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON ab.IntervalId = Keys.Id
	WHERE
		ab.ControlId = @controlId
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

