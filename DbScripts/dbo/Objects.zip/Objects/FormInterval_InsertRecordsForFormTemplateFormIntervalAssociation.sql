SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FormInterval_InsertRecordsForFormTemplateFormIntervalAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[FormInterval_InsertRecordsForFormTemplateFormIntervalAssociation]
GO

 /*
<summary>
Insert records in the FormTemplateFormInterval table for the specified ids 
</summary>
<param name="templateId">The id of the associated FormTemplate</param>
<param name="ids">The ids of the FormInterval's to insert</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.FormInterval_InsertRecordsForFormTemplateFormIntervalAssociation
	@templateId uniqueidentifier, 
	@ids uniqueidentifierarray
AS
	INSERT INTO FormTemplateFormInterval ( TemplateId, IntervalId)
	SELECT @templateId, Keys.* FROM
		GetUniqueidentifiers(@ids) AS Keys
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

