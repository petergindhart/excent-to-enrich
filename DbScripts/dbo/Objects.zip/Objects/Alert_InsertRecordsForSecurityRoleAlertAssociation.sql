SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Alert_InsertRecordsForSecurityRoleAlertAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Alert_InsertRecordsForSecurityRoleAlertAssociation]
GO

 /*
<summary>
Insert records in the SecurityRoleAlert table for the specified ids 
</summary>
<param name="securityRoleId">The id of the associated SecurityRole</param>
<param name="ids">The ids of the Alert's to insert</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.Alert_InsertRecordsForSecurityRoleAlertAssociation
	@securityRoleId uniqueidentifier, 
	@ids uniqueidentifierarray
AS
	INSERT INTO SecurityRoleAlert ( SecurityRoleId, AlertId)
	SELECT @securityRoleId, Keys.* FROM
		GetUniqueidentifiers(@ids) AS Keys
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

