SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Absence_GetRecordsByRosterYear]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Absence_GetRecordsByRosterYear]
GO

 /*
<summary>
Gets records from the Absence table
with the specified ids
</summary>
<param name="ids">Ids of the RosterYear(s) to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.Absence_GetRecordsByRosterYear
	@ids	uniqueidentifierarray
AS
	SELECT
		a.RosterYearId,
		a.*
	FROM
		Absence a INNER JOIN
		GetUniqueidentifiers(@ids) Keys ON a.RosterYearId = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

