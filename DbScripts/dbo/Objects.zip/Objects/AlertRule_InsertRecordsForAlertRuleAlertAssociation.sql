SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AlertRule_InsertRecordsForAlertRuleAlertAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AlertRule_InsertRecordsForAlertRuleAlertAssociation]
GO

 /*
<summary>
Insert records in the AlertRuleAlert table for the specified ids 
</summary>
<param name="alertId">The id of the associated Alert</param>
<param name="ids">The ids of the AlertRule's to insert</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.AlertRule_InsertRecordsForAlertRuleAlertAssociation
	@alertId uniqueidentifier, 
	@ids uniqueidentifierarray
AS
	INSERT INTO AlertRuleAlert ( AlertId, AlertRuleId)
	SELECT @alertId, Keys.* FROM
		GetUniqueidentifiers(@ids) AS Keys
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

