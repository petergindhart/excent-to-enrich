SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AlertRuleType_GetRecordsForSecurityRoleRuleTypeAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AlertRuleType_GetRecordsForSecurityRoleRuleTypeAssociation]
GO

 /*
<summary>
Gets records from the AlertRuleType table for the specified association 
</summary>
<param name="ids">Ids of the SecurityRole(s) </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.AlertRuleType_GetRecordsForSecurityRoleRuleTypeAssociation
	@ids uniqueidentifierarray
AS
	SELECT ab.RoleId, a.*
	FROM
		SecurityRoleRuleType ab INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON ab.RoleId = Keys.Id INNER JOIN
		AlertRuleType a ON ab.RoleId = a.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

