SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AlertRuleType_InsertRecordsForSecurityRoleRuleTypeAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AlertRuleType_InsertRecordsForSecurityRoleRuleTypeAssociation]
GO

 /*
<summary>
Insert records in the SecurityRoleRuleType table for the specified ids 
</summary>
<param name="roleId">The id of the associated SecurityRole</param>
<param name="ids">The ids of the AlertRuleType's to insert</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.AlertRuleType_InsertRecordsForSecurityRoleRuleTypeAssociation
	@roleId uniqueidentifier, 
	@ids uniqueidentifierarray
AS
	INSERT INTO SecurityRoleRuleType ( RoleId, RoleId)
	SELECT @roleId, Keys.* FROM
		GetUniqueidentifiers(@ids) AS Keys
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

