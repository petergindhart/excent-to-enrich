SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DisciplineIncident_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[DisciplineIncident_UpdateRecord]
GO

 /*
<summary>
Updates a record in the DisciplineIncident table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="studentId">Value to assign to the StudentID field of the record</param>
<param name="rosterYearId">Value to assign to the RosterYearID field of the record</param>
<param name="date">Value to assign to the Date field of the record</param>
<param name="dispositionCodeId">Value to assign to the DispositionCodeID field of the record</param>
<param name="comments">Value to assign to the Comments field of the record</param>
<param name="incidentLocationId">Value to assign to the IncidentLocationID field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.DisciplineIncident_UpdateRecord
	@id uniqueidentifier, 
	@studentId uniqueidentifier, 
	@rosterYearId uniqueidentifier, 
	@date datetime, 
	@dispositionCodeId uniqueidentifier, 
	@comments varchar(8000), 
	@incidentLocationId uniqueidentifier
AS
	UPDATE DisciplineIncident
	SET
		StudentID = @studentId, 
		RosterYearID = @rosterYearId, 
		Date = @date, 
		DispositionCodeID = @dispositionCodeId, 
		Comments = @comments, 
		IncidentLocationID = @incidentLocationId
	WHERE 
		ID = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

