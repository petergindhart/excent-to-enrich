SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AcademicPlanAction_GetRecordsByAcademicPlanID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AcademicPlanAction_GetRecordsByAcademicPlanID]
GO

 /*
<summary>
Gets records from the AcademicPlanAction table for the specified AcademicPlanIDs 
</summary>
<param name="ids">Ids of the AcademicPlan's </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.AcademicPlanAction_GetRecordsByAcademicPlanID 
	@ids uniqueidentifierarray
AS
	SELECT a.AcademicPlanID, a.*
	FROM
		AcademicPlanAction a INNER JOIN
		GetIds(@ids) AS Keys ON a.AcademicPlanID = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

