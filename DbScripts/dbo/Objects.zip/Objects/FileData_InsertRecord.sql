SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FileData_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[FileData_InsertRecord]
GO

 /*
<summary>
Inserts a new record into the FileData table with the specified values
</summary>
<param name="originalName">Value to assign to the OriginalName field of the record</param>
<param name="receivedDate">Value to assign to the ReceivedDate field of the record</param>
<param name="mimeType">Value to assign to the MimeType field of the record</param>
<param name="content">Value to assign to the Content field of the record</param>
<param name="isTemporary">Value to assign to the IsTemporary field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE [dbo].[FileData_InsertRecord]	
	@originalName varchar(1024), 
	@receivedDate datetime, 
	@mimeType varchar(50), 
	@content image, 
	@isTemporary bit
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
	
	INSERT INTO FileData
	(
		Id, 
		OriginalName, 
		ReceivedDate, 
		MimeType, 
		Content, 
		IsTemporary
	)
	VALUES
	(
		@id, 
		@originalName, 
		@receivedDate, 
		@mimeType, 
		@content, 
		@isTemporary
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

