SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ClassRosterTeacherHistory_DeleteRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ClassRosterTeacherHistory_DeleteRecord]
GO

 /*
<summary>
Deletes a ClassRosterTeacherHistory record
</summary>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ClassRosterTeacherHistory_DeleteRecord
	@classRosterId uniqueidentifier, 
	@teacherId uniqueidentifier, 
	@startDate datetime
AS
	DELETE FROM 
		ClassRosterTeacherHistory
	WHERE
		ClassRosterId = @classRosterId AND TeacherId = @teacherId AND StartDate = @startDate
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

