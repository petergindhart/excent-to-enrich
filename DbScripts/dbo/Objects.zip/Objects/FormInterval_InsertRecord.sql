SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FormInterval_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[FormInterval_InsertRecord]
GO

 /*
<summary>
Inserts a new record into the FormInterval table with the specified values
</summary>
<param name="name">Value to assign to the Name field of the record</param>
<param name="sequence">Value to assign to the Sequence field of the record</param>
<param name="seriesId">Value to assign to the SeriesId field of the record</param>
<param name="abbreviation">Value to assign to the Abbreviation field of the record</param>
<param name="cumulativeUpTo">Value to assign to the CumulativeUpTo field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE dbo.FormInterval_InsertRecord	
	@name varchar(50), 
	@sequence int, 
	@seriesId uniqueidentifier, 
	@abbreviation varchar(10), 
	@cumulativeUpTo uniqueidentifier
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
	
	INSERT INTO FormInterval
	(
		Id, 
		Name, 
		Sequence, 
		SeriesId, 
		Abbreviation, 
		CumulativeUpTo
	)
	VALUES
	(
		@id, 
		@name, 
		@sequence, 
		@seriesId, 
		@abbreviation, 
		@cumulativeUpTo
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

