SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[CertificationExam_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[CertificationExam_InsertRecord]
GO

 /*
<summary>
Inserts a new record into the CertificationExam table with the specified values
</summary>
<param name="name">Value to assign to the Name field of the record</param>
<param name="code">Value to assign to the Code field of the record</param>
<param name="descriptionUrl">Value to assign to the DescriptionUrl field of the record</param>
<param name="familyId">Value to assign to the FamilyID field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE dbo.CertificationExam_InsertRecord
	@name varchar(200), 
	@code varchar(10), 
	@descriptionUrl varchar(500), 
	@familyId uniqueidentifier
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
	
	INSERT INTO CertificationExam
	(
		Id, 
		Name, 
		Code, 
		DescriptionUrl, 
		FamilyId
	)
	VALUES
	(
		@id, 
		@name, 
		@code, 
		@descriptionUrl, 
		@familyId
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

