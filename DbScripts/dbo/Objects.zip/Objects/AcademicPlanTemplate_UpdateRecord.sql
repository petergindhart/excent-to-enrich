SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AcademicPlanTemplate_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AcademicPlanTemplate_UpdateRecord]
GO

 /*
<summary>
Updates a record in the AcademicPlanTemplate table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="primaryTestTypeId">Value to assign to the PrimaryTestTypeID field of the record</param>
<param name="predictorTestTypeId">Value to assign to the PredictorTestTypeID field of the record</param>
<param name="predictorTestGoalTypeId">Value to assign to the PredictorTestGoalTypeID field of the record</param>
<param name="predictorChartTitle">Value to assign to the PredictorChartTitle field of the record</param>
<param name="enableSecondYear">Value to assign to the EnableSecondYear field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.AcademicPlanTemplate_UpdateRecord
	@id uniqueidentifier, 
	@primaryTestTypeId uniqueidentifier, 
	@predictorTestTypeId uniqueidentifier, 
	@predictorTestGoalTypeId uniqueidentifier, 
	@predictorChartTitle varchar(100), 
	@enableSecondYear bit
AS
	UPDATE AcademicPlanTemplate
	SET
		PrimaryTestTypeID = @primaryTestTypeId, 
		PredictorTestTypeID = @predictorTestTypeId, 
		PredictorTestGoalTypeID = @predictorTestGoalTypeId, 
		PredictorChartTitle = @predictorChartTitle, 
		EnableSecondYear = @enableSecondYear
	WHERE 
		ID = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

