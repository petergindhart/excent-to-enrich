SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Alert_InsertRecordsForAlertRuleAlertAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Alert_InsertRecordsForAlertRuleAlertAssociation]
GO

 /*
<summary>
Insert records in the AlertRuleAlert table for the specified ids 
</summary>
<param name="alertRuleId">The id of the associated AlertRule</param>
<param name="ids">The ids of the Alert's to insert</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.Alert_InsertRecordsForAlertRuleAlertAssociation
	@alertRuleId uniqueidentifier, 
	@ids uniqueidentifierarray
AS
	INSERT INTO AlertRuleAlert ( AlertRuleId, AlertId)
	SELECT @alertRuleId, Keys.* FROM
		GetUniqueidentifiers(@ids) AS Keys
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

