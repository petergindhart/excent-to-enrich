set nocount on;
set ansi_warnings off;

declare @gtbl table (gstudentid uniqueidentifier not null primary key, iepseqnum int)
insert @gtbl 
select distinct gstudentid, iepseqnum from SpecialEdStudentsAndIEPs

-- select * from @gtbl x where iepseqnum = 164077


select 	
	ServiceType = v.Type, 
	v.ServiceRefId, 
	v.IEPRefID,
count(*) tot
from (
	select 
		Type = 
			case v.Type -- SpEd, RelServ, Personnel, Aids
				when 'SpEd' then 'SpecialEd'
				when 'RelServ' then 'Related'
				when 'Personnel' then 'Support'
				when 'Aids' then 'Supplementary'
				else ''
			end,
		ServiceRefID = v.ServSeqNum, 
		IepRefID = v.IEPComplSeqNum, 
		ServiceDefinitionCode = case isnull(ServCode, '') when '' then 'ZZZ' else ServCode end, 
		BeginDate = isnull(v.InitDate, dateadd(dd, 1, i.InitDate)), -- select top 10 * from ServiceTbl where gstudentid = '0D2173AE-A416-4C12-A5F8-D6D4B016EFF2' -- select * from student where gstudentid = '0D2173AE-A416-4C12-A5F8-D6D4B016EFF2'
		EndDate = isnull(v.EndDate, dateadd(dd, -1, dateadd(yy, 1, isnull(v.InitDate, dateadd(dd, 1, i.InitDate))))),
		IsRelated = cast(0 as bit), -- select top 10 * from ieptbl
		IsDirect = cast(1 as bit), 
		ExcludesFromGenEd = cast(0 as bit), 
		ServiceLocationCode = 
			case 
				when k.Code is not null then k.Code 
				when isnull(v.LocationCode, k.Code) is null then ''
				when k.LookDesc = v.LocationDesc then k.Code -- should be last because it is most accurate.
					-- note:  at Polk there are 2 locations named "Home" with different codes - 10 and 24.
			end,
		Sequence = ServOrder, 
		-- IsEsy = cast(isnull(v.ESY,0) as bit), 
		IsESY = cast(case when v.AntDuration like 'ESY%' then 1 else 0 end as bit),
		ServiceTime = 
			cast(
			cast(
				case when v.Frequency like '%$%' then 
					right(
						v.Frequency, 
						patindex(
							'%$%', reverse(rtrim(v.Frequency)
							)
						)-1
					)
				else 
					'0'
				end 
			as numeric(9,2))
			as int)
			, -- service time is provided in hours, but we need minutes
		ServiceFrequencyCode = 
			case 
				when v.Frequency like '%year%' then 'year'
				when v.Frequency like '%quarter%' then 'quarter'
				when (v.Frequency like '%month%' or v.Frequency = 'Biweekly') then 'month'
				when ((v.Frequency like '%week%' or v.Frequency like '%Wk%') and v.Frequency <> 'Biweekly') then 'week'
				when (v.Frequency like '%day%' or v.Frequency like '%daily%' or v.Frequency like '%Continuous%') then 'day'		-- note:  use this same case statement when extracting data from this text field
				else 'ZZZ'
			end,
		ServiceAreaText = v.ServDesc,
		StaffTypeCode = '', --p.Code,
		StaffEmail = t.email
	from 
		@gtbl x 
		JOIN IEPCompleteTbl i on x.IEPSeqNum = i.IEPSeqNum 
		JOIN ICServiceTbl v on i.IEPSeqNum = v.IEPComplSeqNum and isnull(v.del_flag,0)=0 -- select top 10 * from ServiceTbl
		LEFT JOIN CodeDescLook k on v.LocationDesc = k.LookDesc and UsageID = 'Location'
		LEFT JOIN Staff t on v.ProvCode = t.StaffId -- select * from ServiceTbl where ServProv is not null -- select top 100 * from ICServiceTbl where Teacher is not null
	where 
		v.Type in ('SpEd', 'RelServ', 
			-- 'Personnel',  -- support 
		'Aids')
) v
group by v.Type, 
	v.ServiceRefId, 
	v.IEPRefID
having count(*) > 1


select v.* 
from icservicetbl v
LEFT JOIN CodeDescLook k on v.LocationDesc = k.LookDesc and UsageID = 'Location'
LEFT JOIN Staff t on v.ProvCode = t.StaffId 
where iepcomplseqnum = 164077 and servseqnum = 209427	



select LookDesc, count(*) tot
from CodeDescLook where UsageID = 'Location'
group by LookDesc
having count(*) > 1

select * from CodeDescLook where UsageID = 'Location' and LookDesc = 'Home'



--select v.iepcomplseqnum, v.servseqnum, count(*) tot
--from iepcompletetbl i join
--icservicetbl v on i.IEPSeqNum = v.IEPComplSeqNum
--where isnull(i.del_flag,0)=0
--group by v.iepcomplseqnum, v.servseqnum
--having count(*) > 1

