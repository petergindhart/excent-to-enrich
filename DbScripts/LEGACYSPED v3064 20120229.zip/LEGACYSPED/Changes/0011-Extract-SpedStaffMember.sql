IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'LEGACYSPED.SpedStaffMember_LOCAL') AND type in (N'U'))
DROP TABLE LEGACYSPED.SpedStaffMember_LOCAL  
GO  
  
IF  EXISTS (SELECT 1 FROM sys.views WHERE object_id = OBJECT_ID(N'LEGACYSPED.SpedStaffMember'))  
DROP VIEW LEGACYSPED.SpedStaffMember  
GO  
  
CREATE TABLE LEGACYSPED.SpedStaffMember_LOCAL(  
SpedStaffRefID		  varchar(150), 
SpedStaffLocalID		  varchar(20), 
Lastname		  varchar(50), 
Firstname		  varchar(50), 
Email		  varchar(75), 
SISStaffRefID		  varchar(150), 
LDAPUsername		  varchar(200), 
MedicaidCert		  varchar(1), 
CertificationDate		  datetime, 
SSN		  varchar(11)
)  
GO  
  
  
CREATE VIEW LEGACYSPED.SpedStaffMember  
AS  
 SELECT * FROM LEGACYSPED.SpedStaffMember_LOCAL  
GO  
--