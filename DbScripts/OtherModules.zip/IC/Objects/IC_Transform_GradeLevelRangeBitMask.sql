IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'IC.Transform_GradeLevelBitMask') AND OBJECTPROPERTY(id, N'IsView') = 1)
	DROP VIEW IC.Transform_GradeLevelBitMask
GO

CREATE View IC.Transform_GradeLevelBitMask
AS
select 
	MinGradeID = gl1.ID,
	MinGradeName = gl1.Name,
	MinGradeMask = power(2, gl1.Sequence),
	MaxGradeID = gl2.ID,
	MaxGradeName = gl2.Name,
	MaxGradeMask = power(2, gl2.Sequence),
	BitMask = power(2, gl1.Sequence) | power(2, gl2.Sequence)
from
	dbo.GradeLevel gl1 cross join
	dbo.GradeLevel gl2
GO