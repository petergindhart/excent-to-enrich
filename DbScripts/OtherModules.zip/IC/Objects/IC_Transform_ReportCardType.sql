IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'IC.Transform_ReportCardType') AND OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW IC.Transform_ReportCardType
GO

CREATE VIEW IC.Transform_ReportCardType
AS
SELECT
	mrct.DestID,
	Name,
	TaskSequence = gt.TaskID
FROM
	(
		SELECT TaskID 
		from 
			IC.GradingScore gs
		group by
			TaskID
	) gtRollup join
	IC.GradingTask gt on gtRollup.TaskID = gt.TaskID left join 
	IC.Map_ReportCardTypeID mrct on gt.TaskID = mrct.TaskSequence
where
	standardID is null