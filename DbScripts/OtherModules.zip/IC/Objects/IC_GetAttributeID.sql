IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[IC].[GetAttributeID]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [IC].[GetAttributeID]
GO

CREATE FUNCTION IC.GetAttributeID(@object varchar(100), @element varchar(100))
RETURNS INT
AS
BEGIN
RETURN(
	SELECT
		AttributeID
	FROm
		IC.Map_EnumTypeID
	WHERE
		[Object] = @object AND Element = @element
	)
END