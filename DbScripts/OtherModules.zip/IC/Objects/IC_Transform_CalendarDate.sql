IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[IC].[Transform_CalendarDate]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [IC].[Transform_CalendarDate]
GO

CREATE FUNCTION [IC].Transform_CalendarDate(@endYear int)
RETURNS TABLE
AS
RETURN
SELECT
	CalendarID = mc1.DestID,
	[Date] = cd1.[date],
	IsSchoolDay = schoolday, --encapsulates all the absence logic
	ElapsedSchoolDays = SchoolDaysSinceFirstDate.DaySince,
	ElapsedCalendarDays = datediff(d,StartDate, [date]) + 1,
	c1.calendarID as calID --,
	--cd1.dayID
FROm 
	(
		SELECT
			calendarID,
			date,
			MAX( cast(schoolday as int)) schoolday -- this rolls up all the various scheduling, 99.9% of time the school days move in unison, but just in case
		FROM
			IC.[Day]			
		group by
			calendarID,
			date
	) cd1 join	
	IC.Calendar c1 on c1.CalendarID = cd1.calendarID and c1.exclude =0 and c1.SummerSchool = 0 join	
	IC.Map_calendarID mc1  on mc1.Schoolid = c1.Schoolid and mc1.endYear = @endYear join 		
	(
		SELECT
			mc2.DestID as CalID,
			InstanceDate = cd2.[date],					
			DaySince =  (
						select 
							SUM( cast(schoolday as int))
						from 
							(
								SELECT
									calendarID,
									date,
									MAX( cast(schoolday as int)) schoolday -- this rolls up all the various scheduling, 99.9% of time the school days move in unison, but just in case
								FROM
									IC.[Day]			
								group by
									calendarID,
									date
							)  cd3 join							
							IC.Calendar c3 on c3.CalendarID = cd3.calendarID and c3.exclude =0 and c3.SummerSchool = 0  join																						
							IC.Map_CalendarID mc3 on mc3.schoolid = c3.schoolid and c3.endYear = @endYear
						WHERE
							cd3.[date] <= cd2.[date] and mc3.DestID = mc2.DestID AND							
							cd3.[date] >= c3.StartDate AND [date] <= c3.EndDate
						)
		FROM	
			(
				SELECT
					calendarID,
					date,
					MAX( cast(schoolday as int)) schoolday -- this rolls up all the various scheduling, 99.9% of time the school days move in unison, but just in case
				FROM
					IC.[Day]			
				group by
					calendarID,
					date
			) cd2 join			
			IC.Calendar c2 on c2.CalendarID = cd2.calendarID and c2.exclude =0 and c2.SummerSchool = 0  join
			IC.Map_calendarID mc2 on mc2.Schoolid = c2.Schoolid and mc2.endYear = c2.endyear			
		where
			c2.EndYear = @endYear
		group by
			mc2.DestID,
			cd2.[date]
	) SchoolDaysSinceFirstDate on SchoolDaysSinceFirstDate.CalID = mc1.DestID and SchoolDaysSinceFirstDate.InstanceDate = cd1.[date]
where
	[date] between StartDate and EndDate
GO
