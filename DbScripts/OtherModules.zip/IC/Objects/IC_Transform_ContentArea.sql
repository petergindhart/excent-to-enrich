IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[IC].[Transform_ContentArea]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [IC].[Transform_ContentArea]
GO

CREATE FUNCTION IC.Transform_ContentArea(@endYear int)
RETURNS TABLE
AS
RETURN
SELECT
	mc.DestID,
	d.Name,
	SubjectID =	
	case 
		when Name like '%LANG%' OR Name like '%ELA%' OR NAME LIKE '%RDG%'
		then 'DF2274C7-1714-44C1-A8FC-61F29D5504AC'
		when Name like '%MAT%' --Math
		then '7BC1F354-2787-4C88-83F1-888D93F0E71E'
		when Name like '%Sci%' --science
		then '0351CAC6-40EE-479C-A506-DC84E77C6665'
		when Name like '%SOC%' OR Name like '%SCLS%'  --social studies
		then 'C90E81B1-30CB-4D2D-B301-F4AB6A1F5E75'
		else
			cast(null as uniqueidentifier)
	END,
	MaxCertificationLevelID = cast('CCFB4A0C-43E5-4C94-B7F3-BAAC99A0539D' as uniqueidentifier),
	d.DepartmentID
FROM
	IC.Department d left join	
	IC.Map_ContentAreaID mc on mc.DepartmentID = d.DepartmentID