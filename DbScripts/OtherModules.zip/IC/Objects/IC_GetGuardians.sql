IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[IC].[GetGuardians]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [IC].[GetGuardians]
GO

CREATE FUNCTION IC.GetGuardians(@studentPersonID int)
RETURNS Varchar(50)
AS
BEGIN
	DECLARE @names varchar(50)

	SELECT
		@names = IsNUll(@names + ', ','') + FirstName + ' ' +  LastName
	FROM
		IC.RelatedPair rp join
		IC.Person p1 on p1.Personid = rp.personID1 join
		IC.IC_identity it1 on p1.CurrentIdentityID = it1.identityID		
	where
		personId2 = @studentPersonID

	return @names
END

