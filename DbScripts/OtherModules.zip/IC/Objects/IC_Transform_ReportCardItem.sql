IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[IC].[Transform_ReportCardITem]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [IC].[Transform_ReportCardITem]
GO

CREATE FUNCTION IC.Transform_ReportCardItem(@endYear int)
RETURNS TABLE
AS
RETURN
SELECT
	mrci.DestID,
	gt.taskID,
	UsesTerm = 1,
	IsFinal = term.IsFinal,
	ReportCardTypeID = mrct.DestID,	
	TermID = t.TermID,
	Sequence = term.Seq,
	Name = gt.name + ' ' + term.Name	
FROM
	IC.GradingTask gt join	
	IC.Map_ReportCardTypeID mrct on mrct.TaskSequence = TaskID join	
	(
		SELECT
			TaskID, TermID
		FROM
			IC.GradingScore gs join
			IC.Calendar cal on gs.CalendarID = cal.calendarID
		WHERE
			(score is not null OR [percent] is not null) AND
			cal.EndYear = @endYear
		GROUP BY
			TaskID, TermID
	) t on t.TaskID = gt.TaskID join
	(
		select 
			t1.TermID, t1.Name, t1.Seq ,
			IsFinal = case when (select max(seq) from IC.Term tInner where tInner.termScheduleID = t1.termScheduleID) = t1.Seq then 1 else 0 end			
		from 
			IC.Term t1 join
			IC.TermSchedule ts on t1.TermScheduleID = ts.TermScheduleID join
			IC.ScheduleStructure ss on ss.structureID = ts.structureID join
			IC.Calendar cal on cal.CalendarID = ss.CalendarID
		where
			cal.EndYear = @endYear
	) term on term.TermID = t.TermID left join	
	IC.Map_ReportCardItemID mrci on mrci.TaskID = t.taskID	and mrci.Termid = t.Termid
where
	StandardID is null AND
	gt.TaskID NOT IN (81)