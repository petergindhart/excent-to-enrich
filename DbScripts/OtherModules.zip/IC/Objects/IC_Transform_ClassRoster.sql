IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[IC].[Transform_ClassRoster]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [IC].[Transform_ClassRoster]
GO

CREATE FUNCTION [IC].[Transform_ClassRoster] (@endYear int)
RETURNS TABLE
AS
RETURN
select	
	DestID = (select DestID FROM IC.Map_ClassRosterID mc WHERE mc.SectionID = s.SectionID),
	SchoolID = msch.DestID,
	RosterYearID = (select ID from RosterYear where StartYear = (@endYear - 1)),
	SectionName =c.number + '-' + case when LEN(s.Number) = 1 then '0' else '' end + cast(s.Number as varchar(4)),
	ClassName = c.Name,
	CourseCode = c.number,
	BM.MinGradeID,
	BM.MaxGradeID,
	ContentAreaId = mca.DestiD, 
	GradeBitMask = BM.BitMask,
	IC_SchoolID = cal.SchoolID,
	IC_SectionID = s.SectionID,
	TeacherID = mt.DestID,
	s.SectionID	
FROM
	IC.Course c join
	IC.Section s on c.courseID = s.CourseID join
	IC.Trial t on t.TrialID = s.TrialID join
	IC.Calendar cal on t.CalendarID = cal.calendarID join
	IC.Map_SchoolID msch on msch.SchoolID = cal.SchoolID left join	
	IC.Map_TeacherID mt on mt.PersonID = s.TeacherPersonID left join
	IC.Map_ContentAreaID mca on mca.DepartmentID = c.departmentID left join
	(	
		SELECT
			sectionID,						
			MIN(Seq) AS MinGradeSeq,
			MAX(Seq) AS MAxGradeSeq			
		FROM
			IC.Roster r2 join				
			IC.Enrollment e on e.Personid = r2.PersonID join
			IC.GradeLevel gl on gl.Name = e.Grade join
			IC.Calendar cal on cal.calendarID = e.CalendarID join
			IC.Trial tr on tr.TrialID = r2.TrialID
		WHERE
			cal.EndYear = @endYear and 
			cal.Exclude = 0 and			
			tr.Active = 1
		group by
			sectionID		
	) I ON I.sectionID = s.sectionID left join
	(
		SELECT 
			Sequence,
			MIn(Name) AS Name
		FROM
			dbo.GradeLevel 
		GROUP BY
			Sequence		
	) lgR on lgr.Sequence = I.MinGradeSeq left join
	(
		SELECT 
			Sequence,
			MIn(Name) AS Name
		FROM
			dbo.GradeLevel 
		GROUP BY
			Sequence
	) hgr on I.MAxGradeSeq = hgr.Sequence left join
	GradeRangeBitMask BM on 
		lGr.Name like '%' + BM.MinGradeName and
		hGr.Name like '%' + BM.MaxGradeName 
where
	cal.EndYear = @endYear and
	t.Active = 1