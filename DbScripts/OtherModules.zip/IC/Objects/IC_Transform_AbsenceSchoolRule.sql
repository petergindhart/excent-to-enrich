IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[IC].[Transform_AbsenceSchoolRule]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [IC].[Transform_AbsenceSchoolRule]
GO

CREATE FUNCTION IC.Transform_AbsenceSchoolRule(@endYear int)
RETURNS TABLE
AS
RETURN
SELECT
	ar.DestID as ReasonID,
	ms.DestID as SchoolID
FROM
	IC.AttendanceExcuse ae join
	IC.Map_AbsenceReasonID ar on ar.ExcuseID = ae.ExcuseID join
	IC.Calendar c on ae.CalendarID = c.CalendarID and c.EndYear = @endYear join
	IC.Map_SchoolID ms on ms.SchoolID = c.SchoolID
GO