IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[IC].[Transform_StudentClassRoster]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [IC].[Transform_StudentClassRoster]
GO

CREATE FUNCTION IC.Transform_StudentClassRoster (@endYear int)
RETURNS TABLE
AS
RETURN
select
	StudentID = ms.DestID,
	ClassRosterID = mc.DestID,
	StartDate = Coalesce(r.StartDate, tr.StartDate, c.StartDate),
	EndDate = Coalesce(r.EndDate, tr.EndDate, c.EndDate)
FROm
	(
		SELECT
			personID,
			sectionID,
			max(rosterID) as RosterID
		FROm
			IC.Roster r2	join
			IC.Trial t2 on t2.TrialID = r2.TrialID join
			IC.Calendar c2 on t2.calendarID = c2.calendarID 
		WHERE	
			c2.EndYear = @endYear and
			c2.exclude = 0 and	
			t2.Active = 1
		group by
			personID,
			sectionID
	) rRollup join
	IC.Roster r on r.RosterID = rRollup.RosterID join
	IC.Map_StudentId ms on ms.PersonID = r.Personid join
	IC.Map_ClassRosterID mc on mc.SectionID = r.SectionID join
	IC.Trial t on t.TrialID = r.TrialID join
	IC.Calendar c on t.calendarID = c.calendarID left join
	(
		SELECT
			sectionID,
			MAX(termID) AS TermID, --this filters out multiple enrollments (Q1,Q2,Q3,Q4) in the same class and makes them appear as one course
			trialID
		FROM
			IC.SectionPlacement 
		GROUP BY
			sectionID,			
			trialID
		having
			MIN(TermID) = MAX(TermID)
	) sp on sp.sectionID = rRollup.sectionID and sp.TrialID  = r.TrialID left join
	IC.Term tr on tr.TermID = sp.TermID
WHERE
	c.EndYear = @endYear