IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[IC].[Transform_StudentGuardian]') AND OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [IC].[Transform_StudentGuardian]
GO

CREATE VIEW IC.Transform_StudentGuardian
AS
SELECT
	msg.DestID,
	StudentID = ms.DestId,
	RelationshipID = mr.DestID,
	PersonID = mp.DestID,
	Sequence = ISNULL(rtRollup.sequence,0)	
FROM
	(
		select 
			ic.personID, MAX(identityID) as maxIdentity
		From 
			IC.Person p left join
			IC.IC_Identity ic on ic.PersonID = p.personID join
			IC.RelatedPair rp on rp.personID1 = p.personID
		WHERE
			p.studentNumber is null AND
			(endDate is null OR endDate >= GETDATE())--filter out deactivated parent
		GROUP BY
			ic.personID
	) recs join
	IC.Map_PersonID mp on mp.IdentityID = recs.maxIdentity join	
	IC.RelatedPair stuPairs on stuPairs.personID1 = recs.personID join		
	IC.MAP_StudentID ms on ms.PersonID = stuPairs.personID2 join
	IC.Map_StudentGuardianRelationshipID mr on mr.Name = IC.GetCleanRelationshipName(stuPairs.Name) left join
	IC.Map_StudentGuardianID msg on msg.StudentID = ms.DestID and msg.PersonID = mp.DestID left join
	(
		SELECT	
			IC.GetCleanRelationshipName(rt.name) as CleanName,
			MIN(TypeID) sequence
		FROM
			IC.RelationshipType rt
		GROUP BY
			IC.GetCleanRelationshipName(rt.name)
	) rtRollup on rtRollup.CleanName = IC.GetCleanRelationshipName(stuPairs.Name)	
GO

