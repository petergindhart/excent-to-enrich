IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[IC].[Transform_DisciplineIncident]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [IC].[Transform_DisciplineIncident]
GO

CREATE FUNCTION IC.Transform_DisciplineIncident(@endYear int)
RETURNS TABLE 
AS
RETURN
SELECT
	--ID = newID(),	
	StudentID = ms.DestID,
	RosterYearID = ry.ID,
	Date = ev.[timestamp],
	DispositionCodeID = mev.DestID,
	ev.Comments,
	IncidentLocationID = msch.DestID
FROM
	IC.BehaviorRole br join		
	IC.BehaviorEvent ev on br.EventId = ev.EvenTID join
	IC.Calendar cal on ev.CalendarID = cal.calendarID join	
	IC.Map_StudentID ms on ms.Personid = br.PersonID join
	RosterYear ry on ry.StartYear = (EndYear - 1) join
	IC.Map_SchoolID msch on msch.SchoolID = cal.SchoolID join
	IC.BehaviorResolution ber on ber.roleid= br.roleID join	
	IC.Map_EnumValueID mev on mev.AttributeID = -1 and mev.Code = ber.code
WHERE
	EndYear = @endYear AND
	br.Role in ('Offender', 'Participant', 'Instigator') --filter out witnesses and victims of discipline events
GO