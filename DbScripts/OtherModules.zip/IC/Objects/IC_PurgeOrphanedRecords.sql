IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[IC].[PurgeOrphanedRecords]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [IC].[PurgeOrphanedRecords]
GO

CREATE PROCEDURE IC.PurgeOrphanedRecords
AS

delete mrcs
from 
	IC.map_ReportCardScoreID mrcs left join
	ReportCardScore rcs on mrcs.DestID = rcs.ID 
where
	rcs.ID is null