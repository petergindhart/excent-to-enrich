IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[IC].[Transform_Calendar]') AND xtype in (N'FN', N'IF', N'TF'))
	DROP FUNCTION [IC].[Transform_Calendar]
GO

CREATE FUNCTION IC.Transform_Calendar(@endYear int)
RETURNS TABLE
AS
RETURN
SELECT
	mc.DestID,
	c.StartDate,
	c.endDate,
	c.name,
	c.SchoolID,
	c.EndYear,
	exclude,
	TV_SchoolID = ms.DestID,
	RosterYearID = (select ID from RosterYear where startyear = @endYear - 1)
FROM
	IC.Calendar c join
	IC.Map_SchoolID ms on ms.schoolid = c.Schoolid left join
	IC.Map_CalendarID mc on mc.SchoolID = c.SchoolID and mc.endYear = c.endYear 	
where
	c.EndYear = @endYear and
	exclude =0 and
	SummerSchool = 0 and
	startDate is not null and endDate is not null	
GO