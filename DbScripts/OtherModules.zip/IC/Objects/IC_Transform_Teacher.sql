--#include ..\..\dbo\Objects\UserProfileView.sql

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[IC].[Transform_Teacher]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [IC].[Transform_Teacher]
GO

CREATE FUNCTION IC.Transform_Teacher (@endYear int, @ImportDate datetime)
RETURNS TABLE
AS 
RETURN
SELECT
	DestID = mt.DestID,		 	
--	e.startDate,
--	e.endDate,
	CurrentSchoolID = (select DestID from IC.Map_SchoolID ms where ms.SchoolID = ea.schoolID),
	SSN = CASE LEN(i.ssn) WHEN 9 THEN i.ssn ELSE NULL END,
	dbo.CamelCase(IsNull(i.FirstName,'')) AS FirstName,
	dbo.CamelCase(i.LastName) AS LastName,
	c.email,
	GenderID = (SELECT mev.DestID from IC.Map_EnumValueID mev join IC.Map_EnumTypeID met on mev.AttributeID = met.AttributeID and mev.Code = case i.Gender when  'M' then '02' else '01' end WHERE met.Element= 'adjCohortGender' and met.Object = 'Enrollment'),
	EthnicityID = (SELECT mev.DestID from IC.Map_EnumValueID mev join IC.Map_EnumTypeID met on mev.AttributeID = met.AttributeID and mev.Code = i.raceEthnicity WHERE met.Element= 'raceEthnicity' and met.Object = 'identity'),	
	 IsNull(a.Number, '') + ' ' + IsNull(prefix, '') + ' ' + IsNull(Street,'') + ' ' + IsNull(tag,'') + ' ' + IsNull('Apt ' + apt, '') AS condensed_street,
	City,
	[State],
	Zip,
	birthdate,
	c.workPhone,
	staffNumber,
	i.identityID, p.personID,	
	SOCSECNUM_VALIDATED = CASE LEN(i.ssn) WHEN 9 THEN i.ssn ELSE NULL END,
	UserProfileID = isnull((
		select t.UserProfileID
		from dbo.Teacher t
		where t.ID = mt.DestID),		
		case 
		when c.email is not null 
		then 
			(select top 1 ID -- Emails are mostly unique.  Top 1 to prevent the query from failing.
				from UserProfileView u
				where c.email = u.EmailAddress and u.Deleted is null
			)
		else null end
	)
FROM
	IC.Person p join
	(
		-- filter out teachers who aren't actually teaching this year
		SELECT 
			personID
		FROm
			IC.Teacher tch join
			IC.Trial tr on tch.TrialID = tr.TrialID join
			ic.Calendar cal on cal.calendarid = tr.CalendarID
		WHERE
			cal.EndYear = @endYear
		group by
			personID
	) tr on tr.personid = p.personID join
	IC.IC_Identity i on p.currentIdentityID = i.identityID AND p.personID = i.personID join	
--	(
--		SELECT
--			personid,
--			case when MAX(employmentID) as employmentID,
--			MIN(StartDate) AS StartDate,
--			case when MIN(EndDate) is null then null else MAX(EndDate) end AS EndDate
--		FROM
--			IC.Employment
--		group by
--			personid
--	) e on e.personID = p.personID join
	--IC.Employment e ON e.personID = p.personID join
	(	
			SELECT
				personId,
				mAX(schoolID) as schoolID				
			FROM
				IC.EmploymentAssignment
			where
				teacher = 1
			GROUP BY
				personId				
	) ea on ea.personID = p.personID join	
	IC.Map_SchoolID ms on ms.SchoolID = ea.SchoolID left join
	IC.Contact c on c.PersonId = p.personid left join	
	IC.Map_TeacherID mt on mt.PersonId = p.PersonID left join
	(
		SELECT
			personId,
			MAX(householdId) AS householdId,			
			MAX(memberID) AS memberID
		FROm
			IC.HouseHoldMember hmInternal
		WHERE
			(hmInternal.startDate IS NULL OR hmInternal.startDate <= @ImportDate) and 
			(hmInternal.endDate IS NULL OR hmInternal.endDate >= @ImportDate)
		GROUP BY			
			personId
	) hm on hm.personID = p.personID left join	
	IC.HouseHold h on h.householdID = hm.householdID left join
	(
		SELECT
			houseHoldID,
			MAX(addressID)	as addressID,
			MAX(LocationID) as locationID	
		FROM
			IC.HouseHoldLocation  hlInternal
		WHERE
			(hlInternal.startDate IS NULL OR hlInternal.startDate <= @ImportDate) and 
			(hlInternal.endDate IS NULL OR hlInternal.endDate >= @ImportDate) and
			mailing = 1 and 
			secondary = 0
		group by
			houseHoldID
	) hl on hl.householdId = h.householdID left join	
	IC.Address a on a.AddressID= hl.AddressID

GO
