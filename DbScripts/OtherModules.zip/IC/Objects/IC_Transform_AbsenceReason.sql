IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[IC].[Transform_AbsenceReason]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [IC].[Transform_AbsenceReason]
GO

CREATE FUNCTION IC.Transform_AbsenceReason(@endYear int)
RETURNS TABLE
AS
RETURN
SELECT
	mae.DestID,
	ae.code,
	ae.Description,
	IncludeInCount = case when [status] = 'T' then 0 else 1 end,
	ae.ExcuseID
FROm
	IC.AttendanceExcuse	ae join
	IC.Calendar c on c.calendarID = ae.CalendarID and c.EndYear = @endYear left join
	IC.Map_AbsenceReasonID mae on mae.excuseID = ae.ExcuseID 
WHERE
	c.EndYear= @endYear and
	(excuse IS NULL OR excuse <> 'X') and
	[status] IN ('A', 'T')

UNION ALL

-- there are absences that are valid but aren't associated with absences this is a catch all of sorts
SELECT
	DestID = (select destID from IC.Map_AbsenceReasonID where ExcuseID = -1),
	code = NULL,
	Description = 'Unknown',
	IncludeInCount = 1,
	ExcuseID = -1