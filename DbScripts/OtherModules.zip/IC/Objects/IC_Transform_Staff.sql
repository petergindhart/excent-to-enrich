IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[IC].[Transform_Staff]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [IC].[Transform_Staff]
GO

CREATE FUNCTION [IC].[Transform_Staff] (@endYear int, @ImportDate datetime)
RETURNS TABLE
AS
RETURN
select
	p.personID,
	p.staffNumber,
	ic.firstName,
	ic.middleName,
	ic.lastName,
	c.email,
	c.homePhone,
	c.workPhone,	
	c.cellPhone,
	ea.title,
	condensed_street = IsNull(a.Number, '') + ' ' + IsNull(prefix, '') + ' ' + IsNull(Street,'') + ' ' + IsNull(tag,'') + ' ' + IsNull('Apt ' + apt, ''),
	a.city,
	a.state,
	a.zip		
FROM
	IC.Person p join
	IC.IC_Identity ic on ic.personID = p.personID left join	
	IC.Contact c on c.personID = p.personID left join
	(
		SELECT
			personID,
			MAX(AssignmentID) As AssignmentID	
		FROM
			IC.EmploymentAssignment
		where			
			dbo.DateInRange(@ImportDate,startDate,EndDate)  = 1 AND
			title is not null
		group by
			personID
	) eaRollup on eaRollup.personID = p.personId left join	
	IC.EmploymentAssignment ea on ea.AssignmentID = eaRollup.AssignmentID	left join
	(
		SELECT
			personId,
			MAX(householdId) AS householdId,			
			MAX(memberID) AS memberID
		FROm
			IC.HouseHoldMember hmInternal
		WHERE
			(hmInternal.startDate IS NULL OR hmInternal.startDate <= @ImportDate) and 
			(hmInternal.endDate IS NULL OR hmInternal.endDate >= @ImportDate)
		GROUP BY			
			personId
	) hm on hm.personID = p.personID left join	
	IC.HouseHold h on h.householdID = hm.householdID left join
	(
		SELECT
			houseHoldID,
			MAX(addressID)	as addressID,
			MAX(LocationID) as locationID	
		FROM
			IC.HouseHoldLocation  hlInternal
		WHERE
			(hlInternal.startDate IS NULL OR hlInternal.startDate <= @ImportDate) and 
			(hlInternal.endDate IS NULL OR hlInternal.endDate >= @ImportDate) and
			mailing = 1 and 
			secondary = 0
		group by
			houseHoldID
	) hl on hl.householdId = h.householdID left join
	IC.Address a on a.AddressID= hl.AddressID	
where
	p.staffNumber is not null
	