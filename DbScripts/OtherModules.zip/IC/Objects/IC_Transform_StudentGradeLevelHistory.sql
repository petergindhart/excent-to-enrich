IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[IC].[Transform_StudentGradeLevelHistory]') AND OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [IC].[Transform_StudentGradeLevelHistory]
GO

CREATE VIEW [IC].[Transform_StudentGradeLevelHistory] AS 
select 
	StudentID = ms.DestID,
	GradeLevelID = icm.DestID,
	ice.StartDate, 
	EndDate = Coalesce(ice.EndDate, ry.EndDate)
FROM
	(
		select 
			personID,
			grade,
			MAX(EndYear) as EndYear,
			MIN(StartDate) as StartDate,
			case when MIN(IsNULL(EndDate,'')) = '1900-01-01 00:00:00.000' then NULL ELSE MAX(EndDate) END as EndDate  --MAX(endDate) as EndDate
		FROM
			IC.Enrollment ie
		WHERE
			ie.active = 1 and (ie.noShow IS NULL OR ie.noShow = 0) and					  
			ie.ServiceType <> 'S'
		group by
			personID, grade
	)ice join
	IC.Map_StudentID ms on ms.PersonID = ice.personID join
	Ic.Map_gradeLevelID icm on icm.[Name] = ice.grade join
	RosterYear ry on ry.StartYear = EndYear - 1