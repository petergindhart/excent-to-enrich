IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[IC].[Transform_ReportCardScore]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [IC].[Transform_ReportCardScore]
GO

CREATE FUNCTION IC.Transform_ReportCardScore(@endYear int)
RETURNS TABLE
AS
RETURN
SELECT
	mrcs.DestID,
	PercentageScore = 
		case 
			when [percent] is not null
				then [percent]
			when score LIKE  '%[0-9]%'
				then cast(score as float)
			else null
		end,
	LetterScore = 
		case 
			when score is not null and score NOT LIKE  '%[0-9]%'				
				then score
			else null
		end,
	ClassRosterID = mc.DestID,
	ReportCardItem = rci.DestID,
	StudentID = stu.DestID,
	gs.ScoreID
FROm	
	(
		select
			Max(scoreID) AS scoreID,
			calendarID,
			personid,
			termid,
			taskID,
			sectionID
		FROM
			IC.GradingScore
		GROUP BY
			calendarID,
			personid,
			termid,
			taskID,
			sectionID			
	) gsRollup join
	IC.GradingScore gs on gs.ScoreID = gsRollup.scoreID join
	IC.Calendar cal on gs.CalendarID = cal.CalendarID join		 
	IC.GradingTask gt on gs.TaskID = gt.TaskID join		
	IC.Map_ClassRosterID mc on mc.SectionId = gs.SectioNID join
	IC.Map_StudentID stu on stu.Personid = gs.personid join
	IC.Map_ReportCardItemID rci on rci.TaskID = gt.TaskID and (rci.UsesTerm = 0 OR rci.TermID = gs.TermID) left join
	IC.Map_ReportCardScoreID mrcs on mrcs.ScoreID = gs.ScoreID 
WHERE
	(gs.TaskID not between 2 AND 5 ) AND
	(gs.TaskID not in (81) ) AND
	(score is not null OR [percent] is not null) and
	cal.EndYear = @endYear
