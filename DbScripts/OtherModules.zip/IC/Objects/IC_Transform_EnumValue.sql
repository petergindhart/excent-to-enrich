IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'IC.Transform_EnumValue') AND OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW IC.Transform_EnumValue
GO

CREATE VIEW IC.Transform_EnumValue
AS
SELECT 
	DestID = mev.DestID,
	cd.Name,
	cd.Code,
	[Type] = met.DestID,
	DictionaryID,
	cd.attributeID	
FROM
	IC.CampusDictionary cd join
	IC.CampusAttribute ca on ca.AttributeID = cd.AttributeID join
	IC.Map_EnumTypeID met on met.Object = ca.Object and met.Element = ca.Element left join
	IC.Map_EnumValueID mev on mev.AttributeID = cd.AttributeID and mev.code = cd.code

UNION ALL

	SELECT
		DestID = mev.DestID,
		Name, 
		resType.code, 
		[Type] = met.DestID,		
		DictionaryID = -1,	
		attributeID = -1
	FROM
		IC.BehaviorResType resType join
		IC.Map_EnumTypeID met on met.Object = 'behaviorResolution' and met.Element = 'code' left join
		IC.Map_EnumValueID mev on mev.AttributeID = -1 and mev.code = resType.code
	where
		IsNumeric(resType.code) = 1 AND
		typeID < 28 OR typeID > 40

