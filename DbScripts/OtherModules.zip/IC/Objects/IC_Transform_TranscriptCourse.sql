IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'IC.Transform_TranscriptCourse') AND OBJECTPROPERTY(id, N'IsView') = 1)
	DROP VIEW IC.Transform_TranscriptCourse
GO

CREATE VIEW IC.Transform_TranscriptCourse 
AS
SELECT	
	StudentID = ms.DestID,
	RosterYearID = ry.ID,
	GradeLevelID = gl.DestID,
	SchoolID = sch.ID,
	Term = coalesce(ActualTerm, startTerm, EndTerm,''),
	CourseName,
	CourseNumber,
	tcr.CreditsEarned, 
	Score = case when [percent] is null then score else cast([percent] as varchar(10)) end 
FROM
	IC.TranscriptCourse tc join
	IC.Map_StudentID ms on ms.personid = tc.personid join
	IC.Map_GradeLevelID gl on gl.Name = tc.Grade join
	RosterYear ry on ry.StartYear = tc.StartYear join
	dbo.School sch on sch.Number = tc.SchoolNumber left join
	IC.TranscriptCredit tcr on tcr.TranscriptID = tc.TranscriptID
GO