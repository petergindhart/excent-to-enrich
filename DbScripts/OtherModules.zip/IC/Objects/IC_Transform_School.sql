IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[IC].[Transform_School]') AND OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [IC].[Transform_School]
GO

CREATE VIEW IC.Transform_School
AS
SELECT
	DestID = ms.DestID,
	Name, 
	number,
	sch.SchoolID,
	Abbreviation = dbo.CreateAcronym(Name)
FROM
	IC.School sch left join
	IC.Map_SchoolID ms on ms.SchoolID =  sch.SchoolID