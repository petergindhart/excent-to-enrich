IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[IC].[Transform_StudentGuardianRelationship]') AND OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [IC].[Transform_StudentGuardianRelationship]
GO

CREATE VIEW IC.Transform_StudentGuardianRelationship
AS
SELECT
	msgr.DestID,
	rt.CleanName
FROM
	(
		select 
			CleanName = IC.GetCleanRelationshipName(name)
		FROM	
			IC.RelationshipType 
		group by
			IC.GetCleanRelationshipName(name)
	) rt left join
	IC.Map_StudentGuardianRelationshipID msgr on msgr.Name = CleanName