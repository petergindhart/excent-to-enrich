IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[IC].[GetCleanRelationshipName]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [IC].[GetCleanRelationshipName]
GO

CREATE FUNCTION IC.GetCleanRelationshipName(@name varchar(50))
RETURNS Varchar(50)
AS
BEGIN
	return (select case when charindex('/', @name,0) > 0 then substring(@name,0, (CHARINDEX('/',@name,1))) else @name end	)
END