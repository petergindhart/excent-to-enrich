IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[IC].[Transform_StudentRosterYear]') AND xtype in (N'FN', N'IF', N'TF'))
	DROP FUNCTION [IC].[Transform_StudentRosterYear]
GO

CREATE FUNCTION IC.Transform_StudentRosterYear(@endYear int, @ImportDate dateTime, @importRosterYear uniqueidentifier)
RETURNS TABLE
AS
RETURN
SELECT
	m.DestID,
	RosterYearID = @importRosterYear,
	StudentID  = impstu.DestID,
	DisciplineReferrals	= (select count(*) from DisciplineIncident  where StudentID = impstu.DestID and RosterYearID = @importRosterYear ), 
	DailyAbsences		= (
		select count(*) 
		from Absence ab join
		AbsenceReason reason on ab.ReasonID = reason.ID
		where IncludeInCount = 1 AND StudentID = impstu.DestID and RosterYearID = @importRosterYear),
	Guardian =  IC.GetGuardians(impstu.personid)
FROM
	IC.Transform_Student(@endYear, @ImportDate) impstu  left join
	IC.Map_StudentRosterYearID m on m.STudentID = impstu.DestID and m.RosterYearID = @importRosterYear
where
	impstu.DestID is not null
GO
