/****** Object:  UserDefinedFunction [IC].[Transform_GradeLevel]    Script Date: 06/04/2009 16:05:31 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[IC].[Transform_GradeLevel]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [IC].[Transform_GradeLevel]
GO

CREATE FUNCTION IC.Transform_GradeLevel(@endYear int)
RETURNS TABLE
AS
RETURN
SELECT	
	mgl.DestID,
	gl2.Name,
	Sequence = gl2.seq,
	BitMask = BM.MinGradeMask
FROM
	(
		select 
			distinct 
			gl.Name, 
			gl.Seq
		FROM
			IC.GradeLevel gl join
			IC.Calendar cal on gl.CalendarID = cal.CalendarID 
		WHERE
			cal.EndYear = @endYear
	) gl2 left join	
	IC.Map_GradeLevelID mgl on mgl.Name = gl2.Name left join
	(
		select
			MinGradeName,
			MinGradeMask
		FROm
			GradeRangeBitMask
		group by
			MinGradeName,
			MinGradeMask			
	) BM on gl2.Name  like '%' + BM.MinGradeName
GO
