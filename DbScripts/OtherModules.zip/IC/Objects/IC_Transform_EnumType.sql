IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'IC.Transform_EnumType') AND OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW IC.Transform_EnumType
GO

CREATE VIEW IC.Transform_EnumType
AS
SELECT
	DestID = met.DestID,
	ca.AttributeID,
	ca.object,
	ca.element
FROM
	IC.CampusAttribute ca join
	IC.Map_EnumTypeID met on met.object = ca.object and met.element = ca.element


