IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[IC].[Transform_Absence]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [IC].[Transform_Absence]
GO

CREATE FUNCTION IC.Transform_Absence (@endYear int, @importRosterYear uniqueidentifier)
RETURNS TABLE
AS
RETURN

SELECT
	StudentID = stu.DestID,
	AbsenceDate = a.[Date],
	ReasonID = mar.DestID,
	RosterYearID = @importRosterYear,
	a.personID,
	a.excuseID
FROm
	(
		select 
			personID, a.calendarID, date, excuseID
		FROM
			IC.Attendance a join
			IC.Calendar c on a.CalendarID = c.CalendarID
		WHERE
			c.EndYear= @endYear
		group by
			personID, a.calendarID, date, excuseID
	) a	join
	IC.Map_StudentId stu on stu.Personid= a.Personid join	
	IC.Map_AbsenceReasonID mar on mar.ExcuseID = case when a.ExcuseID is not null then a.ExcuseID else -1 end