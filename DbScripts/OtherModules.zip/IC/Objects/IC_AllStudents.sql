--#include IC_Transform_Student.sql
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[IC].[AllStudents]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [IC].[AllStudents]
GO

CREATE FUNCTION [IC].[AllStudents] (@endYear int, @importDate datetime)
RETURNS TABLE
AS
RETURN
SELECT PersonID, studentNumber, curStu.ID
FROM
	IC.Transform_Student(@endYear, @importDate) stu join
	Student curStu on curStu.Number = stu.studentnumber
WHERE
	IsNumeric(curStu.number) = 1