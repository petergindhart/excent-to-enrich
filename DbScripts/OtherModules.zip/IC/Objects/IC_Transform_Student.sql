--#include IC_GetAttributeID.sql
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[IC].[Transform_Student]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [IC].[Transform_Student]
GO

CREATE FUNCTION IC.Transform_Student (@endYear int, @ImportDate datetime)
RETURNS TABLE
AS 
RETURN
SELECT
	DestID = ms.DestID,	
	GenderID = (SELECT mev.DestID from IC.Map_EnumValueID mev join IC.Map_EnumTypeID met on mev.AttributeID = met.AttributeID and mev.Code = case i.Gender when  'M' then '02' else '01' end WHERE met.Element= 'adjCohortGender' and met.Object = 'Enrollment'),
	EthnicityID = (SELECT mev.DestID from IC.Map_EnumValueID mev join IC.Map_EnumTypeID met on mev.AttributeID = met.AttributeID and mev.Code = i.raceEthnicity WHERE met.Element= 'raceEthnicity' and met.Object = 'identity'),
	GradeLevelID = (SELECT Destid From Ic.Map_gradeLevelID where [Name] = e.grade),
	SchoolID = (select DestID from IC.Map_SchoolID ms where ms.SchoolID = cal.schoolID),
	
	GiftedAndTalented = case when giftedTalented > 0 then 1 else 0 end,		
	SOCSECNUM_VALIDATED = CASE LEN(i.ssn) WHEN 9 THEN i.ssn ELSE NULL END, 

	FreeLunch 			= CASE WHEN mealStatus = '01' THEN 1 ELSE 0 END,
	x_GiftedAcademically = case when giftedTalented between 1 and 3 then 1 else 0 end ,	
	cum_gpa AS cumulative_gpa, studentNUmber,
	lastName, firstName, middleName, birthdate, p.PersonId, e.enrollmentID, hm.memberID, h.householdID, hl.locationID, a.addressid, 
	IsNull(h.phone, c.HomePhone) AS HomePhone, IsNull(a.Number, '') + ' ' + IsNull(prefix, '') + ' ' + IsNull(Street,'') + ' ' + IsNull(tag,'') + ' ' + IsNull('Apt ' + apt, '') AS condensed_street, [state], zip, a.city,
	IsHaspanic = IsNull(i.hispanicEthnicity,0),
	x_FreeLunchID = (SELECT DestID from IC.Map_ENumValueID where Code = e.mealStatus AND AttributeID = IC.GetAttributeID('enrollment','mealStatus')),
	x_CBLAStatus = cast(null as uniqueidentifier), --(SELECT DestID from IC.Map_ENumValueID where Code = e.cblaStatus AND AttributeID = IC.GetAttributeID('enrollment','cblaStatus')) --this actually references a table Planstate, but it was empty
	x_DisabilityType = (SELECT DestID from IC.Map_ENumValueID where Code = e.disability1 AND AttributeID = IC.GetAttributeID('enrollment','disability1')),
	x_ESL = (SELECT DestID from IC.Map_ENumValueID where Code = e.esl AND AttributeID = IC.GetAttributeID('enrollment','esl')),
	x_giftedTalented = (SELECT DestID from IC.Map_ENumValueID where Code = e.giftedTalented AND AttributeID = IC.GetAttributeID('enrollment','giftedTalented')),
	x_IEP = case 
			when specialEdStatus is null then 0 
			when specialEdStatus = 'N' then 0 
			when specialEdStatus = 'Y' then 1				
			else specialEdStatus
		end,
	x_language = (SELECT DestID from IC.Map_ENumValueID where Code = e.language AND AttributeID = IC.GetAttributeID('enrollment','language')),
	x_englishProficiency = (SELECT DestID from IC.Map_ENumValueID where Code = e.englishProficiency AND AttributeID = IC.GetAttributeID('enrollment','englishProficiency')),
	x_section504 = case when section504 is null then 0 else section504 end,
	x_spedExitDate = spedExitDate,
	x_CSAP_A = csap.[csap-a],
	StateID
FROM
	IC.Person p join
	IC.IC_Identity i on p.currentIdentityID = i.identityID AND p.personID = i.personID join	
	(
		SELECT
			max(enrollmentID) AS enrollmentID,
			personID
		FROm
			IC.Enrollment eInternal
		WHERE
			eInternal.EndYear = @endYear and
			eInternal.active = 1 and (eInternal.noShow IS NULL OR eInternal.noShow = 0) and	
			(eInternal.EndDate is null OR eInternal.endDate >= @ImportDate) AND
			(eInternal.StartDate is null or eInternal.StartDate <= @ImportDate)	 and		  
			eInternal.ServiceType <> 'S'	
		group by
			personID		
	) eRollup on p.personID = eRollup.personID join	
	IC.Enrollment e on eRollup.enrollmentID = e.enrollmentID join
	IC.Calendar cal on cal.calendarID = e.CalendarID left join
	IC.Contact c on p.PersonID = c.PersonID left join
	IC.Map_StudentID ms on ms.PersonId = p.personID left join
	(
		SELECT
			personId,
			MAX(householdId) AS householdId,			
			MAX(memberID) AS memberID
		FROm
			IC.HouseHoldMember hmInternal
		WHERE
			(hmInternal.startDate IS NULL OR hmInternal.startDate <= @ImportDate) and 
			(hmInternal.endDate IS NULL OR hmInternal.endDate >= @ImportDate)
		GROUP BY			
			personId
	) hm on hm.personID = p.personID left join	
	IC.HouseHold h on h.householdID = hm.householdID left join
	(
		SELECT
			houseHoldID,
			MAX(addressID)	as addressID,
			MAX(LocationID) as locationID	
		FROM
			IC.HouseHoldLocation  hlInternal
		WHERE
			(hlInternal.startDate IS NULL OR hlInternal.startDate <= @ImportDate) and 
			(hlInternal.endDate IS NULL OR hlInternal.endDate >= @ImportDate) and
			mailing = 1 and 
			secondary = 0
		group by
			houseHoldID
	) hl on hl.householdId = h.householdID left join	
	IC.Address a on a.AddressID= hl.AddressID left join
	(
		SELECT 
			p.personID, t.Grade, SUM(t.gpaWeight * t.gpaValue)/SUM(t.gpaWeight) cum_gpa
		FROM
			IC.Person p JOIN			
			IC.TranscriptCourse t ON t.personID = p.personID			
		WHERE 
			t.EndYear = @endYear AND
			t.gpaValue IS NOT NULL			
		GROUP BY 
			p.personID, t.Grade
		HAVING 
			SUM(t.gpaWeight) > 0
	) gpa on gpa.personid= p.personid and gpa.grade = e.grade left join
	IC.CSAP csap on csap.studentid = p.studentNumber
	
	
	