IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[IC].[Transform_Person]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [IC].[Transform_Person]
GO

CREATE FUNCTION IC.Transform_Person 
(
	@ImportDate datetime
)
RETURNS TABLE
AS 
RETURN
select 
	mp.DestID,
	TypeID = 'P',
	allPeople.identityID,
	allPeople.lastName,
	allPeople.firstName,
	allPeople.middleName,	
	IsNull(h.phone, con.HomePhone) AS HomePhone,
	con.workPhone,
	con.cellPhone,
	con.email,
	IsNull(a.Number, '') + ' ' + IsNull(prefix, '') + ' ' + IsNull(Street,'') + ' ' + IsNull(tag,'') + ' ' + IsNull('Apt ' + apt, '') AS condensed_street, [state], zip, a.city
from
	IC.IC_Identity allPeople join
	(
		select ic.personID, MAX(identityID) as maxIdentity
		From 
			IC.Person p left join
			IC.IC_Identity ic on ic.PersonID = p.personID join
			IC.RelatedPair rp on rp.personID1 = p.personID
		WHERE
			p.studentNumber is null
		GROUP BY
			ic.personID
	) parents on allPeople.identityID = parents.maxIdentity  left join
	IC.Contact con on con.personID = parents.personID  left join
	(
		SELECT
			personId,
			MAX(householdId) AS householdId,			
			MAX(memberID) AS memberID
		FROm
			IC.HouseHoldMember hmInternal
		WHERE
			(hmInternal.startDate IS NULL OR hmInternal.startDate <= @ImportDate) and 
			(hmInternal.endDate IS NULL OR hmInternal.endDate >= @ImportDate)
		GROUP BY			
			personId
	) hm on hm.personID = parents.personID left join	
	IC.HouseHold h on h.householdID = hm.householdID left join
	(
		SELECT
			houseHoldID,
			MAX(addressID)	as addressID,
			MAX(LocationID) as locationID	
		FROM
			IC.HouseHoldLocation  hlInternal
		WHERE
			(hlInternal.startDate IS NULL OR hlInternal.startDate <= @ImportDate) and 
			(hlInternal.endDate IS NULL OR hlInternal.endDate >= @ImportDate) and
			mailing = 1 and 
			secondary = 0
		group by
			houseHoldID
	) hl on hl.householdId = h.householdID left join
	IC.Address a on a.AddressID= hl.AddressID left join
	IC.Map_PersonID mp on mp.IdentityID =allPeople.IdentityID