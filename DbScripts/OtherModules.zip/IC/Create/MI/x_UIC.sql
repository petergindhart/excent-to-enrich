IF (SELECT DistrictState FROM SystemSettings) IN ('MI','CO')
BEGIN
	IF NOT EXISTS (SELECT * FROM VC3ETL.LoadColumn where ID= '26AA6CA4-3F83-43D2-B585-FD2F40121124')
	BEGIN		
		INSERT INTO [VC3ETL].[LoadColumn]
			   ([ID]
			   ,[LoadTable]
			   ,[SourceColumn]
			   ,[DestColumn]
			   ,[ColumnType]
			   ,[UpdateOnDelete]
			   ,[DeletedValue]
			   ,[NullValue])
		 VALUES
			   ('26AA6CA4-3F83-43D2-B585-FD2F40121124',
			   'F0EC0B8D-2848-41AF-9E9D-C0036791FCBE',
			   'StateID',
			   '',
			   'C',
			   0,
			   NULL,
			   NULL
		)
	END	
	ELSE
	
	UPDATE VC3ETL.LoadColumn
		SET DestColumn = 
			case (SELECT DistrictState FROM SystemSettings)			
				when 'MI' THEN 'x_UIC' 
				when 'CO' THEN 'x_SASID' 
			END
		WHERE ID ='26AA6CA4-3F83-43D2-B585-FD2F40121124'		
END