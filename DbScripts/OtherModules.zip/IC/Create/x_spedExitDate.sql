INSERT INTO dbo.ExtendedPropertyDefinition (ID, ExtendedPropertyTypeDefinitionID, ColumnName, DisplayName) VALUES ('BFAEB702-ADA0-49CE-A12F-6E6450D05019', 'B1BA406A-80C4-44D0-8E36-9EC34094C553', 'x_spedExitDate', 'Special Ed Exit Date')
ALTER TABLE dbo.Student ADD x_spedExitDate  datetime  NULL 

DECLARE @ID							uniqueidentifier
DECLARE @Name						varchar(100)
DECLARE @TableID					uniqueidentifier
DECLARE @DisplayExpression			varchar(1000)
DECLARE @ValueExpression			varchar(1000)
DECLARE @AllowGrouping				bit
DECLARE @AllowedValuesExpression	varchar(1000)
DECLARE @SchemaDataType				char(1)
DECLARE @ViewTaskID					int

SET @ID								= '09F7527E-EF61-41C4-B89A-4B0F3D566E93'
SET @TableID						= 'F210EF27-1FBA-4518-B3F3-41DD8AFB4615'
SET @Name							= 'Special Ed Exit Date'
SET @DisplayExpression				= NULL
SET @ValueExpression				= '{this}.x_spedExitDate'
SET @AllowGrouping					= 1
SET @AllowedValuesExpression		= NULL
SET @SchemaDataType					= 'D'
SET @ViewTaskID						= null


INSERT INTO VC3Reporting.ReportSchemaColumn
(
Id,
[Name],
SchemaTable,
SchemaDataType,
DisplayExpression,
ValueExpression,
OrderExpression,
LinkExpression,
LinkFormat,
IsSelectColumn,
IsFilterColumn,
IsParameterColumn,
IsGroupColumn,
IsOrderColumn,
IsAggregated,
AllowedValuesExpression,
[Sequence],
Width
)
VALUES 
(
@ID, 
@Name,
@TableID, 
@SchemaDataType,
@DisplayExpression,
@ValueExpression,
null , --OrderExpression
null , --LinkExpression
null , --LinkFormat
1 , --IsSelectColumn
1 , --IsFilterColumn
1 , --IsParameterColumn
@AllowGrouping , --IsGroupColumn
1 , --IsOrderColumn
0, --IsAggregated
@AllowedValuesExpression,
100,	-- [Sequence]
null						
)

INSERT INTO ReportSchemaColumn
(
ID,
ViewTaskID
)
VALUES
(
@ID,
@ViewTaskID
)

INSERT INTO VC3ETL.LoadColumn VALUES ('98CDCA16-44B5-4597-AF2C-B576A91A07FF', 'F0EC0B8D-2848-41AF-9E9D-C0036791FCBE', 'x_spedExitDate' , 'x_spedExitDate' , 'C',0, NULL,NULL)
