INSERT INTO dbo.ExtendedPropertyDefinition (ID, ExtendedPropertyTypeDefinitionID, ColumnName, DisplayName) VALUES ('3D61BC27-DD6B-4018-83CE-21F9694292F2', 'B1BA406A-80C4-44D0-8E36-9EC34094C553', 'x_ESL', 'ESL')
ALTER TABLE dbo.Student ADD x_ESL uniqueidentifier  NULL 
CONSTRAINT FK_Student_x_ESL REFERENCES dbo.EnumValue (ID)

INSERT INTO EnumType VALUES ('246E2268-8F18-4DA6-9901-9C557B172596' , 'ESL', 1,0, NULL)
INSERT INTO IC.Map_EnumTypeID VALUES ('enrollment', 'ESL', 0, '246E2268-8F18-4DA6-9901-9C557B172596')

DECLARE @ID							uniqueidentifier
DECLARE @Name						varchar(100)
DECLARE @TableID					uniqueidentifier
DECLARE @DisplayExpression			varchar(1000)
DECLARE @ValueExpression			varchar(1000)
DECLARE @AllowGrouping				bit
DECLARE @AllowedValuesExpression	varchar(1000)
DECLARE @SchemaDataType				char(1)
DECLARE @ViewTaskID					int

SET @ID								= 'A42B7367-5BDA-4B30-A831-EC0F44C995FC'
SET @TableID						= 'F210EF27-1FBA-4518-B3F3-41DD8AFB4615'
SET @Name							= 'ESL'
SET @DisplayExpression				= Replace( '(select DisplayValue from EnumValue where Id=stu.x_ESL)', 'stu.', '{this}.' )
SET @ValueExpression				= Replace( 'stu.x_ESL', 'stu.', '{this}.' )
SET @AllowGrouping					= 1
SET @AllowedValuesExpression		= 'select v.ID,  v.DisplayValue  from EnumValue v join EnumType t on t.ID = v.Type where t.Type = ''ESL'' order by v.DisplayValue'
SET @SchemaDataType					= 'G'
SET @ViewTaskID						= null

INSERT INTO VC3Reporting.ReportSchemaColumn
(
Id,
[Name],
SchemaTable,
SchemaDataType,
DisplayExpression,
ValueExpression,
OrderExpression,
LinkExpression,
LinkFormat,
IsSelectColumn,
IsFilterColumn,
IsParameterColumn,
IsGroupColumn,
IsOrderColumn,
IsAggregated,
AllowedValuesExpression,
[Sequence],
Width
)
VALUES 
(
@ID, 
@Name,
@TableID, 
@SchemaDataType,
@DisplayExpression,
@ValueExpression,
null , --OrderExpression
null , --LinkExpression
null , --LinkFormat
1 , --IsSelectColumn
1 , --IsFilterColumn
1 , --IsParameterColumn
@AllowGrouping , --IsGroupColumn
1 , --IsOrderColumn
0, --IsAggregated
@AllowedValuesExpression,
100,	-- [Sequence]
null						
)

INSERT INTO ReportSchemaColumn
(
ID,
ViewTaskID
)
VALUES
(
@ID,
@ViewTaskID
)

INSERT INTO VC3ETL.LoadColumn VALUES ('43878BCE-C6E9-44F4-984D-360FA1704CEE', 'F0EC0B8D-2848-41AF-9E9D-C0036791FCBE', 'x_ESL' , 'x_ESL' , 'C',0, NULL,NULL)
