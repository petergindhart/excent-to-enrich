INSERT INTO dbo.ExtendedPropertyDefinition (ID, ExtendedPropertyTypeDefinitionID, ColumnName, DisplayName) VALUES ('D1D0D53E-8722-4C2E-997A-8F84342D86C6', 'B1BA406A-80C4-44D0-8E36-9EC34094C553', 'x_language', 'Language')
ALTER TABLE dbo.Student ADD x_language uniqueidentifier  NULL 
CONSTRAINT FK_Student_x_language REFERENCES dbo.EnumValue (ID)

INSERT INTO EnumType VALUES ('DE57DE9E-3BD5-43BF-9641-FF283C2B651D' , 'language', 1,0, NULL)
INSERT INTO IC.Map_EnumTypeID VALUES ('enrollment', 'language', 0, 'DE57DE9E-3BD5-43BF-9641-FF283C2B651D')

DECLARE @ID							uniqueidentifier
DECLARE @Name						varchar(100)
DECLARE @TableID					uniqueidentifier
DECLARE @DisplayExpression			varchar(1000)
DECLARE @ValueExpression			varchar(1000)
DECLARE @AllowGrouping				bit
DECLARE @AllowedValuesExpression	varchar(1000)
DECLARE @SchemaDataType				char(1)
DECLARE @ViewTaskID					int

SET @ID								= 'D84690CB-1253-4F55-8884-09CD3D8986A8'
SET @TableID						= 'F210EF27-1FBA-4518-B3F3-41DD8AFB4615'
SET @Name							= 'Language Background'
SET @DisplayExpression				= Replace( '(select DisplayValue from EnumValue where Id=stu.x_language)', 'stu.', '{this}.' )
SET @ValueExpression				= Replace( 'stu.x_language', 'stu.', '{this}.' )
SET @AllowGrouping					= 1
SET @AllowedValuesExpression		= 'select v.ID,  v.DisplayValue  from EnumValue v join EnumType t on t.ID = v.Type where t.Type = ''language'' order by v.DisplayValue'
SET @SchemaDataType					= 'G'
SET @ViewTaskID						= null

INSERT INTO VC3Reporting.ReportSchemaColumn
(
Id,
[Name],
SchemaTable,
SchemaDataType,
DisplayExpression,
ValueExpression,
OrderExpression,
LinkExpression,
LinkFormat,
IsSelectColumn,
IsFilterColumn,
IsParameterColumn,
IsGroupColumn,
IsOrderColumn,
IsAggregated,
AllowedValuesExpression,
[Sequence],
Width
)
VALUES 
(
@ID, 
@Name,
@TableID, 
@SchemaDataType,
@DisplayExpression,
@ValueExpression,
null , --OrderExpression
null , --LinkExpression
null , --LinkFormat
1 , --IsSelectColumn
1 , --IsFilterColumn
1 , --IsParameterColumn
@AllowGrouping , --IsGroupColumn
1 , --IsOrderColumn
0, --IsAggregated
@AllowedValuesExpression,
100,	-- [Sequence]
null						
)

INSERT INTO ReportSchemaColumn
(
ID,
ViewTaskID
)
VALUES
(
@ID,
@ViewTaskID
)

INSERT INTO VC3ETL.LoadColumn VALUES ('62970BB3-BCA5-4A9F-91CB-8961A2C4E4ED', 'F0EC0B8D-2848-41AF-9E9D-C0036791FCBE', 'x_language' , 'x_language' , 'C',0, NULL,NULL)