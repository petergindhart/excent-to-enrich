if not exists(select * from securityTaskCategory where id='CF81565B-48FF-493D-9760-7FD6459ED6C8') 
begin
	INSERT INTO SecurityTaskCategory(ID, Name, ParentID, Description, Sequence) VALUES('CF81565B-48FF-493D-9760-7FD6459ED6C8','Free / Reduced Lunch','968A45F2-0F55-4144-92A1-A4D875496C56',null,2)

insert into SecurityTaskType (ID, Name, DisplayName) values('CA78F72A-AC96-464D-A788-691F5CE8185A', 'View Student Free / Reduced Lunch', 'View Student Free / Reduced Lunch')
insert into SecurityTask (ID, SecurityTaskTypeID, CategoryID, Sequence, ContextTypeID, TargetID) values(36, 'CA78F72A-AC96-464D-A788-691F5CE8185A', 'CF81565B-48FF-493D-9760-7FD6459ED6C8', 2, 'F069CEA9-B0F4-44E2-AD7D-EE03E3F7C0D4', NULL)

INSERT INTO SecurityRoleSecurityTask(RoleID, TaskID) VALUES('6A301FDB-EB66-419E-BB9D-A76F8B4DD568',36)
INSERT INTO SecurityRoleSecurityTask(RoleID, TaskID) VALUES('A798648D-777C-411D-B2BA-682400B3EDE6',36)
INSERT INTO SecurityRoleSecurityTask(RoleID, TaskID) VALUES('AAB731E0-2493-47C4-913B-89F1A5E1BC70',36)
INSERT INTO SecurityRoleSecurityTask(RoleID, TaskID) VALUES('124AF265-9085-45AA-BCCD-8C0012F1BA95',36)
END

insert into EnumType values ('A2F0A81F-93DC-4684-B65A-AEB6985DF127',  'FRL', 0, 0, 'Free/Reduced Lunch')
INSERT INTO IC.Map_EnumTypeID  VALUES ('enrollment', 'mealStatus', 0, 'A2F0A81F-93DC-4684-B65A-AEB6985DF127')

alter table dbo.Student 
add x_FreeLunchID uniqueidentifier NULL 
constraint FK_Student_x_FreeLunchID references dbo.EnumValue (ID)

insert into ExtendedPropertyDefinition (ID, ViewTaskID, ExtendedPropertyTypeDefinitionId, ColumnName, DisplayName)  values (
	'754588E5-63B0-4B28-86AE-AAF5DB0B0F6B',
	36,
	'B1BA406A-80C4-44D0-8E36-9EC34094C553', 
	'x_FreeLunchID', 
	'Free/Reduced Lunch' 
)


-- insert schema column
DECLARE @ID							uniqueidentifier
DECLARE @Name						varchar(100)
DECLARE @TableID					uniqueidentifier
DECLARE @DisplayExpression			varchar(1000)
DECLARE @ValueExpression			varchar(1000)
DECLARE @AllowGrouping				bit
DECLARE @AllowedValuesExpression	varchar(1000)
DECLARE @SchemaDataType				char(1)
DECLARE @ViewTaskID					int

SET @ID								= 'F9FBB965-8979-486E-B5C4-013ABC825738'
SET @TableID						= 'F210EF27-1FBA-4518-B3F3-41DD8AFB4615'
SET @Name							= 'Free/Reduced Lunch'
SET @DisplayExpression				= Replace( '(select DisplayValue from EnumValue where Id=stu.x_FreeLunchID)', 'stu.', '{this}.' )
SET @ValueExpression				= Replace( 'stu.x_FreeLunchID', 'stu.', '{this}.' )
SET @AllowGrouping					= 1
SET @AllowedValuesExpression		= 'select v.ID, v.DisplayValue from EnumValue v join EnumType t on t.ID = v.Type where t.Type = ''FRL'' order by v.DisplayValue'
SET @SchemaDataType					= 'G'
SET @ViewTaskID						= 36

INSERT INTO VC3Reporting.ReportSchemaColumn
(
Id,
[Name],
SchemaTable,
SchemaDataType,
DisplayExpression,
ValueExpression,
OrderExpression,
LinkExpression,
LinkFormat,
IsSelectColumn,
IsFilterColumn,
IsParameterColumn,
IsGroupColumn,
IsOrderColumn,
IsAggregated,
AllowedValuesExpression,
[Sequence],
Width
)
VALUES 
(
@ID, 
@Name,
@TableID, 
@SchemaDataType,
@DisplayExpression,
@ValueExpression,
null , --OrderExpression
null , --LinkExpression
null , --LinkFormat
1 , --IsSelectColumn
1 , --IsFilterColumn
1 , --IsParameterColumn
@AllowGrouping , --IsGroupColumn
1 , --IsOrderColumn
0, --IsAggregated
@AllowedValuesExpression,
100,	-- [Sequence]
null						
)


INSERT INTO ReportSchemaColumn
(
ID,
ViewTaskID
)
VALUES
(
@ID,
@ViewTaskID
)

INSERT INTO VC3ETL.LoadColumn VALUES ( 
	'7A35FFF6-FC75-4653-90D1-3010F68272FA',
	'F0EC0B8D-2848-41AF-9E9D-C0036791FCBE',
	'x_FreeLunchID', 
	'x_FreeLunchID', 
	'C', 
	0, 
	NULL, 
	NULL
)



