INSERT INTO dbo.ExtendedPropertyDefinition (ID, ExtendedPropertyTypeDefinitionID, ColumnName, DisplayName, IsIdentifier) VALUES ('ECC1440B-B4B5-432A-8DEC-1EB67B57F08F', 'B1BA406A-80C4-44D0-8E36-9EC34094C553', 'x_SASID', 'SASID',1)
GO

ALTER TABLE dbo.Student ADD
	x_SASID varchar(50) NULL
GO

-- insert schema column
DECLARE @ID							uniqueidentifier
DECLARE @Name						varchar(100)
DECLARE @TableID					uniqueidentifier
DECLARE @DisplayExpression			varchar(1000)
DECLARE @ValueExpression			varchar(1000)
DECLARE @AllowGrouping				bit
DECLARE @AllowedValuesExpression	varchar(1000)
DECLARE @SchemaDataType				char(1)

SET @ID								= '17C7A886-D814-4227-A4ED-B9C00E34B698'
SET @TableID						= 'F210EF27-1FBA-4518-B3F3-41DD8AFB4615'
SET @Name							= 'SASID'
SET @DisplayExpression				= null
SET @ValueExpression				= '{this}.x_SASID'
SET @AllowGrouping					= 0
SET @AllowedValuesExpression		= null
SET @SchemaDataType					= 'T'

INSERT INTO VC3Reporting.ReportSchemaColumn
(
Id,
[Name],
SchemaTable,
SchemaDataType,
DisplayExpression,
ValueExpression,
OrderExpression,
LinkExpression,
LinkFormat,
IsSelectColumn,
IsFilterColumn,
IsParameterColumn,
IsGroupColumn,
IsOrderColumn,
IsAggregated,
AllowedValuesExpression,
[Sequence],
Width
)
VALUES 
(
@ID, 
@Name,
@TableID, 
@SchemaDataType,
@DisplayExpression,
@ValueExpression,
null , --OrderExpression
null , --LinkExpression
null , --LinkFormat
1 , --IsSelectColumn
1 , --IsFilterColumn
1 , --IsParameterColumn
@AllowGrouping , --IsGroupColumn
1 , --IsOrderColumn
0, --IsAggregated
@AllowedValuesExpression,
100,	-- [Sequence]
null						
)

INSERT INTO ReportSchemaColumn
(
ID,
ViewTaskID
)
VALUES
(
@ID,
NULL
)


IF (SELECT DistrictState FROM SystemSettings) IN ('MI','CO')
BEGIN
	IF NOT EXISTS (SELECT * FROM VC3ETL.LoadColumn where ID= '26AA6CA4-3F83-43D2-B585-FD2F40121124')
	BEGIN		
		INSERT INTO [VC3ETL].[LoadColumn]
			   ([ID]
			   ,[LoadTable]
			   ,[SourceColumn]
			   ,[DestColumn]
			   ,[ColumnType]
			   ,[UpdateOnDelete]
			   ,[DeletedValue]
			   ,[NullValue])
		 VALUES
			   ('26AA6CA4-3F83-43D2-B585-FD2F40121124',
			   'F0EC0B8D-2848-41AF-9E9D-C0036791FCBE',
			   'StateID',
			   '',
			   'C',
			   0,
			   NULL,
			   NULL
		)
	END	
	ELSE
	
	UPDATE VC3ETL.LoadColumn
		SET DestColumn = 
			case (SELECT DistrictState FROM SystemSettings)			
				when 'MI' THEN 'x_UIC' 
				when 'CO' THEN 'x_SASID' 
			END
		WHERE ID ='26AA6CA4-3F83-43D2-B585-FD2F40121124'		
END