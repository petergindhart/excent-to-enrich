INSERT INTO dbo.ExtendedPropertyDefinition (ID, ExtendedPropertyTypeDefinitionID, ColumnName, DisplayName) VALUES ('28562A4B-7097-4A2E-86AB-DFE0B7052D32', 'B1BA406A-80C4-44D0-8E36-9EC34094C553', 'x_englishProficiency', 'Language Proficiency')
ALTER TABLE dbo.Student ADD x_englishProficiency uniqueidentifier  NULL 
CONSTRAINT FK_Student_x_englishProficiency REFERENCES dbo.EnumValue (ID)

INSERT INTO EnumType VALUES ('2FEEADA2-AC05-4F03-B99C-B7A2E01E2C55' , 'englishProficiency', 1,0, NULL)
INSERT INTO IC.Map_EnumTypeID VALUES ('enrollment', 'englishProficiency', 0, '2FEEADA2-AC05-4F03-B99C-B7A2E01E2C55')

DECLARE @ID							uniqueidentifier
DECLARE @Name						varchar(100)
DECLARE @TableID					uniqueidentifier
DECLARE @DisplayExpression			varchar(1000)
DECLARE @ValueExpression			varchar(1000)
DECLARE @AllowGrouping				bit
DECLARE @AllowedValuesExpression	varchar(1000)
DECLARE @SchemaDataType				char(1)
DECLARE @ViewTaskID					int

SET @ID								= '4C3CD809-DE4F-4331-937D-6C9D5D211845'
SET @TableID						= 'F210EF27-1FBA-4518-B3F3-41DD8AFB4615'
SET @Name							= 'Language Proficiency'
SET @DisplayExpression				= Replace( '(select DisplayValue from EnumValue where Id=stu.x_englishProficiency)', 'stu.', '{this}.' )
SET @ValueExpression				= Replace( 'stu.x_englishProficiency', 'stu.', '{this}.' )
SET @AllowGrouping					= 1
SET @AllowedValuesExpression		= 'select v.ID,  v.DisplayValue  from EnumValue v join EnumType t on t.ID = v.Type where t.Type = ''englishProficiency'' order by v.DisplayValue'
SET @SchemaDataType					= 'G'
SET @ViewTaskID						= null

INSERT INTO VC3Reporting.ReportSchemaColumn
(
Id,
[Name],
SchemaTable,
SchemaDataType,
DisplayExpression,
ValueExpression,
OrderExpression,
LinkExpression,
LinkFormat,
IsSelectColumn,
IsFilterColumn,
IsParameterColumn,
IsGroupColumn,
IsOrderColumn,
IsAggregated,
AllowedValuesExpression,
[Sequence],
Width
)
VALUES 
(
@ID, 
@Name,
@TableID, 
@SchemaDataType,
@DisplayExpression,
@ValueExpression,
null , --OrderExpression
null , --LinkExpression
null , --LinkFormat
1 , --IsSelectColumn
1 , --IsFilterColumn
1 , --IsParameterColumn
@AllowGrouping , --IsGroupColumn
1 , --IsOrderColumn
0, --IsAggregated
@AllowedValuesExpression,
100,	-- [Sequence]
null						
)

INSERT INTO ReportSchemaColumn
(
ID,
ViewTaskID
)
VALUES
(
@ID,
@ViewTaskID
)

INSERT INTO VC3ETL.LoadColumn VALUES ('D4F9F182-F4DD-4825-8E3B-075A5BFDDD82', 'F0EC0B8D-2848-41AF-9E9D-C0036791FCBE', 'x_englishProficiency' , 'x_englishProficiency' , 'C',0, NULL,NULL)