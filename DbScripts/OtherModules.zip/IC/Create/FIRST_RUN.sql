-- InfiniteCampus will import all of its grade levels, and build up the entire model for it, purge old data to avoid conflicts, this is a RUN ONCE operation at the first installation
-- If the schema has changed and more tables depend on the grade level table, update this script
DELETE GradeGoal
DELETE ContentareaRequirement
DELETE ProbeGoalValue
DELETE GradeRangeBitMask
DELETE GradeLevel

-- COntent areas will be imported
DELETE COntentArea
