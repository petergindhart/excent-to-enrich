INSERT INTO dbo.ExtendedPropertyDefinition (ID, ExtendedPropertyTypeDefinitionID, ColumnName, DisplayName) VALUES ('F66BBB9B-D44F-4F62-BC80-8BCCE87894CC', 'B1BA406A-80C4-44D0-8E36-9EC34094C553', 'x_CSAP_A', 'CSAP Alternative')
GO
ALTER TABLE dbo.Student ADD x_CSAP_A bit  NULL 
GO

DECLARE @ID							uniqueidentifier
DECLARE @Name						varchar(100)
DECLARE @TableID					uniqueidentifier
DECLARE @DisplayExpression			varchar(1000)
DECLARE @ValueExpression			varchar(1000)
DECLARE @AllowGrouping				bit
DECLARE @AllowedValuesExpression	varchar(1000)
DECLARE @SchemaDataType				char(1)
DECLARE @ViewTaskID					int

SET @ID								= 'F00CFD54-50F9-479C-B0A8-60AE816B0D2E'
SET @TableID						= 'F210EF27-1FBA-4518-B3F3-41DD8AFB4615'
SET @Name							= 'CSAP Alternative'
SET @DisplayExpression				= '(case when {this}.x_CSAP_A=1 then ''Yes'' else ''No'' end)' 
SET @ValueExpression				= '{this}.x_CSAP_A'
SET @AllowGrouping					= 1
SET @AllowedValuesExpression		= 'select v.ID,  v.DisplayValue  from EnumValue v join EnumType t on t.ID = v.Type where t.Type = ''CSAP_A'' order by v.DisplayValue'
SET @SchemaDataType					= 'G'
SET @ViewTaskID						= null

INSERT INTO VC3Reporting.ReportSchemaColumn
(
Id,
[Name],
SchemaTable,
SchemaDataType,
DisplayExpression,
ValueExpression,
OrderExpression,
LinkExpression,
LinkFormat,
IsSelectColumn,
IsFilterColumn,
IsParameterColumn,
IsGroupColumn,
IsOrderColumn,
IsAggregated,
AllowedValuesExpression,
[Sequence],
Width
)
VALUES 
(
@ID, 
@Name,
@TableID, 
@SchemaDataType,
@DisplayExpression,
@ValueExpression,
null , --OrderExpression
null , --LinkExpression
null , --LinkFormat
1 , --IsSelectColumn
1 , --IsFilterColumn
1 , --IsParameterColumn
@AllowGrouping , --IsGroupColumn
1 , --IsOrderColumn
0, --IsAggregated
@AllowedValuesExpression,
100,	-- [Sequence]
null						
)

INSERT INTO ReportSchemaColumn
(
ID,
ViewTaskID
)
VALUES
(
@ID,
@ViewTaskID
)

INSERT INTO VC3ETL.LoadColumn VALUES ('7C76CB8C-B92B-4B20-992F-53D70E249985', 'F0EC0B8D-2848-41AF-9E9D-C0036791FCBE', 'x_CSAP_A' , 'x_CSAP_A' , 'C',0, NULL,NULL)

UPDATE vc3etl.ExtractTable
SET Enabled = 1
WHERE ID = '1068288A-BF61-42C1-87CA-985854E0885F'