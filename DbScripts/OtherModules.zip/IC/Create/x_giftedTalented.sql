INSERT INTO dbo.ExtendedPropertyDefinition (ID, ExtendedPropertyTypeDefinitionID, ColumnName, DisplayName) VALUES ('1A914B16-0BB3-4E55-A7EE-77A2E90A9720', 'B1BA406A-80C4-44D0-8E36-9EC34094C553', 'x_giftedTalented', 'Gifted And Talented')
ALTER TABLE dbo.Student ADD x_giftedTalented uniqueidentifier  NULL 
CONSTRAINT FK_Student_x_giftedTalented REFERENCES dbo.EnumValue (ID)

INSERT INTO EnumType VALUES ('D46A9DA2-A7C6-42A5-BE72-FFED5D6D3136' , 'giftedTalented', 1,0, NULL)
INSERT INTO IC.Map_EnumTypeID VALUES ('enrollment', 'giftedTalented', 0, 'D46A9DA2-A7C6-42A5-BE72-FFED5D6D3136')

DECLARE @ID							uniqueidentifier
DECLARE @Name						varchar(100)
DECLARE @TableID					uniqueidentifier
DECLARE @DisplayExpression			varchar(1000)
DECLARE @ValueExpression			varchar(1000)
DECLARE @AllowGrouping				bit
DECLARE @AllowedValuesExpression	varchar(1000)
DECLARE @SchemaDataType				char(1)
DECLARE @ViewTaskID					int

SET @ID								= '3AE1603E-9DBB-4A1F-A851-32C0D2F1884E'
SET @TableID						= 'F210EF27-1FBA-4518-B3F3-41DD8AFB4615'
SET @Name							= 'giftedTalented'
SET @DisplayExpression				= Replace( '(select DisplayValue from EnumValue where Id=stu.x_giftedTalented)', 'stu.', '{this}.' )
SET @ValueExpression				= Replace( 'stu.x_giftedTalented', 'stu.', '{this}.' )
SET @AllowGrouping					= 1
SET @AllowedValuesExpression		= 'select v.ID,  v.DisplayValue  from EnumValue v join EnumType t on t.ID = v.Type where t.Type = ''giftedTalented'' order by v.DisplayValue'
SET @SchemaDataType					= 'G'
SET @ViewTaskID						= null

INSERT INTO VC3Reporting.ReportSchemaColumn
(
Id,
[Name],
SchemaTable,
SchemaDataType,
DisplayExpression,
ValueExpression,
OrderExpression,
LinkExpression,
LinkFormat,
IsSelectColumn,
IsFilterColumn,
IsParameterColumn,
IsGroupColumn,
IsOrderColumn,
IsAggregated,
AllowedValuesExpression,
[Sequence],
Width
)
VALUES 
(
@ID, 
@Name,
@TableID, 
@SchemaDataType,
@DisplayExpression,
@ValueExpression,
null , --OrderExpression
null , --LinkExpression
null , --LinkFormat
1 , --IsSelectColumn
1 , --IsFilterColumn
1 , --IsParameterColumn
@AllowGrouping , --IsGroupColumn
1 , --IsOrderColumn
0, --IsAggregated
@AllowedValuesExpression,
100,	-- [Sequence]
null						
)

INSERT INTO ReportSchemaColumn
(
ID,
ViewTaskID
)
VALUES
(
@ID,
@ViewTaskID
)

INSERT INTO VC3ETL.LoadColumn VALUES ('698984F2-CF1B-4C46-A316-D632555553C8', 'F0EC0B8D-2848-41AF-9E9D-C0036791FCBE', 'x_giftedTalented' , 'x_giftedTalented' , 'C',0, NULL,NULL)
