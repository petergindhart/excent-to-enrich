INSERT INTO dbo.ExtendedPropertyDefinition (ID, ExtendedPropertyTypeDefinitionID, ColumnName, DisplayName) VALUES ('1761B493-1AE3-4046-BC43-E5D77394BA68', 'B1BA406A-80C4-44D0-8E36-9EC34094C553', 'x_section504', 'Section 504')
ALTER TABLE dbo.Student ADD x_section504 bit null

DECLARE @ID							uniqueidentifier
DECLARE @Name						varchar(100)
DECLARE @TableID					uniqueidentifier
DECLARE @DisplayExpression			varchar(1000)
DECLARE @ValueExpression			varchar(1000)
DECLARE @AllowGrouping				bit
DECLARE @AllowedValuesExpression	varchar(1000)
DECLARE @SchemaDataType				char(1)
DECLARE @ViewTaskID					int

SET @ID								= '5176C26B-68EB-4D9A-8A33-C30A8839855A'
SET @TableID						= 'F210EF27-1FBA-4518-B3F3-41DD8AFB4615'
SET @Name							= 'Section 504'
SET @DisplayExpression				= Replace( '(case when stu.x_section504=1 then ''Yes'' else ''No'' end)' , 'stu.', '{this}.')
SET @ValueExpression				= Replace( 'stu.x_section504', 'stu.', '{this}.' )
SET @AllowGrouping					= 1
SET @AllowedValuesExpression		= 'select Value=1, Label=''Yes'' union all select 0, ''No'''
SET @SchemaDataType					= 'B'
SET @ViewTaskID						= null

INSERT INTO VC3Reporting.ReportSchemaColumn
(
Id,
[Name],
SchemaTable,
SchemaDataType,
DisplayExpression,
ValueExpression,
OrderExpression,
LinkExpression,
LinkFormat,
IsSelectColumn,
IsFilterColumn,
IsParameterColumn,
IsGroupColumn,
IsOrderColumn,
IsAggregated,
AllowedValuesExpression,
[Sequence],
Width
)
VALUES 
(
@ID, 
@Name,
@TableID, 
@SchemaDataType,
@DisplayExpression,
@ValueExpression,
null , --OrderExpression
null , --LinkExpression
null , --LinkFormat
1 , --IsSelectColumn
1 , --IsFilterColumn
1 , --IsParameterColumn
@AllowGrouping , --IsGroupColumn
1 , --IsOrderColumn
0, --IsAggregated
@AllowedValuesExpression,
100,	-- [Sequence]
null						
)

INSERT INTO ReportSchemaColumn
(
ID,
ViewTaskID
)
VALUES
(
@ID,
@ViewTaskID
)

INSERT INTO VC3ETL.LoadColumn VALUES ('D2221BEB-2BBC-4AD1-A9E6-C5994EDB855E', 'F0EC0B8D-2848-41AF-9E9D-C0036791FCBE', 'x_section504' , 'x_section504' , 'C',0, NULL,NULL)