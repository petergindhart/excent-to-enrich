UPDATE vc3etl.LoadColumn
SET DeletedValue = '@ImportDefaultEndDate'
WHERE ID= 'D9711C5D-211B-41CF-B12D-1AB62C26E7D9'