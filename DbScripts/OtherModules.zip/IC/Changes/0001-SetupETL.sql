--#assume VC3ETL:20
INSERT INTO vc3etl.ExtractType VALUES ('EEC48072-3657-4689-8EC0-716BA08058E7', 'Infinite Campus')

INSERT INTO  vc3taskscheduler.scheduledtaskschedule values ('FDB4A49E-C948-4FEB-AE27-13DEE8A064DB', 'F03A0C51-7294-4B57-AFB7-AFF136E4025F', '<?xml version="1.0" encoding="utf-16"?>  <ArrayOfDictionaryEntry xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">    <DictionaryEntry>      <Key xsi:type="xsd:string">DatabaseId</Key>      <Value xsi:type="xsd:string">19A65267-D406-4624-852A-BEA3DB449C5C*EEC48072-3657-4689-8EC0-716BA08058E7</Value>    </DictionaryEntry>    <DictionaryEntry>      <Key xsi:type="xsd:string">CreateSnapshot</Key>      <Value xsi:type="xsd:boolean">true</Value>    </DictionaryEntry>  </ArrayOfDictionaryEntry>',
0, '2009-06-03 15:12:32.510', NULL, 1, 'D', NULL, NULL, NULL, 1, 30, 0,0,0,0,0,0,0)

INSERT INTO vc3etl.ExtractDatabase values ('19A65267-D406-4624-852A-BEA3DB449C5C','EEC48072-3657-4689-8EC0-716BA08058E7', '256BEEB5-D6B4-4FA9-9854-8ACCAE51FF2E', NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL, '[{BrandName}] {SisDatabase} import completed', 'Successfully imported {SnapshotRosterYear} {SisDatabase} data into {BrandName}.  {SisDatabase} data in {BrandName} is now current as of {SnapshotDate}.      Next Scheduled Import Time: {NextImportTime}', 
NULL, '[{BrandName}] {SisDatabase} import failed', 'There was a problem importing {SnapshotRosterYear} {SisDatabase} data into {BrandName}:  {ErrorMessage}    Click the link below or go to the SYSADMIN section of {BrandName} for additional information about this problem:  {ErrorLink}',1, '_NEW', '_LOCAL', NULL, 'FDB4A49E-C948-4FEB-AE27-13DEE8A064DB', 'Infinite Campus',0)

INSERT INTO vc3etl.PearsonExtractDatabase  VALUES ('19A65267-D406-4624-852A-BEA3DB449C5C', NULL, NULL,	NULL,0,NULL,0)


INSERT INTO vc3etl.ExtractTable VALUES ('A3C42150-73A2-440F-8E72-EE8ED1867B1C', '19A65267-D406-4624-852A-BEA3DB449C5C', 'School', 'IC', 'School', 'schoolid', NULL, 0,0,NULL,1, 0, NULL)
INSERT INTO vc3etl.PearsonExtractTable Values ('A3C42150-73A2-440F-8E72-EE8ED1867B1C',0, NULL)
GO

/****** Object:  Table [IC].[Address_LOCAL]    Script Date: 06/12/2009 15:16:26 ******/
 
GO
 
GO
CREATE TABLE [IC].[Address_LOCAL](
	[addressID] [int] NOT NULL,
	[number] [varchar](12) NULL,
	[street] [varchar](30) NULL,
	[tag] [varchar](20) NULL,
	[prefix] [varchar](10) NULL,
	[dir] [varchar](10) NULL,
	[apt] [varchar](17) NULL,
	[city] [varchar](24) NULL,
	[state] [varchar](2) NULL,
	[zip] [varchar](10) NULL,
	[comments] [varchar](255) NULL,
	[location_code] [varchar](40) NULL,
	[county] [varchar](50) NULL,
	[districtID] [int] NULL,
	[siteID] [int] NULL,
	[postOfficeBox] [bit] NULL,
	[legacyKey] [int] NULL,
	[latitude] [numeric](9, 6) NULL,
	[longitude] [numeric](9, 6) NULL,
	[tract] [varchar](5) NULL,
	[block] [varchar](4) NULL,
 CONSTRAINT [PK_Address_NEW_697593049] PRIMARY KEY CLUSTERED 
(
	[addressID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [IC].[AttendanceExcuse_LOCAL]    Script Date: 06/12/2009 15:16:26 ******/
 
GO
 
GO
CREATE TABLE [IC].[AttendanceExcuse_LOCAL](
	[excuseID] [int] NOT NULL,
	[calendarID] [int] NOT NULL,
	[code] [varchar](4) NOT NULL,
	[description] [varchar](50) NULL,
	[status] [varchar](1) NOT NULL,
	[excuse] [varchar](1) NULL,
	[stateCode] [varchar](5) NULL,
 CONSTRAINT [PK_AttendanceExcuse_NEW_1333484118] PRIMARY KEY CLUSTERED 
(
	[excuseID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO

/****** Object:  Index [IX_ICAttendanceExcuse_NEW_Import1_525602707]    Script Date: 06/12/2009 15:16:26 ******/
CREATE NONCLUSTERED INDEX [IX_ICAttendanceExcuse_NEW_Import1_525602707] ON [IC].[AttendanceExcuse_LOCAL] 
(
	[calendarID] ASC
) ON [PRIMARY]
GO
/****** Object:  Table [IC].[BehaviorEvent_LOCAL]    Script Date: 06/12/2009 15:16:26 ******/
 
GO
 
GO
CREATE TABLE [IC].[BehaviorEvent_LOCAL](
	[eventID] [int] NOT NULL,
	[calendarID] [int] NULL,
	[name] [varchar](100) NULL,
	[code] [varchar](5) NULL,
	[alignment] [smallint] NULL,
	[weaponCode] [varchar](4) NULL,
	[violenceIndicator] [bit] NULL,
	[timestamp] [datetime] NULL,
	[staffName] [varchar](100) NULL,
	[referralName] [varchar](50) NULL,
	[comments] [text] NULL,
	[context] [varchar](30) NULL,
	[location] [varchar](4) NULL,
	[victim] [varchar](2) NULL,
	[damages] [numeric](8, 2) NULL,
	[legacyKey] [varchar](50) NULL,
	[offenderType] [varchar](2) NULL,
	[reporterType] [varchar](2) NULL,
	[policeNotified] [bit] NULL,
	[gangRelated] [bit] NULL,
	[hateCrime] [bit] NULL,
	[alcoholRelated] [bit] NULL,
	[drugsRelated] [bit] NULL,
	[fightRelated] [bit] NULL,
	[seHearing] [bit] NULL,
	[eventGUID] [uniqueidentifier] NULL,
	[drugCode] [varchar](4) NULL,
	[altComments] [text] NULL,
	[injury] [varchar](1) NULL,
	[unsafeSchoolChoiceEvent] [bit] NULL,
	[victimReferral] [varchar](50) NULL,
	[offenderReferral] [varchar](50) NULL,
	[timeClassifier] [varchar](4) NULL,
	[timeDescription] [varchar](50) NULL,
	[locationClassifier] [varchar](4) NULL,
	[locationDescription] [varchar](50) NULL,
	[incidentType] [varchar](4) NULL,
	[incidentDescription] [varchar](50) NULL,
	[weaponDescription] [varchar](50) NULL,
	[civilProceedings] [bit] NULL,
	[arrest] [bit] NULL,
	[charges] [bit] NULL,
	[schoolSponsoredEvent] [bit] NULL,
	[lawViolation] [varchar](4) NULL,
	[boardViolation] [varchar](4) NULL,
	[nonSchoolHours] [bit] NULL,
	[numOfStuVictims] [smallint] NULL,
	[numOfSchPersonnelVictims] [smallint] NULL,
	[numOfNonSchVictims] [smallint] NULL,
	[policeReport] [bit] NULL,
	[hearingStatus] [varchar](8) NULL,
	[stateEventCode] [varchar](5) NULL,
	[stateEventName] [varchar](100) NULL,
	[regionalEventCode] [varchar](5) NULL,
	[regionalEventName] [varchar](100) NULL,
	[drugCode2] [varchar](4) NULL,
	[drugCode3] [varchar](4) NULL,
	[drugCode4] [varchar](4) NULL,
	[drugCode5] [varchar](4) NULL,
	[name2] [varchar](100) NULL,
	[name3] [varchar](100) NULL,
	[name4] [varchar](100) NULL,
	[name5] [varchar](100) NULL,
	[offenderKnown] [bit] NULL,
	[weaponCode2] [varchar](4) NULL,
	[weaponCode3] [varchar](4) NULL,
	[weaponCode4] [varchar](4) NULL,
	[weaponCode5] [varchar](4) NULL,
	[medicalTreatmentProvided] [bit] NULL,
	[code2] [varchar](5) NULL,
	[code3] [varchar](5) NULL,
	[code4] [varchar](5) NULL,
	[code5] [varchar](5) NULL,
 CONSTRAINT [PK_BehaviorEvent_NEW_1023571742] PRIMARY KEY CLUSTERED 
(
	[eventID] ASC
) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [IC].[BehaviorResolution_LOCAL]    Script Date: 06/12/2009 15:16:26 ******/
 
GO
 
GO
CREATE TABLE [IC].[BehaviorResolution_LOCAL](
	[resolutionID] [int] NOT NULL,
	[roleID] [int] NOT NULL,
	[name] [varchar](100) NULL,
	[code] [varchar](5) NULL,
	[removalReason] [varchar](2) NULL,
	[alignment] [smallint] NULL,
	[timestamp] [datetime] NULL,
	[endDate] [datetime] NULL,
	[comments] [text] NULL,
	[expulsionCode] [varchar](2) NULL,
	[expulsionServiceProvided] [varchar](1) NULL,
	[auxiliaryCode] [varchar](4) NULL,
	[schoolDaysDuration] [numeric](5, 2) NULL,
	[altPlacement] [varchar](4) NULL,
	[altPlacementSped] [varchar](1) NULL,
	[lawEnforcement] [varchar](1) NULL,
	[durationReason] [varchar](2) NULL,
	[restraintReason] [varchar](2) NULL,
	[daysOverride] [numeric](6, 1) NULL,
	[removalReason2] [varchar](2) NULL,
	[resolutionGUID] [uniqueidentifier] NULL,
	[hearingCode] [varchar](1) NULL,
	[noPlay] [bit] NULL,
	[gFSAModification] [bit] NULL,
	[GFSAModificationDescription] [varchar](50) NULL,
	[disabilityManifest] [bit] NULL,
	[zeroTolerance] [bit] NULL,
	[motivationCode] [varchar](2) NULL,
	[motivationDescription] [varchar](50) NULL,
	[daysServedNextYear] [smallint] NULL,
	[staffName] [varchar](100) NULL,
	[discAssignDate] [datetime] NULL,
	[stateResCode] [varchar](5) NULL,
	[stateResName] [varchar](100) NULL,
	[regionalResCode] [varchar](5) NULL,
	[regionalResName] [varchar](100) NULL,
	[returnDate] [datetime] NULL,
	[campusIDAssignment] [int] NULL,
	[actLength] [smallint] NULL,
	[oalDetermination] [bit] NULL,
	[transferOption] [bit] NULL,
	[transferOutcome] [varchar](2) NULL,
	[endTimeStamp] [datetime] NULL,
 CONSTRAINT [PK_BehaviorResolution_NEW_510675857] PRIMARY KEY CLUSTERED 
(
	[resolutionID] ASC
) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [IC].[BehaviorResType_LOCAL]    Script Date: 06/12/2009 15:16:26 ******/
 
GO
 
GO
CREATE TABLE [IC].[BehaviorResType_LOCAL](
	[typeID] [int] NOT NULL,
	[schoolID] [int] NULL,
	[code] [varchar](5) NULL,
	[name] [varchar](100) NULL,
	[category] [varchar](50) NULL,
	[alignment] [smallint] NULL,
	[demerits] [smallint] NULL,
	[stateResCode] [varchar](5) NULL,
	[regionalResCode] [varchar](5) NULL,
 CONSTRAINT [PK_BehaviorResType_NEW_342392283] PRIMARY KEY CLUSTERED 
(
	[typeID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [IC].[BehaviorRole_LOCAL]    Script Date: 06/12/2009 15:16:26 ******/
 
GO
 
GO
CREATE TABLE [IC].[BehaviorRole_LOCAL](
	[roleID] [int] NOT NULL,
	[personID] [int] NOT NULL,
	[eventID] [int] NOT NULL,
	[role] [varchar](40) NULL,
	[demerits] [smallint] NULL,
	[comments] [text] NULL,
	[legacyKey] [varchar](50) NULL,
	[roleGUID] [uniqueidentifier] NULL,
	[campusIDofResponsibility] [int] NULL,
 CONSTRAINT [PK_BehaviorRole_NEW_1395944749] PRIMARY KEY CLUSTERED 
(
	[roleID] ASC
) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [IC].[Calendar_LOCAL]    Script Date: 06/12/2009 15:16:26 ******/
 
GO
 
GO
CREATE TABLE [IC].[Calendar_LOCAL](
	[calendarID] [int] NOT NULL,
	[districtID] [int] NOT NULL,
	[schoolID] [int] NOT NULL,
	[endYear] [smallint] NOT NULL,
	[name] [varchar](30) NOT NULL,
	[number] [varchar](3) NULL,
	[startDate] [datetime] NULL,
	[endDate] [datetime] NULL,
	[comments] [varchar](255) NULL,
	[exclude] [bit] NULL,
	[summerSchool] [bit] NULL,
	[studentDay] [smallint] NULL,
	[teacherDay] [smallint] NULL,
	[wholeDayAbsence] [smallint] NULL,
	[halfDayAbsence] [smallint] NULL,
	[calendarGUID] [uniqueidentifier] NOT NULL,
	[alternativeCode] [varchar](1) NULL,
	[legacyKey] [int] NULL,
	[title3] [bit] NULL,
	[title3consortium] [varchar](50) NULL,
	[title1] [varchar](2) NULL,
	[schoolChoice] [bit] NULL,
	[type] [varchar](4) NULL,
	[countDate] [datetime] NULL,
	[assignmentRequired] [bit] NULL,
 CONSTRAINT [PK_Calendar_NEW_155422074] PRIMARY KEY CLUSTERED 
(
	[calendarID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO

/****** Object:  Index [IX_Calendar_LOCAL]    Script Date: 06/12/2009 15:16:26 ******/
CREATE NONCLUSTERED INDEX [IX_Calendar_LOCAL] ON [IC].[Calendar_LOCAL] 
(
	[endYear] ASC
) ON [PRIMARY]
GO
/****** Object:  Table [IC].[CampusAttribute_LOCAL]    Script Date: 06/12/2009 15:16:26 ******/
 
GO
 
GO
CREATE TABLE [IC].[CampusAttribute_LOCAL](
	[attributeID] [int] NOT NULL,
	[object] [varchar](30) NOT NULL,
	[element] [varchar](30) NOT NULL,
	[name] [varchar](35) NULL,
	[defaultValue] [varchar](10) NULL,
	[dataType] [varchar](15) NULL,
	[dated] [bit] NULL,
	[seq] [tinyint] NULL,
	[hide] [bit] NULL,
	[required] [bit] NULL,
	[maxSize] [tinyint] NULL,
	[custom] [bit] NULL,
	[lock] [bit] NULL,
	[copiesForward] [bit] NULL,
	[statusData] [bit] NULL,
	[comments] [varchar](100) NULL,
	[hidePortal] [bit] NULL,
	[stateTable] [bit] NULL,
	[planEnabled] [bit] NULL,
	[coreLock] [bit] NULL,
 CONSTRAINT [PK_CampusAttribute_NEW_1938767778] PRIMARY KEY CLUSTERED 
(
	[attributeID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [IC].[CampusDictionary_LOCAL]    Script Date: 06/12/2009 15:16:26 ******/
 
GO
 
GO
CREATE TABLE [IC].[CampusDictionary_LOCAL](
	[dictionaryID] [int] NOT NULL,
	[attributeID] [int] NOT NULL,
	[code] [varchar](15) NOT NULL,
	[name] [varchar](50) NOT NULL,
	[value] [varchar](20) NULL,
	[seq] [smallint] NULL,
	[standardCode] [varchar](20) NULL,
	[active] [bit] NULL,
 CONSTRAINT [PK_CampusDictionary_NEW_1042171072] PRIMARY KEY CLUSTERED 
(
	[dictionaryID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [IC].[Contact_LOCAL]    Script Date: 06/12/2009 15:16:26 ******/
 
GO
 
GO
CREATE TABLE [IC].[Contact_LOCAL](
	[personID] [int] NOT NULL,
	[homePhone] [varchar](25) NULL,
	[workPhone] [varchar](25) NULL,
	[cellPhone] [varchar](25) NULL,
	[pager] [varchar](25) NULL,
	[email] [varchar](100) NULL,
	[comments] [varchar](500) NULL,
	[homePhonePrivate] [bit] NULL,
	[workPhonePrivate] [bit] NULL,
	[cellPhonePrivate] [bit] NULL,
	[pagerPrivate] [bit] NULL,
	[emailPrivate] [bit] NULL,
	[homePhoneMessenger] [int] NULL,
	[workPhoneMessenger] [int] NULL,
	[cellPhoneMessenger] [int] NULL,
	[emailMessenger] [int] NULL,
	[inboxMessenger] [int] NULL,
	[communicationLanguage] [varchar](5) NULL,
 CONSTRAINT [PK_Contact_NEW_2043133315] PRIMARY KEY CLUSTERED 
(
	[personID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [IC].[Course_DepartmentID_LOCAL]    Script Date: 06/12/2009 15:16:26 ******/
 
GO
 
GO
CREATE TABLE [IC].[Course_DepartmentID_LOCAL](
	[CourseID] [varchar](10) NOT NULL,
	[CourseName] [varchar](50) NULL,
	[Number] [varchar](20) NULL,
	[DepartmentID] [varchar](10) NOT NULL,
	[DepartmentName] [varchar](10) NULL,
	[CalendarID] [varchar](10) NULL,
 CONSTRAINT [PK_Course_DepartmentID_NEW_445424719] PRIMARY KEY CLUSTERED 
(
	[CourseID] ASC,
	[DepartmentID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [IC].[Course_LOCAL]    Script Date: 06/12/2009 15:16:26 ******/
 
GO
 
GO
CREATE TABLE [IC].[Course_LOCAL](
	[courseID] [int] NOT NULL,
	[courseMasterID] [int] NULL,
	[calendarID] [int] NOT NULL,
	[departmentID] [int] NULL,
	[number] [varchar](13) NOT NULL,
	[stateCode] [varchar](20) NULL,
	[name] [varchar](30) NOT NULL,
	[description] [text] NULL,
	[comments] [varchar](250) NULL,
	[active] [bit] NULL,
	[type] [varchar](15) NULL,
	[teachingMethod] [varchar](2) NULL,
	[vocationalCode] [varchar](7) NULL,
	[distanceCode] [varchar](2) NULL,
	[honorsCode] [varchar](5) NULL,
	[activityCode] [varchar](3) NULL,
	[homeroom] [bit] NULL,
	[transcript] [bit] NULL,
	[requestable] [bit] NULL,
	[required] [bit] NULL,
	[attendance] [bit] NULL,
	[unitAttendance] [bit] NULL,
	[terms] [tinyint] NULL,
	[schedules] [tinyint] NULL,
	[periods] [tinyint] NULL,
	[gpaWeight] [numeric](6, 3) NULL,
	[bonusPointsAvail] [bit] NULL,
	[maxStudents] [smallint] NULL,
	[priority] [smallint] NULL,
	[sectionsToBuild] [tinyint] NULL,
	[pseoType] [varchar](9) NULL,
	[pseoCredit] [numeric](6, 3) NULL,
	[legacyKey] [int] NULL,
	[specialEdCode] [varchar](2) NULL,
	[coursePart] [tinyint] NULL,
	[grade] [varchar](3) NULL,
	[program] [varchar](2) NULL,
	[programType] [varchar](7) NULL,
	[technology] [bit] NULL,
	[highlyQualified] [varchar](2) NULL,
	[allowTeacherRequests] [bit] NULL,
	[standardsBased] [bit] NULL,
	[specialCode] [varchar](15) NULL,
	[abbreviation] [varchar](100) NULL,
	[altStateCode] [varchar](15) NULL,
	[transcriptField1] [varchar](255) NULL,
	[transcriptField2] [varchar](255) NULL,
	[transcriptField3] [varchar](255) NULL,
	[transcriptField4] [varchar](255) NULL,
	[transcriptField5] [varchar](255) NULL,
 CONSTRAINT [PK_Course_NEW_2129845653] PRIMARY KEY CLUSTERED 
(
	[courseID] ASC
) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [IC].[Day_LOCAL]    Script Date: 06/12/2009 15:16:26 ******/
 
GO
 
GO
CREATE TABLE [IC].[Day_LOCAL](
	[dayID] [int] NOT NULL,
	[calendarID] [int] NOT NULL,
	[structureID] [int] NOT NULL,
	[periodScheduleID] [int] NULL,
	[date] [datetime] NOT NULL,
	[instruction] [bit] NULL,
	[attendance] [bit] NULL,
	[schoolDay] [bit] NULL,
	[duration] [smallint] NULL,
	[comments] [varchar](250) NULL,
	[startTime] [datetime] NULL,
	[endTime] [datetime] NULL,
 CONSTRAINT [PK_Day_NEW_606688723] PRIMARY KEY CLUSTERED 
(
	[dayID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO

/****** Object:  Index [IX_Day_LOCAL]    Script Date: 06/12/2009 15:16:26 ******/
CREATE NONCLUSTERED INDEX [IX_Day_LOCAL] ON [IC].[Day_LOCAL] 
(
	[calendarID] ASC
) ON [PRIMARY]
GO
/****** Object:  Table [IC].[Department_LOCAL]    Script Date: 06/12/2009 15:16:26 ******/
 
GO
 
GO
CREATE TABLE [IC].[Department_LOCAL](
	[departmentID] [int] NOT NULL,
	[schoolID] [int] NOT NULL,
	[name] [varchar](50) NOT NULL,
 CONSTRAINT [PK_Department_NEW_1766493539] PRIMARY KEY CLUSTERED 
(
	[departmentID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [IC].[Employment_LOCAL]    Script Date: 06/12/2009 15:16:26 ******/
 
GO
 
GO
CREATE TABLE [IC].[Employment_LOCAL](
	[employmentID] [int] NOT NULL,
	[personID] [int] NOT NULL,
	[districtID] [int] NOT NULL,
	[employmentGUID] [uniqueidentifier] NOT NULL,
	[startDate] [datetime] NULL,
	[endDate] [datetime] NULL,
	[teachingStartYear] [datetime] NULL,
	[teachingYearsModifier] [smallint] NULL,
	[licenseNumber] [varchar](10) NULL,
	[ftePercent] [numeric](18, 0) NULL,
	[seniority] [varchar](2) NULL,
	[educationLevel] [varchar](4) NULL,
	[salary] [numeric](9, 2) NULL,
	[additionalCompensation] [numeric](9, 2) NULL,
	[benefitsValue] [numeric](9, 2) NULL,
	[grade] [varchar](10) NULL,
	[subjectArea] [varchar](3) NULL,
	[certification] [varchar](2) NULL,
	[housse] [varchar](1) NULL,
	[housseCompletionDate] [datetime] NULL,
	[major] [varchar](50) NULL,
	[subjectMatterCompetency] [varchar](1) NULL,
	[highlyQualified] [varchar](1) NULL,
	[exceptionalContractCondition] [bit] NULL,
	[employmentStatus] [varchar](2) NULL,
	[exitReason] [varchar](2) NULL,
 CONSTRAINT [PK_Employment_NEW_2129535157] PRIMARY KEY CLUSTERED 
(
	[employmentID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [IC].[EmploymentAssignment_LOCAL]    Script Date: 06/12/2009 15:16:26 ******/
 
GO
 
GO
CREATE TABLE [IC].[EmploymentAssignment_LOCAL](
	[assignmentID] [int] NOT NULL,
	[personID] [int] NOT NULL,
	[schoolID] [int] NOT NULL,
	[departmentID] [int] NULL,
	[startDate] [datetime] NULL,
	[endDate] [datetime] NULL,
	[titleCode] [varchar](3) NULL,
	[title] [varchar](50) NULL,
	[type] [varchar](4) NULL,
	[assignmentCode] [varchar](6) NULL,
	[teacher] [bit] NULL,
	[specialed] [bit] NULL,
	[behavior] [bit] NULL,
	[health] [bit] NULL,
	[advisor] [bit] NULL,
	[supervisor] [bit] NULL,
	[foodservice] [bit] NULL,
	[excludeReferral] [bit] NULL,
	[fte] [numeric](7, 3) NULL,
	[highlyQualifiedTeacherDate] [datetime] NULL,
	[nationalBoardCertification] [varchar](1) NULL,
	[alternateType] [varchar](3) NULL,
	[highlyQualified] [varchar](2) NULL,
	[readingFirst] [varchar](2) NULL,
	[pdYear] [varchar](2) NULL,
	[pdClass] [varchar](4) NULL,
	[pdClassType] [varchar](2) NULL,
	[pdClassOfferedBy] [varchar](2) NULL,
	[pdCredit] [numeric](4, 2) NULL,
	[pdHours] [numeric](4, 2) NULL,
	[program] [bit] NULL,
	[counselor] [bit] NULL,
	[subjectMatterCompetancy] [varchar](2) NULL,
	[grade] [varchar](4) NULL,
	[resourceTeacher] [bit] NULL,
	[pupilSupport] [bit] NULL,
	[suAdmin] [bit] NULL,
	[title1] [bit] NULL,
	[schoolAdmin] [bit] NULL,
 CONSTRAINT [PK_EmploymentAssignment_NEW_241795186] PRIMARY KEY CLUSTERED 
(
	[assignmentID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [IC].[Enrollment_LOCAL]    Script Date: 06/12/2009 15:16:26 ******/
 
GO
 
GO
CREATE TABLE [IC].[Enrollment_LOCAL](
	[enrollmentID] [int] NOT NULL,
	[personID] [int] NOT NULL,
	[calendarID] [int] NOT NULL,
	[structureID] [int] NOT NULL,
	[grade] [varchar](4) NULL,
	[serviceType] [varchar](1) NOT NULL,
	[active] [bit] NOT NULL,
	[classRankExclude] [bit] NULL,
	[noShow] [bit] NULL,
	[startDate] [datetime] NOT NULL,
	[startStatus] [varchar](3) NULL,
	[startComments] [varchar](250) NULL,
	[endDate] [datetime] NULL,
	[endStatus] [varchar](4) NULL,
	[endComments] [varchar](250) NULL,
	[endAction] [varchar](1) NULL,
	[nextCalendar] [int] NULL,
	[nextGrade] [varchar](3) NULL,
	[diplomaDate] [datetime] NULL,
	[diplomaType] [varchar](3) NULL,
	[diplomaPeriod] [varchar](3) NULL,
	[postGradPlans] [varchar](3) NULL,
	[postGradLocation] [varchar](2) NULL,
	[gradYear] [smallint] NULL,
	[stateExclude] [bit] NULL,
	[servingDistrict] [varchar](12) NULL,
	[residentDistrict] [varchar](12) NULL,
	[residentSchool] [varchar](10) NULL,
	[mealStatus] [varchar](4) NULL,
	[englishProficiency] [varchar](4) NULL,
	[englishProficiencyDate] [datetime] NULL,
	[lep] [varchar](50) NULL,
	[esl] [varchar](5) NULL,
	[language] [varchar](4) NULL,
	[citizenship] [varchar](2) NULL,
	[title1] [varchar](2) NULL,
	[title3] [varchar](1) NULL,
	[transportation] [varchar](2) NULL,
	[migrant] [varchar](2) NULL,
	[immigrant] [varchar](2) NULL,
	[homeless] [varchar](2) NULL,
	[homeSchooled] [varchar](1) NULL,
	[homebound] [varchar](1) NULL,
	[giftedTalented] [varchar](2) NULL,
	[nclbChoice] [varchar](2) NULL,
	[percentEnrolled] [numeric](7, 3) NULL,
	[admOverride] [numeric](7, 3) NULL,
	[adaOverride] [numeric](7, 3) NULL,
	[vocationalCode] [varchar](2) NULL,
	[pseo] [varchar](4) NULL,
	[facilityCode] [varchar](6) NULL,
	[stateAid] [varchar](6) NULL,
	[stateFundingCode] [varchar](2) NULL,
	[section504] [varchar](1) NULL,
	[specialEdStatus] [varchar](5) NULL,
	[specialEdSetting] [varchar](6) NULL,
	[disability1] [varchar](5) NULL,
	[disability2] [varchar](5) NULL,
	[disability3] [varchar](5) NULL,
	[disability4] [varchar](5) NULL,
	[disability5] [varchar](5) NULL,
	[enrollmentGUID] [uniqueidentifier] NOT NULL,
	[privateSchooled] [varchar](1) NULL,
	[spedExitDate] [datetime] NULL,
	[spedExitReason] [varchar](3) NULL,
	[childCountStatus] [varchar](2) NULL,
	[grade9Date] [datetime] NULL,
	[singleParent] [varchar](1) NULL,
	[displacedHomemaker] [varchar](1) NULL,
	[legacyKey] [int] NULL,
	[legacySeq1] [smallint] NULL,
	[legacySeq2] [smallint] NULL,
	[adult] [bit] NULL,
	[servingCounty] [varchar](8) NULL,
	[endYear] [smallint] NOT NULL,
	[districtID] [int] NOT NULL,
	[localStudentNumber] [varchar](15) NULL,
	[modifiedDate] [datetime] NULL,
	[modifiedByID] [int] NULL,
	[dropoutCode] [varchar](3) NULL,
	[eip] [varchar](1) NULL,
	[projectedGraduationDate] [datetime] NULL,
	[attendanceGroup] [varchar](3) NULL,
	[withdrawDate] [datetime] NULL,
	[rollForwardCode] [varchar](1) NULL,
	[rollForwardEnrollmentID] [int] NULL,
	[cohortYear] [varchar](4) NULL,
	[disability6] [varchar](5) NULL,
	[disability7] [varchar](5) NULL,
	[disability8] [varchar](5) NULL,
	[disability9] [varchar](5) NULL,
	[disability10] [varchar](5) NULL,
 CONSTRAINT [PK_Enrollment_NEW_2024305057] PRIMARY KEY CLUSTERED 
(
	[enrollmentID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [IC].[GradeLevel_LOCAL]    Script Date: 06/12/2009 15:16:26 ******/
 
GO
 
GO
CREATE TABLE [IC].[GradeLevel_LOCAL](
	[gradeLevelID] [int] NOT NULL,
	[calendarID] [int] NOT NULL,
	[structureID] [int] NOT NULL,
	[name] [varchar](4) NOT NULL,
	[seq] [tinyint] NULL,
	[standardDay] [real] NULL,
	[kindergartenCode] [varchar](5) NULL,
	[standardCode] [varchar](4) NULL,
	[excludeGPA] [bit] NULL,
	[wholeDayAbsence] [smallint] NULL,
	[halfDayAbsence] [smallint] NULL,
	[maxMembershipDays] [varchar](6) NULL,
	[schoolChoiceSeatCount] [int] NULL,
	[comments] [varchar](50) NULL,
	[excludeState] [bit] NOT NULL,
	[stateGrade] [varchar](4) NULL,
	[regionalGrade] [varchar](4) NULL,
	[assignmentExempt] [bit] NULL,
	[attendanceTime] [datetime] NULL,
	[gradeLevelGUID] [uniqueidentifier] NOT NULL,
 CONSTRAINT [PK_GradeLevel_NEW_2047513595] PRIMARY KEY CLUSTERED 
(
	[gradeLevelID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [IC].[Household_LOCAL]    Script Date: 06/12/2009 15:16:26 ******/
 
GO
 
GO
CREATE TABLE [IC].[Household_LOCAL](
	[householdID] [int] NOT NULL,
	[phone] [varchar](25) NULL,
	[phonePrivate] [bit] NULL,
	[name] [varchar](50) NULL,
	[comments] [varchar](255) NULL,
	[messenger] [int] NULL,
	[legacyKey] [varchar](80) NULL,
 CONSTRAINT [PK_Household_NEW_860031444] PRIMARY KEY CLUSTERED 
(
	[householdID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [IC].[HouseholdLocation_LOCAL]    Script Date: 06/12/2009 15:16:26 ******/
 
GO
 
GO
CREATE TABLE [IC].[HouseholdLocation_LOCAL](
	[locationID] [int] NOT NULL,
	[householdID] [int] NOT NULL,
	[addressID] [int] NOT NULL,
	[startDate] [datetime] NULL,
	[endDate] [datetime] NULL,
	[private] [bit] NULL,
	[secondary] [bit] NULL,
	[mailing] [bit] NULL,
 CONSTRAINT [PK_HouseholdLocation_NEW_96139685] PRIMARY KEY CLUSTERED 
(
	[locationID] ASC,
	[householdID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [IC].[HouseholdMember_LOCAL]    Script Date: 06/12/2009 15:16:26 ******/
 
GO
 
GO
CREATE TABLE [IC].[HouseholdMember_LOCAL](
	[memberID] [int] NOT NULL,
	[householdID] [int] NOT NULL,
	[personID] [int] NOT NULL,
	[startDate] [datetime] NULL,
	[endDate] [datetime] NULL,
	[private] [bit] NULL,
	[guardian] [bit] NULL,
	[secondary] [bit] NULL,
	[mailing] [bit] NULL,
	[messenger] [varchar](1) NULL,
 CONSTRAINT [PK_HouseholdMember_NEW_1724877395] PRIMARY KEY CLUSTERED 
(
	[memberID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [IC].[IC_Identity_LOCAL]    Script Date: 06/12/2009 15:16:26 ******/
 
GO
 
GO
CREATE TABLE [IC].[IC_Identity_LOCAL](
	[identityID] [int] NOT NULL,
	[personID] [int] NOT NULL,
	[effectiveDate] [datetime] NULL,
	[lastName] [varchar](40) NOT NULL,
	[firstName] [varchar](35) NULL,
	[middleName] [varchar](20) NULL,
	[suffix] [varchar](50) NULL,
	[alias] [varchar](50) NULL,
	[gender] [char](1) NULL,
	[birthdate] [datetime] NULL,
	[ssn] [varchar](9) NULL,
	[raceEthnicity] [varchar](3) NULL,
	[birthCountry] [varchar](4) NULL,
	[dateEnteredUS] [datetime] NULL,
	[birthVerification] [varchar](4) NULL,
	[comments] [varchar](255) NULL,
	[districtID] [int] NOT NULL,
	[hispanicEthnicity] [varchar](2) NULL,
	[identityGUID] [uniqueidentifier] NULL,
	[lastNamePhonetic] [varchar](10) NULL,
	[firstNamePhonetic] [varchar](10) NULL,
	[dateEnteredState] [datetime] NULL,
	[birthCertificate] [varchar](12) NULL,
	[immigrant] [varchar](2) NULL,
	[dateEnteredUSSchool] [datetime] NULL,
	[raceEthnicityFed] [varchar](1) NULL,
	[raceEthnicityDetermination] [varchar](2) NULL,
 CONSTRAINT [PK_IC_Identity_NEW_887985794] PRIMARY KEY CLUSTERED 
(
	[identityID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [IC].[PeriodSchedule_LOCAL]    Script Date: 06/12/2009 15:16:26 ******/
 
GO
 
GO
CREATE TABLE [IC].[PeriodSchedule_LOCAL](
	[periodScheduleID] [int] NOT NULL,
	[structureID] [int] NOT NULL,
	[name] [varchar](20) NOT NULL,
	[seq] [tinyint] NOT NULL,
 CONSTRAINT [PK_PeriodSchedule_NEW_82195251] PRIMARY KEY CLUSTERED 
(
	[periodScheduleID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [IC].[Person_LOCAL]    Script Date: 06/12/2009 15:16:26 ******/
 
GO
 
GO
CREATE TABLE [IC].[Person_LOCAL](
	[personID] [int] NOT NULL,
	[currentIdentityID] [int] NULL,
	[stateID] [varchar](15) NULL,
	[studentNumber] [varchar](15) NULL,
	[staffNumber] [varchar](15) NULL,
	[personGUID] [uniqueidentifier] NOT NULL,
	[legacyKey] [varchar](64) NULL,
	[otherID] [varchar](15) NULL,
	[staffStateID] [varchar](15) NULL,
 CONSTRAINT [PK_Person_NEW_547746680] PRIMARY KEY CLUSTERED 
(
	[personID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [IC].[RelatedPair_LOCAL]    Script Date: 06/12/2009 15:16:26 ******/
 
GO
 
GO
CREATE TABLE [IC].[RelatedPair_LOCAL](
	[personID1] [int] NOT NULL,
	[personID2] [int] NOT NULL,
	[name] [varchar](40) NULL,
	[startDate] [datetime] NULL,
	[endDate] [datetime] NULL,
	[guardian] [bit] NULL,
	[private] [bit] NULL,
	[mailing] [bit] NULL,
	[messenger] [bit] NULL,
	[seq] [tinyint] NULL,
	[comments] [varchar](255) NULL,
	[portal] [bit] NULL,
 CONSTRAINT [PK_RelatedPair_NEW_1435144163] PRIMARY KEY CLUSTERED 
(
	[personID1] ASC,
	[personID2] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO

/****** Object:  Index [IX_RelatedPair_Person2]    Script Date: 06/12/2009 15:16:26 ******/
CREATE NONCLUSTERED INDEX [IX_RelatedPair_Person2] ON [IC].[RelatedPair_LOCAL] 
(
	[personID2] ASC
) ON [PRIMARY]
GO
/****** Object:  Table [IC].[Roster_LOCAL]    Script Date: 06/12/2009 15:16:26 ******/
 
GO
 
GO
CREATE TABLE [IC].[Roster_LOCAL](
	[rosterId] [int] NOT NULL,
	[trialID] [int] NOT NULL,
	[personID] [int] NOT NULL,
	[sectionID] [int] NOT NULL,
	[startDate] [datetime] NULL,
	[endDate] [datetime] NULL,
 CONSTRAINT [PK_Roster_NEW_1125019186] PRIMARY KEY CLUSTERED 
(
	[rosterId] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [IC].[ScheduleStructure_LOCAL]    Script Date: 06/12/2009 15:16:26 ******/
 
GO
 
GO
CREATE TABLE [IC].[ScheduleStructure_LOCAL](
	[structureID] [int] NOT NULL,
	[calendarID] [int] NOT NULL,
	[name] [varchar](20) NOT NULL,
	[structureGUID] [uniqueidentifier] NULL,
 CONSTRAINT [PK_ScheduleStructure_NEW_856792608] PRIMARY KEY CLUSTERED 
(
	[structureID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [IC].[School_LOCAL]    Script Date: 06/12/2009 15:16:26 ******/
 
GO
 
GO
CREATE TABLE [IC].[School_LOCAL](
	[schoolID] [int] NOT NULL,
	[districtID] [int] NOT NULL,
	[ncesSchoolID] [int] NULL,
	[number] [varchar](6) NOT NULL,
	[name] [varchar](40) NOT NULL,
	[type] [varchar](5) NULL,
	[comments] [varchar](255) NULL,
	[address] [varchar](50) NULL,
	[city] [varchar](25) NULL,
	[state] [varchar](2) NULL,
	[zip] [varchar](10) NULL,
	[phone] [varchar](25) NULL,
	[fax] [varchar](25) NULL,
	[email] [varchar](100) NULL,
	[url] [varchar](100) NULL,
	[dualEnrollment] [bit] NULL,
	[title1] [varchar](2) NULL,
	[principalName] [varchar](80) NULL,
	[principalTitle] [varchar](50) NULL,
	[principalEmail] [varchar](100) NULL,
	[schoolGUID] [uniqueidentifier] NOT NULL,
	[catalogID] [int] NULL,
	[satNumber] [varchar](8) NULL,
	[standardCode] [varchar](10) NULL,
	[agency] [varchar](50) NULL,
	[restructureStartDate] [datetime] NULL,
	[restructureEndDate] [datetime] NULL,
	[groupNumber] [varchar](10) NULL,
	[aypGrouping] [varchar](10) NULL,
	[reportingSchoolID] [int] NULL,
	[physicalAddress] [varchar](50) NULL,
	[physicalCity] [varchar](25) NULL,
	[physicalState] [varchar](2) NULL,
	[physicalZip] [varchar](10) NULL,
	[county] [varchar](50) NULL,
	[status] [varchar](8) NULL,
	[accreditation] [varchar](10) NULL,
	[gradeType] [varchar](5) NULL,
	[sector] [varchar](10) NULL,
	[locale] [varchar](2) NULL,
	[locale2] [varchar](2) NULL,
	[blueRibbon] [varchar](1) NULL,
	[title1distinguished] [varchar](1) NULL,
	[entityID] [int] NULL,
	[aypStatus] [varchar](8) NULL,
	[size] [varchar](2) NULL,
	[sessionType] [varchar](4) NULL,
 CONSTRAINT [PK_School_NEW_1397958291] PRIMARY KEY CLUSTERED 
(
	[schoolID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [IC].[Section_LOCAL]    Script Date: 06/12/2009 15:16:26 ******/
 
GO
 
GO
CREATE TABLE [IC].[Section_LOCAL](
	[sectionID] [int] NOT NULL,
	[trialID] [int] NOT NULL,
	[courseID] [int] NOT NULL,
	[number] [smallint] NOT NULL,
	[teacherDisplay] [varchar](30) NULL,
	[maxStudents] [smallint] NULL,
	[classType] [varchar](2) NULL,
	[schedGroupID] [int] NULL,
	[roomID] [int] NULL,
	[lunchID] [int] NULL,
	[lunchcount] [bit] NULL,
	[milkcount] [bit] NULL,
	[adultcount] [bit] NULL,
	[serviceDistrict] [varchar](20) NULL,
	[serviceSchool] [varchar](20) NULL,
	[multipleTeacherCode] [varchar](2) NULL,
	[lockBuild] [bit] NULL,
	[lockRoster] [bit] NULL,
	[giftedDelivery] [varchar](1) NULL,
	[giftedContentArea] [varchar](2) NULL,
	[teacherPersonID] [int] NULL,
	[parapros] [tinyint] NULL,
	[skinnySeq] [tinyint] NULL,
	[legacyKey] [int] NULL,
	[weeklyMinutes] [tinyint] NULL,
	[startDate] [datetime] NULL,
	[endDate] [datetime] NULL,
	[highlyQualified] [varchar](2) NULL,
	[homeroomSection] [bit] NULL,
	[teachingmethod] [varchar](4) NULL,
 CONSTRAINT [PK_Section_NEW_1394500707] PRIMARY KEY CLUSTERED 
(
	[sectionID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO

/****** Object:  Index [IX_Section_LOCAL]    Script Date: 06/12/2009 15:16:26 ******/
CREATE NONCLUSTERED INDEX [IX_Section_LOCAL] ON [IC].[Section_LOCAL] 
(
	[sectionID] ASC
) ON [PRIMARY]
GO
/****** Object:  Table [IC].[Teacher_LOCAL]    Script Date: 06/12/2009 15:16:26 ******/
 
GO
 
GO
CREATE TABLE [IC].[Teacher_LOCAL](
	[personID] [int] NOT NULL,
	[sectionID] [int] NOT NULL,
	[trialID] [int] NOT NULL,
 CONSTRAINT [PK_Teacher_NEW_969343823] PRIMARY KEY CLUSTERED 
(
	[personID] ASC,
	[sectionID] ASC,
	[trialID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [IC].[Term_LOCAL]    Script Date: 06/12/2009 15:16:26 ******/
 
GO
 
GO
CREATE TABLE [IC].[Term_LOCAL](
	[termID] [int] NOT NULL,
	[termScheduleID] [int] NOT NULL,
	[name] [varchar](10) NOT NULL,
	[seq] [tinyint] NOT NULL,
	[startDate] [datetime] NULL,
	[endDate] [datetime] NULL,
	[stateCode] [varchar](3) NULL,
 CONSTRAINT [PK_Term_NEW_1952902928] PRIMARY KEY CLUSTERED 
(
	[termID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [IC].[TermSchedule_LOCAL]    Script Date: 06/12/2009 15:16:26 ******/
 
GO
 
GO
CREATE TABLE [IC].[TermSchedule_LOCAL](
	[termScheduleID] [int] NOT NULL,
	[structureID] [int] NOT NULL,
	[name] [varchar](20) NOT NULL,
	[primary] [bit] NULL,
 CONSTRAINT [PK_TermSchedule_NEW_582701916] PRIMARY KEY CLUSTERED 
(
	[termScheduleID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [IC].[transcriptCourse_local]    Script Date: 06/12/2009 15:16:26 ******/
 
GO
 
GO
CREATE TABLE [IC].[transcriptCourse_local](
	[transcriptID] [int] NOT NULL,
	[personID] [int] NOT NULL,
	[courseNumber] [varchar](13) NOT NULL,
	[stateCode] [varchar](15) NULL,
	[courseName] [varchar](60) NULL,
	[standardNumber] [varchar](10) NULL,
	[standardName] [varchar](255) NULL,
	[districtNumber] [varchar](9) NULL,
	[schoolNumber] [varchar](6) NULL,
	[schoolName] [varchar](50) NULL,
	[status] [varchar](2) NULL,
	[date] [datetime] NULL,
	[startYear] [smallint] NULL,
	[endYear] [smallint] NULL,
	[grade] [varchar](3) NULL,
	[score] [varchar](10) NULL,
	[percent] [numeric](6, 3) NULL,
	[gpaWeight] [numeric](6, 4) NULL,
	[gpaValue] [numeric](7, 4) NULL,
	[bonusPoints] [numeric](7, 5) NULL,
	[gpaMax] [numeric](7, 4) NULL,
	[scoreID] [int] NULL,
	[startTerm] [tinyint] NULL,
	[endTerm] [tinyint] NULL,
	[termsLong] [tinyint] NULL,
	[actualTerm] [tinyint] NULL,
	[comments] [varchar](1200) NULL,
	[exempt] [bit] NULL,
	[vocationalCode] [varchar](4) NULL,
	[distanceCode] [varchar](2) NULL,
	[honorsCode] [varchar](2) NULL,
	[activityCode] [varchar](3) NULL,
	[technology] [bit] NULL,
	[giftedDelivery] [varchar](1) NULL,
	[giftedContentArea] [varchar](2) NULL,
	[teacherNumber] [varchar](9) NULL,
	[legacyKey] [varchar](20) NULL,
	[unweightedGPAValue] [numeric](7, 4) NULL,
	[coursePart] [tinyint] NULL,
	[specialEdCode] [varchar](2) NULL,
	[courseType] [varchar](15) NULL,
	[districtID] [int] NOT NULL,
	[modifiedDate] [datetime] NULL,
	[modifiedByID] [int] NULL,
	[repeatCourse] [bit] NULL,
	[collegeCode] [varchar](2) NULL,
	[calendarTerms] [tinyint] NULL,
	[termStartDate] [datetime] NULL,
	[termEndDate] [datetime] NULL,
	[specialGPA] [bit] NULL,
	[specialCode] [varchar](15) NULL,
	[abbreviation] [varchar](8) NULL,
	[altStateCode] [varchar](15) NULL,
	[summerSchool] [bit] NULL,
	[gradingTaskCode] [varchar](25) NULL,
	[calendarType] [varchar](4) NULL,
	[transcriptField1] [varchar](255) NULL,
	[transcriptField2] [varchar](255) NULL,
	[transcriptField3] [varchar](255) NULL,
	[transcriptField4] [varchar](255) NULL,
	[transcriptField5] [varchar](255) NULL,
	[teacherPersonID] [int] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [IC].[TranscriptCredit_LOCAL]    Script Date: 06/12/2009 15:16:26 ******/
 
GO
 
GO
CREATE TABLE [IC].[TranscriptCredit_LOCAL](
	[creditID] [int] NOT NULL,
	[personID] [int] NOT NULL,
	[transcriptID] [int] NOT NULL,
	[standardID] [int] NULL,
	[creditsEarned] [numeric](6, 3) NULL,
	[creditsAttempted] [numeric](6, 3) NULL,
	[creditCode] [varchar](4) NULL,
 CONSTRAINT [PK_TranscriptCredit_NEW_1845911378] PRIMARY KEY CLUSTERED 
(
	[creditID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [IC].[Trial_LOCAL]    Script Date: 06/12/2009 15:16:26 ******/
 
GO
 
GO
CREATE TABLE [IC].[Trial_LOCAL](
	[trialID] [int] NOT NULL,
	[parentID] [int] NULL,
	[calendarID] [int] NOT NULL,
	[structureID] [int] NOT NULL,
	[name] [varchar](50) NULL,
	[modifiedDate] [datetime] NULL,
	[comments] [varchar](250) NULL,
	[active] [bit] NULL,
	[fullDepth] [tinyint] NULL,
	[autoDepth] [tinyint] NULL,
	[autoMove] [tinyint] NULL,
	[autoCreate] [tinyint] NULL,
	[gridDisplay] [tinyint] NULL,
	[conflictTeacher] [bit] NULL,
	[conflictRoom] [bit] NULL,
	[conflictRoster] [bit] NULL,
	[conflictSingleton] [bit] NULL,
	[missingTeacher] [bit] NULL,
	[missingRoom] [bit] NULL,
	[missingGroup] [bit] NULL,
	[highlightSeats] [bit] NULL,
	[highlightFull] [bit] NULL,
	[highlightEmpty] [bit] NULL,
	[highlightSingleton] [bit] NULL,
	[highlightLocked] [bit] NULL,
	[yAxis] [bit] NULL,
	[periodDisplay] [bit] NULL,
	[legacyKey] [int] NULL,
	[studentBalanceWeight] [tinyint] NULL,
	[genderBalanceWeight] [tinyint] NULL,
	[minorityBalanceWeight] [tinyint] NULL,
	[specialEdBalanceWeight] [tinyint] NULL,
	[disciplineBalanceWeight] [tinyint] NULL,
 CONSTRAINT [PK_Trial_NEW_671078462] PRIMARY KEY CLUSTERED 
(
	[trialID] ASC
) ON [PRIMARY]
) ON [PRIMARY]
GO

CREATE VIEW IC.SCHOOL
AS 
	SELECT * FROM IC.SCHOOL_LOCAL
GO

CREATE TABLE [IC].[Map_SchoolID](
	[SchoolID] [int] NOT NULL,
	[DestID] [uniqueidentifier] NOT NULL,
 CONSTRAINT [PK_IC_MapSchoolID] PRIMARY KEY CLUSTERED 
(
	[DestID] ASC
))
GO

INSERT INTO VC3ETL.LoadTable VALUES ('B7E1295D-E833-4A2D-BE05-A0D7D642D5D7', '19A65267-D406-4624-852A-BEA3DB449C5C', 1, 'IC.Transform_School', 'School', 1, 'IC.Map_SchoolID', 'schoolID', 'DestID', 1,1,1,1,1, NULL, NULL, NULL, 0, 0, NULL)

INSERT INTO VC3ETL.LoadColumn VALUES ('0250B421-2DCF-4A94-918E-51454328AD4D' , 'B7E1295D-E833-4A2D-BE05-A0D7D642D5D7', 'Number' , 'NUmber' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('D4A5F6CC-0226-4F1F-A23B-89E74992C73F' , 'B7E1295D-E833-4A2D-BE05-A0D7D642D5D7', 'Name' , 'Name' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('74D10134-6B04-4ADD-9163-16B85CD298B0' , 'B7E1295D-E833-4A2D-BE05-A0D7D642D5D7', 'DestId' , 'ID' , 'K' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('7E5430FC-B7FD-4648-821B-0F60FC0FB49D' , 'B7E1295D-E833-4A2D-BE05-A0D7D642D5D7', 'Abbreviation' , 'Abbreviation' , 'C' , 0 ,NULL,NULL)

--EnumValue

GO
CREATE VIEW IC.CampusDictionary
AS 
	SELECT * FROM IC.CampusDictionary_LOCAL
GO

INSERT INTO vc3etl.ExtractTable VALUES ('E70CFA27-7679-4518-AD33-40FC8EF5D4AC', '19A65267-D406-4624-852A-BEA3DB449C5C', 'CampusDictionary', 'IC', 'CampusDictionary', 'dictionaryID', NULL, 0,0,NULL,1, 0, NULL)
INSERT INTO vc3etl.PearsonExtractTable Values ('E70CFA27-7679-4518-AD33-40FC8EF5D4AC',0, NULL)
GO

INSERT INTO VC3ETL.LoadTable VALUES ('D11CC8E6-E647-4766-8F1A-94E908C77DCB', '19A65267-D406-4624-852A-BEA3DB449C5C', 3, 'IC.Transform_EnumValue', 'EnumValue', 1, 'IC.Map_EnumValueID', 'attributeID, code', 'DestID', 1,1,1,1,1, NULL, NULL, NULL, 0, 0, NULL)

INSERT INTO VC3ETL.LoadColumn VALUES ('70EECA1A-E6E1-433D-BF38-C83D610B6987' , 'D11CC8E6-E647-4766-8F1A-94E908C77DCB', 'Name' , 'DisplayValue' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('21085E5A-599D-429C-9383-4496AE80B275' , 'D11CC8E6-E647-4766-8F1A-94E908C77DCB', 'DestID' , 'ID' , 'K' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('231C7186-5AAE-4D36-8FA8-7A025ED07AEB' , 'D11CC8E6-E647-4766-8F1A-94E908C77DCB', 'Type' , 'Type' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('51F0C440-201B-4473-8F2A-223E54596C94' , 'D11CC8E6-E647-4766-8F1A-94E908C77DCB', 'code' , 'Code' , 'C' , 0 ,NULL,NULL)
GO



CREATE VIEW IC.CampusAttribute
AS 
	SELECT * FROM IC.CampusAttribute_LOCAL
GO

INSERT INTO vc3etl.ExtractTable VALUES ('942AA705-8E10-4C58-901E-DB46A69B4370', '19A65267-D406-4624-852A-BEA3DB449C5C', 'CampusAttribute', 'IC', 'CampusAttribute', 'attributeID', NULL, 0,0,NULL,1, 0, NULL)
INSERT INTO vc3etl.PearsonExtractTable Values ('942AA705-8E10-4C58-901E-DB46A69B4370',0, NULL)
GO

CREATE TABLE IC.Map_EnumTypeID 
(
	Object varchar(30) not null,
	Element varchar(30) not null,
	AttributeID int not null,
	[DestID] [uniqueidentifier] NOT NULL,
 CONSTRAINT [PK_IC_Map_EnumTypeID] PRIMARY KEY CLUSTERED 
(
	[DestID] ASC
))
GO

CREATE TABLE IC.Map_EnumValueID
(	
	AttributeID int not null,
	Code varchar (15),
	[DestID] [uniqueidentifier] NOT NULL,
 CONSTRAINT [PK_IC_Map_EnumValueID] PRIMARY KEY CLUSTERED 
(
	[DestID] ASC
))
GO
CREATE NONCLUSTERED INDEX IX_Map_EnumTypeID_AttributeID ON IC.Map_EnumTypeID
	(
	AttributeID
	)
GO

CREATE NONCLUSTERED INDEX IX_Map_EnumValueID ON IC.Map_EnumValueID
	(
	AttributeID,
	Code
	)
GO

INSERT INTO IC.Map_EnumTypeID  VALUES ('identity', 'raceEthnicity', 0, 'CBB84AE3-A547-4E81-82D2-060AA3A50535')
INSERT INTO IC.Map_EnumTypeID  VALUES ('Enrollment', 'adjCohortGender', 0, 'D6194389-17AC-494C-9C37-FD911DA2DD4B')
GO

INSERT INTO VC3ETL.LoadTable VALUES ('7B1D5CB8-F31C-4B29-9F28-A33D96D5B725', '19A65267-D406-4624-852A-BEA3DB449C5C', 2, 'IC.Transform_EnumType', 'IC.Map_EnumTypeID', 1, 'IC.Map_EnumTypeID', 'object, element, attributeID', 'DestID', 1,0,1,0,1, NULL, NULL, NULL, 0, 0, NULL)

INSERT INTO VC3ETL.LoadColumn VALUES ('5BCA77CD-2933-467A-B659-9C3EFC6DD328' , '7B1D5CB8-F31C-4B29-9F28-A33D96D5B725', 'DestID' , 'DestID' , 'K' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('C31FA40B-5028-4436-B1AD-A604AFC67F83' , '7B1D5CB8-F31C-4B29-9F28-A33D96D5B725', 'AttributeID' , 'AttributeID' , 'C' , 0 ,NULL,NULL)


--Person
INSERT INTO vc3etl.ExtractTable VALUES ('B7E0A49D-A008-4ADF-B84B-8E1972DE0B89', '19A65267-D406-4624-852A-BEA3DB449C5C', 'Person', 'IC', 'Person', 'personID', NULL, 0,0,NULL,1, 0, NULL)
INSERT INTO vc3etl.PearsonExtractTable Values ('B7E0A49D-A008-4ADF-B84B-8E1972DE0B89',0, NULL)
GO



CREATE VIEW  IC.Person
AS 
	SELECT * FROM IC.Person_LOCAL
GO

--Identity
INSERT INTO vc3etl.ExtractTable VALUES ('EED57054-C00B-47AB-8C2F-9557EDF74ADC', '19A65267-D406-4624-852A-BEA3DB449C5C', '[Identity]', 'IC', 'IC_Identity', 'identityID', NULL, 0,0,NULL,1, 0, NULL)
INSERT INTO vc3etl.PearsonExtractTable Values ('EED57054-C00B-47AB-8C2F-9557EDF74ADC',0, NULL)
GO

CREATE VIEW  [IC].[IC_Identity]
AS 
	SELECT * FROM IC.IC_Identity_LOCAL
GO


INSERT INTO vc3etl.ExtractTable VALUES ('7C613B3E-9571-4C44-B836-308D5CD7B78B', '19A65267-D406-4624-852A-BEA3DB449C5C', 'Enrollment', 'IC', 'Enrollment', 'enrollmentID', NULL, 0,0,NULL,1, 0, NULL)
INSERT INTO vc3etl.PearsonExtractTable Values ('7C613B3E-9571-4C44-B836-308D5CD7B78B',0, NULL)
GO


CREATE VIEW  IC.Enrollment
AS 
	SELECT * FROM IC.Enrollment_LOCAL
GO

CREATE TABLE IC.Map_StudentID
(	
	PersonID int not null,
	[DestID] [uniqueidentifier] NOT NULL,
 CONSTRAINT [PK_IC_Map_StudentID] PRIMARY KEY CLUSTERED 
(
	[DestID] ASC
))
GO

INSERT INTO vc3etl.ExtractTable VALUES ('7A76FDDF-62E0-4A09-8320-567F4AF34BAB', '19A65267-D406-4624-852A-BEA3DB449C5C', 'Contact', 'IC', 'Contact', 'personID', NULL, 0,0,NULL,1, 0, NULL)
INSERT INTO vc3etl.PearsonExtractTable Values ('7A76FDDF-62E0-4A09-8320-567F4AF34BAB',0, NULL)
GO



CREATE VIEW  IC.Contact
AS 
	SELECT * FROM IC.Contact_LOCAL
GO

--Student Import
INSERT INTO VC3ETL.LoadTable VALUES ('F0EC0B8D-2848-41AF-9E9D-C0036791FCBE', '19A65267-D406-4624-852A-BEA3DB449C5C', 3, 'IC.Transform_Student(@endYear, @ImportDate)', 'Student', 1, 'IC.Map_StudentID', 'personID', 'DestID', 1,1,1,1,1, NULL, NULL, NULL, 0, 0, NULL)

INSERT INTO VC3ETL.LoadColumn VALUES ('CCCE7278-2FA3-4252-8822-50E15B3F275A' , 'F0EC0B8D-2848-41AF-9E9D-C0036791FCBE', 'GenderID' , 'GenderID' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('E1B8533E-5270-44DC-9EF1-97A7CAF3A042' , 'F0EC0B8D-2848-41AF-9E9D-C0036791FCBE', 'DestID' , 'ID' , 'K' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('4C3941CA-5A12-4EE6-A329-D7BB39B89354' , 'F0EC0B8D-2848-41AF-9E9D-C0036791FCBE', 'studentNUmber' , 'Number' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('89C768C3-DF7F-4EB7-909C-D5463CB14738' , 'F0EC0B8D-2848-41AF-9E9D-C0036791FCBE', 'City' , 'City' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('50DD3EEF-2F98-45D2-BF09-C8BA58A3230C' , 'F0EC0B8D-2848-41AF-9E9D-C0036791FCBE', 'GradeLevelID' , 'CurrentGradeLevelID' , 'C' , 1 ,'NULL',NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('54077188-7B0B-4558-B2FD-CA7A5FAEE69C' , 'F0EC0B8D-2848-41AF-9E9D-C0036791FCBE', 'lastName' , 'LastName' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('6A41BBF9-DE96-4EB5-ADE3-F60AD33C7735' , 'F0EC0B8D-2848-41AF-9E9D-C0036791FCBE', 'firstName' , 'FirstName' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('7F7F61A8-0CFC-49C8-8F5A-714148C46871' , 'F0EC0B8D-2848-41AF-9E9D-C0036791FCBE', 'HomePhone' , 'PhoneNumber' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('FA4FD2CB-2A2C-4075-B5DA-9D3D752FD273' , 'F0EC0B8D-2848-41AF-9E9D-C0036791FCBE', 'state' , 'State' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('C9E12AD5-8C67-48DE-9B06-7AA6A9DDF8F6' , 'F0EC0B8D-2848-41AF-9E9D-C0036791FCBE', 'EthnicityID' , 'EthnicityID' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('8FA935FC-DF47-4A30-990B-731629AECCFC' , 'F0EC0B8D-2848-41AF-9E9D-C0036791FCBE', 'middleName' , 'MiddleName' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('EEE0A7AA-512B-47DC-AE03-9F6A9BA320DA' , 'F0EC0B8D-2848-41AF-9E9D-C0036791FCBE', 'SchoolID' , 'CurrentSchoolID' , 'C' , 1 ,'NULL',NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('FADF4279-F137-4276-B8F0-FF5DFC461ED3' , 'F0EC0B8D-2848-41AF-9E9D-C0036791FCBE', 'birthdate' , 'DOB' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('31C91590-9E86-4287-B4D5-D367D970C271' , 'F0EC0B8D-2848-41AF-9E9D-C0036791FCBE', 'cumulative_gpa' , 'gpa' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('B6907168-1A91-4806-B23C-CC6B8FB442EA' , 'F0EC0B8D-2848-41AF-9E9D-C0036791FCBE', 'condensed_street' , 'street' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('31AB0C90-32C1-4917-BFD0-02019FBFF302' , 'F0EC0B8D-2848-41AF-9E9D-C0036791FCBE', 'zip' , 'ZipCode' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('1D36F96D-AA1B-422A-9523-15B5AB325360' , 'F0EC0B8D-2848-41AF-9E9D-C0036791FCBE', 'SOCSECNUM_VALIDATED' , 'SSN' , 'C' , 0 ,NULL,NULL)

INSERT INTO vc3etl.ExtractTable VALUES ('418FFD78-94E1-4D44-9292-9D854B994A2D', '19A65267-D406-4624-852A-BEA3DB449C5C', 'HouseholdMember', 'IC', 'HouseholdMember', 'memberID', NULL, 0,0,NULL,1, 0, NULL)
INSERT INTO vc3etl.PearsonExtractTable Values ('418FFD78-94E1-4D44-9292-9D854B994A2D',0, NULL)
GO



CREATE VIEW  IC.HouseholdMember
AS 
	SELECT * FROM IC.HouseholdMember_LOCAL
GO

INSERT INTO vc3etl.ExtractTable VALUES ('4340C7B0-65A5-4E3D-9519-72BB9B1745DE', '19A65267-D406-4624-852A-BEA3DB449C5C', 'Household', 'IC', 'Household', 'householdID', NULL, 0,0,NULL,1, 0, NULL)
INSERT INTO vc3etl.PearsonExtractTable Values ('4340C7B0-65A5-4E3D-9519-72BB9B1745DE',0, NULL)
GO



CREATE VIEW  IC.Household
AS 
	SELECT * FROM IC.Household_LOCAL
GO

INSERT INTO vc3etl.ExtractTable VALUES ('4D627944-9BD4-4606-874A-DC42E1B10D69', '19A65267-D406-4624-852A-BEA3DB449C5C', 'HouseholdLocation', 'IC', 'HouseholdLocation', 'locationID, householdID', NULL, 0,0,NULL,1, 0, NULL)
INSERT INTO vc3etl.PearsonExtractTable Values ('4D627944-9BD4-4606-874A-DC42E1B10D69',0, NULL)
GO



CREATE VIEW  IC.HouseholdLocation
AS 
	SELECT * FROM IC.HouseholdLocation_LOCAL
GO

INSERT INTO vc3etl.ExtractTable VALUES ('E8295209-2701-43D6-9743-AF15A9A9D1B1', '19A65267-D406-4624-852A-BEA3DB449C5C', 'Address', 'IC', 'Address', 'addressID', NULL, 0,0,NULL,1, 0, NULL)
INSERT INTO vc3etl.PearsonExtractTable Values ('E8295209-2701-43D6-9743-AF15A9A9D1B1',0, NULL)
GO



CREATE VIEW  IC.Address
AS 
	SELECT * FROM IC.Address_LOCAL
GO

--Teacher
INSERT INTO vc3etl.ExtractTable VALUES ('9ACF986F-B8ED-44AC-971D-27B96188A2A9', '19A65267-D406-4624-852A-BEA3DB449C5C', 'Employment', 'IC', 'Employment', 'employmentID', NULL, 0,0,NULL,1, 0, NULL)
INSERT INTO vc3etl.PearsonExtractTable Values ('9ACF986F-B8ED-44AC-971D-27B96188A2A9',0, NULL)
GO



CREATE VIEW  IC.Employment
AS 
	SELECT * FROM IC.Employment_LOCAL
GO

CREATE TABLE IC.Map_TeacherID
(	
	PersonID int not null,
	[DestID] [uniqueidentifier] NOT NULL,
 CONSTRAINT [PK_IC_Map_TeacherID] PRIMARY KEY CLUSTERED 
(
	[DestID] ASC
))
GO

--EmployeeAssignment
INSERT INTO vc3etl.ExtractTable VALUES ('7568F1AD-BFBF-4E5F-8DC5-2D0B5E1F4825', '19A65267-D406-4624-852A-BEA3DB449C5C', 'EmploymentAssignment', 'IC', 'EmploymentAssignment', 'assignmentID', NULL, 0,0,NULL,1, 0, NULL)
INSERT INTO vc3etl.PearsonExtractTable Values ('7568F1AD-BFBF-4E5F-8DC5-2D0B5E1F4825',0, NULL)
GO



CREATE VIEW  IC.EmploymentAssignment
AS 
	SELECT * FROM IC.EmploymentAssignment_LOCAL
GO

--GradeLevel
INSERT INTO vc3etl.ExtractTable VALUES ('C825E40F-F61B-4EA8-B87A-D3347286A8FD', '19A65267-D406-4624-852A-BEA3DB449C5C', 'GradeLevel', 'IC', 'GradeLevel', 'gradeLevelID', NULL, 0,0,NULL,1, 0, NULL)
INSERT INTO vc3etl.PearsonExtractTable Values ('C825E40F-F61B-4EA8-B87A-D3347286A8FD',0, NULL)
GO



CREATE VIEW  IC.GradeLevel
AS 
	SELECT * FROM IC.GradeLevel_LOCAL
GO

--GradeLevel import
INSERT INTO VC3ETL.LoadTable VALUES ('619E3826-C171-486A-9063-457548886CE9', '19A65267-D406-4624-852A-BEA3DB449C5C', 4, 'IC.Transform_GradeLevel(@endYear)', 'GradeLevel', 1, 'IC.Map_GradeLevelID', 'name', 'DestID', 1,0,1,1,1, NULL, NULL, NULL, 0, 0, NULL)

INSERT INTO VC3ETL.LoadColumn VALUES ('A812AF5C-563C-49F9-9F1A-D882CC2EFC53' , '619E3826-C171-486A-9063-457548886CE9', 'DestID', 'ID', 'K', 0, NULL, NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('E8696D02-0AAA-4D08-8385-C0CAE305AF41' , '619E3826-C171-486A-9063-457548886CE9', 'Name', 'Name', 'C', 0, NULL, NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('84695D39-8338-4B7C-B534-6DB54D4F13B7' , '619E3826-C171-486A-9063-457548886CE9', 'Sequence', 'Sequence', 'C', 0, NULL, NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('9AB48E2F-7023-4D39-A000-B291A3C36109' , '619E3826-C171-486A-9063-457548886CE9', 'BitMask', 'BitMask', 'C', 0, NULL, NULL)
GO

CREATE TABLE IC.Map_GradeLevelID
(	
	Name varchar(4) not null,
	[DestID] [uniqueidentifier] NOT NULL,
 CONSTRAINT [PK_IC_Map_GradeLevelID] PRIMARY KEY CLUSTERED 
(
	[DestID] ASC
))
GO

--Teacher
INSERT INTO VC3ETL.LoadTable VALUES ('F11A0806-B2BB-43D8-BE04-5422F0133D76', '19A65267-D406-4624-852A-BEA3DB449C5C', 5, 'IC.Transform_Teacher(@endYear, @ImportDate)', 'Teacher', 1, 'IC.Map_TeacherID', 'personID', 'DestID', 1,1,1,1,1, NULL, NULL, NULL, 0, 0, NULL)

INSERT INTO VC3ETL.LoadColumn VALUES ('1E2B2156-B23B-47E2-9F97-F691E3AB11A4' , 'F11A0806-B2BB-43D8-BE04-5422F0133D76', 'email' , 'EmailAddress' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('CF6D2234-6214-4AB2-8091-75751626FFC8' , 'F11A0806-B2BB-43D8-BE04-5422F0133D76', 'workPhone' , 'PhoneNUmber' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('6EB70BAC-83FB-4050-A852-6E4F1C68481F' , 'F11A0806-B2BB-43D8-BE04-5422F0133D76', 'state' , 'state' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('860DBD31-21F2-4CE4-A2D5-9A86AC1A8205' , 'F11A0806-B2BB-43D8-BE04-5422F0133D76', 'SOCSECNUM_VALIDATED' , 'SSN' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('F07871C0-6D77-421E-9E86-E8EB3E034B3B' , 'F11A0806-B2BB-43D8-BE04-5422F0133D76', 'EthnicityID' , 'EthnicityID' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('E7D7EED2-C445-4453-8B50-F7A02EC503B6' , 'F11A0806-B2BB-43D8-BE04-5422F0133D76', 'zip' , 'zipcode' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('3CA4445E-533B-4FA0-AA78-693B353CF4A9' , 'F11A0806-B2BB-43D8-BE04-5422F0133D76', 'LastName' , 'LastName' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('0B9E1AFA-F8C3-471A-B3AA-48EB8072C43C' , 'F11A0806-B2BB-43D8-BE04-5422F0133D76', 'GenderId' , 'GenderId' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('CE493ADB-B9BE-4093-B986-9762D0BFA3F2' , 'F11A0806-B2BB-43D8-BE04-5422F0133D76', 'CurrentSchoolID' , 'CurrentSchoolID' , 'C' , 1 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('36BE2A4E-A87C-4A2E-B37A-27AD02454714' , 'F11A0806-B2BB-43D8-BE04-5422F0133D76', 'FIRSTNAME' , 'FirstName' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('5B0FFA11-9E99-42C4-9CF5-C1CE863805DC' , 'F11A0806-B2BB-43D8-BE04-5422F0133D76', 'UserProfileID' , 'UserProfileID' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('D065FA74-A3C7-43B2-B901-016BB763FB5A' , 'F11A0806-B2BB-43D8-BE04-5422F0133D76', 'DESTID' , 'ID' , 'K' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('FE3D4819-672B-4447-8807-870FA1648390' , 'F11A0806-B2BB-43D8-BE04-5422F0133D76', 'condensed_street' , 'street' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('0FE8791C-FCA1-41C6-A5EF-A4EE78CDC461' , 'F11A0806-B2BB-43D8-BE04-5422F0133D76', 'city' , 'city' , 'C' , 0 ,NULL,NULL)

INSERT INTO VC3ETL.LoadColumn VALUES ('7090402B-DAC3-4CB0-BC65-C692A27D8584' , 'F11A0806-B2BB-43D8-BE04-5422F0133D76', 'birthdate', 'DOB' , 'C' , 0 ,NULL,NULL)

--Doing hire/start dates is more complicated than first thought
--INSERT INTO VC3ETL.LoadColumn VALUES ('DF73CBDB-0CE6-4FC6-A7F3-A755E51159A1' , 'F11A0806-B2BB-43D8-BE04-5422F0133D76', 'startDate' , 'HireDate' , 'C' , 0 ,NULL,NULL)
--INSERT INTO VC3ETL.LoadColumn VALUES ('8E41B6F2-487C-4315-8932-D43FCAFAFD6B' , 'F11A0806-B2BB-43D8-BE04-5422F0133D76', 'endDate' , 'ExitDate' , 'C' , 0 ,NULL,NULL)

INSERT INTO vc3etl.ExtractTable VALUES ('BB2B0B0B-D272-4F44-96C2-058E2D298D0C', '19A65267-D406-4624-852A-BEA3DB449C5C', 'Teacher', 'IC', 'Teacher', 'personID, sectionID, trialID', NULL, 0,0,NULL,1, 0, NULL)
INSERT INTO vc3etl.PearsonExtractTable Values ('BB2B0B0B-D272-4F44-96C2-058E2D298D0C',0, NULL)
GO


CREATE VIEW  IC.Teacher
AS 
	SELECT * FROM IC.Teacher_LOCAL
GO

INSERT INTO vc3etl.ExtractTable VALUES ('D31CF6AE-4BF9-47D6-891A-1D1322EE1F55', '19A65267-D406-4624-852A-BEA3DB449C5C', 'Trial', 'IC', 'Trial', 'trialID', NULL, 0,0,NULL,1, 0, NULL)
INSERT INTO vc3etl.PearsonExtractTable Values ('D31CF6AE-4BF9-47D6-891A-1D1322EE1F55',0, NULL)
GO



CREATE VIEW  IC.Trial
AS 
	SELECT * FROM IC.Trial_LOCAL
GO

--Calendar
INSERT INTO vc3etl.ExtractTable VALUES ('A46A2340-FB22-499F-977F-0B748004612F', '19A65267-D406-4624-852A-BEA3DB449C5C', 'Calendar', 'IC', 'Calendar', 'calendarID', 'EndYear', 0,0,NULL,1, 0, NULL)
INSERT INTO vc3etl.PearsonExtractTable Values ('A46A2340-FB22-499F-977F-0B748004612F',0, NULL)
GO



CREATE VIEW  IC.Calendar
AS 
	SELECT * FROM IC.Calendar_LOCAL
GO

--ClassROster
INSERT INTO vc3etl.ExtractTable VALUES ('3C0C3580-43E6-47EF-8CFD-FF6AA1F4D657', '19A65267-D406-4624-852A-BEA3DB449C5C', 'Roster', 'IC', 'Roster', 'rosterID', NULL, 0,0,NULL, 1, 0, NULL)
INSERT INTO vc3etl.PearsonExtractTable Values ('3C0C3580-43E6-47EF-8CFD-FF6AA1F4D657',0, NULL)
GO



CREATE VIEW  IC.Roster
AS 
	SELECT * FROM IC.Roster_LOCAL
GO

--Transcript Course
INSERT INTO VC3ETL.LoadTable VALUES ('B28C547C-7EBF-4A67-8994-4236CA872567', '19A65267-D406-4624-852A-BEA3DB449C5C', 6, 'IC.Transform_TranscriptCourse', 'TranscriptCourse', 0, NULL, NULL, NULL, 2,1,1,1,1, NULL, NULL, NULL, 0, 0, NULL)

INSERT INTO VC3ETL.LoadColumn VALUES ('C6760606-EB74-4C0F-AF4D-4FB9236CEFD3' , 'B28C547C-7EBF-4A67-8994-4236CA872567', 'SchoolID' , 'SchoolID' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('3D52BC57-598C-42D9-992E-4A87E4894D0B' , 'B28C547C-7EBF-4A67-8994-4236CA872567', 'StudentID' , 'StudentID' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('FB77F5D5-D36B-4C83-8DFA-E17BAC2D1C78' , 'B28C547C-7EBF-4A67-8994-4236CA872567', 'CreditsEarned' , 'CreditsEarned' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('B0253817-2993-4948-B2C6-FF41B919C3C4' , 'B28C547C-7EBF-4A67-8994-4236CA872567', 'term' , 'Term' , 'C' , 0 ,NULL,NULL)
--INSERT INTO VC3ETL.LoadColumn VALUES ('E6A97FF9-6B2F-496A-B60D-076B9745589F' , 'B28C547C-7EBF-4A67-8994-4236CA872567', 'DESTID' , 'ID' , 'K' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('3CC552ED-7630-49F5-86E0-F4151C0D8F9C' , 'B28C547C-7EBF-4A67-8994-4236CA872567', 'CourseName' , 'Name' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('6A89FBF9-36E2-4EF2-ACC2-1D383C5C82A6' , 'B28C547C-7EBF-4A67-8994-4236CA872567', 'GradeLevelID' , 'GradeLevelID' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('2A2EBC2F-9201-4388-A8C7-44C8B11B14A8' , 'B28C547C-7EBF-4A67-8994-4236CA872567', 'Score' , 'Score' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('30B48A44-E594-41DF-908D-83BFF795D8B2' , 'B28C547C-7EBF-4A67-8994-4236CA872567', 'CourseNumber' , 'Number' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('D76DA7F1-CEE4-4CE8-AB62-894F5B081765' , 'B28C547C-7EBF-4A67-8994-4236CA872567', 'RosterYearID' , 'RosterYearID' , 'C' , 0 ,NULL,NULL)

--TranscriptCourse
INSERT INTO vc3etl.ExtractTable VALUES ('463FC192-6FC6-4979-9BE0-EF2D8F79B40B', '19A65267-D406-4624-852A-BEA3DB449C5C', 'TranscriptCourse', 'IC', 'TranscriptCourse', 'transcriptID', NULL, 0,0,NULL,1, 0, NULL)
INSERT INTO vc3etl.PearsonExtractTable Values ('463FC192-6FC6-4979-9BE0-EF2D8F79B40B',0, NULL)
GO



CREATE VIEW  IC.TranscriptCourse
AS 
	SELECT * FROM IC.TranscriptCourse_LOCAL
GO

INSERT INTO vc3etl.ExtractTable VALUES ('66DCABAD-D517-4D8E-8DE7-EA2FD9262DC5', '19A65267-D406-4624-852A-BEA3DB449C5C', 'TranscriptCredit', 'IC', 'TranscriptCredit', 'creditid', NULL, 0,0,NULL,1, 0, NULL)
INSERT INTO vc3etl.PearsonExtractTable Values ('66DCABAD-D517-4D8E-8DE7-EA2FD9262DC5',0, NULL)
GO



CREATE VIEW  IC.TranscriptCredit
AS 
	SELECT * FROM IC.TranscriptCredit_LOCAL
GO

--BehaviorEvent
INSERT INTO vc3etl.ExtractTable VALUES ('3F0EBB7F-48C4-4FFB-8A8B-CC998AB078EE', '19A65267-D406-4624-852A-BEA3DB449C5C', 'BehaviorEvent', 'IC', 'BehaviorEvent', 'eventID', NULL, 0,0,NULL,1, 0, NULL)
INSERT INTO vc3etl.PearsonExtractTable Values ('3F0EBB7F-48C4-4FFB-8A8B-CC998AB078EE',0, NULL)
GO



CREATE VIEW  IC.BehaviorEvent
AS 
	SELECT * FROM IC.BehaviorEvent_LOCAL
GO

INSERT INTO vc3etl.ExtractTable VALUES ('9C8F84A3-6073-40C7-81DF-3B519A1622DA', '19A65267-D406-4624-852A-BEA3DB449C5C', 'BehaviorRole', 'IC', 'BehaviorRole', 'roleID', NULL, 0,0,NULL,1, 0, NULL)
INSERT INTO vc3etl.PearsonExtractTable Values ('9C8F84A3-6073-40C7-81DF-3B519A1622DA',0, NULL)
GO


CREATE VIEW  IC.BehaviorRole
AS 
	SELECT * FROM IC.BehaviorRole_LOCAL
GO

INSERT INTO vc3etl.ExtractTable VALUES ('886ECBBC-1186-40FC-9617-221273C78FF4', '19A65267-D406-4624-852A-BEA3DB449C5C', 'BehaviorResType', 'IC', 'BehaviorResType', 'typeID', NULL, 0,0,NULL,1, 0, NULL)
INSERT INTO vc3etl.PearsonExtractTable Values ('886ECBBC-1186-40FC-9617-221273C78FF4',0, NULL)
GO



CREATE VIEW  IC.BehaviorResType
AS 
	SELECT * FROM IC.BehaviorResType_LOCAL
GO

INSERT INTO vc3etl.ExtractTable VALUES ('DED04F7F-4C2A-493F-913D-57BCDB6C0668', '19A65267-D406-4624-852A-BEA3DB449C5C', 'BehaviorResolution', 'IC', 'BehaviorResolution', 'resolutionID', NULL, 0,0,NULL,1, 0, NULL)
INSERT INTO vc3etl.PearsonExtractTable Values ('DED04F7F-4C2A-493F-913D-57BCDB6C0668',0, NULL)
GO



CREATE VIEW  IC.BehaviorResolution
AS 
	SELECT * FROM IC.BehaviorResolution_LOCAL
GO

INSERT INTO IC.Map_EnumTypeID VALUES ('behaviorResolution', 'code',-1, '0870E284-3909-4817-BE7E-9D9C98DC6F07')

INSERT INTO VC3ETL.LoadTable VALUES ('DBA8CA3E-AA06-4822-9990-7520EDF91C05', '19A65267-D406-4624-852A-BEA3DB449C5C', 7, 'IC.Transform_DisciplineIncident(@endYear)', 'DisciplineIncident', 0, NULL, NULL, NULL, 2,1,0,1,1, NULL, 'RosterYearID = @importRosterYear', NULL, 0, 0, NULL)

INSERT INTO VC3ETL.LoadColumn VALUES ('97B3CED9-AFCA-4D08-892E-2097367BD488' , 'DBA8CA3E-AA06-4822-9990-7520EDF91C05', 'Comments' , 'Comments' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('073D460B-D38C-4991-83AB-B7B97A86B7C3' , 'DBA8CA3E-AA06-4822-9990-7520EDF91C05', 'RosterYearID' , 'RosterYearID' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('C659474D-5A56-49A1-972A-01C0FD05FCBF' , 'DBA8CA3E-AA06-4822-9990-7520EDF91C05', '[Date]' , '[Date]' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('12EDA441-DD4D-448E-BB77-975DCA585CE5' , 'DBA8CA3E-AA06-4822-9990-7520EDF91C05', 'DispositionCodeID' , 'DispositionCodeID' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('B643E4AF-DB5F-4130-8B48-CA6270B133CE' , 'DBA8CA3E-AA06-4822-9990-7520EDF91C05', 'IncidentLocationID' , 'IncidentLocationID' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('F3F75F7D-0DF5-4645-AAB2-2269B8954738' , 'DBA8CA3E-AA06-4822-9990-7520EDF91C05', 'StudentID' , 'StudentID' , 'C' , 0 ,NULL,NULL)

--calendar
INSERT INTO vc3etl.ExtractTable VALUES ('BEA67479-9C9C-4EA8-8F7E-A75C7AB33B80', '19A65267-D406-4624-852A-BEA3DB449C5C', '[Day]', 'IC', 'Day', 'dayID', 'calendarID', 0,0,NULL,1, 0, NULL)
INSERT INTO vc3etl.PearsonExtractTable Values ('BEA67479-9C9C-4EA8-8F7E-A75C7AB33B80',0, NULL)
GO



CREATE VIEW  IC.[Day]
AS 
	SELECT * FROM IC.Day_LOCAL
GO

INSERT INTO VC3ETL.LoadTable VALUES ('0D820483-AF47-4170-AD64-D8CEFFDDF90A', '19A65267-D406-4624-852A-BEA3DB449C5C', 8, 'IC.Transform_Calendar(@endYear)', 'Calendar', 1, 'IC.Map_CalendarID', 'schoolID, endYear', 'DestID', 1,0,1,1,1, NULL, NULL, NULL, 0, 0, NULL)

INSERT INTO VC3ETL.LoadColumn VALUES ('7CD906D0-4E43-4EF2-A686-4BB643F5990C' , '0D820483-AF47-4170-AD64-D8CEFFDDF90A', 'Name' , 'Name' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('52F33EE1-D40B-4335-8A0B-4D2C82B3314D' , '0D820483-AF47-4170-AD64-D8CEFFDDF90A', 'EndDate' , 'LastDate' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('577285FA-78F9-4B41-9957-29B4FF228DDA' , '0D820483-AF47-4170-AD64-D8CEFFDDF90A', 'StartDate' , 'FirstDate' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('94A47CCB-AE42-483A-B6D7-6D89B03FBBB2' , '0D820483-AF47-4170-AD64-D8CEFFDDF90A', 'DestID' , 'ID' , 'K' , 0 ,NULL,NULL)
GO

CREATE TABLE IC.Map_CalendarID
(	
	SchoolID int not null,
	EndYear int NOT NULL,
	[DestID] uniqueidentifier not null
 CONSTRAINT [PK_IC_Map_CalendarID] PRIMARY KEY CLUSTERED 
(
	[DestID] ASC
))
GO

INSERT INTO vc3etl.ExtractTable VALUES ('1414E7D1-F1F5-4070-816A-3CA44B05204F', '19A65267-D406-4624-852A-BEA3DB449C5C', 'PeriodSchedule', 'IC', 'PeriodSchedule', 'PeriodScheduleID', NULL, 0,0,NULL,0, 0, NULL)
INSERT INTO vc3etl.PearsonExtractTable Values ('1414E7D1-F1F5-4070-816A-3CA44B05204F',0, NULL)
GO



CREATE VIEW  IC.PeriodSchedule
AS 
	SELECT * FROM IC.PeriodSchedule_LOCAL
GO

CREATE NONCLUSTERED INDEX IX_Map_CalendarID ON IC.Map_CalendarID
	(
	SchoolID,
	EndYear
	) 
GO

INSERT INTO VC3ETL.LoadTable  VALUES ('07D29FE3-AA56-42BD-884D-77CB50A68B97', '19A65267-D406-4624-852A-BEA3DB449C5C', 9, 'IC.Transform_CalendarDate(@endYear)', 'CalendarDate', 0, NULL, NULL, NULL, 1,1,1,1,1, NULL, NULL, NULL, 0, 0, NULL)

INSERT INTO VC3ETL.LoadColumn VALUES ('129226DA-28AD-4723-9945-0D2CE3731796' , '07D29FE3-AA56-42BD-884D-77CB50A68B97', '[Date]' , '[Date]' , 'K' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('9B53617C-AD23-4668-B783-109D05246FAC' , '07D29FE3-AA56-42BD-884D-77CB50A68B97', 'ElapsedCalendarDays' , 'ElapsedCalendarDays' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('CB91423B-79AF-46CD-89F2-7CBAB2C20FEA' , '07D29FE3-AA56-42BD-884D-77CB50A68B97', 'ElapsedSchoolDays' , 'ElapsedSchoolDays' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('77954514-5E08-43DC-BCBC-968B6D93E53E' , '07D29FE3-AA56-42BD-884D-77CB50A68B97', 'CalendarID' , 'CalendarID' , 'K' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('AF7AA1F7-84B6-40C5-9327-5C1B4399E6BB' , '07D29FE3-AA56-42BD-884D-77CB50A68B97', 'IsSchoolDay' , 'IsSchoolDay' , 'C' , 0 ,NULL,NULL)
GO


INSERT INTO VC3ETL.LoadTable VALUES ('5D32A3D5-BAD3-4E8D-B453-1C60272ABF4E', '19A65267-D406-4624-852A-BEA3DB449C5C', 10, 'IC.Transform_Calendar(@endYear)', 'SchoolCalendar', 0, NULL, NULL, NULL, 2,1,1,1,1, NULL, NULL, NULL, 0, 0, NULL)

INSERT INTO VC3ETL.LoadColumn VALUES ('5744EC53-4AC5-490B-9A3C-06664DF5A81B' , '5D32A3D5-BAD3-4E8D-B453-1C60272ABF4E', 'TV_SchoolID' , 'SchoolID' , 'K' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('8F15A66B-2364-4E57-8E77-5D9380DC5543' , '5D32A3D5-BAD3-4E8D-B453-1C60272ABF4E', 'DestID' , 'CalendarID' , 'K' , 0 ,NULL,NULL)


--studentRosterYear
INSERT INTO VC3ETL.LoadTable VALUES ('31B47F67-64F3-4239-9ADA-F201FD65F290', '19A65267-D406-4624-852A-BEA3DB449C5C', 11, 'IC.Transform_StudentRosterYear(@endYear, @importDate, @importRosterYear)', 'StudentRosterYear', 1, 'IC.Map_StudentRosterYearID', 'studentId, ROsterYearID', 'DestID', 1,0,1,1,1, NULL, NULL, NULL, 0, 0, NULL)

INSERT INTO VC3ETL.LoadColumn VALUES ('D4EC6B6F-3C9A-4938-B104-2280719F6BE6' , '31B47F67-64F3-4239-9ADA-F201FD65F290', 'DailyAbsences' , 'DaysAbsent' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('CFA94A4F-787B-444F-B816-A22ABF1A7D3A' , '31B47F67-64F3-4239-9ADA-F201FD65F290', 'DestID' , 'ID' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('AAEA101D-A493-4163-BE37-D1CFBF1C1862' , '31B47F67-64F3-4239-9ADA-F201FD65F290', 'Guardian' , 'Guardian' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('7A81BE29-CD46-4434-9C46-B869BD3AB83F' , '31B47F67-64F3-4239-9ADA-F201FD65F290', 'DisciplineReferrals' , 'DisciplineReferrals' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('1F330C3E-99BC-465E-9F6B-27BC456613F4' , '31B47F67-64F3-4239-9ADA-F201FD65F290', 'RosterYearID' , 'RosterYearID' , 'K' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('C6523878-5DA1-4697-96E9-0A14FA11B411' , '31B47F67-64F3-4239-9ADA-F201FD65F290', 'StudentID' , 'StudentID' , 'K' , 0 ,NULL,NULL)
GO

CREATE TABLE IC.Map_StudentRosterYearID
(	
	StudentID uniqueidentifier not null,
	RosterYearID uniqueidentifier NOT NULL,
	[DestID] uniqueidentifier not null
 CONSTRAINT [PK_IC_Map_StudentRosterYearID] PRIMARY KEY CLUSTERED 
(
	[DestID] ASC
))
GO

INSERT INTO vc3etl.ExtractTable VALUES ('CB238BA0-1331-4AB2-A83E-2039B9FBE6DB', '19A65267-D406-4624-852A-BEA3DB449C5C', 'RelatedPair', 'IC', 'RelatedPair', 'personID1, personID2', 'personID2', 0,0,'guardian = 1',1, 0, NULL)
INSERT INTO vc3etl.PearsonExtractTable Values ('CB238BA0-1331-4AB2-A83E-2039B9FBE6DB',0, NULL)
GO



CREATE VIEW  IC.RelatedPair
AS 
	SELECT * FROM IC.RelatedPair_LOCAL
GO

--gradeLevelHistory
INSERT INTO VC3ETL.LoadTable VALUES ('EAAA2B74-4BA6-4BEB-87FB-510C9EA1DFA7', '19A65267-D406-4624-852A-BEA3DB449C5C', 12, 'IC.Transform_Student(@endYear, @importDate)', 'StudentGradelevelHistory', 0,NULL, 'StudentID', 'DestID',3,1,0 ,1,1, NULL, NULL, NULL, 0, 0, NULL)

INSERT INTO VC3ETL.LoadColumn VALUES ('F6E61415-EA2B-4274-8FF5-CDBD2DA0D765' , 'EAAA2B74-4BA6-4BEB-87FB-510C9EA1DFA7', 'DESTID' , 'StudentID' , 'K' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('49129881-51CC-4156-AF0D-E0B48F71C18F' , 'EAAA2B74-4BA6-4BEB-87FB-510C9EA1DFA7', '(null)' , 'EndDate' , 'E' , 1 ,'@ImportDefaultEndDate',NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('ACF8228D-5324-4789-B6E4-80C91025273C' , 'EAAA2B74-4BA6-4BEB-87FB-510C9EA1DFA7', '(@ImportDefaultStartDate)' , 'StartDate' , 'S' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('B948C594-5E11-438E-A9CC-F13E527AD3EB' , 'EAAA2B74-4BA6-4BEB-87FB-510C9EA1DFA7', 'GradeLevelID' , 'GradeLevelID' , 'K' , 0 ,NULL,NULL)

--schoolHistory
INSERT INTO VC3ETL.LoadTable VALUES ('80B46E05-F6A1-46BE-B8C3-5309731D23D3', '19A65267-D406-4624-852A-BEA3DB449C5C', 13, 'IC.Transform_Student(@endYear, @importDate)', 'StudentSchoolHistory', 0,NULL, 'StudentID', 'DestID',3,1,0 ,1,1, NULL, NULL, NULL, 0, 0, NULL)

INSERT INTO VC3ETL.LoadColumn VALUES ('10E91A13-DF88-4DC2-90AF-8B76EB7B870B' , '80B46E05-F6A1-46BE-B8C3-5309731D23D3', 'SchoolID' , 'SchoolID' , 'K' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('36DDF695-7CB3-4BB6-8691-0C0F871D9FB0' , '80B46E05-F6A1-46BE-B8C3-5309731D23D3', 'DESTID' , 'StudentID' , 'K' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('1C429626-C587-4B09-BACF-DC37202311B1' , '80B46E05-F6A1-46BE-B8C3-5309731D23D3', '(@ImportDefaultStartDate)' , 'StartDate' , 'S' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('D9711C5D-211B-41CF-B12D-1AB62C26E7D9' , '80B46E05-F6A1-46BE-B8C3-5309731D23D3', '(null)' , 'EndDate' , 'E' , 1 ,NULL,NULL)

--teacherHIstory
INSERT INTO VC3ETL.LoadTable VALUES ('4729E3C8-066A-474D-B6AB-358BAC9D9E80', '19A65267-D406-4624-852A-BEA3DB449C5C', 14, 'IC.Transform_Teacher(@endYear, @importDate)', 'TeacherSchoolHistory', 0,NULL, 'TeacherID', 'DestID',3,1,0 ,1,1, NULL, NULL, NULL, 0, 0, NULL)

INSERT INTO VC3ETL.LoadColumn VALUES ('630066A9-F55C-4035-97D8-69F6017738A8' , '4729E3C8-066A-474D-B6AB-358BAC9D9E80', '(null)' , 'EndDate' , 'E' , 1 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('30B6ED9A-CD9A-4950-A6A5-D64FE476F523' , '4729E3C8-066A-474D-B6AB-358BAC9D9E80', 'CurrentSchoolID' , 'SchoolID' , 'K' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('4B3EB7AD-A1F3-4F38-851D-8FBCD7745A0D' , '4729E3C8-066A-474D-B6AB-358BAC9D9E80', '(@ImportDefaultStartDate)' , 'StartDate' , 'S' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('DB9DD8B0-9D14-4B65-B608-A95A2D49B265' , '4729E3C8-066A-474D-B6AB-358BAC9D9E80', 'DestID' , 'TeacherID' , 'K' , 0 ,NULL,NULL)

--StudentTeacher
INSERT INTO VC3ETL.LoadTable VALUES ('BA93A123-5B8E-43F7-ADD0-D4CFA1E576E0', '19A65267-D406-4624-852A-BEA3DB449C5C', 15, 'Transform_StudentTeacher', 'StudentTeacher', 0,NULL, NULL, NULL, 2,1,0 ,1,1, NULL, NULL, NULL, 0, 0, NULL)

INSERT INTO VC3ETL.LoadColumn VALUES ('6952D1A0-84E6-4B75-94FB-5C8466A2610C' , 'BA93A123-5B8E-43F7-ADD0-D4CFA1E576E0', 'StudentID' , 'StudentID' , 'K' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('524B4AF9-DB70-48BD-8F01-FB4F8300225F' , 'BA93A123-5B8E-43F7-ADD0-D4CFA1E576E0', 'CurrentClassCount' , 'CurrentClassCount' , 'K' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('208AFADF-9AC4-45E7-97D1-A1137C3D4481' , 'BA93A123-5B8E-43F7-ADD0-D4CFA1E576E0', 'TeacherID' , 'TeacherID' , 'K' , 0 ,NULL,NULL)

--StudentSchool
INSERT INTO VC3ETL.LoadTable VALUES ('045B8FD1-3001-49B5-BDE3-076C33A8F7B9', '19A65267-D406-4624-852A-BEA3DB449C5C', 16, 'Transform_StudentSchool', 'StudentSchool', 0,NULL, NULL, NULL, 2,1,0 ,1,1, NULL, NULL, NULL, 0, 0, NULL)

INSERT INTO VC3ETL.LoadColumn VALUES ('8DE68578-0F40-4C3F-9DCA-A919EF6307FE' , '045B8FD1-3001-49B5-BDE3-076C33A8F7B9', 'SchoolID' , 'SchoolID' , 'K' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('4E887779-2F4B-4C38-B8CB-8E106BA6EE99' , '045B8FD1-3001-49B5-BDE3-076C33A8F7B9', 'RosterYearID' , 'RosterYearID' , 'K' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('7AD2F922-E27B-48D8-B7CF-93F35B89ABA6' , '045B8FD1-3001-49B5-BDE3-076C33A8F7B9', 'StudentID' , 'StudentID' , 'K' , 0 ,NULL,NULL)

--studentClassRosterHistory
INSERT INTO VC3ETL.LoadTable VALUES ('457E9AC6-A210-4BC7-B3C1-F009933A95F3', '19A65267-D406-4624-852A-BEA3DB449C5C', 17, 'Transform_StudentTeacherClassRoster', 'StudentTeacherClassRoster', 0,NULL, NULL, NULL, 2,1,0 ,1,1, NULL, NULL, NULL, 0, 0, NULL)

INSERT INTO VC3ETL.LoadColumn VALUES ('0AFB7017-BAA4-4147-81A7-985AAA3A64F4' , '457E9AC6-A210-4BC7-B3C1-F009933A95F3', 'RosterYearID' , 'RosterYearID' , 'K' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('D0443D13-AD63-4A03-8FA7-E83148588FC3' , '457E9AC6-A210-4BC7-B3C1-F009933A95F3', 'StudentID' , 'StudentID' , 'K' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('9DC844A2-B0CD-41CF-ABDF-294D5F0A9BFC' , '457E9AC6-A210-4BC7-B3C1-F009933A95F3', 'SchoolID' , 'SchoolID' , 'K' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('76BCE005-F4FE-4459-A839-A9740D83FCF3' , '457E9AC6-A210-4BC7-B3C1-F009933A95F3', 'TeacherID' , 'TeacherID' , 'K' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('860BC618-D075-4C82-83F4-68D27021626E' , '457E9AC6-A210-4BC7-B3C1-F009933A95F3', 'ClassRosterID' , 'ClassRosterID' , 'K' , 0 ,NULL,NULL)


--AttendanceExcuse
INSERT INTO vc3etl.ExtractTable VALUES ('3EDF5170-F23C-49BF-988F-C6E0A1B1D047', '19A65267-D406-4624-852A-BEA3DB449C5C', 'AttendanceExcuse', 'IC', 'AttendanceExcuse', 'excuseID', 'calendarID', 0,0,NULL,1, 0, NULL)
INSERT INTO vc3etl.PearsonExtractTable Values ('3EDF5170-F23C-49BF-988F-C6E0A1B1D047',0, NULL)
GO



CREATE VIEW  IC.AttendanceExcuse
AS 
	SELECT * FROM IC.AttendanceExcuse_LOCAL
GO

CREATE TABLE IC.Map_AbsenceReasonID
(	
	ExcuseID int not null,	
	[DestID] uniqueidentifier not null
 CONSTRAINT [PK_IC_Map_AbsenceReasonID] PRIMARY KEY CLUSTERED 
(
	[DestID] ASC
))
GO

--AbsenceReason
INSERT INTO VC3ETL.LoadTable VALUES ('0341525D-A540-4585-BAE5-BB5F3C883897', '19A65267-D406-4624-852A-BEA3DB449C5C', 18, 'IC.Transform_AbsenceReason(@endYear)', 'AbsenceReason', 1, 'IC.Map_AbsenceReasonID', 'excuseID', 'DestID',1,1,1 ,1,1, NULL, NULL, NULL, 0, 0, NULL)

INSERT INTO VC3ETL.LoadColumn VALUES ('DF33C5AD-3438-4EE9-A8F4-F2699647B69B' , '0341525D-A540-4585-BAE5-BB5F3C883897', 'code' , 'Code' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('1DB57FE4-6B53-4F4B-AA06-BFAF89E020E7' , '0341525D-A540-4585-BAE5-BB5F3C883897', 'Description' , 'Name' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('8D434E0C-BF62-4740-AB8E-4A13D9E986ED' , '0341525D-A540-4585-BAE5-BB5F3C883897', 'DestID' , 'ID' , 'K' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('FFEA9133-BFED-4D27-AC6B-06C41AE8EAEB' , '0341525D-A540-4585-BAE5-BB5F3C883897', 'IncludeInCount' , 'IncludeInCount' , 'C' , 0 ,NULL,NULL)

--AbsenceSchoolRule
INSERT INTO VC3ETL.LoadTable VALUES ('17E7AED9-C9DE-4F6C-8045-DF9450E14160', '19A65267-D406-4624-852A-BEA3DB449C5C', 19, 'IC.Transform_AbsenceSchoolRule(@endYear)', 'AbsenceSchoolRule', 0,NULL, NULL, NULL, 2,1,0 ,1,1, NULL, NULL, NULL, 0, 0, NULL)

INSERT INTO VC3ETL.LoadColumn VALUES ('8578A16D-6B4D-4750-814B-DC5DA52BA160' , '17E7AED9-C9DE-4F6C-8045-DF9450E14160', 'ReasonID' , 'ReasonID' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('A66F578E-6A13-450C-9287-328AFE17D275' , '17E7AED9-C9DE-4F6C-8045-DF9450E14160', 'SchoolID' , 'SchoolID' , 'C' , 0 ,NULL,NULL)

--Absence
INSERT INTO VC3ETL.LoadTable VALUES ('A148338E-E4DA-4D0F-9806-7E27DA50ABA2', '19A65267-D406-4624-852A-BEA3DB449C5C', 20, 'IC.Transform_Absence', 'Absence', 0,NULL, NULL, NULL, 2,1,0 ,1,1, NULL, NULL, NULL, 0, 0, NULL)

INSERT INTO VC3ETL.LoadColumn VALUES ('5AB5A498-1D44-43D2-AB45-E9F6EAF184A7' , 'A148338E-E4DA-4D0F-9806-7E27DA50ABA2', 'RosterYearID' , 'RosterYearID' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('E08E8DA6-9361-4FCA-8AF2-E5E3BBEA55BB' , 'A148338E-E4DA-4D0F-9806-7E27DA50ABA2', 'ReasonID' , 'ReasonID' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('509880FE-D24F-475D-88EE-EACACE37196B' , 'A148338E-E4DA-4D0F-9806-7E27DA50ABA2', 'AbsenceDate' , 'Date' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('C760658B-D45F-44D2-9EB7-16C02D94185F' , 'A148338E-E4DA-4D0F-9806-7E27DA50ABA2', 'StudentID' , 'StudentID' , 'C' , 0 ,NULL,NULL)

--Terms
INSERT INTO vc3etl.ExtractTable VALUES ('F12D2ED4-3FFD-455F-861F-AD1DE9EA158F', '19A65267-D406-4624-852A-BEA3DB449C5C', 'Term', 'IC', 'Term', 'TermID', NULL, 0,0,NULL,1, 0, NULL)
INSERT INTO vc3etl.PearsonExtractTable Values ('F12D2ED4-3FFD-455F-861F-AD1DE9EA158F',0, NULL)

GO

CREATE VIEW  IC.Term
AS 
	SELECT * FROM IC.Term_LOCAL
GO

INSERT INTO vc3etl.ExtractTable VALUES ('D577A406-C6E3-46FF-948A-FB6131365842', '19A65267-D406-4624-852A-BEA3DB449C5C', 'TermSchedule', 'IC', 'TermSchedule', 'TermScheduleID', NULL, 0,0,NULL,1, 0, NULL)
INSERT INTO vc3etl.PearsonExtractTable Values ('D577A406-C6E3-46FF-948A-FB6131365842',0, NULL)
GO



CREATE VIEW  IC.TermSchedule
AS 
	SELECT * FROM IC.TermSchedule_LOCAL
GO

INSERT INTO vc3etl.ExtractTable VALUES ('DF230C47-3465-4726-AC14-35571B637169', '19A65267-D406-4624-852A-BEA3DB449C5C', 'ScheduleStructure', 'IC', 'ScheduleStructure', 'structureID', NULL, 0,0,NULL,1, 0, NULL)
INSERT INTO vc3etl.PearsonExtractTable Values ('DF230C47-3465-4726-AC14-35571B637169',0, NULL)
GO



CREATE VIEW  IC.ScheduleStructure
AS 
	SELECT * FROM IC.ScheduleStructure_LOCAL
GO

--classRoster
INSERT INTO VC3ETL.LoadTable VALUES ('5F4E41B0-D4ED-4B3E-AE2F-154969D8C584', '19A65267-D406-4624-852A-BEA3DB449C5C', 20, 'IC.Transform_ClassRoster(@endYear)', 'ClassRoster', 1, 'IC.Map_ClassRosterID', 'IC_SectionID', 'DestID',1,1,1 ,1,1, NULL, NULL, NULL, 0, 0, NULL)

INSERT INTO VC3ETL.LoadColumn VALUES ('37AE8A85-C319-41AE-ABF4-F6004F28849D' , '5F4E41B0-D4ED-4B3E-AE2F-154969D8C584', 'MinGradeID' , 'MinGradeID' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('363872DE-7935-4AC4-9BD6-3D86BAE425EE' , '5F4E41B0-D4ED-4B3E-AE2F-154969D8C584', 'SectionName' , 'SectionName' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('3029ACB9-CFA8-416B-BB32-051DC6E36E6F' , '5F4E41B0-D4ED-4B3E-AE2F-154969D8C584', 'RosterYearID' , 'RosterYearID' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('04B337A8-37A8-428C-B54A-006506E3D093' , '5F4E41B0-D4ED-4B3E-AE2F-154969D8C584', 'MaxGradeID' , 'MaxGradeID' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('29043E41-EC96-4DE4-ACD7-6A805AB0BA7C' , '5F4E41B0-D4ED-4B3E-AE2F-154969D8C584', 'ClassName' , 'ClassName' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('B3350E4E-5AC8-4E68-88EF-C1531BF096F9' , '5F4E41B0-D4ED-4B3E-AE2F-154969D8C584', 'SchoolID' , 'SchoolID' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('749E8ED5-9938-48A7-A145-40715C15B985' , '5F4E41B0-D4ED-4B3E-AE2F-154969D8C584', 'DESTID' , 'ID' , 'K' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('906384D2-CADF-4F95-81A0-5AC49C553806' , '5F4E41B0-D4ED-4B3E-AE2F-154969D8C584', 'ContentAreaId' , 'ContentAreaId' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('D260A652-013A-4863-AFE4-D4E739E62602' , '5F4E41B0-D4ED-4B3E-AE2F-154969D8C584', 'GradeBitMask' , 'GradeBitMask' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('B7650B2A-92F2-4D24-BB7E-7CACB8921184' , '5F4E41B0-D4ED-4B3E-AE2F-154969D8C584', 'CourseCode' , 'CourseCode' , 'C' , 0 ,NULL,NULL)

INSERT INTO vc3etl.ExtractTable VALUES ('FFD22FB1-5274-4BBA-8421-0B9A3036D6A1', '19A65267-D406-4624-852A-BEA3DB449C5C', 'Course', 'IC', 'Course', 'courseID', NULL, 0,0,NULL,1, 0, NULL)
INSERT INTO vc3etl.PearsonExtractTable Values ('FFD22FB1-5274-4BBA-8421-0B9A3036D6A1',0, NULL)
GO



CREATE VIEW  IC.Course
AS 
	SELECT * FROM IC.Course_LOCAL
GO

INSERT INTO vc3etl.ExtractTable VALUES ('F4AE040B-E152-420A-994B-4559FA793398', '19A65267-D406-4624-852A-BEA3DB449C5C', 'Section', 'IC', 'Section', 'SectionID', 'courseID', 0,0,NULL,1, 0, NULL)
INSERT INTO vc3etl.PearsonExtractTable Values ('F4AE040B-E152-420A-994B-4559FA793398',0, NULL)
GO



CREATE VIEW  IC.Section
AS 
	SELECT * FROM IC.Section_LOCAL
GO

CREATE TABLE IC.Map_ClassRosterID
(	
	SectionID int not null,	
	[DestID] uniqueidentifier not null
 CONSTRAINT [PK_IC_Map_ClassRosterID] PRIMARY KEY CLUSTERED 
(
	[DestID] ASC
))
GO

--department
INSERT INTO vc3etl.ExtractTable VALUES ('340FBC33-2D03-4CF6-BC20-26731625A127', '19A65267-D406-4624-852A-BEA3DB449C5C', 'Department', 'IC', 'Department', 'DepartmentID', NULL, 0,0,NULL,1, 0, NULL)
INSERT INTO vc3etl.PearsonExtractTable Values ('340FBC33-2D03-4CF6-BC20-26731625A127',0, NULL)
GO



CREATE VIEW  IC.Department
AS 
	SELECT * FROM IC.Department_LOCAL
GO

--course_departmentID
INSERT INTO vc3etl.ExtractTable VALUES ('EB477A4F-B548-4064-BBEE-653EBB38219B', '19A65267-D406-4624-852A-BEA3DB449C5C', 'Course_DepartmentID', 'IC', 'Course_DepartmentID', 'courseID, DepartmentID', NULL, 0,0,NULL,1, 0, NULL)
INSERT INTO vc3etl.PearsonExtractTable Values ('EB477A4F-B548-4064-BBEE-653EBB38219B',0, NULL)
GO



CREATE VIEW  IC.Course_DepartmentID
AS 
	SELECT * FROM IC.Course_DepartmentID_LOCAL
GO


--TeacherClassROsterHistory
INSERT INTO VC3ETL.LoadTable VALUES ('45004BB9-2CF2-42A2-8CA2-3CBEBE3495DB', '19A65267-D406-4624-852A-BEA3DB449C5C', 21, 'IC.Transform_ClassRoster(@endYear)', 'ClassRosterTeacherHistory', 0,NULL, 'ClassRosterID', 'DestID', 3,1,0 ,1,1, 'TeacherID is not null', NULL, NULL, 0, 0, NULL)

INSERT INTO VC3ETL.LoadColumn VALUES ('A38FE7AA-7510-4356-A40E-1910064CEF9D' , '45004BB9-2CF2-42A2-8CA2-3CBEBE3495DB', '(null)' , 'EndDate' , 'E' , 1 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('657D9C59-9D2E-439C-A412-01C6D94295C3' , '45004BB9-2CF2-42A2-8CA2-3CBEBE3495DB', 'TeacherID' , 'TeacherID' , 'K' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('705BA445-5760-4A41-8A30-6C1142D320FC' , '45004BB9-2CF2-42A2-8CA2-3CBEBE3495DB', 'DestID' , 'ClassRosterID' , 'K' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('AE893F91-5625-468D-BA4E-4F1BAFD5A080' , '45004BB9-2CF2-42A2-8CA2-3CBEBE3495DB', '(@ImportDefaultStartDate)' , 'StartDate' , 'S' , 0 ,NULL,NULL)

--ContentArea
INSERT INTO VC3ETL.LoadTable VALUES ('22A34537-31A9-4328-B97F-86622739EB15', '19A65267-D406-4624-852A-BEA3DB449C5C', 24, 'IC.Transform_ContentArea(@endYear)', 'ContentArea', 1,'IC.Map_ContentAreaID', 'DepartmentID', 'DestID', 1,1,1 ,1,1, NULL, NULL, NULL, 0, 0, NULL)

INSERT INTO VC3ETL.LoadColumn VALUES ('E2A75449-6C6A-4EEE-A4E4-655D6E628E13' , '22A34537-31A9-4328-B97F-86622739EB15', 'DestID' , 'ID' , 'K' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('998E1243-7649-47FE-A093-A68BAB6DF6FE' , '22A34537-31A9-4328-B97F-86622739EB15', 'MaxCertificationLevelID' , 'MaxCertificationLevelID' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('28286442-15EF-468B-9203-1C69F64C6083' , '22A34537-31A9-4328-B97F-86622739EB15', 'Name' , 'Name' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('0F7A9ECD-AAA2-4285-87DD-4EDD9740C35A' , '22A34537-31A9-4328-B97F-86622739EB15', 'SubjectID' , 'SubjectID' , 'C' , 0 ,NULL,NULL)
GO

CREATE TABLE IC.Map_ContentAreaID
(	
	DepartmentID int not null,	
	[DestID] uniqueidentifier not null
 CONSTRAINT [PK_IC_Map_ContentAreaID] PRIMARY KEY CLUSTERED 
(
	[DestID] ASC
))
GO

--StudentClassRosterHistory
INSERT INTO VC3ETL.LoadTable VALUES ('AEFA9D26-89C2-4920-B4F8-C4ED93E7560E', '19A65267-D406-4624-852A-BEA3DB449C5C', 25, 'IC.Transform_StudentClassRoster(@endYear)', 'StudentClassRosterHistory', 0,NULL, 'StudentID, ClassRosterID', 'StudentID',1,1,1 ,1,1, NULL, NULL, NULL, 0, 0, NULL)

INSERT INTO VC3ETL.LoadColumn VALUES ('1C276C9B-AF56-4531-AE74-E43F0F3D48E8' , 'AEFA9D26-89C2-4920-B4F8-C4ED93E7560E', 'StudentID' , 'StudentID' , 'K' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('4C9221D7-FB6E-4463-B4CB-E416CCDF281C' , 'AEFA9D26-89C2-4920-B4F8-C4ED93E7560E', 'StartDate' , 'StartDate' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('6256DF7A-EAE5-4C4E-B0FA-AB4319A7D39E' , 'AEFA9D26-89C2-4920-B4F8-C4ED93E7560E', 'EndDate' , 'EndDate' , 'C' , 1 ,'case when {dest}.EndDate is null then @ImportDefaultEndDate when {dest}.EndDate < @ImportDefaultEndDate then {dest}.EndDate else @ImportDefaultEndDate end',NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('92366304-2E70-4FB2-802F-AA63A1A20BA4' , 'AEFA9D26-89C2-4920-B4F8-C4ED93E7560E', 'ClassRosterID' , 'ClassRosterID' , 'K' , 0 ,NULL,NULL)

--Grade Range BitMask
INSERT INTO VC3ETL.LoadTable VALUES ('6A9E264F-F1E2-476C-9B80-B7DD1DAC58F6', '19A65267-D406-4624-852A-BEA3DB449C5C', 26, 'IC.Transform_GradeLevelBitMask', 'GradeRangeBitMask', 0,NULL, NULL, NULL,1,1,1 ,1,1, NULL, NULL, NULL, 0, 0, NULL)

INSERT INTO VC3ETL.LoadColumn VALUES ('68B57B2A-8ECB-4FE6-8ACC-C92E4DE53DC7' , '6A9E264F-F1E2-476C-9B80-B7DD1DAC58F6', 'MinGradeID' , 'MinGradeID' , 'K' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('21BB6AEA-D09C-4A41-8485-5DFF34AA1CF9' , '6A9E264F-F1E2-476C-9B80-B7DD1DAC58F6', 'MinGradeName' , 'MinGradeName' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('DD0925C3-EEAD-40C4-A8B7-F2DB013625D6' , '6A9E264F-F1E2-476C-9B80-B7DD1DAC58F6', 'MinGradeMask' , 'MinGradeMask' , 'C' , 0 ,NULL,NULL)

INSERT INTO VC3ETL.LoadColumn VALUES ('5686C10D-497C-4EB5-8977-EE44C8F244AA' , '6A9E264F-F1E2-476C-9B80-B7DD1DAC58F6', 'MaxGradeID' , 'MaxGradeID' , 'K' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('44E6FBD4-0B0D-4248-BC82-9DEC7A7751A3' , '6A9E264F-F1E2-476C-9B80-B7DD1DAC58F6', 'MaxGradeMask' , 'MaxGradeMask' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('9D948573-C12F-45FA-A4B8-3A3A5557C4E7' , '6A9E264F-F1E2-476C-9B80-B7DD1DAC58F6', 'MaxGradeName' , 'MaxGradeName' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('A2C2F3A0-5853-4A56-B1BB-11E488331E4C' , '6A9E264F-F1E2-476C-9B80-B7DD1DAC58F6', 'BitMask' , 'BitMask' , 'C' , 0 ,NULL,NULL)

-- School [IC.Transform_School] 
UPDATE VC3ETL.LoadTable SET Sequence = 0 WHERE ID='B7E1295D-E833-4A2D-BE05-A0D7D642D5D7'

-- IC.Map_EnumTypeID [IC.Transform_EnumType] 
UPDATE VC3ETL.LoadTable SET Sequence = 1 WHERE ID='7B1D5CB8-F31C-4B29-9F28-A33D96D5B725'

-- EnumValue [IC.Transform_EnumValue] 
UPDATE VC3ETL.LoadTable SET Sequence = 2 WHERE ID='D11CC8E6-E647-4766-8F1A-94E908C77DCB'

-- GradeLevel [IC.Transform_GradeLevel(@endYear)] 
UPDATE VC3ETL.LoadTable SET Sequence = 3 WHERE ID='619E3826-C171-486A-9063-457548886CE9'

-- GradeRangeBitMask [IC.Transform_GradeLevelBitMask] 
UPDATE VC3ETL.LoadTable SET Sequence = 4 WHERE ID='6A9E264F-F1E2-476C-9B80-B7DD1DAC58F6'

-- Student [IC.Transform_Student(@endYear, @ImportDate)] 
UPDATE VC3ETL.LoadTable SET Sequence = 5 WHERE ID='F0EC0B8D-2848-41AF-9E9D-C0036791FCBE'

-- Teacher [IC.Transform_Teacher(@endYear, @ImportDate)] 
UPDATE VC3ETL.LoadTable SET Sequence = 6 WHERE ID='F11A0806-B2BB-43D8-BE04-5422F0133D76'

-- TranscriptCourse [IC.Transform_TranscriptCourse] 
UPDATE VC3ETL.LoadTable SET Sequence = 7 WHERE ID='B28C547C-7EBF-4A67-8994-4236CA872567'

-- ContentArea [IC.Transform_ContentArea(@endYear)] 
UPDATE VC3ETL.LoadTable SET Sequence = 8 WHERE ID='22A34537-31A9-4328-B97F-86622739EB15'

-- ClassRoster [IC.Transform_ClassRoster(@endYear)] 
UPDATE VC3ETL.LoadTable SET Sequence = 10 WHERE ID='5F4E41B0-D4ED-4B3E-AE2F-154969D8C584'

-- ClassRosterTeacherHistory [IC.Transform_ClassRoster(@endYear)] 
UPDATE VC3ETL.LoadTable SET Sequence = 11 WHERE ID='45004BB9-2CF2-42A2-8CA2-3CBEBE3495DB'

-- Calendar [IC.Transform_Calendar(@endYear)] 
UPDATE VC3ETL.LoadTable SET Sequence = 12 WHERE ID='0D820483-AF47-4170-AD64-D8CEFFDDF90A'

-- CalendarDate [IC.Transform_CalendarDate(@endYear)] 
UPDATE VC3ETL.LoadTable SET Sequence = 13 WHERE ID='07D29FE3-AA56-42BD-884D-77CB50A68B97'

-- SchoolCalendar [IC.Transform_Calendar(@endYear)] 
UPDATE VC3ETL.LoadTable SET Sequence = 14 WHERE ID='5D32A3D5-BAD3-4E8D-B453-1C60272ABF4E'

-- StudentGradelevelHistory [IC.Transform_Student(@endYear, @importDate)] 
UPDATE VC3ETL.LoadTable SET Sequence = 15 WHERE ID='EAAA2B74-4BA6-4BEB-87FB-510C9EA1DFA7'

-- StudentSchoolHistory [IC.Transform_Student(@endYear, @importDate)] 
UPDATE VC3ETL.LoadTable SET Sequence = 16 WHERE ID='80B46E05-F6A1-46BE-B8C3-5309731D23D3'

-- TeacherSchoolHistory [IC.Transform_Teacher(@endYear, @importDate)] 
UPDATE VC3ETL.LoadTable SET Sequence = 17 WHERE ID='4729E3C8-066A-474D-B6AB-358BAC9D9E80'

-- AbsenceReason [IC.Transform_AbsenceReason(@endYear)] 
UPDATE VC3ETL.LoadTable SET Sequence = 18 WHERE ID='0341525D-A540-4585-BAE5-BB5F3C883897'

-- AbsenceSchoolRule [IC.Transform_AbsenceSchoolRule(@endYear)] 
UPDATE VC3ETL.LoadTable SET Sequence = 19 WHERE ID='17E7AED9-C9DE-4F6C-8045-DF9450E14160'

-- DisciplineIncident [IC.Transform_DisciplineIncident(@endYear)] 
UPDATE VC3ETL.LoadTable SET Sequence = 20 WHERE ID='DBA8CA3E-AA06-4822-9990-7520EDF91C05'

-- StudentRosterYear [IC.Transform_StudentRosterYear(@endYear, @importDate, @importRosterYear)] 
UPDATE VC3ETL.LoadTable SET Sequence = 21 WHERE ID='31B47F67-64F3-4239-9ADA-F201FD65F290'

-- StudentClassRosterHistory [IC.Transform_StudentClassRoster(@endYear)] 
UPDATE VC3ETL.LoadTable SET Sequence = 22 WHERE ID='AEFA9D26-89C2-4920-B4F8-C4ED93E7560E'

-- StudentTeacher [Transform_StudentTeacher] 
UPDATE VC3ETL.LoadTable SET Sequence = 23 WHERE ID='BA93A123-5B8E-43F7-ADD0-D4CFA1E576E0'

-- StudentSchool [Transform_StudentSchool] 
UPDATE VC3ETL.LoadTable SET Sequence = 24 WHERE ID='045B8FD1-3001-49B5-BDE3-076C33A8F7B9'

-- StudentTeacherClassRoster [Transform_StudentTeacherClassRoster] 
UPDATE VC3ETL.LoadTable SET Sequence = 25 WHERE ID='457E9AC6-A210-4BC7-B3C1-F009933A95F3'


INSERT INTO VC3ETL.ExtractValidator VALUES ('F695F3EA-0B0D-4123-A32F-BB31F1C138B1' , '7B80FB5C-4333-4CFB-902B-9A0BDA1E4A8B',  'BB2B0B0B-D272-4F44-96C2-058E2D298D0C', 1, -0.05, NULL, NULL)
INSERT INTO VC3ETL.ExtractValidator VALUES ('6F02DCF8-D28E-4950-8218-7FB807AF33C7' , '7B80FB5C-4333-4CFB-902B-9A0BDA1E4A8B',  'A46A2340-FB22-499F-977F-0B748004612F', 1, -0.05, NULL, NULL)
INSERT INTO VC3ETL.ExtractValidator VALUES ('903DA66F-32A3-4C46-AC77-11B9FF3AA274' , '7B80FB5C-4333-4CFB-902B-9A0BDA1E4A8B',  'FFD22FB1-5274-4BBA-8421-0B9A3036D6A1', 1, -0.05, NULL, NULL)
INSERT INTO VC3ETL.ExtractValidator VALUES ('FFE0A1BD-DD9E-4EAC-82E4-F6CDD4082A79' , '7B80FB5C-4333-4CFB-902B-9A0BDA1E4A8B',  'D31CF6AE-4BF9-47D6-891A-1D1322EE1F55', 1, -0.05, NULL, NULL)
INSERT INTO VC3ETL.ExtractValidator VALUES ('E16128D6-7E67-4CED-8338-873EBD129270' , '7B80FB5C-4333-4CFB-902B-9A0BDA1E4A8B',  'CB238BA0-1331-4AB2-A83E-2039B9FBE6DB', 1, -0.05, NULL, NULL)
INSERT INTO VC3ETL.ExtractValidator VALUES ('F1EA0E4A-D981-4904-9524-C3EEE9DDD85D' , '7B80FB5C-4333-4CFB-902B-9A0BDA1E4A8B',  '886ECBBC-1186-40FC-9617-221273C78FF4', 1, -0.05, NULL, NULL)
INSERT INTO VC3ETL.ExtractValidator VALUES ('611B94DC-9AAB-40F7-85C1-92D3879953CB' , '7B80FB5C-4333-4CFB-902B-9A0BDA1E4A8B',  '340FBC33-2D03-4CF6-BC20-26731625A127', 1, -0.05, NULL, NULL)
INSERT INTO VC3ETL.ExtractValidator VALUES ('31F1E432-4950-4046-8D01-853DC36F13E4' , '7B80FB5C-4333-4CFB-902B-9A0BDA1E4A8B',  '9ACF986F-B8ED-44AC-971D-27B96188A2A9', 1, -0.05, NULL, NULL)
INSERT INTO VC3ETL.ExtractValidator VALUES ('B2641A7A-24D7-475A-B4AF-7B4E18BA7E55' , '7B80FB5C-4333-4CFB-902B-9A0BDA1E4A8B',  '7568F1AD-BFBF-4E5F-8DC5-2D0B5E1F4825', 1, -0.05, NULL, NULL)
INSERT INTO VC3ETL.ExtractValidator VALUES ('B5900EED-166C-40AC-960C-28DF28B1126D' , '7B80FB5C-4333-4CFB-902B-9A0BDA1E4A8B',  '7C613B3E-9571-4C44-B836-308D5CD7B78B', 1, -0.05, NULL, NULL)
INSERT INTO VC3ETL.ExtractValidator VALUES ('422973C1-7054-4077-8524-8981012AD30B' , '7B80FB5C-4333-4CFB-902B-9A0BDA1E4A8B',  'DF230C47-3465-4726-AC14-35571B637169', 1, -0.05, NULL, NULL)
INSERT INTO VC3ETL.ExtractValidator VALUES ('C363704A-AC77-49D5-BA28-A977A4542773' , '7B80FB5C-4333-4CFB-902B-9A0BDA1E4A8B',  '9C8F84A3-6073-40C7-81DF-3B519A1622DA', 1, -0.05, NULL, NULL)
INSERT INTO VC3ETL.ExtractValidator VALUES ('FFB5528E-39CD-4621-BB5E-0BEFCA8AC817' , '7B80FB5C-4333-4CFB-902B-9A0BDA1E4A8B',  '1414E7D1-F1F5-4070-816A-3CA44B05204F', 1, -0.05, NULL, NULL)
INSERT INTO VC3ETL.ExtractValidator VALUES ('92106F6D-E6B7-4CC1-983D-CF82ACCAD699' , '7B80FB5C-4333-4CFB-902B-9A0BDA1E4A8B',  'E70CFA27-7679-4518-AD33-40FC8EF5D4AC', 1, -0.05, NULL, NULL)
INSERT INTO VC3ETL.ExtractValidator VALUES ('3A4A6695-42A0-452E-93AC-15B9AE495314' , '7B80FB5C-4333-4CFB-902B-9A0BDA1E4A8B',  'F4AE040B-E152-420A-994B-4559FA793398', 1, -0.05, NULL, NULL)
INSERT INTO VC3ETL.ExtractValidator VALUES ('2B7A7AE4-DFE2-4E28-96FD-EB79261BC107' , '7B80FB5C-4333-4CFB-902B-9A0BDA1E4A8B',  '7A76FDDF-62E0-4A09-8320-567F4AF34BAB', 1, -0.05, NULL, NULL)
INSERT INTO VC3ETL.ExtractValidator VALUES ('755045EB-2275-4641-98AD-900C6672BF46' , '7B80FB5C-4333-4CFB-902B-9A0BDA1E4A8B',  'DED04F7F-4C2A-493F-913D-57BCDB6C0668', 1, -0.05, NULL, NULL)
INSERT INTO VC3ETL.ExtractValidator VALUES ('EB62E84D-09F5-472C-AFB9-6FCE7B492C1B' , '7B80FB5C-4333-4CFB-902B-9A0BDA1E4A8B',  'EB477A4F-B548-4064-BBEE-653EBB38219B', 1, -0.05, NULL, NULL)
INSERT INTO VC3ETL.ExtractValidator VALUES ('2AFC8188-987A-4022-8E31-F9F051A4E547' , '7B80FB5C-4333-4CFB-902B-9A0BDA1E4A8B',  '4340C7B0-65A5-4E3D-9519-72BB9B1745DE', 1, -0.05, NULL, NULL)
INSERT INTO VC3ETL.ExtractValidator VALUES ('EE0177CE-1AF7-4909-A6D4-C721C72E43C6' , '7B80FB5C-4333-4CFB-902B-9A0BDA1E4A8B',  'B7E0A49D-A008-4ADF-B84B-8E1972DE0B89', 1, -0.05, NULL, NULL)
INSERT INTO VC3ETL.ExtractValidator VALUES ('8E87D49C-F945-4E9E-A1FA-90DC3DB8A88B' , '7B80FB5C-4333-4CFB-902B-9A0BDA1E4A8B',  'EED57054-C00B-47AB-8C2F-9557EDF74ADC', 1, -0.05, NULL, NULL)
INSERT INTO VC3ETL.ExtractValidator VALUES ('DD19EE2F-3CA9-4ACB-8E0C-B8F9398A6670' , '7B80FB5C-4333-4CFB-902B-9A0BDA1E4A8B',  '418FFD78-94E1-4D44-9292-9D854B994A2D', 1, -0.05, NULL, NULL)
INSERT INTO VC3ETL.ExtractValidator VALUES ('2066F4C0-FB7F-4FE9-94F5-AE86A1C81F21' , '7B80FB5C-4333-4CFB-902B-9A0BDA1E4A8B',  'BEA67479-9C9C-4EA8-8F7E-A75C7AB33B80', 1, -0.05, NULL, NULL)
INSERT INTO VC3ETL.ExtractValidator VALUES ('61E56E03-E314-407D-B19A-A6FC3DD0F38D' , '7B80FB5C-4333-4CFB-902B-9A0BDA1E4A8B',  'F12D2ED4-3FFD-455F-861F-AD1DE9EA158F', 1, -0.05, NULL, NULL)
INSERT INTO VC3ETL.ExtractValidator VALUES ('DD0384A8-56E4-4D5D-A7AC-DFD7CCD51573' , '7B80FB5C-4333-4CFB-902B-9A0BDA1E4A8B',  'E8295209-2701-43D6-9743-AF15A9A9D1B1', 1, -0.05, NULL, NULL)
INSERT INTO VC3ETL.ExtractValidator VALUES ('27D6E3BE-EFC3-4F32-ACEE-52E34F97917F' , '7B80FB5C-4333-4CFB-902B-9A0BDA1E4A8B',  '3EDF5170-F23C-49BF-988F-C6E0A1B1D047', 1, -0.05, NULL, NULL)
INSERT INTO VC3ETL.ExtractValidator VALUES ('442970A6-AB9A-458D-945E-2B2553EC1E3D' , '7B80FB5C-4333-4CFB-902B-9A0BDA1E4A8B',  '3F0EBB7F-48C4-4FFB-8A8B-CC998AB078EE', 1, -0.05, NULL, NULL)
INSERT INTO VC3ETL.ExtractValidator VALUES ('57FB19DA-0A59-4E67-8344-B78AFFC5C600' , '7B80FB5C-4333-4CFB-902B-9A0BDA1E4A8B',  'C825E40F-F61B-4EA8-B87A-D3347286A8FD', 1, -0.05, NULL, NULL)
INSERT INTO VC3ETL.ExtractValidator VALUES ('04ED7EB3-5742-4479-847D-D8DE1AD34AEB' , '7B80FB5C-4333-4CFB-902B-9A0BDA1E4A8B',  '942AA705-8E10-4C58-901E-DB46A69B4370', 1, -0.05, NULL, NULL)
INSERT INTO VC3ETL.ExtractValidator VALUES ('B4D3A844-E90A-4055-9137-9E22C25C8043' , '7B80FB5C-4333-4CFB-902B-9A0BDA1E4A8B',  '4D627944-9BD4-4606-874A-DC42E1B10D69', 1, -0.05, NULL, NULL)
INSERT INTO VC3ETL.ExtractValidator VALUES ('91F08E49-21F2-467C-BC86-D9F8DD98F0BA' , '7B80FB5C-4333-4CFB-902B-9A0BDA1E4A8B',  '66DCABAD-D517-4D8E-8DE7-EA2FD9262DC5', 1, -0.05, NULL, NULL)
INSERT INTO VC3ETL.ExtractValidator VALUES ('226D1EEB-F414-4A66-9FA8-5F961FE4DC30' , '7B80FB5C-4333-4CFB-902B-9A0BDA1E4A8B',  'A3C42150-73A2-440F-8E72-EE8ED1867B1C', 1, -0.05, NULL, NULL)
INSERT INTO VC3ETL.ExtractValidator VALUES ('D1573894-3A72-4716-BE4D-33764F4FFF6C' , '7B80FB5C-4333-4CFB-902B-9A0BDA1E4A8B',  '463FC192-6FC6-4979-9BE0-EF2D8F79B40B', 1, -0.05, NULL, NULL)
INSERT INTO VC3ETL.ExtractValidator VALUES ('6BC5C105-E230-4F03-BF86-D4E7057F599E' , '7B80FB5C-4333-4CFB-902B-9A0BDA1E4A8B',  'D577A406-C6E3-46FF-948A-FB6131365842', 1, -0.05, NULL, NULL)
INSERT INTO VC3ETL.ExtractValidator VALUES ('CDC9D334-B819-4BBD-B4CE-AC30157D52A0' , '7B80FB5C-4333-4CFB-902B-9A0BDA1E4A8B',  '3C0C3580-43E6-47EF-8CFD-FF6AA1F4D657', 1, -0.05, NULL, NULL)

INSERT INTO VC3ETL.ExtractValidator VALUES ('CCF19BB5-F27D-42E2-BD39-56DE4A303007' , 'F33610D3-3E7A-48B7-AFDB-2FB16D9C39F8',  'B7E0A49D-A008-4ADF-B84B-8E1972DE0B89', 1, NULL, NULL, 'personid')


select * From vc3etl.ExtractTable where Id = '3C0C3580-43E6-47EF-8CFD-FF6AA1F4D657'