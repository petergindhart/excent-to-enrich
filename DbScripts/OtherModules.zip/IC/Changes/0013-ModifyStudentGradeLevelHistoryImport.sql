UPDATE vc3etl.LoadTable
SET SourceTable='IC.Transform_StudentGradeLevelHistory', ImportType = 1, UpdateTrans = 1, DeleteTrans = 0
WHERE ID = 'EAAA2B74-4BA6-4BEB-87FB-510C9EA1DFA7'

UPDATE vc3etl.LoadColumn
SET SourceColumn ='StartDate', ColumnType='K'
WHERE ID = 'ACF8228D-5324-4789-B6E4-80C91025273C'

UPDATE vc3etl.LoadColumn
SET SourceColumn ='StudentID', ColumnType='K'
WHERE ID = 'F6E61415-EA2B-4274-8FF5-CDBD2DA0D765'

UPDATE vc3etl.LoadColumn
SET SourceCOlumn ='EndDate', ColumnType='C'
WHERE ID = '49129881-51CC-4156-AF0D-E0B48F71C18F'

UPDATE vc3etl.LoadColumn
SET ColumnType='K'
WHERE ID = 'B948C594-5E11-438E-A9CC-F13E527AD3EB'