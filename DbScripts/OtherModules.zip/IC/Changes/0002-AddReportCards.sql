--ReportCardType
INSERT INTO VC3ETL.LoadTable VALUES ('AEFABFC0-69BE-4E4D-84C0-AE5A771656F4', '19A65267-D406-4624-852A-BEA3DB449C5C', 26, 'IC.Transform_ReportCardType', 'ReportCardType', 1, 'IC.Map_ReportCardTypeID', 'taskSequence', 'DestID',1,1,1 ,1,1, NULL, NULL, NULL, 0, 0, NULL)

INSERT INTO VC3ETL.LoadColumn VALUES ('38C207F7-9CA8-4135-9281-BDB1FD1B6473' , 'AEFABFC0-69BE-4E4D-84C0-AE5A771656F4', 'Name' , 'Name' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('047ACD8D-C665-44A1-A932-E055E8DB7DB0' , 'AEFABFC0-69BE-4E4D-84C0-AE5A771656F4', 'DestID' , 'ID' , 'K' , 0 ,NULL,NULL)
GO

INSERT INTO vc3etl.ExtractTable VALUES ('CAA1AB2A-AFA4-4389-ABE5-5D879F0217C1', '19A65267-D406-4624-852A-BEA3DB449C5C', 'GradingTask', 'IC', 'GradingTask', 'taskID', NULL, 0,0,NULL,1, 0, NULL)
INSERT INTO vc3etl.PearsonExtractTable Values ('CAA1AB2A-AFA4-4389-ABE5-5D879F0217C1',0, NULL)
GO

CREATE TABLE [IC].[GradingScore_LOCAL](
	[scoreID] [int] NOT NULL,
	[calendarID] [int] NOT NULL,
	[personiD] [int] NOT NULL,
	[sectionID] [int] NOT NULL,
	[termID] [int] NULL,
	[taskID] [int] NOT NULL,
	[score] [varchar](255) NULL,
	[percent] [numeric](6, 3) NULL
) ON [PRIMARY]
GO

CREATE TABLE [IC].[GradingTask_LOCAL](
	[taskID] [int] NOT NULL,
	[parentID] [int] NULL,
	[calendarID] [int] NULL,
	[standardID] [int] NULL,
	[number] [varchar](10) NULL,
	[name] [varchar](75) NULL,
	[termMask] [int] NULL,
	[activeMask] [int] NULL,
	[comments] [varchar](250) NULL,
	[transcript] [bit] NULL,
	[description] [text] NULL,
	[gradeBookPosted] [bit] NULL,
	[seq] [int] NULL,
	[gradedOnce] [bit] NULL,
	[legacyKey] [int] NULL,
	[legacyKey2] [int] NULL,
	[oll] [bit] NULL,
	[abbreviation] [varchar](10) NULL,
	[powerStandard] [bit] NULL,
	[code] [varchar](25) NULL,
 CONSTRAINT [PK_GradingTask_NEW_1104875299] PRIMARY KEY CLUSTERED 
(
	[taskID] ASC
) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE VIEW  IC.GradingTask
AS 
	SELECT * FROM IC.GradingTask_LOCAL
GO

INSERT INTO vc3etl.ExtractTable VALUES ('F0377037-170E-43D9-B30D-46C438FA28D1', '19A65267-D406-4624-852A-BEA3DB449C5C', 'GradingScore', 'IC', 'GradingScore', 'scoreID', 'personid, sectionID', 0,0,NULL,1, 0, NULL)
INSERT INTO vc3etl.PearsonExtractTable Values ('F0377037-170E-43D9-B30D-46C438FA28D1',0, NULL)
GO

CREATE VIEW  IC.GradingScore
AS 
	SELECT * FROM IC.GradingScore_LOCAL
GO

INSERT INTO VC3ETL.LoadTable VALUES ('F6377604-AF64-464F-BAD3-5C518F4E504F', '19A65267-D406-4624-852A-BEA3DB449C5C', 27, 'IC.Transform_ReportCardItem(@endYear)', 'ReportCardItem', 1, 'IC.Map_ReportCardItemID', 'taskID, termID, UsesTerm', 'DestID',1,1,1 ,1,1, NULL, NULL, NULL, 0, 0, NULL)

INSERT INTO VC3ETL.LoadColumn VALUES ('71180775-8513-459C-97F6-00A9CE9A13FD' , 'F6377604-AF64-464F-BAD3-5C518F4E504F', 'Sequence' , 'Sequence' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('A316CA22-DA9E-4146-9D4F-B184AA9D58B7' , 'F6377604-AF64-464F-BAD3-5C518F4E504F', 'DestID' , 'ID' , 'K' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('1FDB2282-1EF6-4190-AD8F-E862268FD1FA' , 'F6377604-AF64-464F-BAD3-5C518F4E504F', 'IsFinal' , 'IsFinal' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('2D8DD6BB-2B84-49E1-9B44-7ADE215731E3' , 'F6377604-AF64-464F-BAD3-5C518F4E504F', 'ReportCardTypeID' , 'ReportCardType' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('D04BAEB0-1FBF-4CD5-A3BA-65A3E98FA192' , 'F6377604-AF64-464F-BAD3-5C518F4E504F', 'Name' , 'Name' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('2255784F-7444-4EB1-AFFC-E1E667D62A03' , 'F6377604-AF64-464F-BAD3-5C518F4E504F', 'Name' , 'ShortName' , 'C' , 0 ,NULL,NULL)

GO
CREATE TABLE IC.Map_ReportCardItemID (
	taskID [int] NOT NULL,
		TermID int null,
	UsesTerm bit NOT NULL,
	[DestID] [uniqueidentifier] NOT NULL,
 CONSTRAINT [PK_IC_ReportCardItemID] PRIMARY KEY CLUSTERED 
(
	[DestID] ASC
))
GO

CREATE TABLE IC.Map_ReportCardTypeID (
	TaskSequence [int] NOT NULL,
	[DestID] [uniqueidentifier] NOT NULL,
 CONSTRAINT [PK_IC_ReportCardTypeID] PRIMARY KEY CLUSTERED 
(
	[DestID] ASC
))
GO

CREATE NONCLUSTERED INDEX IX_Map_ReportCardItemID_TaskID ON IC.Map_ReportCardItemID
	(
	taskID
	)
GO

CREATE NONCLUSTERED INDEX IX_Map_ReportCardTypeID_TaskSequence ON IC.Map_ReportCardTypeID
	(
	TaskSequence
	)
GO

CREATE TABLE IC.Map_ReportCardScoreID (
	[scoreID] [int] NOt NULL,
	[DestID] [uniqueidentifier] NOT NULL,
 CONSTRAINT [PK_IC_Map_ReportCardScoreID] PRIMARY KEY CLUSTERED 
(
	[DestID] ASC
))
GO

CREATE NONCLUSTERED INDEX IX_Map_ReportCardScoreID_ScoreID ON IC.Map_ReportCardScoreID
	(
	scoreID
	)
GO

INSERT INTO VC3ETL.LoadTable VALUES ('BBED9CA1-DE3B-47D8-9FFC-92A4E6966227', '19A65267-D406-4624-852A-BEA3DB449C5C', 28, 'IC.Transform_ReportCardScore(@endYear)', 'ReportCardScore', 1, 'IC.Map_ReportCardScoreID', 'scoreID', 'DestID',1,1,1 ,1,1, NULL, NULL, NULL, 0, 0, NULL)

INSERT INTO VC3ETL.LoadColumn VALUES ('F92BF43B-5EDA-4247-A1D4-05D2CB8B51FF' , 'BBED9CA1-DE3B-47D8-9FFC-92A4E6966227', 'ReportCardItem' , 'ReportCardItem' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('2F423B37-6E9E-42C2-8398-FEA70D3E3EE1' , 'BBED9CA1-DE3B-47D8-9FFC-92A4E6966227', 'LetterScore' , 'LetterScore' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('387CBE44-F77E-4FC0-A367-B158FF18B5CC' , 'BBED9CA1-DE3B-47D8-9FFC-92A4E6966227', 'ClassRosterID' , 'ClassRoster' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('1C02AA32-887D-4447-A0BD-C09DE83AD584' , 'BBED9CA1-DE3B-47D8-9FFC-92A4E6966227', 'DestID' , 'ID' , 'K' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('5CACEE0F-75E2-4DB4-A812-2AB9B8B482B2' , 'BBED9CA1-DE3B-47D8-9FFC-92A4E6966227', 'StudentID' , 'Student' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('F7518A99-049F-4DCE-BB2D-FE898B86C326' , 'BBED9CA1-DE3B-47D8-9FFC-92A4E6966227', 'PercentageScore' , 'PercentageScore' , 'C' , 0 ,NULL,NULL)



