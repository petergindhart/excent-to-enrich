UPDATE VC3ETL.ExtractTable
SET Indexes='personid, sectionID; calendarID'
WHERE ID ='F0377037-170E-43D9-B30D-46C438FA28D1'