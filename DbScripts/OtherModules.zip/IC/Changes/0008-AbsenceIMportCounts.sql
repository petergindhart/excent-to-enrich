UPDATE vc3etl.LoadTable
SET DestTableFilter='RosterYearID = @importRosterYear'
WHERE id= '7BD85FCE-5D61-4B88-943D-C9AF79B26AA2'