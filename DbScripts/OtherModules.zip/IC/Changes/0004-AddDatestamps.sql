INSERT INTO vc3etl.ExtractTable VALUES ('E63176D3-16B5-436C-8163-FE8A78D8D5E2', '19A65267-D406-4624-852A-BEA3DB449C5C', 'SectionPlacement', 'IC', 'SectionPlacement', 'sectionID, termID, periodID, trialID', 'sectionID', 0,0,NULL,1, 0, NULL)
INSERT INTO vc3etl.PearsonExtractTable Values ('E63176D3-16B5-436C-8163-FE8A78D8D5E2',0, NULL)
GO

CREATE TABLE [IC].[SectionPlacement_LOCAL](
	[sectionID] [int] NOT NULL,
	[termID] [int] NOT NULL,
	[periodID] [int] NOT NULL,
	[trialID] [int] NOT NULL,
 CONSTRAINT [PK_SectionPlacement_LOCAL] PRIMARY KEY CLUSTERED 
(
	[sectionID] ASC,
	[termID] ASC,
	[periodID] ASC,
	[trialID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO

CREATE VIEW  IC.SectionPlacement
AS 
	SELECT * FROM IC.SectionPlacement_LOCAL
GO
