INSERT INTO VC3ETL.LoadTable VALUES ('7BD85FCE-5D61-4B88-943D-C9AF79B26AA2', '19A65267-D406-4624-852A-BEA3DB449C5C', 20, 'IC.Transform_Absence(@endYear, @importRosterYear)', 'Absence', 0,NULL, NULL, NULL, 2,1,0 ,1,1, NULL, NULL, NULL, 0, 0, NULL)

INSERT INTO VC3ETL.LoadColumn VALUES ('A23A50A5-58CA-44F4-A278-DF8908999CDF' , '7BD85FCE-5D61-4B88-943D-C9AF79B26AA2', 'RosterYearID' , 'RosterYearID' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('D7B7040E-886E-4A67-B700-AAD510FDD7A5' , '7BD85FCE-5D61-4B88-943D-C9AF79B26AA2', 'ReasonID' , 'ReasonID' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('BC30D5A2-EE07-4FF3-9ED2-3E5BB070682D' , '7BD85FCE-5D61-4B88-943D-C9AF79B26AA2', 'AbsenceDate' , 'Date' , 'C' , 0 ,NULL,NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('BC39C7CA-716E-434A-AB88-EACD8D33B80E' , '7BD85FCE-5D61-4B88-943D-C9AF79B26AA2', 'StudentID' , 'StudentID' , 'C' , 0 ,NULL,NULL)

INSERT INTO vc3etl.ExtractTable VALUES ('86A8E71E-931F-4467-B6E1-0DCB8E9EDCA1', '19A65267-D406-4624-852A-BEA3DB449C5C', 'Attendance', 'IC', 'Attendance', 'AttendanceID', NULL, 0,0,NULL,1, 0, 'attendanceID, calendarID, personid, periodID, [date], status, excuse, presentMinutes, excuseID')
INSERT INTO vc3etl.PearsonExtractTable Values ('86A8E71E-931F-4467-B6E1-0DCB8E9EDCA1',0, NULL)
GO

GO
CREATE TABLE [IC].[Attendance_local](
	[attendanceID] [int] NOT NULL,
	[calendarID] [int] NOT NULL,
	[personID] [int] NOT NULL,
	[periodID] [int] NOT NULL,
	[date] [datetime] NULL,
	[status] [varchar](1) NULL,
	[excuse] [varchar](1) NULL,
	[presentMinutes] [smallint] NULL,
	[comments] [varchar](50) NULL,
	[excuseID] [int] NULL,
	[modifiedDate] [datetime] NULL,
	[modifiedByID] [int] NULL
) ON [PRIMARY]
GO

CREATE VIEW  IC.Attendance
AS 
	SELECT * FROM IC.Attendance_LOCAL
GO

INSERT INTO AbsenceReason VALUES ('C14E6F88-0A96-4891-A302-8282D51A702D', 'Unknown', NULL, 1)
INSERT INTO IC.Map_AbsenceReasonID VALUES ( -1,'C14E6F88-0A96-4891-A302-8282D51A702D')