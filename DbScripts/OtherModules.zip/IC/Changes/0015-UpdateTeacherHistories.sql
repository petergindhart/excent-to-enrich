IF (SELECT Enabled From Vc3etl.ExtractDatabase where id = '19A65267-D406-4624-852A-BEA3DB449C5C') = 1
BEGIN
	UPDATE hist
	SET EndDate =  (select max(EndDate) from StudentClassROsterHistory sHist where sHist.CLassRosterID =cr.ID)
	from
		CLassROster cr join
		ClassRosterTeacherHistory hist on hist.ClassRosterID= cr.ID join
		RosterYear ry on cr.RosterYearID = ry.ID
	where
		cr.RosterYearID in ('E71F4116-C71A-404A-87CB-3612A89A1657', '6609C10E-AA0C-4475-BC0E-70842D8076F1')
END

UPDATE vc3etl.LoadColumn
SET DeletedValue= '(@ImportDefaultEndDate)'
WHERE ID = 'A38FE7AA-7510-4356-A40E-1910064CEF9D'

UPDATE vc3etl.LoadColumn
SET ColumnType='I'
WHERE ID = 'CFA94A4F-787B-444F-B816-A22ABF1A7D3A'