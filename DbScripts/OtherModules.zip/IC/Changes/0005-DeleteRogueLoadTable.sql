delete vc3etl.LoadColumn where LoadTable = 'A148338E-E4DA-4D0F-9806-7E27DA50ABA2'
DELETE vc3etl.LoadTable where id = 'A148338E-E4DA-4D0F-9806-7E27DA50ABA2'