UPDATE vc3etl.LoadTable
SET PurgeCondition='{dest}.ClassRoster IN (select ID from ClassRoster where RosterYearID = @importRosterYear)'
WHERE ID  = 'BBED9CA1-DE3B-47D8-9FFC-92A4E6966227'