--#include ..\..\dbo\Objects\UserProfileView.sql

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[Transform_Teacher]') AND OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [PWRSCH].[Transform_Teacher]
GO

CREATE VIEW PWRSCH.Transform_Teacher
AS
	SELECT
		tech.*,
		-- Only set the userprofile-teacher association once
		UserProfileID = isnull((select t.UserProfileID
				from Teacher t
				where t.Id = tech.DestID),
				
				(select top 1 ID -- Emails are mostly unique.  Top 1 to prevent the query from failing.
				from UserProfileView u
				where tech.Email_addr = u.EmailAddress and u.Deleted is null
				)
			)
	FROM
		(
			SELECT
				DestID = mt.DestID,
				TeacherID = tch.ID,
				SOCSECNUM_VALIDATED = CASE LEN(replace(ssn,'-','')) WHEN 9 THEN replace(ssn,'-','') ELSE NULL END,
				CurrentSchoolID = msch.DestID,
				EthnicityID = ev.DestID,
				GenderId = gev.DestID,
				LegacyTeacherID = case when IsNumeric(TeacherNumber) = 1
							THEN
								case 
									when LEN(TeacherNumber) = 6 AND IsNumeric(TeacherNumber) = 1 
										then SUBSTRING(TeacherNumber, 4,3)
									when  LEN(TeacherNumber) = 5 AND IsNumeric(TeacherNumber) = 1
										then SUBSTRING(TeacherNumber, 3,3)
									when LEN(TeacherNumber) = 4
										then SUBSTRING(TeacherNumber, 2,3) 
									when LEN(TeacherNumber) = 7 AND SUBSTRING(TeacherNumber,3,1) = 'S' 
										then '0' + SUBSTRING(TeacherNumber, 5,3)
									else null end 
							ELSE NUll end,
				LegacySchoolID = case when IsNumeric(TeacherNumber) = 1
							THEN
								case 
									when LEN(TeacherNumber) = 6
										then SUBSTRING(TeacherNumber, 1,3) 
									when LEN(TeacherNumber) = 7 AND SUBSTRING(TeacherNumber,3,1) = 'S' 
										then '0' + SUBSTRING(TeacherNumber, 1,2)
-- THE FOLLOWING ARE FAR MORE AGGRESSIVE RULES FOR DETECTION AND SHOULD ONLY BE USED IF THE ABOVE SKIP TO MANY
--									when LEN(TeacherNumber) = 6 AND SUBSTRING(TeacherNumber,1,1) = '0'
--										then SUBSTRING(TeacherNumber, 1,3) 
--									when LEN(TeacherNumber) = 6 AND SUBSTRING(TeacherNumber,1,1) <> '0'
--										then '0' + SUBSTRING(TeacherNumber, 1, 2)
--									when LEN(TeacherNumber) = 4
--										then '00' + SUBSTRING(TeacherNumber, 1,1) 
--									when LEN(TeacherNumber) = 5
--										then '00' + SUBSTRING(TeacherNumber, 1,1)
									else null end
							ELSE NUll end,
				tch.*
			FROM
				PWRSCH.Teachers tch left join
				PWRSCH.Map_Teacher_ID mt on mt.TeacherID = tch.ID left join
				PWRSCH.Map_SchoolID msch on msch.School_Number = tch.SchoolID left join
				pwrsch.Map_EnumValueID ev on ev.Cat = 'ETH' and ev.Code = ethnicity left join
				pwrsch.Map_EnumValueID gev on gev.Cat = 'GEN' and gev.Code = sched_gender
			WHERE
				tch.StaffStatus = 1 And [Status] = 1 AND First_Name IS NOT NULL and Last_Name IS NOT NULL
		)  tech
