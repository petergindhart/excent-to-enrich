IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[Transform_StudentRosterYear]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [PWRSCH].[Transform_StudentRosterYear]
GO

CREATE FUNCTION PWRSCH.Transform_StudentRosterYear(@ImportRosterYear uniqueidentifier)
RETURNS TABLE
AS
RETURN
select
	DestID 			= m.DestID,
	RosterYearID	= @importRosterYear,
	StudentID 		= impstu.DestID,
	DisciplineReferrals	= (select count(*) from DisciplineIncident  where StudentID = impstu.DestID and RosterYearID = @importRosterYear ), 
	DailyAbsences		= (
		select count(*) 
		from Absence ab join
		AbsenceReason reason on ab.ReasonID = reason.ID
		where IncludeInCount = 1 AND StudentID = impstu.DestID and RosterYearID = @importRosterYear ) , 
	Guardian =  PWRSCH.GetGuardians(impstu.StudentID) --impstu.ParentGuardian
from	
	PWRSCH.Transform_Student impstu left join
	PWRSCH.Map_StudentRosterYearID m on m.StudentId = impstu.DestID AND m.RosterYearID = @importRosterYear