IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[Transform_Absence]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [PWRSCH].[Transform_Absence]
GO

CREATE FUNCTION PWRSCH.Transform_Absence(@importRosterYear uniqueidentifier)
RETURNS TABLE
AS
RETURN
SELECT
      AbsenceDate = cd.Date_value,
      StudentID = ms.DestID,
      ReasonID= mar.DestID,
      RosterYearId= @importRosterYear
FROm
      (
            select
                  attendance_CodeID,
                  Calendar_DayID,
                  StudentID
            FROM
                  PWRSCH.Attendance 
            GROUP BY
                  attendance_CodeID,
                  Calendar_DayID,
                  StudentID
      ) att join      
      PWRSCH.Attendance_Code ac on att.attendance_CodeID= ac.ID join
      PWRSCH.Map_AbsenceReason_ID mar on mar.AttendanceCode = ac.att_code join
      PWRSCH.CALENDAR_DAY cd on att.Calendar_DayID = cd.ID join
      pwrsch.MAP_StudentID ms on ms.STudentid = att.StudentID join
      RosterYear ry on ry.ID = @importRosterYear
WHERE
          ac.Att_Code is not null and
          (cd.Date_Value between ry.StartDate and ry.EndDate)

