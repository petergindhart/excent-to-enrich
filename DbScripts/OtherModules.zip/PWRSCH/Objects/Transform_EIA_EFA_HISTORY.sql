IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[Transform_EIA_EFA_HISTORY]') AND OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [PWRSCH].[Transform_EIA_EFA_HISTORY]
GO

CREATE VIEW [PWRSCH].[Transform_EIA_EFA_HISTORY]
AS
SELECT 
	ms.DestID,
	T.*
FROM
(	
	SELECT
		studentID,
		-- Autism
		AU	= case when 'AU' in (MAX(EFA_PRIMARY), MAX(EFA2), MAX(EFA3), MAX(EFA4), MAX(EFA5), MAX(EFA6), MAX(EFA7), MAX(EFA8), MAX(EFA9), MAX(EIA10)) then cast(1 as bit) else cast(0 as bit) end,

		-- EmotionallyHandicap 
		EH = case when 'EH' in (MAX(EFA_PRIMARY), MAX(EFA2), MAX(EFA3), MAX(EFA4), MAX(EFA5), MAX(EFA6), MAX(EFA7), MAX(EFA8), MAX(EFA9), MAX(EIA10)) then cast(1 as bit) else cast(0 as bit) end,
		
		GTA = case when 'GTA' in (MAX(EIA1), MAX(EIA2), MAX(EIA3), MAX(EIA4), MAX(EIA5), MAX(EIA6), MAX(EIA7), MAX(EIA8), MAX(EIA9), MAX(EIA10)) then cast(1 as bit) else cast(0 as bit) end,
		GTR = case when 'GTR' in (MAX(EIA1), MAX(EIA2), MAX(EIA3), MAX(EIA4), MAX(EIA5), MAX(EIA6), MAX(EIA7), MAX(EIA8), MAX(EIA9), MAX(EIA10)) then cast(1 as bit) else cast(0 as bit) end,

		--EducableMentallyHd 
		EM = case when 'EM' in (MAX(EFA_PRIMARY), MAX(EFA2), MAX(EFA3), MAX(EFA4), MAX(EFA5), MAX(EFA6), MAX(EFA7), MAX(EFA8), MAX(EFA9), MAX(EIA10)) then cast(1 as bit) else cast(0 as bit) end,	
		
		--HearingHandicapped 
		HH = case when 'HH' in (MAX(EFA_PRIMARY), MAX(EFA2), MAX(EFA3), MAX(EFA4), MAX(EFA5), MAX(EFA6), MAX(EFA7), MAX(EFA8), MAX(EFA9), MAX(EIA10)) then cast(1 as bit) else cast(0 as bit) end,	
		
		--Homebound
		HO = case when 'HO' in (MAX(EFA_PRIMARY), MAX(EFA2), MAX(EFA3), MAX(EFA4), MAX(EFA5), MAX(EFA6), MAX(EFA7), MAX(EFA8), MAX(EFA9), MAX(EIA10)) then cast(1 as bit) else cast(0 as bit) end,	
		
		-- ChildDevelopment
		EC3 = case when 'EC3' in (MAX(EFA_PRIMARY), MAX(EFA2), MAX(EFA3), MAX(EFA4), MAX(EFA5), MAX(EFA6), MAX(EFA7), MAX(EFA8), MAX(EFA9), MAX(EIA10)) then cast(1 as bit) else cast(0 as bit) end,
		EC4 = case when 'EC4' in (MAX(EFA_PRIMARY), MAX(EFA2), MAX(EFA3), MAX(EFA4), MAX(EFA5), MAX(EFA6), MAX(EFA7), MAX(EFA8), MAX(EFA9), MAX(EIA10)) then cast(1 as bit) else cast(0 as bit) end,

		-- LearningDisability 
		LD = case when 'LD' in (MAX(EFA_PRIMARY), MAX(EFA2), MAX(EFA3), MAX(EFA4), MAX(EFA5), MAX(EFA6), MAX(EFA7), MAX(EFA8), MAX(EFA9), MAX(EIA10)) then cast(1 as bit) else cast(0 as bit) end,

		-- OrthopedicallyHd 
		OH = case when 'OH' in (MAX(EFA_PRIMARY), MAX(EFA2), MAX(EFA3), MAX(EFA4), MAX(EFA5), MAX(EFA6), MAX(EFA7), MAX(EFA8), MAX(EFA9), MAX(EIA10)) then cast(1 as bit) else cast(0 as bit) end,
		
		-- Primary
		P = case when 'P' in (MAX(EFA_PRIMARY), MAX(EFA2), MAX(EFA3), MAX(EFA4), MAX(EFA5), MAX(EFA6), MAX(EFA7), MAX(EFA8), MAX(EFA9), MAX(EIA10)) then cast(1 as bit) else cast(0 as bit) end,
		
		-- SpeechHandicapped 
		SP = case when 'SP' in (MAX(EFA_PRIMARY), MAX(EFA2), MAX(EFA3), MAX(EFA4), MAX(EFA5), MAX(EFA6), MAX(EFA7), MAX(EFA8), MAX(EFA9), MAX(EIA10)) then cast(1 as bit) else cast(0 as bit) end,
		
		-- TrainableMentally 
		TM = case when 'TM' in (MAX(EFA_PRIMARY), MAX(EFA2), MAX(EFA3), MAX(EFA4), MAX(EFA5), MAX(EFA6), MAX(EFA7), MAX(EFA8), MAX(EFA9), MAX(EIA10)) then cast(1 as bit) else cast(0 as bit) end,
		
		-- VisuallyHandicapped 
		VH = case when 'VH' in (MAX(EFA_PRIMARY), MAX(EFA2), MAX(EFA3), MAX(EFA4), MAX(EFA5), MAX(EFA6), MAX(EFA7), MAX(EFA8), MAX(EFA9), MAX(EIA10)) then cast(1 as bit) else cast(0 as bit) end
	FROM		
		PWRSCH.VirtualTable_SC_EIA_EFA_HISTORY eia
	group by
		eia.StudentID
) T join
PWRSCH.Map_StudentID ms on T.studentID = ms.StudentID