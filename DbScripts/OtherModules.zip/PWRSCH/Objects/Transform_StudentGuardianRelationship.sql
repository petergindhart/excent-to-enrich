IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[Transform_StudentGuardianRelationship]') AND OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [PWRSCH].[Transform_StudentGuardianRelationship]
GO

CREATE VIEW PWRSCH.Transform_StudentGuardianRelationship
AS
SELECT
	map.DestiD,
	string_value
FROM
	(
		SELECT
			LTrim(Rtrim(string_value)) AS string_value
		FROM	
			PWRSCH.PVSIS_Custom_Students cusStu 
		where 
			Field_Name ='cnt1_rel'
		GROUP BY
			string_value
	) T left join
	PWRSCH.Map_StudentGuardianRelationshipID map on map.Name = T.string_value