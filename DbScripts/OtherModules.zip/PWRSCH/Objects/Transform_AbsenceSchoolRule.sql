IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[Transform_AbsenceSchoolRule]') AND OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [PWRSCH].[Transform_AbsenceSchoolRule]
GO

CREATE VIEW [PWRSCH].[Transform_AbsenceSchoolRule]
AS
SELECT
	ReasonID = mar.DestId,
	SchoolID = ms.DestID
FROM
	PWRSCH.Map_AbsenceReason_ID mar join
	PWRSCH.ATTENDANCE_CODE code	on mar.AttendanceCode = code.ID join
	PWRSCH.MAP_SchoolID ms on ms.School_number = code.SchoolID

