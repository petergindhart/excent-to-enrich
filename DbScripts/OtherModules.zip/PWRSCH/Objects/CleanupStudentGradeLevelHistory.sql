IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[CleanupStudentGradeLevelHistory]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [PWRSCH].[CleanupStudentGradeLevelHistory]
GO

/*
<summary>
Cleans up StudentGradeLevelHistory
</summary>

<model isGenerated="False" returnType="System.Void" />
*/
CREATE PROCEDURE [PWRSCH].[CleanupStudentGradeLevelHistory]
	@startDate	datetime
AS

-- This script will reopen grade level histories that are preparing to be re-inserted (because they are perceived to be new for some reason)
UPDATE hist
SET EndDate = null
From StudentGradeLevelHistory hist join
(
	SELECT 
		s.DESTID as StudentID, s.GradeLevelID, @startDate As StartDate, (null) as EndDate
	FROM 
		StudentGradelevelHistory d RIGHT OUTER JOIN 
		PWRSCH.Transform_Student s ON s.DESTID=d.StudentID AND s.GradeLevelID=d.GradeLevelID AND d.EndDate IS NULL
	WHERE 
		(d.StudentID IS NULL) AND s.DESTID IS NOT NULL  AND s.GradeLevelID IS NOT NULL 
) newHist on newHist.StudentID = hist.StudentID and hist.GradeLevelID = newHist.GradeLevelID and newhist.StartDate = hist.StartDate
