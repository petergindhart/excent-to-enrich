IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[CleanupClassRosterTeacherHistory]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [PWRSCH].[CleanupClassRosterTeacherHistory]
GO

CREATE PROCEDURE [PWRSCH].[CleanupClassRosterTeacherHistory]
	@startDate	datetime,
	@importRosterYear uniqueidentifier
AS

UPDATE hist
SET EndDate = null
From ClassRosterTeacherHistory hist join
(
	SELECT 
		s.TeacherID, s.DestID as ClassRosterID, @startDate as StartDate, (null) as EndDate
	FROM 
		ClassRosterTeacherHistory d RIGHT OUTER JOIN 
		PWRSCH.Transform_ClassRoster(@ImportRosterYear) s ON s.DestID=d.ClassRosterID AND s.DestID=d.TeacherID AND d.EndDate IS NULL
	WHERE 
		(d.ClassRosterID IS NULL) AND s.TeacherID IS NOT NULL  AND s.DestID IS NOT NULL 
) newHist on newHist.TeacherID = hist.TeacherID and newHist.ClassRosterID = hist.ClassRosterID and newHist.StartDate = hist.StartDate
