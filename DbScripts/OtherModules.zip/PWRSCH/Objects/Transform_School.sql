IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[Transform_School]') AND OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [PWRSCH].[Transform_School]
GO

CREATE VIEW [PWRSCH].[Transform_School]
AS
SELECT
	ms.DestID,
	ps.School_number,
	Abbreviation,
	Name,
	LegacyID = 
		case when LEN(ps.school_number) < 3 
			then replace((space(3-len(ps.school_number))) + cast(ps.school_number as varchar(3)),' ','0')			
		else 
			substring( cast(ps.school_number as varchar(10)), LEN(ps.school_number) - 2, 3)
		end
FROm
	PWRSCH.Schools ps left join
	PWRSCH.Map_SchoolId ms on ms.School_number = ps.School_number
