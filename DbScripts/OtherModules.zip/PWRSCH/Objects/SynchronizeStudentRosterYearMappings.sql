IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[SynchronizeStudentRosterYearMappings]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [PWRSCH].[SynchronizeStudentRosterYearMappings]
GO

CREATE PROCEDURE [PWRSCH].[SynchronizeStudentRosterYearMappings]
	@importRosterYear uniqueidentifier
AS

-- Empty out the old mapping table
TRUNCATE TABLE PWRSCH.Map_StudentRosterYearID 

--Insert all the current records in there, its more important to track immedidate system state than history in this case (i.e. due to student merging)
INSERT INTO PWRSCH.Map_StudentRosterYearID 
SELECT
	StudentID,
	RosterYearID,
	ID
FROM
	StudentRosterYear