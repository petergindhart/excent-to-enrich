IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[Transform_ReportCardItem]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [PWRSCH].[Transform_ReportCardItem]
GO

CREATE FUNCTION PWRSCH.Transform_ReportCardItem ( @importRosterYear uniqueidentifier )
RETURNS TABLE
AS
RETURN

	SELECT
		DestID = mrci.DestID,
		ReportCardTypeID  = mrct.DestID,	
		ShortName = case when LEN(T2.Abbreviation) < LEN(T.StoreCode) then T2.Abbreviation else T.StoreCode end,
		Name = T.StoreCode,
		Sequence =  
			case when T.StoreCode = 'F1' then 99999 else 
			(
				--First determine the relative weight of this School/Term combo, by subtracting its portion of the year from the lowest portion of the year, a 4 portion from a 1 would yield 3, whereas a 1 portion of a 1 yields 0 (correctly so)
				(t2.Portion - (SELECT MIN(Portion) FROM pwrsch.storedgrades sg join pwrsch.Terms trm on sg.termid = trm.id	 WHERE sg.Schoolid = T.Schoolid and trm.YearID = T.YearID)) +
				
				-- Usage documentation makes it seem as if the format of [A-Zaz][0-9] would be used for most store codes so this provides a second level of sorting, else it leaves it alone
				case when isNumeric(substring(T.StoreCode,2,1) ) = 1 then cast( substring(T.StoreCode,2,1) as int) else 0 end +

				case when isNumeric(substring(T.StoreCode,1,1) ) = 0 then ASCII(substring(T.StoreCode,1,1)) - 65 else 0 end
			) end,
		IsFinal = case when T.StoreCode = 'F1' then 1 else 0 end,				
		T.YearID,
		T.SchoolID,
		T.StoreCode,
		T.TermID
	FROM
		(
			select 
				sg.schoolid, sg.StoreCode,  max(termid) termid, yearid 
			FROM 
				pwrsch.storedgrades sg join	
				pwrsch.Terms trm on sg.termid = trm.id							
			where
				sg.SectionID <> 0
			group by
				sg.schoolid, sg.StoreCode, yearid
		) T join
		pwrsch.Map_rosteryearid mry on mry.YearId = T.YearId join
		RosterYear ry on ry.Id = mry.DestID join
		PWRSCH.Map_ReportCardTypeID mrct on mrct.SchoolID = T.SchoolID and mrct.YearID = T.yearid 		join
		pwrsch.Terms t2 on t2.ID = T.termid and t2.Schoolid = T.schoolid left join
		PWRSCH.Map_ReportCardItemID mrci on mrci.ReportCardTypeID = mrct.DestID and mrci.StoreCode = T.StoreCode

