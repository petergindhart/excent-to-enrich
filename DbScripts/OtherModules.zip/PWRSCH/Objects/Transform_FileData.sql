IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[Transform_FileData]') AND OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [PWRSCH].[Transform_FileData]
GO

CREATE VIEW PWRSCH.Transform_FileData
AS
SELECT	
	MimeType = 'image/jpeg', -- PowerSchool stores its images as jpegs 		
	*
FROM
	PWRSCH.StudentPhoto