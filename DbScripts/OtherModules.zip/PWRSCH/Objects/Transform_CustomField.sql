IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[Transform_CustomField]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [PWRSCH].[Transform_CustomField]
GO

CREATE FUNCTION PWRSCH.Transform_CustomField
( 
	@fieldName			varchar(150),	
	@rosterYearID		uniqueidentifier,
	@nullToEmptyString	bit = 1
)
RETURNS TABLE
AS
RETURN
select 	
	ms.StudentID,
	ms.DestID,
	RosterYearID = @rosterYearID,
	REPLACE(IsNull( PWRSCH.GetCustomField(ms.StudentID, @fieldName), case when @nullToEmptyString = 1 then '' else null end),'&amp;','&') AS CustomFieldData
FROM
	PWRSCH.Map_StudentID ms