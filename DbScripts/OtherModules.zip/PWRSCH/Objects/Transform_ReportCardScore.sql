IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[Transform_ReportCardScore]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [PWRSCH].[Transform_ReportCardScore]
GO

CREATE FUNCTION PWRSCH.Transform_ReportCardScore (@importRosterYear uniqueidentifier)
RETURNS TABLE
AS
RETURN
SELECT
                DestID = (select DestID
                                                from PWRSCH.MAP_ReportCardScoreID  mrcs
                                                where 
                                                                mrcs.StudentID = ms.DestID and
                                                                mrcs.ClassRosterID = mscri.DestID and 
                                                                mrcs.StoreCode = grades.storeCode),   
                ReportCardItem               = mrci.DestID,
                StudentID = ms.DestID,
                ClassRosterID = mscri.DestID,
                grades.StoreCode,
                PercentageScore = grades.[percent],     
                LetterScore = case when IsNumeric(grades.grade) = 1 then null else grades.grade end
FROM
                (
                                Select
                                                MAX(DCID) AS DCID,
                                                StudentID,
                                                SectionID,
                                                StoreCode,
                                                MAX([percent]) as [percent],
                                                MAX(grade) as grade,
                                                MAX(schoolid) as schoolid,
                                                MAX(termid) as termid
                                FROM
                                                PWRSCH.StoredGrades
                                WHERE
                                                sectionID <> 0
                                GROUP BY
                                                StudentID,
                                                SectionID,
                                                StoreCode                          
                ) grades join
                PWRSCH.map_StudentID ms on ms.StudentID = grades.StudentID join 
                PWRSCH.Map_SectionIDClassRosterID mscri on mscri.RosterYearId = @importRosterYear and mscri.SectionID = grades.SectionID  join
                PWRSCH.MAP_RosterYearId mry on mry.DestId = @importRosterYear join
                PWRSCH.Map_reportCardTypeID mrct on mrct.SchoolID = grades.SchoolID and mrct.YearId = mry.YearID join
                PWRSCH.Map_ReportCardItemID mrci on mrci.ReportCardTypeID = mrct.DestID and mrci.StoreCode = grades.StoreCode
WHERE
                grades.sectionID <> 0
