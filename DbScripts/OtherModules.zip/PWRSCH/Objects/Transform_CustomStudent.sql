IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[Transform_CustomStudent]') AND OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [PWRSCH].[Transform_CustomStudent]
GO

CREATE VIEW [PWRSCH].[Transform_CustomStudent]
AS
SELECT
	DestID				= ms.DestID,
	x_NineGrID			= PWRSCH.GetCustomFieldEnumValue(ms.StudentID, 'SC_NinthGradeCode', '8046F2CB-1373-472B-AE13-72E0D81930BC'),
	x_EngProfID			= PWRSCH.GetCustomFieldEnumValue(ms.StudentID, 'SC_Engl_Prof', '5DD63D3D-AB81-4D22-A745-497786130F0F'),
	x_HomeLangID		= PWRSCH.GetCustomFieldEnumValue(ms.StudentID, 'SC_HomeLang', '147F2115-6437-4CE8-B1D1-768F1B45F6FE'),
	x_InstrSetID		= PWRSCH.GetCustomFieldEnumValue(ms.StudentID, 'SC_InstrSetting', 'CA7E6431-6ED6-48E5-B8E6-50813C7C7424'),
	x_Retain			= case 
							when PWRSCH.GetCustomField(ms.StudentID, 'SC_RetainReasonCode') is null then 0 
							when IsNumeric(PWRSCH.GetCustomField(ms.StudentID, 'SC_RetainReasonCode')) = 0 then 1 
							when cast(IsNull(PWRSCH.GetCustomField(ms.StudentID, 'SC_RetainReasonCode'),0) as int) > 0 then 1 
						else 0 end,
	x_SpecialEd			= case when IsNull(PWRSCH.GetCustomField(ms.StudentID, 'SC_instrsetting'),'') = 'SE' then 1 else 0 end,
	x_GradDate			= PWRSCH.GetCustomField(ms.StudentID, 'SC_GradDate'),
	x_USSchoolEntryDate	= PWRSCH.GetCustomField(ms.StudentID, 'SC_USSchEntryDate')
FROM
	PWRSCH.Map_StudentID ms





--I have another idea for this, the data is stored in a straight list mapping student 1 to property A student 1 to prop B and so on, it should be possible
-- to have a student returned for each row, and only update the value if its non null or else use the current value