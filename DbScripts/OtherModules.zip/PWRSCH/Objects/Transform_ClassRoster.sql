IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[Transform_CLassRoster]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [PWRSCH].[Transform_CLassRoster]
GO

CREATE FUNCTION PWRSCH.Transform_CLassRoster 
(
	@importRosterYear uniqueidentifier 
)
RETURNS TABLE
AS
RETURN
select      
      DestID = (SELECT DestID from PWRSCH.Map_ClassRosterID mc where mc.Course_NUmber = c.Course_NUmber and mc.Section_number = s.Section_number and mc.School_Number = s.SchoolID and RosterYearID = @importRosterYear),
      CourseID = c.ID,
      s.section_Number,  --Section_Number = c.Course_Number + '-' + s.section_Number, <-- can interfere with imports class roster map table
      s.ID AS SectionID,
      RosterYearID = @importRosterYear,
      School_ID = ms.DestID,
      TeacherID = mt.DestID,  
      ContentAreaId = ( SELECT top 1 ContentAreaID
                                    FROM ClassRosterContentAreaRule arearule
                                    WHERE arearule.RosterYearId = ry.Id and
                                          c.Course_NUmber like arearule.CourseCodePattern and
                                          len( CourseCodePattern ) = (
                                                select max( len( CourseCodePattern ) )
                                                from ClassRosterContentAreaRule 
                                                where RosterYearID = arearule.RosterYearID and c.Course_NUmber like CourseCodePattern 
                                          )),
      RosterYear        = ry.StartYear,
      GradeBitMask      = IsNULL(glRecord.BitMask,BM.BitMask),     
      MinGrade			= IsNULL(glRecord.Name,I.MinGrade),
      MaxGrade			= IsNULL(glRecord.Name,I.MaxGrade),
      MinGradeID        = IsNULL(glRecord.ID,lGr.ID), 
      MaxGradeID        = IsNULL(glRecord.ID,hGr.ID),
      LegacySchoolNumber = 
            case when LEN(s.SchoolID) < 3 
                  then replace((space(3-len(s.SchoolID))) + cast(s.SchoolID as varchar(3)),' ','0')                  
            else 
                  substring( cast(s.SchoolID as varchar(10)), LEN(s.SchoolID) - 2, 3)
            end,
      s.SchoolID AS School_Number,
      c.*
from 
	(
		select
			course_number,
			MAX(ID) as ID
		FROM
			PWRSCH.COURSES c 
		GROUP BY
			course_number
	) coursConsol join
	PWRSCH.Courses c on c.ID = coursConsol.ID join
    (
            select 
                  ID = Max(sInner.id),
                  sInner.section_Number,  
                  sInner.Course_NUmber,
                  sInner.SchoolID,
                  YearID
            FROM
                  PWRSCH.SECTIONS sInner join
                  PWRSCH.TERMS tInner on sInner.TermID = tInner.ID
            group by
                  sInner.section_Number,  
                  sInner.Course_Number,
                  sInner.SchoolID,
                  YearID
      ) sectConsol on c.Course_Number = sectConsol.Course_NUmber join
      PWRSCH.SECTIONS s on sectConsol.ID = s.ID join
      PWRSCH.Terms term on term.ID = s.TermID and term.SchoolID = s.SCHOOLID join
      PWRSCH.Map_RosterYearID mry on mry.YearID = term.YearID and mry.DestID = @importRosterYear join
      RosterYear ry on ry.ID = mry.DestID left join   
      PWRSCH.Map_SchoolID ms on ms.School_Number = s.SchoolID left join
      PWRSCH.Map_Teacher_ID mt on mt.TeacherID = s.Teacher left join
	  GradeLevel glRecord on glRecord.Name = case 
				when Len(s.grade_level) = 1
				   then '0' + cast(s.grade_level as char(1)) 				   
                when  s.grade_level = -1 
                   then 'PK'
				else cast(s.grade_level as char(10)) 				
            end left join
      (     
            SELECT
                cou.SectionID AS SectionID,
				RawMinGrade = MIN(grade_level),
				RawMaxGrade = MAX(grade_level),
                MIN(case when IsNumeric(grade_level) = 0 then -99999 else cast(grade_level as int) end) AS MinGrade,
                MAX(case when IsNumeric(grade_level) = 0 then -99999 else cast(grade_level as int) end) AS MAxGrade              
            FROM
                  PWRSCH.CC cou join      
                  PWRSCH.Students STU ON stu.ID = cou.studentID   
            group by
                  cou.SectionID
      ) I ON I.SectioNID = s.ID left join
      GradeLevel lGr on lGr.Name = 
            case 
				when Len(I.MinGrade) = 1
				   then '0' + cast(I.MinGrade as char(1)) 				   
                when  I.MinGrade = -1 
                   then 'PK'
				else cast(I.RawMinGrade as char(10)) 				
            end  left join
      GradeLevel hGr on hGr.Name = 
            case 
				when Len(I.MAxGrade) = 1
				   then '0' + cast(I.MAxGrade as char(1)) 				   
                when  I.MAxGrade = -1 
                   then 'PK'
				else cast(I.RawMaxGrade as char(5))
            end left join
      GradeRangeBitMask BM on BM.MinGradeID = lGr.ID and    BM.MaxGradeID = hGr.ID
WHERE
      s.SchoolID <> '0'