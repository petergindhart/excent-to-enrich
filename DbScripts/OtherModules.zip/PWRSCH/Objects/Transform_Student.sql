IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[Transform_Student]') AND OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [PWRSCH].[Transform_Student]
GO

DECLARE @sql varchar(7500)
DECLARE @nextSchoolSql varchar(500)

IF EXISTS(select * From information_schema.columns where Table_Schema = 'PWRSCH' AND Table_Name = 'Students_local' AND Column_Name	= 'Next_School')
BEGIN
	SET @nextSchoolSql = 'NextSchool = (select Name From School WHERE number = cast(Next_School as varchar(10))),'
END
ELSE
BEGIN
	SET @nextSchoolSql = ''
END

SET @sql = '
	CREATE VIEW [PWRSCH].[Transform_Student]
	AS
	SELECT
		mstu.DestID, 
		CurrentSchoolID = ms.DestiD,
		GenderID = gev.DestID,
		EthnicityID = ev.DestID,
		StudentId = stu.ID,
		GradeLevelId = gl.ID,
		SOCSECNUM_VALIDATED	= CASE LEN(replace(ssn,''-'','''')) WHEN 9 THEN replace(ssn,''-'','''') ELSE NULL END, 
		StudentNumber =  convert(nvarchar, Cast(stu.student_number as Decimal(24) )),  --the student_number is a REAL, so its difficult to convert

		FreeLunchID = (SELECT ID from EnumValue where [Type]=''A2F0A81F-93DC-4684-B65A-AEB6985DF127'' AND Code = 
			case when LunchStatus in (''P'') OR LEN(LunchStatus) = 0 THEN ''N'' ELSE LunchStatus END),
		IsHispanic = case when ethnicity = ''H'' then 1 else 0 end,
		NextSchool = (select Name From School WHERE number = cast(Next_School as varchar(10))),
		stu.*,
		ClassRankGPA = 	cr.GPA
	FROM
		pwrsch.Students stu left join
		pwrsch.Map_StudentID mstu on mstu.studentID = stu.ID left join	
		pwrsch.Map_SchoolID ms on ms.School_number = stu.Schoolid left join
		pwrsch.Map_EnumValueID gev on gev.Cat = ''GEN'' and gev.Code = gender left join
		pwrsch.Map_EnumValueID ev on ev.Cat = ''ETH'' and ev.Code = ethnicity left join
		GradeLevel gl on gl.Name = 
		case when Len(grade_level) = 1 
				then ''0'' + cast(grade_level as char(1)) 
				else 
						case when substring(grade_level,1,1) = ''-'' 
								THEN ''PK'' 
								ELSE cast(grade_level as char(2))  
						END
				end left join
		(	
			SELECT		
				MAX(ID) AS ID,		
				StudentID,
				GPAMethod
			FROM
				PWRSCH.ClassRank 
			WHERE
				GPAMethod=''SC_UGP_4.0''
			GROUP BY
				StudentID,
				GPAMethod		
		) crRollup on crRollup.StudentID = stu.ID left join
		PWRSCH.ClassRank cr on crRollup.ID = cr.ID 
	WHERE
		stu.First_Name is not null AND stu.Last_Name is not null AND
		Enroll_status = 0'

exec(@sql)