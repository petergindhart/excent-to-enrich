IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[Transform_Person]') AND OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [PWRSCH].[Transform_Person]
GO

CREATE VIEW PWRSCH.Transform_Person
AS
SELECT
	mp.DestID,
	TypeID ='P',
	FirstName = PWRSCH.GetCustomField(recs.StudentID, 'cnt' + recs.ContactNumber + '_fname'),
	LastName = PWRSCH.GetCustomField(recs.StudentID, 'cnt' + recs.ContactNumber + '_lname'),
	EmailAddress = PWRSCH.GetCustomField(recs.StudentID, 'cnt' + recs.ContactNumber + '_email'),
	Street = PWRSCH.GetCustomField(recs.StudentID, 'cnt' + recs.ContactNumber + '_street'),
	City = PWRSCH.GetCustomField(recs.StudentID, 'cnt' + recs.ContactNumber + '_city'),
	ZipCode = PWRSCH.GetCustomField(recs.StudentID, 'cnt' + recs.ContactNumber + '_zip'),
	[State] =  SUBSTRING( REPLACE(PWRSCH.GetCustomField(recs.StudentID, 'cnt' + recs.ContactNumber + '_state'), '.',''),1,2),
	HomePhone = PWRSCH.GetCustomField(recs.StudentID, 'cnt' + recs.ContactNumber + '_hphone'), 
	WorkPhone = PWRSCH.GetCustomField(recs.StudentID, 'cnt' + recs.ContactNumber + '_wphone'),
	CellPhone = PWRSCH.GetCustomField(recs.StudentID, 'cnt' + recs.ContactNumber + '_cphone'),
	recs.*
FROM	
	(
		select
			Student_Number,
			StudentID,
			Field_Name,
			cast(substring(Field_Name,4,1) as char(1)) As ContactNumber
		FROM
			PWRSCH.PVSIS_Custom_Students
		WHERE
			Field_Name like 'cnt%lname'
		GROUP BY
			Student_Number,
			StudentID,
			Field_Name		
	) recs left join
	PWRSCH.Map_PersonID mp on mp.Student_Number = recs.Student_Number AND mp.ContactNumber = recs.ContactNumber