IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[Transform_AbsenceReason]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [PWRSCH].[Transform_AbsenceReason]
GO

CREATE FUNCTION PWRSCH.Transform_AbsenceReason
(
	@importRosterYear uniqueidentifier
)
RETURNS TABLE
AS
RETURN 
select 
	DestID = (select DestId from PWRSCH.Map_AbsenceReason_ID where AttendanceCode = att_code),
	att_code,
	AttendanceCode = att_code,
	MAX(Description) As Description,
	IncludeInCount= case when MAX(Presence_status_cd) = 'Absent' then 1 else 0 end	
FROm
	PWRSCH.ATTENDANCE_CODE code join
	PWRSCH.Map_RosterYearID mry on code.YearId = mry.YearID 
Where 
	att_code is not null and
	mry.DestID = @importRosterYear 
group by
	att_code
