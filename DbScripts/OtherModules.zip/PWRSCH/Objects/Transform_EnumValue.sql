IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[Transform_EnumValue]') AND OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [PWRSCH].[Transform_EnumValue]
GO

CREATE VIEW [PWRSCH].[Transform_EnumValue]
AS
      SELECT 
            DestID                  = (select DestId from PWRSCH.Map_EnumValueID m where m.CAT = et.Type AND m.CODE = IsNull(Value, gen.ID)),
            Type              = mt.DestID,
            DisplayValue      = ISNULL(Name, Value),
            Code              = IsNull(Value, gen.ID),
            cat = et.Type     
      FROM
            PWRSCH.GEN gen join 
            PWRSCH.Map_EnumTypeID mt on mt.Cat = gen.cat left join
            EnumType et on et.ID = mt.DestID

      UNION ALL

      SELECT 
            DestID                  = (select DestId from PWRSCH.Map_EnumValueID m where m.CAT = 'PWRSCH_disc' AND m.CODE = gSubType.Value),
            Type              = et.Id,
            DisplayValue      = valuet,
            Code              = gSubType.Value,
            cat                     = 'PWRSCH_disc'
      FROM
            (
                  SELECT
                        MAX(ID) AS ID,
                        Value
                  FROM
                        PWRSCH.GEN 
                  group by
                              Value
            ) genRollup join
            PWRSCH.GEN gSubType  on genRollup.ID = gSubType .ID join
            (
                  select 
                        top 1 cast(ID as varchar(20)) AS ID
                  From 
                        PWRSCH.GEN g1 
                  where 
                        g1.Cat = 'logtype' and 
                        g1.name = 'Discipline'
            ) DT on DT.ID = gSubType.Name join
            EnumType et on et.Type = 'PWRSCH_disc'
            
		UNION ALL
		
		SELECT 
            DestID                  = (select DestId from PWRSCH.Map_EnumValueID m where m.CAT = 'GEN' AND m.CODE = 'M'),
            Type              = 'D6194389-17AC-494C-9C37-FD911DA2DD4B',
            DisplayValue      = 'Male',
            Code              = 'M',
            cat               = 'GEN'
      
		UNION ALL
	
		SELECT 
            DestID                  = (select DestId from PWRSCH.Map_EnumValueID m where m.CAT = 'GEN' AND m.CODE = 'F'),
            Type              = 'D6194389-17AC-494C-9C37-FD911DA2DD4B',
            DisplayValue      = 'Female',
            Code              = 'F',
            cat               = 'GEN'
			
      
GO
