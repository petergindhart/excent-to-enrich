IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[GetGuardians]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [PWRSCH].[GetGuardians]
GO

CREATE FUNCTION PWRSCH.GetGuardians(@studentId int)
RETURNS varchar(200)
AS
BEGIN
	DECLARE @names varchar(35)

	SELECT
		@names = IsNUll(@names + ', ','') + PWRSCH.GetCustomField(recs.StudentID, 'cnt' + recs.ContactNumber + '_fname') + ' ' +  PWRSCH.GetCustomField(recs.StudentID, 'cnt' + recs.ContactNumber + '_lname')
	FROM	
		(
			select
				Student_Number,
				StudentID,
				Field_Name,
				cast(substring(Field_Name,4,1) as char(1)) As ContactNumber
			FROM
				PWRSCH.PVSIS_Custom_Students
			WHERE
				Field_Name like 'cnt%lname'
			GROUP BY
				Student_Number,
				StudentID,
				Field_Name		
		) recs join
		PWRSCH.Map_StudentID ms on ms.StudentID = recs.StudentID
	WHERE
		recs.StudentID = @studentId AND
		case IsNull(PWRSCH.GetCustomField(recs.StudentID, 'cnt' + recs.ContactNumber + '_custody'),0) when '1' then 1 when 'Yes' then 1 else 0 end = 1

	return @names
END