IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[StudentPhoto_InsertImageExtract]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [PWRSCH].[StudentPhoto_InsertImageExtract]
GO

CREATE PROCEDURE PWRSCH.StudentPhoto_InsertImageExtract
	@uniqueName varchar(50),
	@imageData image	
AS

INSERT INTO PWRSCH.StudentPhoto VALUES ( @uniqueName, @imageData)