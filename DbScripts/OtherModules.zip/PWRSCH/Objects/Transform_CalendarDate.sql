IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[Transform_CalendarDate]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [PWRSCH].[Transform_CalendarDate]
GO

CREATE FUNCTION PWRSCH.Transform_CalendarDate(@importRosterYear uniqueidentifier)
RETURNS TABLE
AS
RETURN
SELECT
	CalendarID = mc1.DestID,
	[Date] = date_value,
	IsSchoolDay = insession, --encapsulates all the absence logic
	ElapsedSchoolDays = SchoolDaysSinceFirstDate.DaySince,
	ElapsedCalendarDays = datediff(d,FirstDate, date_value)	
FROm
	(
		select
			SchoolID,
			Date_value,
			Max(insession) AS insession
		FROM
			pwrsch.CALENDAR_DAY
		group by
			SchoolID,
			Date_value			
	)cd1 join
	PWRSCH.map_CalendarID mc1 on mc1.Schoolid = cd1.Schoolid and mc1.RosterYearID = @importRosterYear  join
	Pwrsch.Map_RosterYearID mry on mry.DestID= @importRosterYear join
	PWRSCH.Terms t on t.YearID = mry.YearID and t.Schoolid = cd1.Schoolid join
	Calendar c1 on mc1.DestID = c1.ID  join
	(
		SELECT
			mc2.DestID as CalID,
			InstanceDate = cd2.date_value,					
			DaySince =  (
						select 
							SUM(insession)
						from 
							pwrsch.CALENDAR_DAY cd3 join
							PWRSCH.map_CalendarID mc3 on mc3.Schoolid = cd3.Schoolid and mc3.RosterYearID = @importRosterYear  join
							Pwrsch.Map_RosterYearID mry3 on mry3.DestID= @importRosterYear join
							PWRSCH.Terms t3 on t3.YearID = mry3.YearID and t3.Schoolid = cd3.Schoolid join
							Calendar c3 on mc3.DestID = c3.ID 
						WHERE
							cd3.date_value <= cd2.date_value and c3.ID = mc2.DestID AND
							t3.IsYearRec = 1 AND -- is this the year term, that essentially marks the beginning and end of the year, it's unique to the table by year and school	
							date_Value >= t3.FirstDay AND date_Value <= t3.LastDay
						)
		FROM	
			pwrsch.CALENDAR_DAY cd2 join
			Pwrsch.Map_RosterYearID mry2 on mry2.DestID= @importRosterYear join
			PWRSCH.Terms t2 on t2.YearID = mry2.YearID and t2.Schoolid = cd2.Schoolid join
			PWRSCH.map_CalendarID mc2 on mc2.Schoolid = cd2.Schoolid and mc2.RosterYearID = @importRosterYear

		group by
			mc2.DestID,
			cd2.date_value		
	) SchoolDaysSinceFirstDate on SchoolDaysSinceFirstDate.CalID = c1.ID and SchoolDaysSinceFirstDate.InstanceDate = cd1.date_value
WHERE
	t.IsYearRec = 1 AND -- is this the year term, that essentially marks the beginning and end of the year, it's unique to the table by year and school	
	date_Value >= t.FirstDay AND date_Value <= t.LastDay