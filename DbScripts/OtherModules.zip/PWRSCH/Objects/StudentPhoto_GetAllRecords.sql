IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[StudentPhoto_GetAllRecords]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [PWRSCH].[StudentPhoto_GetAllRecords]
GO

CREATE PROCEDURE PWRSCH.StudentPhoto_GetAllRecords
AS
SELECT
	UniqueName,
	ImageData,
	ms.DestID as StudentID
FROM
	PWRSCH.STudentPhoto photo join
	PWRSCH.MAP_StudentID ms on photo.UniqueName = ms.StudentID