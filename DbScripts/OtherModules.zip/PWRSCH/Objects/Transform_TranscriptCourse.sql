IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[Transform_TranscriptCourse]') AND OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [PWRSCH].[Transform_TranscriptCourse]
GO

CREATE VIEW PWRSCH.Transform_TranscriptCourse
AS
SELECT
	DESTID = newID(),
	RosterYearID = Years.DestID,
	GradeLevelID = 	gl.ID,
	StudentID = ms.DestID,
	SchoolID = hist.SchoolID,
	IsNull(sg.storecode,'') AS storecode,		
	sg.course_name,
	sg.COURSE_number,
	sg.teacher_name,
	sg.[percent],
	sg.earnedcrhrs,
	sg.grade
FROM
	PWRSCH.StoredGrades sg join		 
	PWRSCH.Map_StudentID ms on ms.StudentID = sg.StudentID left join 	
	PWRSCH.Map_RosterYearID years on years.YearID = (sg.TermID / 100) left join 
	RosterYear ry on ry.ID = years.DestID left join
	GradeLevel gl on gl.Name = case when Len(sg.grade_level) = 2 then  cast(sg.grade_level as char(2))  when Len(sg.grade_level) = 1 then '0' + cast(sg.grade_level as char(1)) else null end left join	
	StudentSchoolHistory hist on hist.StudentID = ms.DestId AND dbo.DateInRange(ry.StartDate + 10, hist.StartDate, hist.EndDate) = 1 -- pad by 10 days from startdate, just to ensure it lands correctly,
WHERE
	sg.StoreCode = 'F1'	
GO