if exists (select * from dbo.sysobjects where id = object_id(N'[PWRSCH].[CleanupOrphanedMappingRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [PWRSCH].[CleanupOrphanedMappingRecords]
GO

CREATE PROCEDURE PWRSCH.CleanupOrphanedMappingRecords
AS

DELETE mcr
From 
	PWRSCH.Map_ClassRosterID mcr left join
	ClassRoster cr on mcr.DestID = cr.ID
where	
	cr.ID is null



