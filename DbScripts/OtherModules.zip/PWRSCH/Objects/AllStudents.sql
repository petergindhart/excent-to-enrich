--#include Transform_Student.sql

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[AllStudents]') AND OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [PWRSCH].[AllStudents]
GO

CREATE VIEW PWRSCH.AllStudents
AS

select studentID, student_number, curStu.ID
From 
	pwrsch.transform_student stu join
	Student curStu on curStu.Number = stu.StudentNumber
where
	IsNumeric(curStu.number) = 1