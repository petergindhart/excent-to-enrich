IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[Transform_AcademicPlan]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [PWRSCH].[Transform_AcademicPlan]
GO

--#include Transform_Student.sql
GO

CREATE FUNCTION PWRSCH.Transform_AcademicPlan(@ImportRosterYear uniqueidentifier)
RETURNS TABLE 
AS
RETURN
SELECT	
	DestID	= ap.ID,  
	s.*
from
	PWRSCH.Transform_Student impstu join
	Student s on s.Id = impstu.DestID join
	AcademicPlan ap on ap.StudentID = impstu.DestID
where
	ap.RosterYearID = @importRosterYear