IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[Transform_ReportCardType]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [PWRSCH].[Transform_ReportCardType]
GO

CREATE FUNCTION PWRSCH.Transform_ReportCardType(@importRosterYear uniqueidentifier )
RETURNS TABLE
AS
RETURN
SELECT
	DestID = (SELECT DESTID from PWRSCH.MAP_ReportCardTypeID mrct where mrct.SchoolID = SgT.Schoolid and mrct.YearID = SgT.yearId) ,
	Name = sch.Name + ' ' + cast( startYear as varchar(4)) + '-' + cast( startYear + 1 as varchar(4)),
	Sgt.YearId,
	Sgt.Schoolid
FROM
	(
		select 
			distinct yearid, sg.schoolid
		FROM 
			pwrsch.storedgrades sg join	
			pwrsch.Terms t on sg.termid = t.id			
		where
			sg.SectionID <> 0  -- only create items for report card (current year) records
	) SgT join 
	pwrsch.Map_rosteryearid mry on mry.YearId = SgT.YearId join
	RosterYear ry on ry.Id = mry.DestID join
	pwrsch.Map_SchoolID ms on ms.School_number = SgT.schoolid join
	School sch on ms.DestId = sch.ID 
WHERE
	ry.ID = @importRosterYear