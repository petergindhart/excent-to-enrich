IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[CleanupStudentSchoolHistory]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [PWRSCH].[CleanupStudentSchoolHistory]
GO

/*
<summary>
Cleans up StudentSchoolHistory
</summary>

<model isGenerated="False" returnType="System.Void" />
*/
CREATE PROCEDURE [PWRSCH].[CleanupStudentSchoolHistory]
	@startDate	datetime
AS

-- This script will reopen student school histories that are preparing to be re-inserted (because they are perceived to be new for some reason)
UPDATE hist
SET EndDate = null
From StudentSchoolHistory hist join
(
	SELECT 
		s.CurrentSchoolID, s.DestID as StudentID, @startDate as StartDate, (null) as EndDate
	FROM 
		StudentSchoolHistory d RIGHT OUTER JOIN 
		PWRSCH.Transform_Student s ON s.CurrentSchoolID=d.SchoolID AND s.DestID=d.StudentID AND d.EndDate IS NULL
	WHERE 
		(d.StudentID IS NULL) AND s.CurrentSchoolID IS NOT NULL  AND s.DestID IS NOT NULL 
) newHist on newHist.StudentID = hist.StudentID and newHist.CurrentSchoolID = hist.SchoolID and newHist.StartDate = hist.StartDate
