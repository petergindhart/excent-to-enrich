/****** Object:  UserDefinedFunction [PWRSCH].[GetCustomField]    Script Date: 09/25/2009 10:22:14 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[GetCustomField]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [PWRSCH].[GetCustomField]
GO

CREATE FUNCTION PWRSCH.GetCustomField
(
	@studentID	[numeric](10, 0),
	@fieldName	varchar(50)
)
RETURNS varchar(500)
AS
BEGIN	
return 
(
	SELECT
		top 1 String_Value
	FROm
		PWRSCH.PVSIS_Custom_Students
	WHERE
		StudentID = @studentID AND
		Field_Name = @fieldName
)
END