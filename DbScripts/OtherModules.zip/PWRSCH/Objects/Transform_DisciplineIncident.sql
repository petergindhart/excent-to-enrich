IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[Transform_DisciplineIncident]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [PWRSCH].[Transform_DisciplineIncident]
GO

CREATE FUNCTION PWRSCH.Transform_DisciplineIncident(@ImportRosterYear uniqueidentifier)
RETURNS TABLE
AS
RETURN
SELECT
                IncidentLocationID = msch.DestID,
                StudentID = ms.DestID,
                incident_date = isNull(Discipline_incidentDate, Entry_date),
                RosterYearID = @ImportRosterYear,
                l.entry,
                DispositionCodeID = mev.DestID                
FROm
                PWRSCH.[LOG] l join
                PWRSCH.Map_schoolID msch on msch.School_number = l.SchoolID join
                PWRSCH.Map_studentID ms on ms.StudentID = l.StudentID join
                PWRSCH.GEN g1 on g1.Id = l.logTypeID and g1.Cat = 'logtype' and g1.name = 'Discipline' join                
                PWRSCH.MAP_EnumValueID mev  on mev.Cat ='PWRSCH_disc' and Code = l.SubType join
                RosterYear ry on ry.ID = @importRosterYear
where
	            IsDate(Discipline_incidentDate) = 1 AND IsDate(Entry_date) = 1 AND
                (
					(Discipline_IncidentDate between ry.StartDate and ry.EndDate) OR
					(Entry_date between ry.StartDate and ry.EndDate)
				)