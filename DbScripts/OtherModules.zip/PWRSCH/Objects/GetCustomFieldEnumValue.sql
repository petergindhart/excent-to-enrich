IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[GetCustomFieldEnumValue]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [PWRSCH].[GetCustomFieldEnumValue]
GO

CREATE FUNCTION PWRSCH.GetCustomFieldEnumValue
(
	@studentID	[numeric](10, 0),
	@fieldName	varchar(50),
	@enumType	uniqueidentifier
)
RETURNS uniqueidentifier
AS
BEGIN
	RETURN
	(
		SELECT
			top 1 ev.ID
		FROm
			PWRSCH.PVSIS_Custom_Students cs join
			EnumValue ev on cs.String_Value = ev.COde
		WHERE
			ev.Type = @enumType AND
			StudentID = @studentID AND
			Field_Name = @fieldName
	)
END