IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[Transform_StudentPhoto]') AND OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [PWRSCH].[Transform_StudentPhoto]
GO

CREATE VIEW PWRSCH.Transform_StudentPhoto
AS
SELECT	
	ID = newID(),
	StudentID = ms.DestID,
	PhotoID = fd.ID,		
	TypeID = 'BA839F5B-CA88-4F50-A132-469B6E2ED2E4' -- Original Photo,
FROM
	FileData fd join
	PWRSCH.Map_StudentID ms on ms.StudentID = cast(fd.OriginalName  as int)
WHERE
	IsNumeric(fd.OriginalName) = 1