IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[Transform_SectionIDClassRosterID]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [PWRSCH].[Transform_SectionIDClassRosterID]
GO

CREATE FUNCTION PWRSCH.Transform_SectionIDClassRosterID
(
	@importRosterYear uniqueidentifier 
)
RETURNS TABLE
AS
RETURN
SELECT
      SectionID = s.ID,
      mcr.DestID,
      RosterYearID = @importRosterYear
FROM
      PWRSCH.Sections s join 
      PWRSCH.Map_RosterYearID mry on mry.DestID = @importRosterYear join
      PWRSCH.Terms t on s.TermID = t.ID and s.SchoolID = t.SchoolID and t.YearID = mry.YearID join
      PWRSCH.Map_ClassRosterID mcr on mcr.Course_Number = s.Course_Number  and mcr.School_number  = s.SchoolID and mcr.Section_Number = s.Section_NUmber  and mcr.RosterYearID=  @importRosterYear