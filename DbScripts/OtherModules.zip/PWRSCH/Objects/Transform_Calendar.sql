IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[Transform_Calendar]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [PWRSCH].[Transform_Calendar]
GO

CREATE FUNCTION PWRSCH.Transform_Calendar(@importRosterYearID uniqueidentifier)
RETURNS TABLE
AS
RETURN
SELECT
	DestID = (select DestID From PWRSCH.Map_CalendarID mc where mc.SchoolID = cd.SchoolID and mc.RosterYearID = @importRosterYearID),
	Name =  MAX(sch.Name) + ' ' + cast(Datepart(yyyy, MIN(date_Value)) as varchar(4))+ '-' + cast(Datepart(yyyy, MAX(date_Value)) as varchar(4)), 
	FirstDate = MIN(date_Value),
	LastDate = MAX(date_Value),
	School_Number = cd.SchoolID,	
	startyear = Datepart(yyyy, MIN(date_Value)),
	SchoolId = ms.DestID,
	LegacySchoolID = substring( cast(cd.SchoolID as varchar(10)), LEN(cd.SchoolID) - 2, 3),
	RosterYearID = @importRosterYearID
FROm
	pwrsch.CALENDAR_DAY cd join
	pwrsch.map_SchoolID ms on ms.School_number = cd.SchoolID join
	School sch on sch.Id = ms.DestID join
	Pwrsch.Map_RosterYearID mry on mry.DestID= @importRosterYearID join
	PWRSCH.Terms t on t.YearID = mry.YearID and t.Schoolid = cd.Schoolid join
	RosterYear ry on ry.ID = @importRosterYearID
WHERE
	t.IsYearRec = 1 AND -- is this the year term, that essentially marks the beginning and end of the year, it's unique to the table by year and school	
	date_Value >= t.FirstDay AND date_Value <= t.LastDay
GROUP BY
	ms.DestID,
	cd.schoolid
GO