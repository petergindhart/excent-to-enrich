IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[Transform_StudentGuardian]') AND OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [PWRSCH].[Transform_StudentGuardian]
GO

CREATE VIEW PWRSCH.Transform_StudentGuardian
AS
SELECT
	msg.DestID,
	StudentID = ms.DestId,
	RelationshipID = mr.DestID,
	PersonID = mp.DestID,
	Sequence = recs.ContactNumber
FROM
	(
		select
			Student_Number,
			StudentID,
			Field_Name,
			cast(substring(Field_Name,4,1) as char(1)) As ContactNumber
		FROM
			PWRSCH.PVSIS_Custom_Students
		WHERE
			Field_Name like 'cnt%_rel'
		GROUP BY
			Student_Number,
			StudentID,
			Field_Name		
	) recs join
	PWRSCH.Map_PersonID mp on mp.Student_Number = recs.Student_Number and mp.ContactNumber = recs.ContactNumber join	
	PWRSCH.MAP_StudentID ms on ms.StudentID = recs.STUDENTID join	
	PWRSCH.Map_StudentGuardianRelationshipID mr on mr.Name = PWRSCH.GetCustomField(recs.StudentID, Field_Name) left join
	pwrsch.Map_StudentGuardianID msg on msg.StudentID = ms.DestID and msg.PersonID = mp.DestID
GO