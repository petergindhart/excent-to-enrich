
DECLARE @srySequence int

select @srySequence = sequence from vc3etl.LoadTable where DestTable= 'StudentRosterYear'
and ExtractDatabase= '48F3EB0A-1139-43D5-BDDF-C66DD51642EB'

UPDATE VC3ETL.LoadTable
SET Sequence = Sequence + 1
WHERE 
	ExtractDatabase='48F3EB0A-1139-43D5-BDDF-C66DD51642EB' AND
	Sequence >= @srySequence
	
INSERT INTO VC3ETL.LoadTable VALUES ('F8BF4711-BF29-49C4-A56A-4A49F91B4200','48F3EB0A-1139-43D5-BDDF-C66DD51642EB', @srySequence, '[PWRSCH].[SynchronizeStudentRosterYearMappings] @importRosterYear','',0,NULL,NULL,NULL,4,0,0,0,1,NULL,NULL,NULL,0,0,NULL)