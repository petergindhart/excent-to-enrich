--Set the final report cards to have the last sequence, to ensure they always get sorted last
UPDATE ReportCardItem 
SET Sequence = 9999
where ShortName='F1'