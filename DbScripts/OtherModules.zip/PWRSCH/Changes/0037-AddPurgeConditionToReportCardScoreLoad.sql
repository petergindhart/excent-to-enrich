UPDATE vc3etl.LoadTable
SET PurgeCondition = '{dest}.ClassRoster IN (select ID from ClassRoster where RosterYearID = @importRosterYear)'
WHERE ID = '81022486-1F6C-455E-866C-180AB2798293'