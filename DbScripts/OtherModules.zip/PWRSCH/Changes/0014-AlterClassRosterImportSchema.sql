DROP TABLE PWRSCH.Map_ClassRosterID
GO

CREATE TABLE PWRSCH.Map_ClassRosterID
	(
	Course_Number varchar(11) NOT NULL,
	Section_Number varchar(11) NOT NULL,
	School_Number varchar(10) NOT NULL,
	RosterYearID uniqueidentifier NOT NULL,
	DestId uniqueidentifier NOT NULL
	)  ON [PRIMARY]
GO

ALTER TABLE PWRSCH.Map_ClassRosterID ADD CONSTRAINT
	PK_PWRSCH_Map_ClassRosterID PRIMARY KEY CLUSTERED 
	(
	DestId
	) WITH FILLFACTOR = 90 ON [PRIMARY]

GO

UPDATE vc3etl.LoadTable 
SET KeyField= 'Course_Number, Section_Number, School_Number, RosterYearID'
where id = '9EECE358-4273-49A2-87FD-0BCC18B2F6A3'

