DELETE ms
from PWRSCH.Map_SchoolID ms join
	School sch on ms.DestId = sch.ID
WHERE
	School_Number ='999999'

DELETE sch
from PWRSCH.Map_SchoolID ms join
	School sch on ms.DestId = sch.ID
WHERE
	School_Number ='999999'

UPDATE vc3etl.ExtractTable
SET LastSuccessfulCount = LastSuccessfulCount - 1
WHERE ID ='9FA3D5CC-4141-43E6-A1E1-E1163BA22C5C' AND
	LastSuccessfulCount > 0 

UPDATE vc3etl.ExtractTable
SET CurrentCount =  CurrentCount - 1
WHERE ID ='9FA3D5CC-4141-43E6-A1E1-E1163BA22C5C' ANd
	CurrentCount > 0
