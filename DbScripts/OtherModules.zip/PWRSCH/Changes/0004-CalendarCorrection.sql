UPDATE vc3etl.LoadTable
SET SourceTable= 'PWRSCH.Transform_Calendar(@importRosterYear)'
WHERE ID = '08699738-2976-4A16-B6A2-8863F5445424'

UPDATE vc3etl.LoadTable
SET SourceTable= 'PWRSCH.Transform_CalendarDate(@importRosterYear)'
WHERE ID = '9527B7BD-3ACD-4579-95CC-3B6A9F2C84DA'

UPDATE vc3etl.LoadTable
SET SourceTable= 'PWRSCH.Transform_Calendar(@importRosterYear)'
WHERE ID = '61573FDD-66EA-4B12-919E-C23A41243598'

UPDATE vc3etl.LoadTable
SET KeyField = 'School_Number, @importRosterYear'
WHERE ID = '61573FDD-66EA-4B12-919E-C23A41243598'
