UPDATE VC3ETL.ExtractTable
SET Indexes='StudentID;SectionID'
WHERE ID ='DFFDF7EC-E215-43D3-9ACF-55DFFFC3BB1D'

UPDATE VC3ETL.ExtractTable
SET Indexes='ID', Columns='cast(DCID as int) AS DCID, cast(ID as int) AS ID, round(Schoolid,0) as Schoolid, round(grade_level,0) as grade_level, student_number, First_Name, middle_name, Last_Name, street, City, state, zip, gender, ethnicity, ssn,  DOB, home_phone, cumulative_gpa, PHOTOFLAG'
WHERE ID ='ED01A269-20C1-43D5-B2BB-31C883F11EAC'

UPDATE VC3ETL.ExtractTable
SET Filter = IsNull(Filter + ' AND ','') + ' School_Number NOT IN (999999)'
WHERE id= '9FA3D5CC-4141-43E6-A1E1-E1163BA22C5C'
AND 
	(charindex('999999', Filter)  = 0 OR charindex('999999', Filter) is null)