UPDATE ReportCardItem 
SET IsFinal = 1
WHERE ShortName='F1'