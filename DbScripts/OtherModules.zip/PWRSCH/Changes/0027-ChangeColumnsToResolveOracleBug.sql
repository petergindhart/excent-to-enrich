UPDATE vc3etl.ExtractTable
SET COlumns= 'round(dcid,0) as dcid, round(ID,0) as ID, round(StudentID,0) as StudentID, logTypeID, subType, round(Schoolid,0) as Schoolid, cast( SUBSTR(entry,0,4000) as varchar(4000)) AS Entry, cast(Entry_date as varchar(20)) AS Entry_date, cast(Discipline_incidentDate as varchar(20)) AS Discipline_incidentDate'
WHERE ID = 'F4397DB1-5BC5-4A07-999A-3D0710C92E86'

UPDATE SisMigrationTable
SET MapTable='Student_Clean'
WHERE ID = 'BCBC6E74-F178-4D11-8DCE-389D392B9F70'