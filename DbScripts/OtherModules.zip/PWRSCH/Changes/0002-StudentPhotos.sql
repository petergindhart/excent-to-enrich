CREATE TABLE PWRSCH.StudentPhoto(
	[UniqueName] [varchar](50) NOT NULL,
	[ImageData] [image] NULL,
 CONSTRAINT [PK_StudentPhoto] PRIMARY KEY CLUSTERED 
(
	[UniqueName] ASC
) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

INSERT INTO vc3taskscheduler.scheduledtaskschedule VALUES ('4F0E41C9-928C-44D1-946D-DC9AF3C24029', 'F03A0C51-7294-4B57-AFB7-AFF136E4025F', '<?xml version="1.0" encoding="utf-16"?>  <ArrayOfDictionaryEntry xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">    <DictionaryEntry>      <Key xsi:type="xsd:string">DatabaseId</Key>      <Value xsi:type="xsd:string">30CCF975-64D3-43EE-B567-CA5C2BEF1F46*FDBC2C27-7803-4831-A1DC-4B0B6F1117E0</Value>    </DictionaryEntry>    <DictionaryEntry>      <Key xsi:type="xsd:string">CreateSnapshot</Key>      <Value xsi:type="xsd:boolean">true</Value>    </DictionaryEntry>  </ArrayOfDictionaryEntry>', 
	0, '2009-03-20 14:58:24.563', NULL, 1, 'W', NULL, NULL, NULL, 3, 0,	0,	0	,0	,0	,0	,0	,0)


INSERT INTO vc3etl.ExtractDatabase VALUES ('30CCF975-64D3-43EE-B567-CA5C2BEF1F46', 'FDBC2C27-7803-4831-A1DC-4B0B6F1117E0'  ,'256BEEB5-D6B4-4FA9-9854-8ACCAE51FF2E', NULL, 'PWRSCH', 'd$\PowerSchoolPremier\data\picture\student', NULL, NULL, NULL, 0, NULL, NULL, NULL, '[{BrandName}] {SisDatabase} import completed', 'Successfully imported {SnapshotRosterYear} {SisDatabase} data into {BrandName}.  {SisDatabase} data in {BrandName} is now current as of {SnapshotDate}.      Next Scheduled Import Time: {NextImportTime}', NULL, '[{BrandName}] {SisDatabase} import failed', 'There was a problem importing {SnapshotRosterYear} {SisDatabase} data into {BrandName}:  {ErrorMessage}    Click the link below or go to the SYSADMIN section of {BrandName} for additional information about this problem:  {ErrorLink}', 1, '_NEW', '_LOCAL', NULL, '4F0E41C9-928C-44D1-946D-DC9AF3C24029', 'PowerSchool Student Photos', 0)
INSERT INTO ImageExtractDatabase Values ('30CCF975-64D3-43EE-B567-CA5C2BEF1F46', '3222959E-8373-413D-B06A-73B0510B9F31')


--FileData
INSERT INTO vc3etl.LoadTable VALUES ('7A3A0A19-1CD2-4B9F-952D-8FF0B62DB1A8' , '30CCF975-64D3-43EE-B567-CA5C2BEF1F46', 0, 'PWRSCH.Transform_FileData', 'FileData', 0, NULL, NULL,NULL, 1,0,1,1,1, NULL, NULL, NULL, 0,0, NULL)

INSERT INTO VC3ETL.LoadColumn VALUES ('482B58DA-6923-407F-8642-B093B5351EFB', '7A3A0A19-1CD2-4B9F-952D-8FF0B62DB1A8', '(@ImportDate)', 'ReceivedDate', 'C', 0, NULL, NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('A750DC94-AD37-4906-9401-5C99B3880017', '7A3A0A19-1CD2-4B9F-952D-8FF0B62DB1A8', 'UniqueName', 'OriginalName', 'K', 0, NULL, NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('08574657-12A4-4927-B09C-1E30C46C77C6', '7A3A0A19-1CD2-4B9F-952D-8FF0B62DB1A8', 'MimeType', 'MimeType', 'C', 0, NULL, NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('E4802763-6D2D-4A4C-8E73-27BC4159273A', '7A3A0A19-1CD2-4B9F-952D-8FF0B62DB1A8', 'ImageData', 'Content', 'C', 0, NULL, NULL)

--StudentPhoto
INSERT INTO vc3etl.LoadTable VALUES ('53290B9E-B1A5-47EF-AC20-99AAF3B38D17' , '30CCF975-64D3-43EE-B567-CA5C2BEF1F46', 1, 'PWRSCH.Transform_StudentPhoto', 'StudentPhoto', 0, NULL, NULL,NULL, 1,0,1,1,1, NULL, NULL, NULL, 0,0, NULL)

INSERT INTO VC3ETL.LoadColumn VALUES ('41CF97F5-D0C2-4CDF-845B-C9D2DFFAC12C', '53290B9E-B1A5-47EF-AC20-99AAF3B38D17', 'ID', 'ID', 'C', 0, NULL, NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('D459070C-08B1-4381-A5BF-6B6E9D8198BD', '53290B9E-B1A5-47EF-AC20-99AAF3B38D17', '(@importRosterYear)', 'RosterYearID', 'K', 0, NULL, NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('3E2E6BA1-0846-4CF8-B320-A935E22088EF', '53290B9E-B1A5-47EF-AC20-99AAF3B38D17', 'StudentID', 'StudentID', 'K', 0, NULL, NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('B63DF81B-4C1C-43C5-851B-3732F84D64CC', '53290B9E-B1A5-47EF-AC20-99AAF3B38D17', 'PhotoID', 'PhotoID', 'K', 0, NULL, NULL)
INSERT INTO VC3ETL.LoadColumn VALUES ('F647DC2C-B4E8-4BCC-973E-010835F0C27D', '53290B9E-B1A5-47EF-AC20-99AAF3B38D17', 'TypeID', 'TypeID', 'K', 0, NULL, NULL)
