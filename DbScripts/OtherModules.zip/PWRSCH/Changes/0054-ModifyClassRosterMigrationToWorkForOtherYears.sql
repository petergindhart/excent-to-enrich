UPDATE SisMigrationTable
SET SourceTable='SASI_Migrate_ClassRoster (@importRosterYear)'
WHERE ID = '8FB4D597-627B-400E-B8DB-CA9AD4AEE740'

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[SASI_Migrate_ClassRoster]') AND OBJECTPROPERTY(id, N'IsView') = 1)
	DROP VIEW [dbo].[SASI_Migrate_ClassRoster]
GO

UPDATE sismigrationcolumn
SET Name = 'StudentNumber'
WHERE id = '5A6374CA-12A1-4E28-BC4C-87A4C2018772'