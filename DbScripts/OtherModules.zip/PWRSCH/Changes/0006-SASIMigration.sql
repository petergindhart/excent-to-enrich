--#ASSUME VC3ETL:20

--STUDENT
UPDATE vc3etl.ExtractTable
SET Columns = 'round(dcid,0) as dcid, round(ID,0) as ID, round(Schoolid,0) as Schoolid, round(grade_level,0) as grade_level, student_number, First_Name, middle_name, Last_Name, street, City, state, zip, gender, ethnicity, ssn,  DOB, home_phone, cumulative_gpa, PHOTOFLAG'
WHERE ID = 'ED01A269-20C1-43D5-B2BB-31C883F11EAC'

--ATTENDANCE
UPDATE vc3etl.ExtractTable
SET Columns = 'round(dcid,0) as dcid, round(ID,0) as ID, round(Schoolid,0) as Schoolid, StudentID, round(YearId,0) as YearId,  round(Attendance_CodeID,0) as Attendance_CodeID, round(Calendar_DayID,0) as Calendar_DayID'
WHERE ID = 'BBAB10A6-2093-4BC0-B8B2-6F6C2D90F2FD'

--ATTENDANCE_CODE
UPDATE vc3etl.ExtractTable
SET Columns = 'round(dcid,0) as dcid, round(ID,0) as ID, att_code, round(Schoolid,0) as Schoolid, PRESENCE_STATUS_CD, CAST(Description as varchar(50)) AS Description, yearID'
WHERE ID = '64A0B032-E01E-4002-AC67-D817880AFC96'

--
----CALENDAR_DAY
--UPDATE vc3etl.ExtractTable
--SET Columns = 'round(dcid,0) as dcid, round(ID,0) as ID, '
--WHERE ID = 'FF21052E-94EB-4F68-B5FE-48423822CDD6'

--CC
UPDATE vc3etl.ExtractTable
SET Columns = 'cast(round(dcid,0) as int) as dcid , cast(round(ID,0) as int) as ID, cast(round(STudentID,0) as int) as STudentID, cast(round(sectionID,0) as int) as sectionID , course_number, section_number, DateEnrolled, DateLeft'
WHERE ID = 'DFFDF7EC-E215-43D3-9ACF-55DFFFC3BB1D'

--
----COURSES
UPDATE vc3etl.ExtractTable
SET Columns = 'round(dcid,0) as dcid, round(ID,0) as ID, round(Schoolid,0) as Schoolid, Course_NUmber, Course_Name'
WHERE ID = '3F7CA6C9-4FB7-4DFC-8CCB-4F08E97C3FE1'

--
----DAILYATTENDANCE
--UPDATE vc3etl.ExtractTable
--SET Columns = 'round(dcid,0) as dcid, round(ID,0) as ID, '
--WHERE ID = '2F04B605-3350-4245-8132-4B79F3CAC618'
--
----DEMOGRAPHIC
--UPDATE vc3etl.ExtractTable
--SET Columns = 'round(dcid,0) as dcid, round(ID,0) as ID, '
--WHERE ID = '336A6DD6-51BA-44DC-9C3F-409962490957'
--
----ETHNICITY
--UPDATE vc3etl.ExtractTable
--SET Columns = 'round(dcid,0) as dcid, round(ID,0) as ID, '
--WHERE ID = 'F54EA53D-E443-4173-B8F3-7A4A2F60E7A8'

----GEN
UPDATE vc3etl.ExtractTable
SET Columns = 'round(dcid,0) as dcid, round(ID,0) as ID, Cat, name, cast(valuet as varchar(4000)) as valuet, cast(Value as varchar(100))  as value'
WHERE ID = 'E13A6CDD-D1E9-4DCB-985F-B8CD5950D649'

--
----GRADESCALEITEM
--UPDATE vc3etl.ExtractTable
--SET Columns = 'round(dcid,0) as dcid, round(ID,0) as ID, '
--WHERE ID = 'A8327573-951A-42FC-A05E-8D64DA0E5693'

--LOG
UPDATE vc3etl.ExtractTable
SET Columns = 'round(dcid,0) as dcid, round(ID,0) as ID, round(StudentID,0) as StudentID, logTypeID, round(Schoolid,0) as Schoolid, cast(entry as varchar(4000)) AS Entry, Entry_date, Discipline_incidentDate'
WHERE ID = 'F4397DB1-5BC5-4A07-999A-3D0710C92E86'


----PGFINALGRADES
--UPDATE vc3etl.ExtractTable
--SET Columns = 'round(dcid,0) as dcid, round(ID,0) as ID, '
--WHERE ID = '09579589-676D-469E-A20E-E42AE29D885B'
--
----PGFINALGRADESSETUP
--UPDATE vc3etl.ExtractTable
--SET Columns = 'round(dcid,0) as dcid, round(ID,0) as ID, '
--WHERE ID = '9C348DCF-67E3-4ED4-897A-A46E6D1EBE23'

--
----SCHOOL_COURSE
--UPDATE vc3etl.ExtractTable
--SET Columns = 'round(dcid,0) as dcid, round(ID,0) as ID, '
--WHERE ID = '03F4DF06-7F33-4434-ACF3-5D80C32F3740'

----SCHOOLS
UPDATE vc3etl.ExtractTable
SET Columns = 'round(dcid,0) as dcid, round(ID,0) as ID, Abbreviation, Name, School_number, District_number, alternate_school_number'
WHERE ID = '9FA3D5CC-4141-43E6-A1E1-E1163BA22C5C'

--SECTIONS
UPDATE vc3etl.ExtractTable
SET Columns = 'round(dcid,0) as dcid, round(ID,0) as ID, Course_NUmber, round(Schoolid,0) as Schoolid,  round(section_Number,0) as section_Number, round(Teacher,0) as Teacher'
WHERE ID = 'BCDFD5BA-81ED-4414-8995-906D1C38611C'

--STOREDGRADES
UPDATE vc3etl.ExtractTable
SET Columns = 'round(dcid,0) as dcid, round(Schoolid,0) as Schoolid, round(StudentID,0) as StudentID, termid, StoreCode, SectionID, grade, percent, course_name, COURSE_number, teacher_name, earnedcrhrs, grade_level'
WHERE ID = '963B39A3-AB6B-4BCD-9B58-FC89AB9E91B1'

----TEACHERS
UPDATE vc3etl.ExtractTable
SET Columns = 'round(dcid,0) as dcid, round(ID,0) as ID, round(Schoolid,0) as Schoolid, email_addr, School_phone, state, ssn,  zip, Last_Name, FIRST_NAME, street, city, ethnicity, sched_gender, teacherNumber'
WHERE ID = '54421A8D-4D4A-45D6-8F0F-65F7619EA25C'

--TERMS
UPDATE vc3etl.ExtractTable
SET Columns = 'cast(round(dcid,0) as int) as dcid , cast(round(ID,0) as int) as ID , cast(round(Schoolid,0) as int) as Schoolid, FirstDay, LastDay, cast(round(YearID,0) as int) as YearID , Abbreviation, cast(round(portion,0) as int) as portion , cast(round(noofdays,0) as int) as noofdays , cast(round(termsinyear,0) as int) as termsinyear, cast(round(sterms,0) as int) as sterms, IsYearRec'
WHERE ID = 'A21BBE58-7E3B-4911-85C7-20C348B4D02F'


UPDATE VC3ETL.ExtractTable
SET Enabled = 0
WHERE ID IN ('9C348DCF-67E3-4ED4-897A-A46E6D1EBE23', 'A8327573-951A-42FC-A05E-8D64DA0E5693', '2F04B605-3350-4245-8132-4B79F3CAC618', '09579589-676D-469E-A20E-E42AE29D885B')