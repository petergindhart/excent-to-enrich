ALTER TABLE pwrsch.Map_StudentID
 DROP COLUMN student_number
GO

UPDATE vc3etl.LoadTable
SET KeyField= 'studentID'
where ID = 'EA8289C8-14AF-4048-A4D2-A985B8198138'


GO
DROP TABLE PWRSCH.Map_AbsenceReason_ID

GO
CREATE TABLE [PWRSCH].[Map_AbsenceReason_ID](
	[AttendanceCode] varchar(5) NOT NULL,
	[DestId] [uniqueidentifier] NOT NULL,
 CONSTRAINT [PK_PWRSCH_Map_AbsenceReason_ID] PRIMARY KEY CLUSTERED 
(
	[DestId] ASC
) ON [PRIMARY]
) ON [PRIMARY]
GO

UPDATE vc3etl.LoadTable
SEt KeyField ='att_code'
WHeRE ID = 'DCEA94B3-F6D9-43B9-AA09-54C906F08B93'

UPDATE VC3ETL.LoadTable
SET SourceTable = 'PWRSCH.Transform_Calendar(@importRosterYearID)', MapTable='School_Number, @importRosterYear'
WHERE ID = '61573FDD-66EA-4B12-919E-C23A41243598'

UPDATE VC3ETL.LoadTable
SET SourceTable = 'PWRSCH.Transform_CalendarDate(@importRosterYear)'
WHERE ID = '9527B7BD-3ACD-4579-95CC-3B6A9F2C84DA'

UPDATE VC3ETL.LoadTable
SET SourceTable = 'PWRSCH.Transform_Calendar(@importRosterYear)'
WHERE ID = '08699738-2976-4A16-B6A2-8863F5445424'
GO

CREATE TABLE [PWRSCH].[Map_EnumTypeID](
	[Cat] varchar(20) NOT NULL,
	[DestID] uniqueidentifier NOT NULL,
 CONSTRAINT [PK_PWRSCH_Map_EnumTypeID] PRIMARY KEY CLUSTERED 
(
	[DestID] ASC
) ON [PRIMARY]
) ON [PRIMARY]
GO

delete EnumType where id in
(
	'9AB3B5C0-F71E-4565-AF19-C3D67DF27A4D' ,
	'C24F7DEE-55D9-4089-81C5-3B9C08079F8D'
)

INSERT INTO [PWRSCH].[Map_EnumTypeID] VALUES ('gender', 'D6194389-17AC-494C-9C37-FD911DA2DD4B')
INSERT INTO [PWRSCH].[Map_EnumTypeID] VALUES ('ethnicity', 'CBB84AE3-A547-4E81-82D2-060AA3A50535')
INSERT INTO [PWRSCH].[Map_EnumTypeID] VALUES ('specprog', 'DB28F760-14AF-469C-8F58-8040D846F7EE')
INSERT INTO [PWRSCH].[Map_EnumTypeID] VALUES ('PWRSCH_disc', 'A2179715-E644-474D-9F30-1016F8F57AA2')