UPDATE vc3etl.LoadTable
SET Sequence =  Sequence + 1
WHERE 
	ExtractDatabase='48F3EB0A-1139-43D5-BDDF-C66DD51642EB' AND
	Sequence >= (select top 1 sequence from vc3etl.LoadTable where id= '9EECE358-4273-49A2-87FD-0BCC18B2F6A3')
GO

DECLARE @seq int
SET @seq = ((select top 1 sequence from vc3etl.LoadTable where id= '9EECE358-4273-49A2-87FD-0BCC18B2F6A3') - 1)
	
INSERT INTO vc3etl.LoadTable VALUES ( 'FCD5CD8B-3AD2-4321-981A-17E4FB21F226', '48F3EB0A-1139-43D5-BDDF-C66DD51642EB', @seq, '[PWRSCH].[CleanupOrphanedMappingRecords]',
NULL,
0,NULL,NULL,NULL,4,0,0,0,1,NULL,NULL,NULL,0,0,NULL)