--#assume VC3ETL:24
GO
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[VirtualTable_SC_EIA_EFA_HISTORY_LOCAL]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
	DROP TABLE [PWRSCH].[VirtualTable_SC_EIA_EFA_HISTORY_LOCAL]
GO

CREATE TABLE [PWRSCH].[VirtualTable_SC_EIA_EFA_HISTORY_LOCAL](
	[SCHOOLID] [numeric](10, 0) NULL,
	[LAST_NAME] [varchar](20) NULL,
	[FIRST_NAME] [varchar](15) NULL,
	[GRADE_LEVEL] [numeric](10, 0) NULL,
	[ENTRYDATE] [datetime] NULL,
	[ENTRYCODE] [varchar](10) NULL,
	[STUDENTID] [numeric](10, 0) NULL,
	[SCHOOLID_CREATED] [varchar](40) NULL,
	[EIASTARTDT] [varchar](40) NULL,
	[EIAENDDT] [varchar](40) NULL,
	[EIA1] [varchar](40) NULL,
	[EIA2] [varchar](40) NULL,
	[EIA3] [varchar](40) NULL,
	[EIA4] [varchar](40) NULL,
	[EIA5] [varchar](40) NULL,
	[EIA6] [varchar](40) NULL,
	[EIA7] [varchar](40) NULL,
	[EIA8] [varchar](40) NULL,
	[EIA9] [varchar](40) NULL,
	[EIA10] [varchar](40) NULL,
	[EFA_PRIMARY] [varchar](40) NULL,
	[EFAENDDT] [varchar](40) NULL,
	[EFA2] [varchar](40) NULL,
	[EFA3] [varchar](40) NULL,
	[EFA4] [varchar](40) NULL,
	[EFA5] [varchar](40) NULL,
	[EFA6] [varchar](40) NULL,
	[EFA7] [varchar](40) NULL,
	[EFA8] [varchar](40) NULL,
	[EFA9] [varchar](40) NULL,
	[EFA10] [varchar](40) NULL,
	[ENROLL_STATUS] [numeric](10, 0) NULL,
	[EXITDATE] [datetime] NULL,
	[EXITCODE] [varchar](10) NULL,
	[SC_INCLUDEINREPORTING] [varchar](40) NULL
) ON [PRIMARY]

GO

CREATE VIEW PWRSCH.VirtualTable_SC_EIA_EFA_HISTORY
AS
SELECT  * FROM PWRSCH.VirtualTable_SC_EIA_EFA_HISTORY_LOCAL
GO

INSERT INTO VC3ETL.ExtractTable VALUES ( '503A5F19-3296-4320-AC91-21EE02DA1BE7', '48F3EB0A-1139-43D5-BDDF-C66DD51642EB', '(PS.students stu left outer join PS.virtualtablesdata2 vtd2  on stu.id = vtd2.foreignkey)', 'PWRSCH','VirtualTable_SC_EIA_EFA_HISTORY',NULL, NULL,0,0,NULL,1,0,
'stu.schoolid, stu.last_name, stu.first_name, stu.grade_level,
	stu.entrydate, stu.entrycode, stu.ID as studentID,
	substr(PS_CUSTOMFIELDS.getCF(''''SC_EIA_HISTORY'''',vtd2.unique_ID,''''school_id''''),1,8) schoolid_created,
	substr(to_Char(PS_CUSTOMFIELDS.getCF(''''SC_EIA_HISTORY'''',vtd2.unique_ID,''''start_dt'''')),1,10) EIASTARTDT,
	substr(PS_CUSTOMFIELDS.getCF(''''SC_EIA_HISTORY'''',vtd2.unique_ID,''''stop_dt''''),1,12) eiaEndDt,
	substr(PS_CUSTOMFIELDS.getCF(''''SC_EIA_HISTORY'''',vtd2.unique_ID,''''eia_1''''),1,5) EIA1,
	substr(PS_CUSTOMFIELDS.getCF(''''SC_EIA_HISTORY'''',vtd2.unique_ID,''''eia_2''''),1,5) EIA2,
	substr(PS_CUSTOMFIELDS.getCF(''''SC_EIA_HISTORY'''',vtd2.unique_ID,''''eia_3''''),1,5) EIA3,
	substr(PS_CUSTOMFIELDS.getCF(''''SC_EIA_HISTORY'''',vtd2.unique_ID,''''eia_4''''),1,5) EIA4,
	substr(PS_CUSTOMFIELDS.getCF(''''SC_EIA_HISTORY'''',vtd2.unique_ID,''''eia_5''''),1,5) EIA5,
	substr(PS_CUSTOMFIELDS.getCF(''''SC_EIA_HISTORY'''',vtd2.unique_ID,''''eia_6''''),1,5) EIA6,
	substr(PS_CUSTOMFIELDS.getCF(''''SC_EIA_HISTORY'''',vtd2.unique_ID,''''eia_7''''),1,5) EIA7,
	substr(PS_CUSTOMFIELDS.getCF(''''SC_EIA_HISTORY'''',vtd2.unique_ID,''''eia_8''''),1,5) EIA8,
	substr(PS_CUSTOMFIELDS.getCF(''''SC_EIA_HISTORY'''',vtd2.unique_ID,''''eia_9''''),1,5) EIA9,
	substr(PS_CUSTOMFIELDS.getCF(''''SC_EIA_HISTORY'''',vtd2.unique_ID,''''eia_10''''),1,5) EIA10,
	substr(PS_CUSTOMFIELDS.getCF(''''SC_EFA_HISTORY'''',vtd2.unique_ID,''''efa_primary''''),1,12) EFA_primary,
	substr(PS_CUSTOMFIELDS.getCF(''''SC_EFA_HISTORY'''',vtd2.unique_ID,''''stop_dt''''),1,12) EFAEndDt,	
	substr(PS_CUSTOMFIELDS.getCF(''''SC_EFA_HISTORY'''',vtd2.unique_ID,''''EFA_2''''),1,5) EFA2,
	substr(PS_CUSTOMFIELDS.getCF(''''SC_EFA_HISTORY'''',vtd2.unique_ID,''''EFA_3''''),1,5) EFA3,
	substr(PS_CUSTOMFIELDS.getCF(''''SC_EFA_HISTORY'''',vtd2.unique_ID,''''EFA_4''''),1,5) EFA4,
	substr(PS_CUSTOMFIELDS.getCF(''''SC_EFA_HISTORY'''',vtd2.unique_ID,''''EFA_5''''),1,5) EFA5,
	substr(PS_CUSTOMFIELDS.getCF(''''SC_EFA_HISTORY'''',vtd2.unique_ID,''''EFA_6''''),1,5) EFA6,
	substr(PS_CUSTOMFIELDS.getCF(''''SC_EFA_HISTORY'''',vtd2.unique_ID,''''EFA_7''''),1,5) EFA7,
	substr(PS_CUSTOMFIELDS.getCF(''''SC_EFA_HISTORY'''',vtd2.unique_ID,''''EFA_8''''),1,5) EFA8,
	substr(PS_CUSTOMFIELDS.getCF(''''SC_EFA_HISTORY'''',vtd2.unique_ID,''''EFA_9''''),1,5) EFA9,
	substr(PS_CUSTOMFIELDS.getCF(''''SC_EFA_HISTORY'''',vtd2.unique_ID,''''EFA_10''''),1,5) EFA10,
	stu.Enroll_status,
	stu.exitdate, stu.exitcode,
	substr(PS_CUSTOMFIELDS.getCF(''''STUDENTS'''',stu.ID,''''SC_IncludeInReporting''''),1,1) SC_IncludeInReporting')



DECLARE @customSeq int
SELECT @customSeq = Sequence FROM vc3etl.LoadTable where ID = '86EBF668-8E15-424A-99BF-F802B3F87869'

UPDATE vc3etl.LoadTable
SET Sequence = Sequence + 1
WHERE ExtractDatabase = '48F3EB0A-1139-43D5-BDDF-C66DD51642EB' AND Sequence >= @customSeq

--always add the root, without any of the columns it will do nothing
INSERT INTO vc3etl.LoadTable VALUES ( 'B5ABE7D3-5FE6-4F1A-A601-81EAE28A3F89', '48F3EB0A-1139-43D5-BDDF-C66DD51642EB', @customSeq,'[PWRSCH].[Transform_EIA_EFA_HISTORY]', 'Student',1,'PWRSCH.MAP_StudentID','studentID','DestID', 1,0,1,0,1,NULL, NULL,NULL, 0, 0, NULL)

--add the DestID column
IF NOT EXISTS(Select * from vc3etl.LoadColumn where id ='E657304A-502C-4128-83C1-5F3A0E6F2EB6') AND 
	( 
		EXISTS(select * from vc3etl.LoadColumn where id = 'F929EF79-589A-40BA-A156-4BA53372BA19') OR
		EXISTS(select * from vc3etl.LoadColumn where id = '3BF37A43-3A3D-45C5-9BCE-6A35183DC256')
	)
BEGIN
	INSERT INTO vc3etl.LoadColumn VALUES ( 'E657304A-502C-4128-83C1-5F3A0E6F2EB6','B5ABE7D3-5FE6-4F1A-A601-81EAE28A3F89','DestID','ID','K',0,NULL,NULL)
END

--add the GTA column, IF they have it with SASI, but NOT with PS yet
IF EXISTS(select * from vc3etl.LoadColumn where id = 'F929EF79-589A-40BA-A156-4BA53372BA19') AND NOT EXISTS(select * from vc3etl.loadColumn where id = 'F2E1016C-8CF4-488D-B4CA-1C272DCAFB4A')
BEGIN
	INSERT INTO vc3etl.LoadColumn VALUES ( 'F2E1016C-8CF4-488D-B4CA-1C272DCAFB4A','B5ABE7D3-5FE6-4F1A-A601-81EAE28A3F89','GTA','x_GiftedAcademically','C',0,NULL,0)
END

--add the GTR column, IF they have it with SASI, but NOT with PS yet
IF EXISTS(select * from vc3etl.LoadColumn where id = '3BF37A43-3A3D-45C5-9BCE-6A35183DC256') AND NOT EXISTS(select * from vc3etl.loadColumn where id ='A497555E-6B7C-42C7-B510-3A70D3B0F2A7')
BEGIN
	INSERT INTO vc3etl.LoadColumn VALUES ( 'A497555E-6B7C-42C7-B510-3A70D3B0F2A7','B5ABE7D3-5FE6-4F1A-A601-81EAE28A3F89','GTR','x_GiftedArtistically','C',0,NULL,0)
END
GO

IF EXISTS(select * from vc3etl.extracttable where id = '503A5F19-3296-4320-AC91-21EE02DA1BE7') AND NOT EXISTS(select * from vc3etl.pearsonextracttable where id ='503A5F19-3296-4320-AC91-21EE02DA1BE7')
BEGIN
	INSERT INTO vc3etl.pearsonextracttable VALUES('503A5F19-3296-4320-AC91-21EE02DA1BE7', 0, null)
END
GO