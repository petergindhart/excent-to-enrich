if not exists(select * from sysobjects t join syscolumns c on c.id=t.id where t.name='STUDENTS_LOCAL' and c.name='Enroll_Status')
begin
	ALTER TABLE PWRSCH.STUDENTS_LOCAL ADD
		Enroll_Status bit NOT NULL CONSTRAINT DF_STUDENTS_LOCAL_Enroll_Status DEFAULT 0
end
GO

sp_refreshview [PWRSCH.Students]