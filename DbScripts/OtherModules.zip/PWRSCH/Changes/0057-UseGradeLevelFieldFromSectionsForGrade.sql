UPDATE vc3etl.ExtractTable
SET Columns='round(dcid,0) as dcid, round(ID,0) as ID, round(Schoolid,0) as Schoolid, Course_Number, grade_level, section_Number, round(Teacher,0) as Teacher,TermID'
WHERE ID= 'BCDFD5BA-81ED-4414-8995-906D1C38611C'
GO

ALTER TABLE PWRSCH.Sections_Local ADD
	grade_level int
GO

sp_refreshview [PWRSCH.Sections]
