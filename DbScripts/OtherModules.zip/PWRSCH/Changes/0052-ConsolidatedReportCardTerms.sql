UPDATE vc3etl.LoadTable
SET KeyField = 'ReportCardTypeID, StoreCode'
WHERE ID = '13CDAB97-2E93-4BAA-B758-71865B0A5BE4'
GO

ALTER TABLE PWRSCH.Map_ReportCardItemID DROP COLUMN TermID
GO

--If PowerSchool is Active, then purge with this method
IF EXISTS( select * FROM VC3ETL.ExtractDatabase where ID = '48F3EB0A-1139-43D5-BDDF-C66DD51642EB' and Enabled = 1 )
BEGIN
		--Run this statement 4 times, to catch records that have 2, then 3, then 4, and maybe 5 versions of the same ReportCardItem records with different termID's (it happens, especially for F1 grades)
		UPDATE ReportCardScore
		SET ReportCardItem = MinID
		FROM
		(
			select
				min( cast(rci.ID as varchar(36))) AS MinID,
				max( cast(rci.ID as varchar(36))) AS MaxID
			from
				ReportCardScore rcs join
				ReportCardItem rci on rci.ID = rcs.ReportCardItem join
				ReportCardType rct on rci.ReportCardType = rct.ID
			where
				rct.Name like '%2009%'	AND rct.Name  like  '%2010%'		
			GROUP BY
				rct.Name,
				shortName
			having
				min( cast(rci.ID as varchar(36))) <> max( cast(rci.ID as varchar(36)))
		) T
		WHERE
			ReportCardItem = MaxID


		UPDATE ReportCardScore
		SET ReportCardItem = MinID
		FROM
		(
			select
				min( cast(rci.ID as varchar(36))) AS MinID,
				max( cast(rci.ID as varchar(36))) AS MaxID
			from
				ReportCardScore rcs join
				ReportCardItem rci on rci.ID = rcs.ReportCardItem join
				ReportCardType rct on rci.ReportCardType = rct.ID
			where
				rct.Name like '%2010%'		
			GROUP BY
				rct.Name,
				shortName
			having
				min( cast(rci.ID as varchar(36))) <> max( cast(rci.ID as varchar(36)))
		) T
		WHERE
			ReportCardItem = MaxID
			
			
				
		UPDATE ReportCardScore
		SET ReportCardItem = MinID
		FROM
		(
			select
				min( cast(rci.ID as varchar(36))) AS MinID,
				max( cast(rci.ID as varchar(36))) AS MaxID
			from
				ReportCardScore rcs join
				ReportCardItem rci on rci.ID = rcs.ReportCardItem join
				ReportCardType rct on rci.ReportCardType = rct.ID
			where
				rct.Name like '%2010%'		
			GROUP BY
				rct.Name,
				shortName
			having
				min( cast(rci.ID as varchar(36))) <> max( cast(rci.ID as varchar(36)))
		) T
		WHERE
			ReportCardItem = MaxID
			
				
		UPDATE ReportCardScore
		SET ReportCardItem = MinID
		FROM
		(
			select
				min( cast(rci.ID as varchar(36))) AS MinID,
				max( cast(rci.ID as varchar(36))) AS MaxID
			from
				ReportCardScore rcs join
				ReportCardItem rci on rci.ID = rcs.ReportCardItem join
				ReportCardType rct on rci.ReportCardType = rct.ID
			where
				rct.Name like '%2010%'		
			GROUP BY
				rct.Name,
				shortName
			having
				min( cast(rci.ID as varchar(36))) <> max( cast(rci.ID as varchar(36)))
		) T
		WHERE
			ReportCardItem = MaxID
END

--purge the old RCS records	
delete rci
FROM
	ReportCardItem rci left join
	ReportCardScore rcs on rci.ID = rcs.ReportCardITem
where 
	rcs.ReportCardITem is null