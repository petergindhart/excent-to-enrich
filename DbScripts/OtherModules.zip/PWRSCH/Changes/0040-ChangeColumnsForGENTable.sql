UPDATE VC3ETL.ExtractTable
SET Columns= 'round(dcid,0) as dcid,round(ID,0) as ID,cast(Cat as varchar(25)) as Cat,cast(name as varchar(25)) as name,cast(SUBSTR(valuet,0,4000) as varchar(4000)) as valuet,cast(Value as varchar(100)) as value'
where ID = 'E13A6CDD-D1E9-4DCB-985F-B8CD5950D649'