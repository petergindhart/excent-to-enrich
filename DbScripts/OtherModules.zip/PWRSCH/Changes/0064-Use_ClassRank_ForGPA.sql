CREATE TABLE [PWRSCH].[ClassRank_Local](
	[DCID] [nvarchar](384) NULL,
	[ID] [nvarchar](384) NULL,
	[STUDENTID] [nvarchar](384) NULL,
	[YEARID] [numeric](10, 0) NULL,
	[GRADE_LEVEL] [numeric](10, 0) NULL,
	[SCHOOLID] [numeric](10, 0) NULL,
	[STORECODE] [varchar](10) NULL,
	[GPAMETHOD] [varchar](50) NULL,
	[GPA] [varchar](80) NULL,
	[RANK] [numeric](10, 0) NULL,
	[OUTOF] [numeric](10, 0) NULL,
	[DATERANKED] [datetime] NULL
) ON [PRIMARY]
GO

CREATE VIEW PWRSCH.ClassRank
AS
SELECT * FROM PWRSCH.ClassRank_Local
GO

INSERT INTO vc3etl.ExtractTable VALUES ( 'CC571B34-CBBA-4FC6-A03E-0DA2D9DF44EF', '48F3EB0A-1139-43D5-BDDF-C66DD51642EB','PS.CLASSRANK','PWRSCH',
	'ClassRank','DCID', NULL,0,0,NULL,
	1,1,'round(dcid,0) as dcid, round(ID,0) as ID, round(StudentID,0) as StudentID, yearID, Grade_Level, SchoolID, storeCode,GPAMethod,  GPA, Rank, OutOf, DateRanked'
	)

INSERT INTO VC3ETL.PearsonExtractTable VALUES ( 'CC571B34-CBBA-4FC6-A03E-0DA2D9DF44EF', 0, NULL)

UPDATE VC3ETL.LoadColumn
SET SourceColumn='ClassRankGPA'
WHERE ID ='512B93DE-779D-41E8-8BA8-D4936614A760'
