UPDATE cr
SET
	MinGradeID = gl.ID,
	MaxGradeID = gl.ID,
    GradeBitMask = (select Bitmask from GradeRangeBitMask gbm where gbm.MinGradeID = gl.ID AND gbm.MaxGradeID = gl.ID)
FROM
	ClassRoster cr join
	PWRSCH.Map_SectionIDClassRosterID sicri on sicri.DestID = cr.ID join
	pwrsch.Sections s on sicri.SectionID = s.ID join
	GradeLevel gl on gl.Name = 
case 
				when Len(s.grade_level) = 1
				   then '0' + cast(s.grade_level as char(1)) 				   
                when  s.grade_level = -1 
                   then 'PK'
				else cast(s.grade_level as char(10)) 				
            end
where
	cr.RosterYearID = '334840F6-125D-41AD-AB64-0A029298D1F5'