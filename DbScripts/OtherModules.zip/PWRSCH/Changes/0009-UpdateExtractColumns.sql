UPDATE vc3etl.ExtractTable
SET Columns = 'select round(dcid,0) as dcid, round(ID,0) as ID, round(Schoolid,0) as Schoolid, round(grade_level,0) as grade_level, round(student_number,0) as student_number , First_Name, middle_name, Last_Name, street, City, state, zip, gender, ethnicity, ssn,  DOB, home_phone, cumulative_gpa, PHOTOFLAG From ps.students'
where id = 'ED01A269-20C1-43D5-B2BB-31C883F11EAC'

--Update where the columns are not alreay changed (some where changed out of band, because of testing)
UPDATE vc3etl.ExtractTable
SET SourceTable = 'PS.' + SourceTable
where 
	ExtractDatabase='48F3EB0A-1139-43D5-BDDF-C66DD51642EB' AND
	substring(SourceTable,1,3) <> 'PS.'
