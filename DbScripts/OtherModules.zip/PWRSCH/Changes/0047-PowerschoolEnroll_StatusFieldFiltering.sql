update vc3etl.ExtractTable
set [columns] = 'cast(DCID as int) AS DCID, cast(ID as int) AS ID, round(Schoolid,0) as Schoolid, round(grade_level,0) as grade_level, student_number, First_Name, middle_name, Last_Name, street, City, state, zip, gender, ethnicity, ssn, DOB, home_phone, cumulative_gpa, PHOTOFLAG, LunchStatus, State_StudentNumber, ExitCode, next_school,enroll_status', 
[filter]= IsNull ('(' + Filter + ') AND', '') + ' (enroll_status=0 or enroll_status = -1)'
where ID = 'ED01A269-20C1-43D5-B2BB-31C883F11EAC'
