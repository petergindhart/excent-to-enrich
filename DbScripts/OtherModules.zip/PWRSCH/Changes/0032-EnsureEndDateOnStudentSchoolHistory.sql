UPDATE vc3etl.LoadColumn
SET DeletedValue ='@ImportDefaultEndDate'
WHERE ID ='9011F91E-275E-41B4-80E2-C0D3EAB03BC8'

UPDATE StudentSchoolHistory
SET EndDate = OldEndDate
FROM
	(
		select
			StudentID,
			MAX(StartDate) AS CurrentEnrollmentDate,
		   (MAX(StartDate) - 1) AS OldEndDate,
			MIN(StartDate) AS MatchingStartDate
		From
			StudentSchoolHistory
		where
			EndDate is null
		group by
			StudentID
		having
			count(*) = 2
	) nd join
StudentSchoolHistory hist on nd.StudentID = hist.StudentID and StartDate = MatchingStartDate