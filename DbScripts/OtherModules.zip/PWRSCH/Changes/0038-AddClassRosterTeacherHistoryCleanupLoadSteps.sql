
DECLARE @crthSequence int

select @crthSequence = sequence from vc3etl.LoadTable where DestTable= 'ClassRosterTeacherHistory'
and ExtractDatabase= '48F3EB0A-1139-43D5-BDDF-C66DD51642EB'

UPDATE VC3ETL.LoadTable
SET Sequence = Sequence + 1
WHERE 
	ExtractDatabase='48F3EB0A-1139-43D5-BDDF-C66DD51642EB' AND
	Sequence >= @crthSequence
	
INSERT INTO VC3ETL.LoadTable VALUES ('8DBCAA2D-FF0A-46C6-AF8C-3879FF52C4E4','48F3EB0A-1139-43D5-BDDF-C66DD51642EB', @crthSequence, '[PWRSCH].[CleanupClassRosterTeacherHistory] @ImportDefaultStartDate, @ImportRosterYear','',0,NULL,NULL,NULL,4,0,0,0,1,NULL,NULL,NULL,0,0,NULL)