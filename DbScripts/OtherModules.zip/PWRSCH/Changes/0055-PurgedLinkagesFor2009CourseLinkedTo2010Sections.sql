-- Disable the first cleanup...as its "automatic disable" at the end of its run, doesn't seem to be getting committed
UPDATE  vc3etl.LoadTable Set Enabled = 0 WHERE ID = '478EB309-BA9A-435B-B430-A7FC7DCBCF42'

DELETE mscr
From		
	ClassRoster cr join
	PWRSCH.Map_SectionIDClassRosterID mscr on mscr.DestID = cr.ID join
	Pwrsch.Sections scs on scs.ID = mscr.SectionID
where
	cr.RosterYearID= '334840F6-125D-41AD-AB64-0A029298D1F5' and --2010
	scs.TermID >= 2000 --terms from in/after 2010
	
--purge 2010 courses that have an end date before the startdate, in all likelihood these are records that were closed prematurely, in either case
--the import won't import inverted dates, so it had to be created by our system
DELETE hist
From 
	StudentClassRosterHistory hist join
	CLassRoster cr on hist.ClassRosterID = cr.ID
where 
	cr.RosterYearID = '6F33C8AC-A7AD-457D-82CF-43F7A4164FE8' AND
	EndDate < StartDate

--purge any orphaned courses that were linked to invalid student enrollments	
delete cr
From
	ClassRoster cr left join
	StudentClassRosterHistory hist on hist.ClassRosterID = cr.ID
where
	RosterYearID = '6F33C8AC-A7AD-457D-82CF-43F7A4164FE8' AND
	hist.ClassRosterID is null
	

--update 2009-2010 classes that had ranges
UPDATE crUpdate
SET 
                MinGradeID = IsNull(crNew.MinGradeID,crUpdate.MinGradeID),
                MaxGradeID = IsNull(crNew.MaxGradeID, crUpdate.MaxGradeID),
                GradeBitMask = IsNUll(crUpdate.GradeBitMask, (select Bitmask from GradeRangeBitMask gbm where gbm.MinGradeID = IsNull(crNew.MinGradeID,crUpdate.MinGradeID) AND gbm.MaxGradeID = IsNull(crNew.MaxGradeID, crUpdate.MaxGradeID)))
FROM
ClassRoster crUpdate join
(
                select
                                cr.ID,
                                MinGradeID = (select top 1 ID from GradeLevel where bitMask =             MIN(gl.bitmask)),
                                MaxGradeID = (select top 1 ID from GradeLevel where bitMask =            MAX(gl.bitmask))

                FROM   
                                ClassRoster cr join
                                StudentClassRosterHistory hist on hist.ClassRosterID = cr.ID join
                                StudentGradeLevelHistory stuHist on hist.StudentID = stuHist.StudentID join
                                GradeLevel gl on stuHist.GradeLevelID = gl.ID
                WHERE
                                cr.RosterYearID='334840F6-125D-41AD-AB64-0A029298D1F5' AND
                                dbo.DateRangesOverlap(hist.StartDate, hist.EndDate, stuHist.StartDate, stuHist.EndDate, null) =1
                group by
                                cr.ID
) crNew on crUpdate.ID = crNew.ID
