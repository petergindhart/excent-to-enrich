--update default roster year for Pwrsch to 2010 for non-migrated PWRSCH imports
UPDATE ped
SET LastExtractRosterYear ='6F33C8AC-A7AD-457D-82CF-43F7A4164FE8', LastLoadRosterYear = '6F33C8AC-A7AD-457D-82CF-43F7A4164FE8'
FROM
	vc3etl.ExtractDatabase ed join
	VC3ETL.PearsonExtractDatabase ped on ed.ID = ped.ID
WHERE
	ped.ID = '48F3EB0A-1139-43D5-BDDF-C66DD51642EB' AND
	ed.Enabled = 0