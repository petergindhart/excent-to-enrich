UPDATE vc3etl.ExtractDatabase
SEt IsLinkedServerManaged = 1
WHERE ID = '48F3EB0A-1139-43D5-BDDF-C66DD51642EB' AND LinkedServer is null