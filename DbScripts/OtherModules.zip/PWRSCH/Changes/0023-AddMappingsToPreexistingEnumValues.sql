UPDATE vc3etl.LoadTable
SET DeleteTrans=0
WHERE id= 'AEC9C031-D211-4041-954A-FDA91A1F81B3'

DECLARE @maleID uniqueidentifier
DECLARE @femaleID uniqueidentifier

SELECT @maleID = ID from EnumValue WHERE Code ='M' and Type='D6194389-17AC-494C-9C37-FD911DA2DD4B'
SELECT @femaleID = ID from EnumValue WHERE Code ='F' and Type='D6194389-17AC-494C-9C37-FD911DA2DD4B'

IF NOT EXISTS (select * FROm PWRSCH.Map_EnumValueID where Cat = 'GEN' and COde in ('M','F'))
BEGIN
	
	IF @maleID IS NOT NULL	
		INSERT INTO PWRSCH.Map_EnumValueID VALUES ('GEN', 'M', @maleID)
	
	IF @femaleID IS NOT NULL
		INSERT INTO PWRSCH.Map_EnumValueID VALUES ('GEN', 'F', @femaleID)
END