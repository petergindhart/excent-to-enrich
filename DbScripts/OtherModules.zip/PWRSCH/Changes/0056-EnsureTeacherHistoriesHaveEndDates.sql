-- Add an end date to class roster teacher records, based on the latest end date of an enrolled student in class
UPDATE hist
SET EndDate	= IsNull(hist.EndDate, (select MAX(EndDate) from StudentClassRosterHistory sHist where sHist.ClassRosterID = hist.ClassRosterID))
From 
	ClassRoster cr join
	ClassRosterTeacherHistory hist on hist.ClassRosterID = cr.ID
where
	hist.EndDate is null AND
	RosterYearID ='334840F6-125D-41AD-AB64-0A029298D1F5'
		

UPDATE VC3ETL.LoadTable
SET DeleteKey ='DestID'
WHERE ID = 'D548C5CC-55D9-4457-9EAD-12CEF86E9827'

UPDATE VC3ETL.LoadColumn
SET DeletedValue='@ImportDefaultEndDate'
WHERE ID = '6716DEB2-CBC9-4DFC-9F15-14F3DAFB2A99'

--remove class/teacher
DELETE hist
FROM
	ClassRosterTeacherHistory hist join
	ClassRoster cr on hist.ClassRosterID = cr.ID join
	PWRSCH.Map_SectionIDClassRosterID sicri on sicri.DestId = cr.ID join
	pwrsch.Map_Teacher_ID mt on mt.DestID = hist.TeacherID join
	PWRSCH.SECTIONS s on sicri.SectionID = s.ID
where 
	s.TEACHER <> mt.TeacherID 
	
--resync class/teacher relationship
exec vc3etl.LoadTable_run 'FEFCFB34-4E07-422E-B3C5-6CAA01DB293A','',1,1