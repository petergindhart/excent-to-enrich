--This is the point where imports fail after rollover typically
UPDATE VC3ETL.LoadTable 
SET StartNewTransaction = 1
WHERE ID ='E255A926-682F-49A3-890A-C12394069BB6'
	
UPDATE VC3ETL.LoadTable
SET Sequence = Sequence + 2
WHERE 
	ExtractDatabase='48F3EB0A-1139-43D5-BDDF-C66DD51642EB' AND
	Sequence >= 15
	
INSERT INTO VC3ETL.LoadTable VALUES ('C526F8DE-D1AE-43F4-811F-ABA3737EFBAC','48F3EB0A-1139-43D5-BDDF-C66DD51642EB', 15, '[PWRSCH].[CleanupStudentGradeLevelHistory] @ImportDefaultStartDate','',0,NULL,NULL,NULL,4,0,0,0,1,NULL,NULL,NULL,0,0,NULL)


UPDATE VC3ETL.LoadTable
SET Sequence = Sequence + 2
WHERE 
	ExtractDatabase='48F3EB0A-1139-43D5-BDDF-C66DD51642EB' AND
	Sequence >= 18

INSERT INTO VC3ETL.LoadTable VALUES ('38AF1237-E51A-4326-909A-00B59796B668','48F3EB0A-1139-43D5-BDDF-C66DD51642EB', 18, '[PWRSCH].[CleanupStudentSchoolHistory] @ImportDefaultStartDate','',0,NULL,NULL,NULL,4,0,0,0,1,NULL,NULL,NULL,0,0,NULL)