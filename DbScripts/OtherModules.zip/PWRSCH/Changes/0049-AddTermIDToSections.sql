UPDATE VC3ETL.ExtractTable
SET Columns= 'round(dcid,0) as dcid, round(ID,0) as ID, round(Schoolid,0) as Schoolid, Course_Number, section_Number, round(Teacher,0) as Teacher,TermID'
where SourceTable like '%ps.sections%'
GO

IF NOT EXISTS(select * From INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME ='sections' AND COLUMN_NAME ='termID')
BEGIN
	ALTER TABLE PWRSCH.SECTIONS_LOCAL ADD 
		TermID int
END
GO

sp_refreshview [PWRSCH.SECTIONS]