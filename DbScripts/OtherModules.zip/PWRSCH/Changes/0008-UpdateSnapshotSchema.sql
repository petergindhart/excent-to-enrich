/****** Object:  Table [PWRSCH].[ATTENDANCE_CODE_local]    Script Date: 07/07/2009 15:53:15 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[ATTENDANCE_CODE_local]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [PWRSCH].[ATTENDANCE_CODE_local]
GO
/****** Object:  Table [PWRSCH].[attendance_local]    Script Date: 07/07/2009 15:53:15 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[attendance_local]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [PWRSCH].[attendance_local]
GO
/****** Object:  Table [PWRSCH].[CALENDAR_DAY_LOCAL]    Script Date: 07/07/2009 15:53:15 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[CALENDAR_DAY_LOCAL]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [PWRSCH].[CALENDAR_DAY_LOCAL]
GO
/****** Object:  Table [PWRSCH].[CC_LOCAL]    Script Date: 07/07/2009 15:53:15 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[CC_LOCAL]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [PWRSCH].[CC_LOCAL]
GO
/****** Object:  Table [PWRSCH].[COURSES_LOCAL]    Script Date: 07/07/2009 15:53:15 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[COURSES_LOCAL]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [PWRSCH].[COURSES_LOCAL]
GO
/****** Object:  Table [PWRSCH].[DAILYATTENDANCE_LOCAL]    Script Date: 07/07/2009 15:53:15 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[DAILYATTENDANCE_LOCAL]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [PWRSCH].[DAILYATTENDANCE_LOCAL]
GO
/****** Object:  Table [PWRSCH].[DEMOGRAPHIC_LOCAL]    Script Date: 07/07/2009 15:53:15 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[DEMOGRAPHIC_LOCAL]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [PWRSCH].[DEMOGRAPHIC_LOCAL]
GO
/****** Object:  Table [PWRSCH].[ETHNICITY_LOCAL]    Script Date: 07/07/2009 15:53:15 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[ETHNICITY_LOCAL]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [PWRSCH].[ETHNICITY_LOCAL]
GO
/****** Object:  Table [PWRSCH].[GEN_LOCAL]    Script Date: 07/07/2009 15:53:15 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[GEN_LOCAL]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [PWRSCH].[GEN_LOCAL]
GO
/****** Object:  Table [PWRSCH].[GRADESCALEITEM_LOCAL]    Script Date: 07/07/2009 15:53:15 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[GRADESCALEITEM_LOCAL]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [PWRSCH].[GRADESCALEITEM_LOCAL]
GO
/****** Object:  Table [PWRSCH].[LOG_LOCAL]    Script Date: 07/07/2009 15:53:15 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[LOG_LOCAL]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [PWRSCH].[LOG_LOCAL]
GO
/****** Object:  Table [PWRSCH].[PGFINALGRADES_LOCAL]    Script Date: 07/07/2009 15:53:15 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[PGFINALGRADES_LOCAL]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [PWRSCH].[PGFINALGRADES_LOCAL]
GO
/****** Object:  Table [PWRSCH].[PGFINALGRADESSETUP_LOCAL]    Script Date: 07/07/2009 15:53:15 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[PGFINALGRADESSETUP_LOCAL]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [PWRSCH].[PGFINALGRADESSETUP_LOCAL]
GO
/****** Object:  Table [PWRSCH].[SCHOOL_COURSE_LOCAL]    Script Date: 07/07/2009 15:53:15 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[SCHOOL_COURSE_LOCAL]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [PWRSCH].[SCHOOL_COURSE_LOCAL]
GO
/****** Object:  Table [PWRSCH].[SCHOOLS_LOCAL]    Script Date: 07/07/2009 15:53:15 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[SCHOOLS_LOCAL]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [PWRSCH].[SCHOOLS_LOCAL]
GO
/****** Object:  Table [PWRSCH].[SECTIONS_LOCAL]    Script Date: 07/07/2009 15:53:15 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[SECTIONS_LOCAL]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [PWRSCH].[SECTIONS_LOCAL]
GO
/****** Object:  Table [PWRSCH].[STOREDGRADES_LOCAL]    Script Date: 07/07/2009 15:53:15 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[STOREDGRADES_LOCAL]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [PWRSCH].[STOREDGRADES_LOCAL]
GO
/****** Object:  Table [PWRSCH].[StudentPhoto]    Script Date: 07/07/2009 15:53:15 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[StudentPhoto]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [PWRSCH].[StudentPhoto]
GO
/****** Object:  Table [PWRSCH].[STUDENTS_LOCAL]    Script Date: 07/07/2009 15:53:15 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[STUDENTS_LOCAL]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [PWRSCH].[STUDENTS_LOCAL]
GO
/****** Object:  Table [PWRSCH].[teachers_local]    Script Date: 07/07/2009 15:53:15 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[teachers_local]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [PWRSCH].[teachers_local]
GO
/****** Object:  Table [PWRSCH].[terms_local]    Script Date: 07/07/2009 15:53:15 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[terms_local]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [PWRSCH].[terms_local]
GO
/****** Object:  Table [PWRSCH].[ATTENDANCE_CODE_local]    Script Date: 07/07/2009 15:53:49 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [PWRSCH].[attendance_code_local](
	[DCID] [nvarchar](384) NULL,
	[ID] [nvarchar](384) NULL,
	[ATT_CODE] [varchar](10) NULL,
	[SCHOOLID] [numeric](10, 0) NULL,
	[PRESENCE_STATUS_CD] [varchar](10) NULL,
	[DESCRIPTION] [varchar](50) NULL,
	[YEARID] [numeric](10, 0) NULL
) ON [PRIMARY]

GO
/****** Object:  Table [PWRSCH].[attendance_local]    Script Date: 07/07/2009 15:53:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [PWRSCH].[attendance_local](
	[DCID] [nvarchar](384) NULL,
	[ID] [nvarchar](384) NULL,
	[SCHOOLID] [nvarchar](384) NULL,
	[STUDENTID] [numeric](10, 0) NULL,
	[YEARID] [nvarchar](384) NULL,
	[ATTENDANCE_CODEID] [nvarchar](384) NULL,
	[CALENDAR_DAYID] [nvarchar](384) NULL
) ON [PRIMARY]

GO
/****** Object:  Table [PWRSCH].[CALENDAR_DAY_LOCAL]    Script Date: 07/07/2009 15:53:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [PWRSCH].[CALENDAR_DAY_LOCAL](
	[DCID] [numeric](18, 0) NOT NULL,
	[ID] [numeric](10, 0) NULL,
	[SCHOOLID] [numeric](10, 0) NULL,
	[DATE_VALUE] [datetime] NULL,
	[SCHEDULEID] [varchar](20) NULL,
	[A] [numeric](10, 0) NULL,
	[B] [numeric](10, 0) NULL,
	[C] [numeric](10, 0) NULL,
	[D] [numeric](10, 0) NULL,
	[E] [numeric](10, 0) NULL,
	[F] [numeric](10, 0) NULL,
	[INSESSION] [numeric](10, 0) NULL,
	[MEMBERSHIPVALUE] [float] NULL,
	[NOTE] [varchar](50) NULL,
	[TYPE] [varchar](20) NULL,
	[CYCLE_DAY_ID] [numeric](10, 0) NULL,
	[BELL_SCHEDULE_ID] [numeric](10, 0) NULL,
	[WEEK_NUM] [numeric](10, 0) NULL,
 CONSTRAINT [PK_CALENDAR_DAY_NEW_863950232] PRIMARY KEY CLUSTERED 
(
	[DCID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [PWRSCH].[cc_local](
	[DCID] [numeric](38, 0) NULL,
	[ID] [numeric](38, 0) NULL,
	[STUDENTID] [numeric](38, 0) NULL,
	[SECTIONID] [numeric](38, 0) NULL,
	[COURSE_NUMBER] [varchar](11) NULL,
	[SECTION_NUMBER] [varchar](10) NULL,
	[DATEENROLLED] [datetime] NULL,
	[DATELEFT] [datetime] NULL
) ON [PRIMARY]


GO
/****** Object:  Table [PWRSCH].[COURSES_LOCAL]    Script Date: 07/07/2009 15:53:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [PWRSCH].[COURSES_LOCAL](
	[DCID] [nvarchar](384) NOT NULL,
	[ID] [nvarchar](384) NULL,
	[SCHOOLID] [nvarchar](384) NULL,
	[COURSE_NUMBER] [varchar](11) NULL,
	[COURSE_NAME] [varchar](40) NULL,
 CONSTRAINT [PK_COURSES_NEW_587621533] PRIMARY KEY CLUSTERED 
(
	[DCID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [PWRSCH].[DAILYATTENDANCE_LOCAL]    Script Date: 07/07/2009 15:53:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [PWRSCH].[DAILYATTENDANCE_LOCAL](
	[DCID] [numeric](10, 0) NOT NULL,
	[ID] [numeric](10, 0) NULL,
	[ATTENDANCE_DATE] [datetime] NULL,
	[TIME_IN] [numeric](10, 0) NULL,
	[TIME_OUT] [numeric](10, 0) NULL,
	[TIME_RETURNED] [numeric](10, 0) NULL,
	[ATTENDANCE_CODE] [varchar](2) NULL,
	[COMMENT_VALUE] [text] NULL,
	[ATTENDANCE_MINUTES] [numeric](10, 0) NULL,
	[STUDENTID] [numeric](10, 0) NULL,
	[SCHOOLID] [numeric](10, 0) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [PWRSCH].[DEMOGRAPHIC_LOCAL]    Script Date: 07/07/2009 15:53:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [PWRSCH].[DEMOGRAPHIC_LOCAL](
	[DCID] [numeric](18, 0) NOT NULL,
	[ID] [numeric](10, 0) NULL,
	[STUDENTID] [numeric](10, 0) NULL,
	[BIRTH_DT] [datetime] NULL,
	[BIRTH_CERTIFICATE_NUM] [varchar](40) NULL,
	[BIRTH_CITY] [varchar](80) NULL,
	[BIRTH_STATE_CD] [varchar](10) NULL,
	[BIRTH_COUNTRY_CD] [varchar](10) NULL,
	[BIRTH_CERT_VERIFY_DT] [datetime] NULL,
	[CITIZENSHIP_CD] [varchar](10) NULL,
	[PRIMARY_LANG_CD] [varchar](10) NULL,
	[HOME_LANG_CD] [varchar](10) NULL,
	[GIFTED_YN] [numeric](10, 0) NULL,
	[HOMELESS_YN] [numeric](10, 0) NULL,
	[HOME_SCHOOLED_YN] [numeric](10, 0) NULL,
	[MIGRANT_YN] [numeric](10, 0) NULL,
	[SINGLE_PARENT_YN] [numeric](10, 0) NULL,
	[TRANSIENT_YN] [numeric](10, 0) NULL,
	[WARD_OF_STATE_YN] [numeric](10, 0) NULL,
	[IMMIGRANT_YN] [numeric](10, 0) NULL,
	[LIM_ENG_PROF] [numeric](10, 0) NULL,
	[ECONOM_DISADVANTAGED] [numeric](10, 0) NULL,
 CONSTRAINT [PK_DEMOGRAPHIC_NEW_1001971256] PRIMARY KEY CLUSTERED 
(
	[DCID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [PWRSCH].[ETHNICITY_LOCAL]    Script Date: 07/07/2009 15:53:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [PWRSCH].[ETHNICITY_LOCAL](
	[DCID] [numeric](18, 0) NOT NULL,
	[ID] [numeric](10, 0) NULL,
	[STUDENTID] [numeric](10, 0) NULL,
	[ETHNICITY_CD] [varchar](10) NULL,
	[PROPORTION] [float] NULL,
	[UNUSED] [numeric](10, 0) NULL,
	[UNUSED2] [varchar](40) NULL,
	[UNUSED3] [varchar](10) NULL,
	[UNUSED4] [numeric](10, 0) NULL,
 CONSTRAINT [PK_ETHNICITY_NEW_856572648] PRIMARY KEY CLUSTERED 
(
	[DCID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [PWRSCH].[GEN_LOCAL]    Script Date: 07/07/2009 15:53:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [PWRSCH].[GEN_LOCAL](
	[DCID] [nvarchar](384) NOT NULL,
	[ID] [nvarchar](384) NULL,
	[CAT] [varchar](15) NULL,
	[NAME] [varchar](50) NULL,
	[VALUET] [varchar](4000) NULL,
	[VALUE] [varchar](40) NULL,
 CONSTRAINT [PK_GEN_NEW_2109521096] PRIMARY KEY CLUSTERED 
(
	[DCID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [PWRSCH].[GRADESCALEITEM_LOCAL]    Script Date: 07/07/2009 15:53:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [PWRSCH].[GRADESCALEITEM_LOCAL](
	[DCID] [numeric](10, 0) NOT NULL,
	[ID] [numeric](10, 0) NULL,
	[GRADESCALEID] [numeric](10, 0) NULL,
	[NAME] [varchar](50) NULL,
	[DESCRIPTION] [text] NULL,
	[COUNTSINGPA] [numeric](10, 0) NULL,
	[GRADUATIONCREDIT] [numeric](10, 0) NULL,
	[TEACHERSCALE] [numeric](10, 0) NULL,
	[CUTOFFPERCENTAGE] [float] NULL,
	[POWERLINK] [varchar](40) NULL,
	[POWERLINKSPANISH] [varchar](40) NULL,
	[GRADE_POINTS] [float] NULL,
	[VALUE] [float] NULL,
	[ADDEDVALUE] [numeric](10, 0) NULL,
	[MODIFY_CODE] [numeric](10, 0) NULL,
	[EXCLUDEFROMAFG] [numeric](10, 0) NULL,
	[ALT_GRADE_POINTS] [float] NULL,
	[CUTOFFPOINTS] [float] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

CREATE TABLE [PWRSCH].[Log_local](
	[DCID] [nvarchar](384) NULL,
	[ID] [nvarchar](384) NULL,
	[STUDENTID] [nvarchar](384) NULL,
	[LOGTYPEID] [numeric](10, 0) NULL,
	[SCHOOLID] [nvarchar](384) NULL,
	[ENTRY] [varchar](4000) NULL,
	[ENTRY_DATE] [datetime] NULL,
	[DISCIPLINE_INCIDENTDATE] [datetime] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [PWRSCH].[PGFINALGRADES_LOCAL]    Script Date: 07/07/2009 15:53:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [PWRSCH].[PGFINALGRADES_LOCAL](
	[DCID] [numeric](10, 0) NOT NULL,
	[ID] [numeric](10, 0) NULL,
	[SECTIONID] [numeric](10, 0) NULL,
	[STUDENTID] [numeric](10, 0) NULL,
	[FINALGRADENAME] [varchar](8) NULL,
	[GRADE] [varchar](7) NULL,
	[CITIZENSHIP] [varchar](7) NULL,
	[PERCENT] [float] NULL,
	[POINTS] [float] NULL,
	[POINTSPOSSIBLE] [float] NULL,
	[STARTDATE] [datetime] NULL,
	[ENDDATE] [datetime] NULL,
	[COMMENT_VALUE] [text] NULL,
	[LASTGRADEUPDATE] [datetime] NULL,
	[VARCREDIT] [float] NULL,
	[OVERRIDEFG] [varchar](2) NULL,
	[GRADEBOOKTYPE] [numeric](10, 0) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [PWRSCH].[PGFINALGRADESSETUP_LOCAL]    Script Date: 07/07/2009 15:53:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [PWRSCH].[PGFINALGRADESSETUP_LOCAL](
	[DCID] [numeric](10, 0) NOT NULL,
	[ID] [numeric](10, 0) NULL,
	[ABBREVIATION] [varchar](7) NULL,
	[BEGINDATE] [datetime] NULL,
	[CHANGEGRADETO] [varchar](20) NULL,
	[CITIZENSHIPASMTNAME] [varchar](50) NULL,
	[CURRENTGRADE] [numeric](10, 0) NULL,
	[DISPLAYONSPREADSHEET] [numeric](10, 0) NULL,
	[DUEDATE] [datetime] NULL,
	[ENDDATE] [datetime] NULL,
	[EXCLUDEDMARKS] [varchar](40) NULL,
	[FACTORINFOS] [image] NULL,
	[FACTORNUMSCORESTODROP] [image] NULL,
	[FACTORTYPES] [image] NULL,
	[FACTORWEIGHTS] [image] NULL,
	[FROMSERVER] [numeric](10, 0) NULL,
	[NAME] [varchar](7) NULL,
	[NUMATTPOINTS] [float] NULL,
	[NUMFACTORS] [numeric](10, 0) NULL,
	[SECTIONID] [numeric](10, 0) NULL,
	[SERVERID] [numeric](10, 0) NULL,
	[SCHOOLID] [numeric](10, 0) NULL,
	[YEARID] [numeric](10, 0) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [PWRSCH].[SCHOOL_COURSE_LOCAL]    Script Date: 07/07/2009 15:53:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [PWRSCH].[SCHOOL_COURSE_LOCAL](
	[DCID] [numeric](18, 0) NOT NULL,
	[ID] [numeric](10, 0) NULL,
	[SCHOOLID] [numeric](10, 0) NULL,
	[COURSEID] [numeric](10, 0) NULL,
	[COURSE_NAME] [varchar](40) NULL,
	[YEARID] [numeric](10, 0) NULL,
	[CREATEDBY] [varchar](40) NULL,
	[CREATEDDT] [datetime] NULL,
	[MODIFIEDBY] [varchar](40) NULL,
	[MODIFIEDDT] [datetime] NULL,
	[ALT_COURSE_NUMBER] [varchar](40) NULL,
	[EXCLUDE_STATE_RPT_YN] [numeric](10, 0) NULL,
	[SCHOOLCRSEINFO_GUID] [varchar](32) NULL,
	[ATT_MODE_CODE] [varchar](20) NULL,
 CONSTRAINT [PK_SCHOOL_COURSE_NEW_301966857] PRIMARY KEY CLUSTERED 
(
	[DCID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [PWRSCH].[SCHOOLS_LOCAL]    Script Date: 07/07/2009 15:53:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [PWRSCH].[SCHOOLS_LOCAL](
	[DCID] [nvarchar](384) NOT NULL,
	[ID] [nvarchar](384) NULL,
	[ABBREVIATION] [varchar](20) NULL,
	[NAME] [varchar](60) NULL,
	[SCHOOL_NUMBER] [numeric](10, 0) NULL,
	[DISTRICT_NUMBER] [numeric](10, 0) NULL,
	[ALTERNATE_SCHOOL_NUMBER] [numeric](10, 0) NULL,
 CONSTRAINT [PK_SCHOOLS_NEW_1697455992] PRIMARY KEY CLUSTERED 
(
	[DCID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [PWRSCH].[SECTIONS_LOCAL]    Script Date: 07/07/2009 15:53:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [PWRSCH].[SECTIONS_LOCAL](
	[DCID] [nvarchar](384) NOT NULL,
	[ID] [nvarchar](384) NULL,
	[COURSE_NUMBER] [varchar](11) NULL,
	[SCHOOLID] [nvarchar](384) NULL,
	[SECTION_NUMBER] [nvarchar](384) NULL,
	[TEACHER] [nvarchar](384) NULL,
 CONSTRAINT [PK_SECTIONS_NEW_617597432] PRIMARY KEY CLUSTERED 
(
	[DCID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [PWRSCH].[STOREDGRADES_LOCAL]    Script Date: 07/07/2009 15:53:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [PWRSCH].[STOREDGRADES_LOCAL](
	[DCID] [nvarchar](384) NOT NULL,
	[SCHOOLID] [nvarchar](384) NULL,
	[STUDENTID] [nvarchar](384) NULL,
	[TERMID] [numeric](10, 0) NULL,
	[STORECODE] [varchar](10) NULL,
	[SECTIONID] [numeric](10, 0) NULL,
	[GRADE] [varchar](7) NULL,
	[PERCENT] [float] NULL,
	[COURSE_NAME] [varchar](40) NULL,
	[COURSE_NUMBER] [varchar](11) NULL,
	[TEACHER_NAME] [varchar](40) NULL,
	[EARNEDCRHRS] [float] NULL,
	[GRADE_LEVEL] [numeric](10, 0) NULL,
 CONSTRAINT [PK_STOREDGRADES_NEW_201012665] PRIMARY KEY CLUSTERED 
(
	[DCID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

/****** Object:  Table [PWRSCH].[STUDENTS_LOCAL]    Script Date: 07/07/2009 15:53:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [PWRSCH].[STUDENTS_LOCAL](
	[DCID] [nvarchar](384) NOT NULL,
	[ID] [nvarchar](384) NULL,
	[SCHOOLID] [nvarchar](384) NULL,
	[GRADE_LEVEL] [nvarchar](384) NULL,
	[STUDENT_NUMBER] [float] NULL,
	[FIRST_NAME] [varchar](15) NULL,
	[MIDDLE_NAME] [varchar](20) NULL,
	[LAST_NAME] [varchar](20) NULL,
	[STREET] [varchar](60) NULL,
	[CITY] [varchar](50) NULL,
	[STATE] [varchar](2) NULL,
	[ZIP] [varchar](10) NULL,
	[GENDER] [varchar](2) NULL,
	[ETHNICITY] [varchar](20) NULL,
	[SSN] [varchar](12) NULL,
	[DOB] [datetime] NULL,
	[HOME_PHONE] [varchar](30) NULL,
	[CUMULATIVE_GPA] [float] NULL,
	[PHOTOFLAG] [numeric](10, 0) NULL,
 CONSTRAINT [PK_STUDENTS_NEW_1563954631] PRIMARY KEY CLUSTERED 
(
	[DCID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [PWRSCH].[teachers_local]    Script Date: 07/07/2009 15:53:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [PWRSCH].[teachers_local](
	[DCID] [nvarchar](384) NULL,
	[ID] [nvarchar](384) NULL,
	[SCHOOLID] [nvarchar](384) NULL,
	[EMAIL_ADDR] [varchar](50) NULL,
	[SCHOOL_PHONE] [varchar](20) NULL,
	[STATE] [varchar](2) NULL,
	[SSN] [varchar](12) NULL,
	[ZIP] [varchar](10) NULL,
	[LAST_NAME] [varchar](20) NULL,
	[FIRST_NAME] [varchar](20) NULL,
	[STREET] [varchar](80) NULL,
	[CITY] [varchar](40) NULL,
	[ETHNICITY] [varchar](20) NULL,
	[SCHED_GENDER] [varchar](2) NULL,
	[TEACHERNUMBER] [varchar](20) NULL
) ON [PRIMARY]

GO

CREATE TABLE [PWRSCH].[terms_local](
	[DCID] [numeric](38, 0) NULL,
	[ID] [numeric](38, 0) NULL,
	[SCHOOLID] [numeric](38, 0) NULL,
	[FIRSTDAY] [datetime] NULL,
	[LASTDAY] [datetime] NULL,
	[YEARID] [numeric](38, 0) NULL,
	[ABBREVIATION] [varchar](6) NULL,
	[PORTION] [numeric](38, 0) NULL,
	[NOOFDAYS] [numeric](38, 0) NULL,
	[TERMSINYEAR] [numeric](38, 0) NULL,
	[STERMS] [numeric](38, 0) NULL,
	[ISYEARREC] [numeric](10, 0) NULL
) ON [PRIMARY]
GO

CREATE TABLE [PWRSCH].[StudentPhoto](
	[UniqueName] [varchar](50) NOT NULL,
	[ImageData] [image] NULL,
 CONSTRAINT [PK_StudentPhoto] PRIMARY KEY CLUSTERED 
(
	[UniqueName] ASC
) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

exec sp_refreshview [PWRSCH.TERMS]
exec sp_refreshview [PWRSCH.STUDENTS]
exec sp_refreshview [PWRSCH.LOG]
exec sp_refreshview [PWRSCH.DEMOGRAPHIC]
exec sp_refreshview [PWRSCH.CALENDAR_DAY]
exec sp_refreshview [PWRSCH.DAILYATTENDANCE]
exec sp_refreshview [PWRSCH.COURSES]
exec sp_refreshview [PWRSCH.CC]
exec sp_refreshview [PWRSCH.SCHOOL_COURSE]
exec sp_refreshview [PWRSCH.TEACHERS]
exec sp_refreshview [PWRSCH.ATTENDANCE]
exec sp_refreshview [PWRSCH.ETHNICITY]
exec sp_refreshview [PWRSCH.GRADESCALEITEM]
exec sp_refreshview [PWRSCH.SECTIONS]
exec sp_refreshview [PWRSCH.PGFINALGRADESSETUP]
exec sp_refreshview [PWRSCH.GEN]
exec sp_refreshview [PWRSCH.ATTENDANCE_CODE]
exec sp_refreshview [PWRSCH.SCHOOLS]
exec sp_refreshview [PWRSCH.PGFINALGRADES]
exec sp_refreshview [PWRSCH.STOREDGRADES]