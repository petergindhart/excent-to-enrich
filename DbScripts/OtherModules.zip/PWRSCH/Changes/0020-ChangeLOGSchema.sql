UPDATE VC3ETL.ExtractTable
SET Columns='round(dcid,0) as dcid, round(ID,0) as ID, round(StudentID,0) as StudentID, logTypeID, subType, round(Schoolid,0) as Schoolid, cast(entry as varchar(4000)) AS Entry, Entry_date, Discipline_incidentDate'
WHERE iD = 'F4397DB1-5BC5-4A07-999A-3D0710C92E86'


ALTER TABLE PWRSCH.LOG_LOCAL ADD
	subType int
GO

sp_Refreshview [PWRSCH.log]