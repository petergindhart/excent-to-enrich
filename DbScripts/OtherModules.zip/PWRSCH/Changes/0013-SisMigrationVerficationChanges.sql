--#assume dbo:928

UPDATE sismigrationtable
SET DestinationTablePK ='cat, code'
WHERE Id = 'CCE86FD4-762C-4681-9AD5-E3AF160E5EC7'

UPDATE sismigrationtable
SET MapTable='Student'
WHERE ID = 'BCBC6E74-F178-4D11-8DCE-389D392B9F70'

UPDATE sismigrationColumn
SET Name = 'Number'
WHERE id=  'A358BA55-4A23-4581-82E9-A1EBB5C44592'

UPDATE sismigrationTable
SET KeyField ='ID'
WHERE ID = 'BCBC6E74-F178-4D11-8DCE-389D392B9F70'

INSERT INTO VC3ETL.ExtractValidator VALUES ('B774E388-BA11-4DD3-AE57-ACA42A78A468','F33610D3-3E7A-48B7-AFDB-2FB16D9C39F8', '54421A8D-4D4A-45D6-8F0F-65F7619EA25C',1,NULL,NULL,'Status, StaffStatus, TeacherNumber')

UPDATE vc3taskscheduler.scheduledtaskschedule
SET Parameters='<?xml version="1.0" encoding="utf-16"?>  <ArrayOfDictionaryEntry xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">    <DictionaryEntry>      <Key xsi:type="xsd:string">DatabaseId</Key>      <Value xsi:type="xsd:string">48F3EB0A-1139-43D5-BDDF-C66DD51642EB*71F9CD65-3E75-41BC-94D7-537E4BC9C9B2</Value>    </DictionaryEntry>    <DictionaryEntry>      <Key xsi:type="xsd:string">CreateSnapshot</Key>      <Value xsi:type="xsd:boolean">true</Value>    </DictionaryEntry>  </ArrayOfDictionaryEntry>'
WHERE ID = '4C8E4007-64B5-482D-91E3-614A970D6BF7'

UPDATE vc3taskscheduler.scheduledtaskschedule
SET Parameters='<?xml version="1.0" encoding="utf-16"?>  <ArrayOfDictionaryEntry xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">    <DictionaryEntry>      <Key xsi:type="xsd:string">DatabaseId</Key>      <Value xsi:type="xsd:string">30CCF975-64D3-43EE-B567-CA5C2BEF1F46*FDBC2C27-7803-4831-A1DC-4B0B6F1117E0</Value>    </DictionaryEntry>    <DictionaryEntry>      <Key xsi:type="xsd:string">CreateSnapshot</Key>      <Value xsi:type="xsd:boolean">true</Value>    </DictionaryEntry>  </ArrayOfDictionaryEntry>'
WHERE ID = '4F0E41C9-928C-44D1-946D-DC9AF3C24029'
GO

ALTER TABLE PWRSCH.Map_SectionIDClassRosterID
	DROP CONSTRAINT PK_PWRSCH_Map_SectionIDClassRosterID
GO
ALTER TABLE PWRSCH.Map_SectionIDClassRosterID ADD CONSTRAINT
	PK_Map_SectionIDClassRosterID PRIMARY KEY CLUSTERED 
	(
	SectionID,
	RosterYearID
	)

GO

INSERT INTO vc3etl.ExtractTable VALUES ('76D75592-585A-416A-849A-07F25F6FCF3C', '48F3EB0A-1139-43D5-BDDF-C66DD51642EB', 'GUARDIANS','PWRSCH','GUARDIANS','DCID',NULL,0,0,NULL,1,0,'cast(round(dcid,0) as int) as dcid, cast(round(ID,0) as int) as ID, FIRST_NAME, LAST_NAME, cast(round(StudentID,0) as int) as StudentID')
INSERT INTO vc3etl.PearsonExtractTable VALUES ('76D75592-585A-416A-849A-07F25F6FCF3C',0, NULL)
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[GUARDIANS_LOCAL]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [PWRSCH].[GUARDIANS_LOCAL]
GO

CREATE TABLE [PWRSCH].[GUARDIANS_LOCAL](
	[DCID] [numeric](18, 0) NOT NULL,
	[ID] [numeric](10, 0) NULL,
	[STUDENTID] [numeric](10, 0) NULL,
	[FAMILYID] [numeric](10, 0) NULL,
	[FIRST_NAME] [varchar](15) NULL,
	[LAST_NAME] [varchar](20) NULL,
	[MIDDLE_NAME] [varchar](20) NULL,
	[CLASSIFICATION] [varchar](20) NULL,
	[RELATIONSHIP] [varchar](20) NULL,
	[DAY_PHONE] [varchar](30) NULL,
	[EVENING_PHONE] [varchar](30) NULL,
	[FAX] [varchar](30) NULL,
	[EMAIL] [varchar](80) NULL,
	[LASTFIRST] [varchar](35) NULL,
	[TIER] [varchar](20) NULL,
	[ROLEVALUE] [varchar](20) NULL,
	[STATUS] [numeric](10, 0) NULL,
	[ALLOWWEBACCESS] [numeric](10, 0) NULL,
	[WEB_ID] [varchar](20) NULL,
	[WEBPASSWORD] [varchar](20) NULL,
	[WEBEMAIL] [varchar](20) NULL,
	[WEBMAILPASSWORD] [varchar](20) NULL,
	[ALIAS] [varchar](20) NULL,
 CONSTRAINT [PK_GUARDIANS_NEW_344165639] PRIMARY KEY CLUSTERED 
(
	[DCID] ASC
) ON [PRIMARY]
) ON [PRIMARY]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[PWRSCH].[GUARDIANS]') AND OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [PWRSCH].[GUARDIANS]
GO

CREATE VIEW [PWRSCH].[GUARDIANS]
AS 
SELECT * FROM PWRSCH.GUARDIANS_LOCAL
GO

UPDATE vc3etl.LoadColumn
SET ColumnType='C'
WHERE ID in ('DAF6EDBC-A0FC-4E2F-BB54-EFCB3B715F54', '2EDC98AE-21EC-4665-A733-E6FA21F5FEA7')

UPDATE vc3etl.LoadColumn
SET ColumnType='K'
WHERE ID in ('24D2CC0A-B5EF-4E0A-9BFD-6B1522744B93')


UPDATE vc3etl.LoadTable 
SET Sequence = 24, DestTable='ReportCardItem'
WHERE ID = '13CDAB97-2E93-4BAA-B758-71865B0A5BE4'

UPDATE vc3etl.LoadTable 
SET Sequence = 25
WHERE ID = '81022486-1F6C-455E-866C-180AB2798293'

UPDATE vc3etl.LoadTable
SET SourceTable='PWRSCH.Transform_Calendar(@importRosterYear)'
WHERE ID = '61573FDD-66EA-4B12-919E-C23A41243598'

UPDATE vc3etl.LoadTable
SET MapTable='PWRSCH.Map_CalendarID'
WHERE ID= '61573fdd-66ea-4b12-919e-c23a41243598'
