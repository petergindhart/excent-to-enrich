ALTER TABLE Student ALTER COLUMN
	PhoneNumber varchar(40) NULL
GO