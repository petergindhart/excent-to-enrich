UPDATE vc3etl.ExtractValidator 
SET Columns='TeacherNumber'
where id = 'B774E388-BA11-4DD3-AE57-ACA42A78A468'

UPDATE vc3etl.ExtractTable 
SET Filter='StaffStatus = 1 AND Status = 1'
WHERE ID = '54421A8D-4D4A-45D6-8F0F-65F7619EA25C'