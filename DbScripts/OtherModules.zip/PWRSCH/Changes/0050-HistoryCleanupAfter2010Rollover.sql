--Ensure that for students that left, ensure the coutns match the actual number of absences, these records will NOT update during the update,
--you can't set them to 0, because it isn't certain when this script will run
UPDATE sry
SET DaysAbsent = (select count(*) from Absence abInner where abInner.StudentID = stu.ID and abInner.Date between ry.StartDate and ry.EndDate)
FROM
	StudentRosterYear sry join
	Student stu on sry.StudentID = stu.ID	join
	RosterYear ry on ry.ID= sry.RosterYearID and ry.ID = '6F33C8AC-A7AD-457D-82CF-43F7A4164FE8' 
WHERE 	
	stu.CurrentSchoolID is null
	
--delete section/class alignments, where the 2010 section is for a 2009 class
delete mscr
From 
	PWRSCH.Map_CLassRosterID mcr join
	ClassROster cr on mcr.DestID = cr.ID join
	PWRSCH.Map_SectionIDClassRosterID mscr on mscr.DestID = mcr.DestID join
	Pwrsch.Sections scs on scs.ID = mscr.SectionID
where
	cr.RosterYearID= '6F33C8AC-A7AD-457D-82CF-43F7A4164FE8' and --2010
	scs.TermID < 2000 --terms from before 2010
	
--delete 2010 course enrollments where they ended before the year even started...(i.e. above)
DELETE hist
From
	StudentCLassRosterHistory hist join
	ClassRoster cr on hist.ClassRosterId = cr.ID join
	RosterYear ry on cr.RosterYearID = ry.ID
where
	cr.RosterYearID= '6F33C8AC-A7AD-457D-82CF-43F7A4164FE8' and	
	hist.EndDate < ry.StartDate 
	
-- remove classes that were from 2009
delete cr
from 
	ClassRoster cr join
	PWRSCH.Map_CLassRosterID mcr on mcr.DestID= cr.ID and cr.RosterYearID ='6F33C8AC-A7AD-457D-82CF-43F7A4164FE8' left join -- this ensures only classes that were imported with PowerSchool are included
	PWRSCH.Map_SectionIDClassRosterID mscr on mscr.DestID= cr.ID and mscr.DestID is null left join
	StudentClassRosterHistory hist on hist.CLassROsterID =  cr.ID and hist.ClassRosterID is null 
	
	
--purge orphaned mapping records
DELETE mcr
FROM
	PWRSCH.Map_CLassRosterID mcr left join
	ClassRoster cr on mcr.DestID = cr.ID
where
	mcr.RosterYearID= '6F33C8AC-A7AD-457D-82CF-43F7A4164FE8' AND
	cr.ID is null	