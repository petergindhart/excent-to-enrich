insert into VC3ETL.LoadColumn values (
	'8B110A22-B440-4C8E-A680-46EB6D672DA8', 
	'86EBF668-8E15-424A-99BF-F802B3F87869', 
	'x_SpecialEd', 
	'x_SpecialEd', 
	'C', 
	0, 
	NULL, 
	NULL
)