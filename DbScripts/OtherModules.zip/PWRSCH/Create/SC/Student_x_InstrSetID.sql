IF NOT EXISTS(select * From EnumType where Id = 'CA7E6431-6ED6-48E5-B8E6-50813C7C7424')
BEGIN
      insert into EnumType values (
            'CA7E6431-6ED6-48E5-B8E6-50813C7C7424', 
            'SET', 
            1,0,'Instructional Setting'
      )

      INSERT INTO EnumValue VALUES ('7BA74C47-CFDE-44F8-BF37-B02A83E9C5BE' , 'CA7E6431-6ED6-48E5-B8E6-50813C7C7424', 'Special Education','SE',1,0)
END


INSERT INTO Vc3ETL.LoadColumn VALUES ('6B61BE15-F13F-4BFC-BD99-5A94BAF4D5C0','86EBF668-8E15-424A-99BF-F802B3F87869', 'x_InstrSetID', 'x_InstrSetID','C',0,NULL,NULL)