SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3Reporting].[ReportColumnParameterValue_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3Reporting].[ReportColumnParameterValue_InsertRecord]
GO


 /*
<summary>
Inserts a new record into the ReportColumnParameterValue table with the specified values
</summary>
<param name="reportColumn">Value to assign to the ReportColumn field of the record</param>
<param name="schemaTableParameter">Value to assign to the SchemaTableParameter field of the record</param>
<param name="valueExpression">Value to assign to the ValueExpression field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="False" returnType="System.Guid" />
*/
CREATE PROCEDURE VC3Reporting.ReportColumnParameterValue_InsertRecord
	@reportColumn uniqueidentifier, 
	@schemaTableParameter uniqueidentifier, 
	@valueExpression varchar(100)
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
	
	INSERT INTO VC3Reporting.ReportColumnParameterValue
	(
		Id, 
		ReportColumn, 
		SchemaTableParameter, 
		ValueExpression
	)
	VALUES
	(
		@id, 
		@reportColumn, 
		@schemaTableParameter, 
		@valueExpression
	)

	SELECT @id

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

