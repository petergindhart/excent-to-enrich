SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3Reporting].[ReportSchemaSummaryFunction_GetRecordsForReportSchemaDataTypeSummaryFunctionAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3Reporting].[ReportSchemaSummaryFunction_GetRecordsForReportSchemaDataTypeSummaryFunctionAssociation]
GO


 /*
<summary>
Gets records from the ReportSchemaSummaryFunction table for the specified association 
</summary>
<param name="ids">Ids of the ReportSchemaDataType's </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="False" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE VC3Reporting.ReportSchemaSummaryFunction_GetRecordsForReportSchemaDataTypeSummaryFunctionAssociation 
	@ids char1array
AS
	SELECT r1.SchemaDataType, r2.*
	FROM
		VC3Reporting.ReportSchemaDataTypeSummaryFunction r1 INNER JOIN
		GetChar1s(@ids) AS Keys ON r1.SchemaDataType = Keys.Id INNER JOIN
		VC3Reporting.ReportSchemaSummaryFunction r2 ON r1.SchemaSummaryFunction = r2.Id
	ORDER BY Sequence

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

