IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[VC3Reporting].[Report_InsertRecord]') AND type in (N'P', N'PC'))
DROP PROCEDURE [VC3Reporting].[Report_InsertRecord]

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
 /*
<summary>
Inserts a new record into the Report table with the specified values
</summary>
<param name="title">Value to assign to the Title field of the record</param>
<param name="query">Value to assign to the Query field of the record</param>
<param name="owner">Value to assign to the Owner field of the record</param>
<param name="type">Value to assign to the Type field of the record</param>
<param name="path">Value to assign to the Path field of the record</param>
<param name="description">Value to assign to the Description field of the record</param>
<param name="format">Value to assign to the Format field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="False" returnType="System.Guid" />
*/
CREATE PROCEDURE [VC3Reporting].[Report_InsertRecord]
	@title varchar(200), 
	@query text,
	@type char(1), 
	@path varchar(300), 
	@description text, 
	@format char(1)
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
	
	INSERT INTO VC3Reporting.Report
	(
		Id, 
		Title, 
		Query, 
		Type, 
		Path, 
		Description, 
		Format
	)
	VALUES
	(
		@id, 
		@title, 
		@query, 
		@type, 
		@path, 
		@description, 
		@format
	)

	SELECT @id