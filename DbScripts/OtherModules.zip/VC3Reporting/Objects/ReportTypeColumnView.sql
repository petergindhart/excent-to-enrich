SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3Reporting].[ReportTypeColumnView]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [VC3Reporting].[ReportTypeColumnView]
GO

CREATE VIEW [VC3Reporting].[ReportTypeColumnView]
AS 
	SELECT
		rtc.*
	FROM
		VC3Reporting.ReportTypeColumn rtc

	UNION


	SELECT 
		rsc.Id,
		rtt.Id,
		rsc.Name,
		rsc.Sequence
	FROM
		VC3Reporting.ReportSchemaColumn rsc JOIN
		VC3Reporting.ReportSchemaTable rst ON rsc.SchemaTable = rst.Id JOIN
		VC3Reporting.ReportTypeTable rtt ON rst.Id = rtt.SchemaTable LEFT JOIN
		VC3Reporting.ReportTypeColumn rtc ON rtt.Id = rtc.ReportTypeTable
	WHERE
		rtc.SchemaColumn IS NULL

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

