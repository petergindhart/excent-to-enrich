IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[VC3Reporting].[ReportSchemaColumn_GetAllRecords]') AND type in (N'P', N'PC'))
DROP PROCEDURE [VC3Reporting].[ReportSchemaColumn_GetAllRecords]

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
 /*
<summary>
Gets all records from the ReportSchemaColumn table
</summary>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="False" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE [VC3Reporting].[ReportSchemaColumn_GetAllRecords]
AS
	SELECT r.*
	FROM
		VC3Reporting.ReportSchemaColumn r