SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3Reporting].[ReportSchemaOperator_DeleteRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3Reporting].[ReportSchemaOperator_DeleteRecord]
GO


 /*
<summary>
Deletes a ReportSchemaOperator record
</summary>

<model isGenerated="False" returnType="System.Void" />
*/
CREATE PROCEDURE VC3Reporting.ReportSchemaOperator_DeleteRecord 
	@id uniqueidentifier
AS
	DELETE FROM VC3Reporting.ReportSchemaOperator
	WHERE Id = @id

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

