SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3Reporting].[ReportType_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3Reporting].[ReportType_InsertRecord]
GO


 /*
<summary>
Inserts a new record into the ReportType table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<param name="isEditable">Value to assign to the IsEditable field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="False" returnType="System.Char" />
*/
CREATE PROCEDURE VC3Reporting.ReportType_InsertRecord 
	@id char(1), 
	@name varchar(30), 
	@isEditable bit, 
	@description text = NULL
AS
INSERT INTO VC3Reporting.ReportType
	(
		Id, 
		Name, 
		IsEditable, 
		Description
	)
	VALUES
	(
		@id, 
		@name, 
		@isEditable, 
		@description
	)

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

