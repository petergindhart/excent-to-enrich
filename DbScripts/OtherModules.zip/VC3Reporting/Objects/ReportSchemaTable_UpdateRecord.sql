SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3Reporting].[ReportSchemaTable_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3Reporting].[ReportSchemaTable_UpdateRecord]
GO


 /*
<summary>
Updates a record in the ReportSchemaTable table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<param name="tableExpression">Value to assign to the TableExpression field of the record</param>
<param name="identityExpression">Value to assign to the IdentityExpression field of the record</param>

<model isGenerated="False" returnType="System.Void" />
*/
CREATE PROCEDURE VC3Reporting.ReportSchemaTable_UpdateRecord 
	@id uniqueidentifier,
	@name varchar(50),
	@tableExpression varchar(500),
	@identityExpression varchar(50)
AS
	UPDATE VC3Reporting.ReportSchemaTable
	SET
		Name = @name,
		TableExpression = @tableExpression,
		IdentityExpression = @identityExpression
	WHERE Id = @id

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

