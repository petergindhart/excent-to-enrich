IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[VC3Reporting].[ReportSelectColumn_GetRecords]') AND type in (N'P', N'PC'))
DROP PROCEDURE [VC3Reporting].[ReportSelectColumn_GetRecords]

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
 /*
<summary>
Gets records from the ReportColumn table for the specified ids 
</summary>
<param name="ids">Ids of the Report's </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="False" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE [VC3Reporting].[ReportSelectColumn_GetRecords] 
	@ids uniqueidentifierarray
AS
	SELECT
		r.*, s.*
	FROM
		VC3Reporting.ReportColumn r INNER JOIN
		VC3Reporting.ReportSelectColumn s ON r.Id = s.Id INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.id = Keys.Id
	WHERE
		Type = 'S'
	ORDER BY
		Sequence