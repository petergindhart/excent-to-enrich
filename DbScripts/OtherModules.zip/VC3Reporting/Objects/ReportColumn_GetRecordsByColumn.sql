SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3Reporting].[ReportColumn_GetRecordsByColumn]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3Reporting].[ReportColumn_GetRecordsByColumn]
GO

/*
<summary>
Gets records from the ReportColumn table with the specified ids
</summary>
<param name="ids">Ids of the ReportSchemaColumn(s) to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="False" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE [VC3Reporting].[ReportColumn_GetRecordsByColumn]
	@ids	uniqueidentifierarray
AS
	SELECT r.SchemaColumn, r.*, s.*
	FROM
		VC3Reporting.ReportColumn r INNER JOIN
		VC3Reporting.ReportSelectColumn s ON r.Id = s.Id INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.SchemaColumn = Keys.Id
	WHERE
		Type = 'S'

	SELECT r.SchemaColumn, r.*, o.*
	FROM
		VC3Reporting.ReportColumn r INNER JOIN
		VC3Reporting.ReportOrderColumn o ON r.Id = o.Id INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.SchemaColumn = Keys.Id
	WHERE
		Type = 'O'

	SELECT r.SchemaColumn, r.*, f.*
	FROM
		VC3Reporting.ReportColumn r INNER JOIN
		VC3Reporting.ReportFilterColumn f ON r.Id = f.Id INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.Report = Keys.Id
	WHERE
		Type = 'P'

	SELECT r.SchemaColumn, r.*, g.*
	FROM
		VC3Reporting.ReportColumn r INNER JOIN
		VC3Reporting.ReportOrderColumn g ON r.Id = g.Id INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.Report = Keys.Id
	WHERE
		Type = 'G'
		
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO