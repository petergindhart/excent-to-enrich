/****** Object:  StoredProcedure [VC3Reporting].[ReportSchemaColumnAllowedValue_GetRecordsBySchemaColumn]    Script Date: 01/27/2009 13:56:31 ******/
IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[VC3Reporting].[ReportSchemaColumnAllowedValue_GetRecordsBySchemaColumn]') AND type in (N'P', N'PC'))
DROP PROCEDURE [VC3Reporting].[ReportSchemaColumnAllowedValue_GetRecordsBySchemaColumn]
GO

/****** Object:  StoredProcedure [VC3Reporting].[ReportSchemaColumnAllowedValue_GetRecordsBySchemaColumn]    Script Date: 01/27/2009 13:56:31 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

 /*
<summary>
Gets records from the ReportSchemaColumnAllowedValue table
with the specified ids
</summary>
<param name="ids">Ids of the SchemaColumn(s) to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="False" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE [VC3Reporting].[ReportSchemaColumnAllowedValue_GetRecordsBySchemaColumn]
	@ids	uniqueidentifierarray
AS
	SELECT
		r.SchemaColumn,
		r.*
	FROM
		ReportSchemaColumnAllowedValue r INNER JOIN
		GetUniqueidentifiers(@ids) Keys ON r.SchemaColumn = Keys.Id

GO


