IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[VC3Reporting].[ReportType_DeleteRecordsForReportTypeFormatAssociation]') AND type in (N'P', N'PC'))
DROP PROCEDURE [VC3Reporting].[ReportType_DeleteRecordsForReportTypeFormatAssociation]

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
 /*
<summary>
Deletes records from the ReportTypeFormat table for the specified ids 
</summary>
<param name="reportFormat">The id of the associated ReportFormat</param>
<param name="ids">The ids of the ReportType's to delete</param>
<model isGenerated="False" returnType="System.Void" />
*/
CREATE PROCEDURE [VC3Reporting].[ReportType_DeleteRecordsForReportTypeFormatAssociation]
	@reportFormat char(1), 
	@ids chararray
AS
	DELETE VC3Reporting.ReportTypeFormat
	FROM 
		VC3Reporting.ReportTypeFormat ab INNER JOIN
		GetChars(@ids) AS Keys ON ab.ReportType = Keys.Id
	WHERE
		ab.ReportFormat = @reportFormat