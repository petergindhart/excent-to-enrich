SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3Reporting].[ReportSelectColumn_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3Reporting].[ReportSelectColumn_InsertRecord]
GO


 /*
<summary>
Inserts a new record into the ReportSelectColumn table with the specified values
</summary>
<param name="label">Value to assign to the Label field of the record</param>
<param name="id">Value to assign to the Id field of the record</param>
<param name="schemaSummaryFunction">Value to assign to the SchemaSummaryFunction field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="False" returnType="IDataReader" />
*/
CREATE PROCEDURE VC3Reporting.ReportSelectColumn_InsertRecord 
	@label varchar(50),
	@id uniqueidentifier,
	@schemaSummaryFunction char(1)
AS
INSERT INTO VC3Reporting.ReportSelectColumn
	(

		Label,
		Id,
		SchemaSummaryFunction
	)
	VALUES
	(

		@label,
		@id,
		@schemaSummaryFunction
	)

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

