 SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3Reporting].[ReportTypeColumn_GetRecordsByReportTypeTable]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3Reporting].[ReportTypeColumn_GetRecordsByReportTypeTable]
GO

 /*
<summary>
Gets records from the ReportTypeColumn table for the specified ids 
</summary>
<param name="ids">Ids of the ReportTypeTable's </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model returnType="System.Data.IDataReader" isGenerated="False"/>
*/
CREATE PROCEDURE [VC3Reporting].[ReportTypeColumn_GetRecordsByReportTypeTable] 
	@ids uniqueidentifierarray
AS
	SELECT r.ReportTypeTable, r.*
	FROM
		VC3Reporting.ReportTypeColumnView r INNER JOIN
		VC3Reporting.ReportSchemaColumn rsc on r.SchemaColumn = rsc.id inner join
		GetUniqueidentifiers(@ids) AS Keys ON r.ReportTypeTable = Keys.Id
	ORDER BY r.Sequence, isnull(r.Name, rsc.Name)
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

