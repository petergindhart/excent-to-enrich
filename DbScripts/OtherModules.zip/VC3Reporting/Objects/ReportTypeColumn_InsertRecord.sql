SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3Reporting].[ReportTypeColumn_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3Reporting].[ReportTypeColumn_InsertRecord]
GO


 /*
<summary>
Inserts a new record into the ReportTypeColumn table with the specified values
</summary>
<param name="name">Value to assign to the Name field of the record</param>
<param name="sequence">Value to assign to the Sequence field of the record</param>
<param name="schemaColumn">Value to assign to the SchemaColumn field of the record</param>
<param name="reportTypeTable">Value to assign to the ReportTypeTable field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="False" returnType="IDataReader" />
*/
CREATE PROCEDURE VC3Reporting.ReportTypeColumn_InsertRecord 
	@name varchar(100),
	@sequence int,
	@schemaColumn uniqueidentifier,
	@reportTypeTable uniqueidentifier
AS
INSERT INTO VC3Reporting.ReportTypeColumn
	(

		Name,
		Sequence,
		SchemaColumn,
		ReportTypeTable
	)
	VALUES
	(

		@name,
		@sequence,
		@schemaColumn,
		@reportTypeTable
	)

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

