SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3Reporting].[ReportSchemaOperator_GetRecordsForReportSchemaDataTypeOperatorAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3Reporting].[ReportSchemaOperator_GetRecordsForReportSchemaDataTypeOperatorAssociation]
GO


 /*
<summary>
Gets records from the ReportSchemaOperator table for the specified association 
</summary>
<param name="ids">Ids of the ReportSchemaDataType(s) </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="False" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE VC3Reporting.ReportSchemaOperator_GetRecordsForReportSchemaDataTypeOperatorAssociation
	@ids chararray
AS
	SELECT ab.SchemaDataType, a.*
	FROM
		VC3Reporting.ReportSchemaDataTypeOperator ab INNER JOIN
		GetChars(@ids) AS Keys ON ab.SchemaDataType = Keys.Id INNER JOIN
		VC3Reporting.ReportSchemaOperator a ON ab.SchemaOperator = a.Id
	ORDER BY Sequence

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

