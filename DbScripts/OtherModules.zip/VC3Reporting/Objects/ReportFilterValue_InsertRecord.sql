/****** Object:  StoredProcedure [VC3Reporting].[ReportFilterValue_InsertRecord]    Script Date: 01/27/2009 14:00:52 ******/
IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[VC3Reporting].[ReportFilterValue_InsertRecord]') AND type in (N'P', N'PC'))
DROP PROCEDURE [VC3Reporting].[ReportFilterValue_InsertRecord]
GO

/****** Object:  StoredProcedure [VC3Reporting].[ReportFilterValue_InsertRecord]    Script Date: 01/27/2009 14:00:52 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

 /*
<summary>
Inserts a new record into the ReportFilterValue table with the specified values
</summary>
<param name="filterColumn">Value to assign to the FilterColumn field of the record</param>
<param name="valueExpression">Value to assign to the ValueExpression field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="False" returnType="System.Guid" />
*/
CREATE PROCEDURE [VC3Reporting].[ReportFilterValue_InsertRecord]
	@filterColumn uniqueidentifier, 
	@valueExpression varchar(100),
	@isDynamic bit
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
	
	INSERT INTO VC3Reporting.ReportFilterValue
	(
		Id, 
		FilterColumn, 
		ValueExpression,
		IsDynamic
	)
	VALUES
	(
		@id, 
		@filterColumn, 
		@valueExpression,
		@isDynamic
	)

	SELECT @id
GO


