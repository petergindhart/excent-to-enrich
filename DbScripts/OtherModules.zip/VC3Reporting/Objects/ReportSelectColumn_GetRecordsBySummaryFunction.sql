SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3Reporting].[ReportSelectColumn_GetRecordsBySummaryFunction]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3Reporting].[ReportSelectColumn_GetRecordsBySummaryFunction]
GO


 /*
<summary>
Gets records from the ReportSelectColumn table with the specified ids
</summary>
<param name="ids">Ids of the ReportSchemaSummaryFunction(s) to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="False" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE VC3Reporting.ReportSelectColumn_GetRecordsBySummaryFunction
	@ids	chararray
AS
	SELECT r.SchemaSummaryFunction, r.*, a.*
	FROM
		VC3Reporting.ReportSelectColumn r INNER JOIN
		VC3Reporting.ReportColumn a on r.id=a.id INNER JOIN
		GetChars(@ids) AS Keys ON r.SchemaSummaryFunction = Keys.Id

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

