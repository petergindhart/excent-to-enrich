IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[VC3Reporting].[ReportType_InsertRecordsForReportTypeFormatAssociation]') AND type in (N'P', N'PC'))
DROP PROCEDURE [VC3Reporting].[ReportType_InsertRecordsForReportTypeFormatAssociation]

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
 /*
<summary>
Insert records in the ReportTypeFormat table for the specified ids 
</summary>
<param name="reportFormat">The id of the associated ReportFormat</param>
<param name="ids">The ids of the ReportType's to insert</param>
<model isGenerated="False" returnType="System.Void" />
*/
CREATE PROCEDURE [VC3Reporting].[ReportType_InsertRecordsForReportTypeFormatAssociation]
	@reportFormat char(1), 
	@ids chararray
AS
	INSERT INTO VC3Reporting.ReportTypeFormat ( ReportFormat, ReportType)
	SELECT @reportFormat, Keys.* FROM
		GetChars(@ids) AS Keys