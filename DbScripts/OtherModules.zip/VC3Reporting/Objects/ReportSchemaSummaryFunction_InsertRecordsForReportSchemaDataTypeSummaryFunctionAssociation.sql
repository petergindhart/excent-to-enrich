SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3Reporting].[ReportSchemaSummaryFunction_InsertRecordsForReportSchemaDataTypeSummaryFunctionAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3Reporting].[ReportSchemaSummaryFunction_InsertRecordsForReportSchemaDataTypeSummaryFunctionAssociation]
GO


 /*
<summary>
Insert records in the ReportSchemaDataTypeSummaryFunction table for the specified ids 
</summary>
<param name="id">The id of the associated ReportSchemaDataType</param>
<param name="ids">The ids of the ReportSchemaSummaryFunction's to insert</param>
<model isGenerated="False" returnType="System.Void" />
*/
CREATE PROCEDURE VC3Reporting.ReportSchemaSummaryFunction_InsertRecordsForReportSchemaDataTypeSummaryFunctionAssociation 
	@id char(1),
	@ids char1array
AS
	INSERT INTO VC3Reporting.ReportSchemaDataTypeSummaryFunction
	SELECT @id, Keys.*	FROM
		GetChar1s(@ids) AS Keys

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

