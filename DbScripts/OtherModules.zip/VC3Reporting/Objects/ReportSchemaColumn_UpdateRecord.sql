IF EXISTS(
	SELECT * 
	FROM SYSOBJECTS 
	WHERE ID = OBJECT_ID('VC3REPORTING.ReportSchemaColumn_UpdateRecord') AND
	TYPE = 'P')
DROP PROCEDURE VC3REPORTING.ReportSchemaColumn_UpdateRecord
GO

/*
<summary>
Updates a record in the ReportSchemaColumn table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<param name="schemaTable">Value to assign to the SchemaTable field of the record</param>
<param name="schemaDataType">Value to assign to the SchemaDataType field of the record</param>
<param name="displayExpression">Value to assign to the DisplayExpression field of the record</param>
<param name="valueExpression">Value to assign to the ValueExpression field of the record</param>
<param name="orderExpression">Value to assign to the OrderExpression field of the record</param>
<param name="linkExpression">Value to assign to the LinkExpression field of the record</param>
<param name="linkFormat">Value to assign to the LinkFormat field of the record</param>
<param name="isSelectColumn">Value to assign to the IsSelectColumn field of the record</param>
<param name="isFilterColumn">Value to assign to the IsFilterColumn field of the record</param>
<param name="isParameterColumn">Value to assign to the IsParameterColumn field of the record</param>
<param name="isGroupColumn">Value to assign to the IsGroupColumn field of the record</param>
<param name="isOrderColumn">Value to assign to the IsOrderColumn field of the record</param>
<param name="isAggregated">Value to assign to the IsAggregated field of the record</param>
<param name="allowedValuesExpression">Value to assign to the AllowedValuesExpression field of the record</param>
<param name="sequence">Value to assign to the Sequence field of the record</param>
<param name="width">Value to assign to the Width field of the record</param>
<param name="description">Value to assign to the Description field of the record</param>
<param name="parentSchemaColumn">Value to assign to the ParentSchemaColumn field of the record</param>

<model isGenerated="False" returnType="System.Void" />
*/
CREATE PROCEDURE VC3Reporting.ReportSchemaColumn_UpdateRecord
	@id uniqueidentifier, 
	@name varchar(150), 
	@schemaTable uniqueidentifier, 
	@schemaDataType char(1), 
	@displayExpression varchar(1000), 
	@valueExpression varchar(1000), 
	@orderExpression varchar(1000), 
	@linkExpression varchar(1000), 
	@linkFormat varchar(1000), 
	@isSelectColumn bit, 
	@isFilterColumn bit, 
	@isParameterColumn bit, 
	@isGroupColumn bit, 
	@isOrderColumn bit, 
	@isAggregated bit, 
	@allowedValuesExpression varchar(1000), 
	@sequence int, 
	@width decimal(18, 0), 
	@description text = NULL,
	@parentSchemaColumn uniqueidentifier
AS
	UPDATE VC3Reporting.ReportSchemaColumn
	SET
		Name = @name, 
		SchemaTable = @schemaTable, 
		SchemaDataType = @schemaDataType, 
		DisplayExpression = @displayExpression, 
		ValueExpression = @valueExpression, 
		OrderExpression = @orderExpression, 
		LinkExpression = @linkExpression, 
		LinkFormat = @linkFormat, 
		IsSelectColumn = @isSelectColumn, 
		IsFilterColumn = @isFilterColumn, 
		IsParameterColumn = @isParameterColumn, 
		IsGroupColumn = @isGroupColumn, 
		IsOrderColumn = @isOrderColumn, 
		IsAggregated = @isAggregated, 
		AllowedValuesExpression = @allowedValuesExpression, 
		Sequence = @sequence, 
		Width = @width, 
		Description = @description, 
		ParentSchemaColumn = @parentSchemaColumn
	WHERE 
		Id = @id
GO

