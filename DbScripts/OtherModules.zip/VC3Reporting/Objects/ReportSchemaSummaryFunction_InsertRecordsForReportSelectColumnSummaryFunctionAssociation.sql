SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3Reporting].[ReportSchemaSummaryFunction_InsertRecordsForReportSelectColumnSummaryFunctionAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3Reporting].[ReportSchemaSummaryFunction_InsertRecordsForReportSelectColumnSummaryFunctionAssociation]
GO


 /*
<summary>
Insert records in the ReportSelectColumnSummaryFunction table for the specified ids 
</summary>
<param name="selectColumn">The id of the associated ReportSelectColumn</param>
<param name="ids">The ids of the ReportSchemaSummaryFunction's to insert</param>
<model isGenerated="False" returnType="System.Void" />
*/
CREATE PROCEDURE VC3Reporting.ReportSchemaSummaryFunction_InsertRecordsForReportSelectColumnSummaryFunctionAssociation
	@selectColumn uniqueidentifier, 
	@ids chararray
AS
	INSERT INTO VC3Reporting.ReportSelectColumnSummaryFunction ( SelectColumn, SummaryFunction)
	SELECT @selectColumn, Keys.* FROM
		GetChars(@ids) AS Keys

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

