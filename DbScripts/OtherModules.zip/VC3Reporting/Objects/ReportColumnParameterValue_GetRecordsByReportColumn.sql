IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[VC3Reporting].[ReportColumnParameterValue_GetRecordsByReportColumn]') AND type in (N'P', N'PC'))
DROP PROCEDURE [VC3Reporting].[ReportColumnParameterValue_GetRecordsByReportColumn]

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
 /*
<summary>
Gets records from the ReportColumnParameterValue table for the specified ids 
</summary>
<param name="ids">Ids of the ReportColumn's </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="False" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE [VC3Reporting].[ReportColumnParameterValue_GetRecordsByReportColumn] 
	@ids uniqueidentifierarray
AS
	SELECT r.ReportColumn, r.*
	FROM
		VC3Reporting.ReportColumnParameterValue r INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.ReportColumn = Keys.Id INNER JOIN
		VC3Reporting.ReportSchemaTableParameter p ON r.SchemaTableParameter = p.Id
	ORDER BY
		p.Sequence