SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3Reporting].[ReportSchemaJoinMultiplicity_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3Reporting].[ReportSchemaJoinMultiplicity_InsertRecord]
GO


 /*
<summary>
Inserts a new record into the ReportSchemaJoinMultiplicity table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<param name="lowerBound">Value to assign to the LowerBound field of the record</param>
<param name="upperBound">Value to assign to the UpperBound field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="False" returnType="System.Char" />
*/
CREATE PROCEDURE VC3Reporting.ReportSchemaJoinMultiplicity_InsertRecord 
	@id char(1),
	@name varchar(50),
	@lowerBound int,
	@upperBound int
AS
INSERT INTO VC3Reporting.ReportSchemaJoinMultiplicity
	(

		Id,
		Name,
		LowerBound,
		UpperBound
	)
	VALUES
	(

		@id,
		@name,
		@lowerBound,
		@upperBound
	)

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

