SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3Reporting].[ReportSchemaTable_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3Reporting].[ReportSchemaTable_InsertRecord]
GO


 /*
<summary>
Inserts a new record into the ReportSchemaTable table with the specified values
</summary>
<param name="name">Value to assign to the Name field of the record</param>
<param name="tableExpression">Value to assign to the TableExpression field of the record</param>
<param name="identityExpression">Value to assign to the IdentityExpression field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="False" returnType="System.Guid" />
*/
CREATE PROCEDURE VC3Reporting.ReportSchemaTable_InsertRecord 
	@name varchar(50),
	@tableExpression varchar(500),
	@identityExpression varchar(50)
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
INSERT INTO VC3Reporting.ReportSchemaTable
	(

		Id,
		Name,
		TableExpression,
		IdentityExpression
	)
	VALUES
	(

		@id,
		@name,
		@tableExpression,
		@identityExpression
	)

	SELECT @id

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

