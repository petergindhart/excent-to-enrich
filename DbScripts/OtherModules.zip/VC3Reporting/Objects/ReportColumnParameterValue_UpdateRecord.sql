SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3Reporting].[ReportColumnParameterValue_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3Reporting].[ReportColumnParameterValue_UpdateRecord]
GO


 /*
<summary>
Updates a record in the ReportColumnParameterValue table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="reportColumn">Value to assign to the ReportColumn field of the record</param>
<param name="schemaTableParameter">Value to assign to the SchemaTableParameter field of the record</param>
<param name="valueExpression">Value to assign to the ValueExpression field of the record</param>

<model isGenerated="False" returnType="System.Void" />
*/
CREATE PROCEDURE VC3Reporting.ReportColumnParameterValue_UpdateRecord
	@id uniqueidentifier, 
	@reportColumn uniqueidentifier, 
	@schemaTableParameter uniqueidentifier, 
	@valueExpression varchar(100)
AS
	UPDATE VC3Reporting.ReportColumnParameterValue
	SET
		ReportColumn = @reportColumn, 
		SchemaTableParameter = @schemaTableParameter, 
		ValueExpression = @valueExpression
	WHERE 
		Id = @id

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

