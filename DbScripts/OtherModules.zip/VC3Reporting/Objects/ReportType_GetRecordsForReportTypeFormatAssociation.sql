IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[VC3Reporting].[ReportType_GetRecordsForReportTypeFormatAssociation]') AND type in (N'P', N'PC'))
DROP PROCEDURE [VC3Reporting].[ReportType_GetRecordsForReportTypeFormatAssociation]

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

 /*
<summary>
Gets records from the ReportType table for the specified association 
</summary>
<param name="ids">Ids of the ReportFormat(s) </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="False" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE [VC3Reporting].[ReportType_GetRecordsForReportTypeFormatAssociation]
	@ids chararray
AS
	SELECT ab.ReportFormat, a.*
	FROM
		VC3Reporting.ReportTypeFormat ab INNER JOIN
		GetChars(@ids) AS Keys ON ab.ReportFormat = Keys.Id INNER JOIN
		VC3Reporting.ReportType a ON ab.ReportType = a.Id
