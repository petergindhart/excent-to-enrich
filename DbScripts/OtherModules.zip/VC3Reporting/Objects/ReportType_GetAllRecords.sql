IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[VC3Reporting].[ReportType_GetAllRecords]') AND type in (N'P', N'PC'))
DROP PROCEDURE [VC3Reporting].[ReportType_GetAllRecords]

SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER ON
GO
 /*
<summary>
Gets all records from the ReportType table
</summary>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="False" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE [VC3Reporting].[ReportType_GetAllRecords] 
AS
	SELECT c.*
	FROM
		VC3Reporting.ReportTypeView c
	WHERE
		c.IsEditable = 1
	ORDER BY
		Name