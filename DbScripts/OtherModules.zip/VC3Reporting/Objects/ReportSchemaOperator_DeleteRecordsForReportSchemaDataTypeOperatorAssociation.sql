SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3Reporting].[ReportSchemaOperator_DeleteRecordsForReportSchemaDataTypeOperatorAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3Reporting].[ReportSchemaOperator_DeleteRecordsForReportSchemaDataTypeOperatorAssociation]
GO


 /*
<summary>
Deletes records from the ReportSchemaDataTypeOperator table for the specified ids 
</summary>
<param name="schemaDataType">The id of the associated ReportSchemaDataType</param>
<param name="ids">The ids of the ReportSchemaOperator's to delete</param>
<model isGenerated="False" returnType="System.Void" />
*/
CREATE PROCEDURE VC3Reporting.ReportSchemaOperator_DeleteRecordsForReportSchemaDataTypeOperatorAssociation
	@schemaDataType char(1), 
	@ids uniqueidentifierarray
AS
	DELETE ReportSchemaDataTypeOperator
	FROM 
		VC3Reporting.ReportSchemaDataTypeOperator ab INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON ab.SchemaOperator = Keys.Id
	WHERE
		ab.SchemaDataType = @schemaDataType

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

