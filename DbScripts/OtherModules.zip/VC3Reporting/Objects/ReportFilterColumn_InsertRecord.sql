IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[VC3Reporting].[ReportFilterColumn_InsertRecord]') AND type in (N'P', N'PC'))
DROP PROCEDURE [VC3Reporting].[ReportFilterColumn_InsertRecord]

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
 /*
<summary>
Inserts a new record into the ReportFilterColumn table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="schemaOperator">Value to assign to the SchemaOperator field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="False" returnType="ReportColumn" />
*/
CREATE PROCEDURE [VC3Reporting].[ReportFilterColumn_InsertRecord] 
	@id uniqueidentifier,
	@schemaOperator uniqueidentifier,
	@nullable bit
AS
INSERT INTO [VC3Reporting].ReportFilterColumn
	(

		Id,
		SchemaOperator,
		Nullable
	)
	VALUES
	(

		@id,
		@schemaOperator,
		@nullable
	)