IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[VC3Reporting].[ReportColumn_InsertRecord]') AND type in (N'P', N'PC'))
DROP PROCEDURE [VC3Reporting].[ReportColumn_InsertRecord]

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER OFF
GO
 /*
<summary>
Inserts a new record into the ReportColumn table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="sequence">Value to assign to the Sequence field of the record</param>
<param name="report">Value to assign to the Report field of the record</param>
<param name="type">Value to assign to the Type field of the record</param>
<param name="schemaColumn">Value to assign to the SchemaColumn field of the record</param>
<param name="reportTypeTable">Value to assign to the ReportTypeTable field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model returnType="System.Guid" isGenerated="False" />
*/
CREATE PROCEDURE [VC3Reporting].[ReportColumn_InsertRecord] 
	@sequence int,
	@report uniqueidentifier,
	@type char(1),
	@schemaColumn uniqueidentifier,
	@reportTypeTable uniqueidentifier
AS
declare @id uniqueidentifier 

set @id = newid()

	INSERT INTO VC3Reporting.ReportColumn
	(
		Id,
		Sequence,
		Report,
		Type,
		SchemaColumn,
		ReportTypeTable
	)
	VALUES
	(

		@id,
		@sequence,
		@report,
		@type,
		@schemaColumn,
		@reportTypeTable
	)

select @id