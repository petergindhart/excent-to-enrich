SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3Reporting].[ReportSchemaOperator_InsertRecordsForReportSchemaDataTypeOperatorAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3Reporting].[ReportSchemaOperator_InsertRecordsForReportSchemaDataTypeOperatorAssociation]
GO


 /*
<summary>
Insert records in the ReportSchemaDataTypeOperator table for the specified ids 
</summary>
<param name="schemaDataType">The id of the associated ReportSchemaDataType</param>
<param name="ids">The ids of the ReportSchemaOperator's to insert</param>
<model isGenerated="False" returnType="System.Void" />
*/
CREATE PROCEDURE VC3Reporting.ReportSchemaOperator_InsertRecordsForReportSchemaDataTypeOperatorAssociation
	@schemaDataType char(1), 
	@ids uniqueidentifierarray
AS
	INSERT INTO VC3Reporting.ReportSchemaDataTypeOperator ( SchemaDataType, SchemaOperator)
	SELECT @schemaDataType, Keys.* FROM
		GetUniqueidentifiers(@ids) AS Keys

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

