SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3Reporting].[ReportColumnParameterValue_DeleteRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3Reporting].[ReportColumnParameterValue_DeleteRecord]
GO


 /*
<summary>
Deletes a ReportColumnParameterValue record
</summary>

<model isGenerated="False" returnType="System.Void" />
*/
CREATE PROCEDURE VC3Reporting.ReportColumnParameterValue_DeleteRecord
	@id uniqueidentifier
AS
	DELETE FROM 
		VC3Reporting.ReportColumnParameterValue
	WHERE
		Id = @id

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

