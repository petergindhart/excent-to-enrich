SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3Reporting].[ReportSchemaDataType_GetRecordsForReportSchemaDataTypeSummaryFunctionAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3Reporting].[ReportSchemaDataType_GetRecordsForReportSchemaDataTypeSummaryFunctionAssociation]
GO


 /*
<summary>
Gets records from the ReportSchemaDataType table for the specified association 
</summary>
<param name="ids">Ids of the ReportSchemaSummaryFunction(s) </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="False" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE VC3Reporting.ReportSchemaDataType_GetRecordsForReportSchemaDataTypeSummaryFunctionAssociation
	@ids chararray
AS
	SELECT ab.SchemaSummaryFunction, a.*
	FROM
		VC3Reporting.ReportSchemaDataTypeSummaryFunction ab INNER JOIN
		GetChars(@ids) AS Keys ON ab.SchemaSummaryFunction = Keys.Id INNER JOIN
		VC3Reporting.ReportSchemaDataType a ON ab.SchemaDataType = a.Id

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

