SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3Reporting].[ReportSchemaDataType_InsertRecordsForReportSchemaDataTypeSummaryFunctionAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3Reporting].[ReportSchemaDataType_InsertRecordsForReportSchemaDataTypeSummaryFunctionAssociation]
GO


 /*
<summary>
Insert records in the ReportSchemaDataTypeSummaryFunction table for the specified ids 
</summary>
<param name="schemaSummaryFunction">The id of the associated ReportSchemaSummaryFunction</param>
<param name="ids">The ids of the ReportSchemaDataType's to insert</param>
<model isGenerated="False" returnType="System.Void" />
*/
CREATE PROCEDURE VC3Reporting.ReportSchemaDataType_InsertRecordsForReportSchemaDataTypeSummaryFunctionAssociation
	@schemaSummaryFunction char(1), 
	@ids chararray
AS
	INSERT INTO VC3Reporting.ReportSchemaDataTypeSummaryFunction ( SchemaSummaryFunction, SchemaDataType)
	SELECT @schemaSummaryFunction, Keys.* FROM
		GetChars(@ids) AS Keys

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

