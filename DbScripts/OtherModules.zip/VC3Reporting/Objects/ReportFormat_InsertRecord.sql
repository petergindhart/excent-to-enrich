SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3Reporting].[ReportFormat_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3Reporting].[ReportFormat_InsertRecord]
GO


 /*
<summary>
Inserts a new record into the ReportFormat table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<param name="builder">Value to assign to the Builder field of the record</param>
<param name="template">Value to assign to the Template field of the record</param>
<param name="datasource">Value to assign to the Datasource field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="False" returnType="System.Void" />
*/
CREATE PROCEDURE VC3Reporting.ReportFormat_InsertRecord
	@id char(1), 
	@name varchar(30), 
	@builder varchar(200), 
	@template varchar(200), 
	@datasource varchar(200)
AS
	INSERT INTO VC3Reporting.ReportFormat
	(
		Id, 
		Name, 
		Builder, 
		Template, 
		Datasource
	)
	VALUES
	(
		@id, 
		@name, 
		@builder, 
		@template, 
		@datasource
	)

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

