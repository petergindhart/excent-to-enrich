IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[VC3Reporting].[ReportOrderColumn_InsertRecord]') AND type in (N'P', N'PC'))
DROP PROCEDURE [VC3Reporting].[ReportOrderColumn_InsertRecord]

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
 /*
<summary>
Inserts a new record into the ReportOrderColumn table with the specified values
</summary>
<param name="isAscending">Value to assign to the IsAscending field of the record</param>
<param name="id">Value to assign to the Id field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="False" returnType="ReportColumn" />
*/
CREATE PROCEDURE [VC3Reporting].[ReportOrderColumn_InsertRecord] 
	@isAscending bit,
	@id uniqueidentifier
AS
	INSERT INTO VC3Reporting.ReportOrderColumn
	(

		IsAscending,
		Id
	)
	VALUES
	(

		@isAscending,
		@id
	)