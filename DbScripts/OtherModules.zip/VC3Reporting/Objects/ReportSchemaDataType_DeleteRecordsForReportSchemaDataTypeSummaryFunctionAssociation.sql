SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3Reporting].[ReportSchemaDataType_DeleteRecordsForReportSchemaDataTypeSummaryFunctionAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3Reporting].[ReportSchemaDataType_DeleteRecordsForReportSchemaDataTypeSummaryFunctionAssociation]
GO


 /*
<summary>
Deletes records from the ReportSchemaDataTypeSummaryFunction table for the specified ids 
</summary>
<param name="schemaSummaryFunction">The id of the associated ReportSchemaSummaryFunction</param>
<param name="ids">The ids of the ReportSchemaDataType's to delete</param>
<model isGenerated="False" returnType="System.Void" />
*/
CREATE PROCEDURE VC3Reporting.ReportSchemaDataType_DeleteRecordsForReportSchemaDataTypeSummaryFunctionAssociation
	@schemaSummaryFunction char(1), 
	@ids chararray
AS
	DELETE ReportSchemaDataTypeSummaryFunction
	FROM 
		VC3Reporting.ReportSchemaDataTypeSummaryFunction ab INNER JOIN
		GetChars(@ids) AS Keys ON ab.SchemaDataType = Keys.Id
	WHERE
		ab.SchemaSummaryFunction = @schemaSummaryFunction

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

