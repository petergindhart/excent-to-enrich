SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3Reporting].[ReportTypeColumn_DeleteRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3Reporting].[ReportTypeColumn_DeleteRecord]
GO


 /*
<summary>
Deletes a ReportTypeColumn record
</summary>

<model isGenerated="False" returnType="System.Void" />
*/
CREATE PROCEDURE VC3Reporting.ReportTypeColumn_DeleteRecord 
	@schemaColumn uniqueidentifier,
	@reportTypeTable uniqueidentifier
AS
	DELETE FROM VC3Reporting.ReportTypeColumn
	WHERE SchemaColumn = @schemaColumn AND ReportTypeTable = @reportTypeTable

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

