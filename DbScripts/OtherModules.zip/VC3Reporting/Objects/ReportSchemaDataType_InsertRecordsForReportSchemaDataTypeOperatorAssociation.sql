SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3Reporting].[ReportSchemaDataType_InsertRecordsForReportSchemaDataTypeOperatorAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3Reporting].[ReportSchemaDataType_InsertRecordsForReportSchemaDataTypeOperatorAssociation]
GO


 /*
<summary>
Insert records in the ReportSchemaDataTypeOperator table for the specified ids 
</summary>
<param name="id">The id of the associated ReportSchemaOperator</param>
<param name="ids">The ids of the ReportSchemaDataType's to insert</param>
<model isGenerated="False" returnType="System.Void" />
*/
CREATE PROCEDURE VC3Reporting.ReportSchemaDataType_InsertRecordsForReportSchemaDataTypeOperatorAssociation 
	@id uniqueidentifier,
	@ids char1array
AS
	INSERT INTO VC3Reporting.ReportSchemaDataTypeOperator
	SELECT @id, Keys.*	FROM
		GetChar1s(@ids) AS Keys

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

