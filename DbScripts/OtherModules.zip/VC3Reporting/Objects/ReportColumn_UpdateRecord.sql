SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3Reporting].[ReportColumn_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3Reporting].[ReportColumn_UpdateRecord]
GO


 /*
<summary>
Updates a record in the ReportColumn table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="sequence">Value to assign to the Sequence field of the record</param>
<param name="report">Value to assign to the Report field of the record</param>
<param name="type">Value to assign to the Type field of the record</param>
<param name="schemaColumn">Value to assign to the SchemaColumn field of the record</param>
<param name="reportTypeTable">Value to assign to the ReportTypeTable field of the record</param>

<model isGenerated="False" returnType="System.Void" />
*/
CREATE PROCEDURE VC3Reporting.ReportColumn_UpdateRecord 
	@id uniqueidentifier,
	@sequence int,
	@report uniqueidentifier,
	@type char(1),
	@schemaColumn uniqueidentifier,
	@reportTypeTable uniqueidentifier
AS
	UPDATE VC3Reporting.ReportColumn
	SET
		Sequence = @sequence,
		Report = @report,
		Type = @type,
		SchemaColumn = @schemaColumn,
		ReportTypeTable = @reportTypeTable
	WHERE Id = @id AND Id = @id AND Id = @id AND Id = @id

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

