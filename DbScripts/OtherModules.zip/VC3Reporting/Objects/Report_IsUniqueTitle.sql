IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[VC3Reporting].[Report_IsUniqueTitle]') AND type in (N'P', N'PC'))
DROP PROCEDURE [VC3Reporting].[Report_IsUniqueTitle]

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
 /*
<summary>
Ensures that the title is unique and may be used for the specified report.
</summary>
<param name="title">The title of the report to check</param>
<param name="ids">The id of the report the title is for</param>
<returns>True if the report title is unique, otherwise False</returns>
<model isGenerated="False" returnType="System.Boolean" />
*/
CREATE PROCEDURE [VC3Reporting].[Report_IsUniqueTitle]
	@title varchar(200),
	@report uniqueidentifier
AS
	IF EXISTS 
	(
		SELECT
			a.Id
		FROM
			VC3Reporting.Report a
		WHERE
			a.Title = @title AND (@report IS NULL OR @report != a.Id)
	)
		SELECT CAST(0 AS BIT)
	ELSE
		SELECT CAST(1 AS BIT)