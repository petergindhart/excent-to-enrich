/****** Object:  StoredProcedure [VC3Reporting].[ReportFilterValue_UpdateRecord]    Script Date: 01/27/2009 14:00:55 ******/
IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[VC3Reporting].[ReportFilterValue_UpdateRecord]') AND type in (N'P', N'PC'))
DROP PROCEDURE [VC3Reporting].[ReportFilterValue_UpdateRecord]
GO

/****** Object:  StoredProcedure [VC3Reporting].[ReportFilterValue_UpdateRecord]    Script Date: 01/27/2009 14:00:55 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

 /*
<summary>
Updates a record in the ReportFilterValue table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="filterColumn">Value to assign to the FilterColumn field of the record</param>
<param name="valueExpression">Value to assign to the ValueExpression field of the record</param>

<model isGenerated="False" returnType="System.Void" />
*/
CREATE PROCEDURE [VC3Reporting].[ReportFilterValue_UpdateRecord]
	@id uniqueidentifier, 
	@filterColumn uniqueidentifier, 
	@valueExpression varchar(100),
	@isDynamic bit
AS
	UPDATE VC3Reporting.ReportFilterValue
	SET
		FilterColumn = @filterColumn, 
		ValueExpression = @valueExpression,
		IsDynamic = @isDynamic
	WHERE 
		Id = @id
GO


