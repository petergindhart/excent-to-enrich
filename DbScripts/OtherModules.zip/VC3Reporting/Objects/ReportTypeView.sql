SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3Reporting].[ReportTypeView]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [VC3Reporting].[ReportTypeView]
GO

CREATE VIEW [VC3Reporting].[ReportTypeView]
AS 
	SELECT  rt.Id, rt.Name, rt.IsEditable, rtt.Id AS PrimaryTable, rt.Description
	FROM    VC3Reporting.ReportType rt
		LEFT OUTER JOIN VC3Reporting.ReportTypeTable AS rtt ON rtt.ReportType = rt.Id
	WHERE     (rtt.JoinTable IS NULL)

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

