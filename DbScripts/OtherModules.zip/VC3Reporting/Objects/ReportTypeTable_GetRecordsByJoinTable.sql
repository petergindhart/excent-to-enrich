SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3Reporting].[ReportTypeTable_GetRecordsByJoinTable]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3Reporting].[ReportTypeTable_GetRecordsByJoinTable]
GO


 /*
<summary>
Gets records from the ReportTypeTable table with the specified ids
</summary>
<param name="ids">Ids of the ReportTypeTable(s) to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="False" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE VC3Reporting.ReportTypeTable_GetRecordsByJoinTable
	@ids	uniqueidentifierarray
AS
	SELECT r.JoinTable, r.*
	FROM
		VC3Reporting.ReportTypeTable r INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.JoinTable = Keys.Id
	ORDER BY Sequence, Name

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

