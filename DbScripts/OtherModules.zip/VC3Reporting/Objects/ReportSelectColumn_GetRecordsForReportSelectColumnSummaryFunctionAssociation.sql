SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3Reporting].[ReportSelectColumn_GetRecordsForReportSelectColumnSummaryFunctionAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3Reporting].[ReportSelectColumn_GetRecordsForReportSelectColumnSummaryFunctionAssociation]
GO


 /*
<summary>
Gets records from the ReportSelectColumn table for the specified association 
</summary>
<param name="ids">Ids of the ReportSchemaSummaryFunction(s) </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="False" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE VC3Reporting.ReportSelectColumn_GetRecordsForReportSelectColumnSummaryFunctionAssociation
	@ids chararray
AS
	SELECT ab.SummaryFunction, a.*
	FROM
		VC3Reporting.ReportSelectColumnSummaryFunction ab INNER JOIN
		GetChars(@ids) AS Keys ON ab.SummaryFunction = Keys.Id INNER JOIN
		VC3Reporting.ReportSelectColumn a ON ab.SelectColumn = a.Id

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

