SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3Reporting].[ReportSchemaDataType_GetRecordsForReportSchemaDataTypeOperatorAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3Reporting].[ReportSchemaDataType_GetRecordsForReportSchemaDataTypeOperatorAssociation]
GO


 /*
<summary>
Gets records from the ReportSchemaDataType table for the specified association 
</summary>
<param name="ids">Ids of the ReportSchemaOperator's </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="False" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE VC3Reporting.ReportSchemaDataType_GetRecordsForReportSchemaDataTypeOperatorAssociation 
	@ids uniqueidentifierarray
AS
	SELECT r1.SchemaOperator, r2.*
	FROM
		VC3Reporting.ReportSchemaDataTypeOperator r1 INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r1.SchemaOperator = Keys.Id INNER JOIN
		VC3Reporting.ReportSchemaDataType r2 ON r1.SchemaDataType = r2.Id

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

