SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3Reporting].[ReportColumnGroupColumn_GetRecordsByReport]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3Reporting].[ReportColumnGroupColumn_GetRecordsByReport]
GO


 /*
<summary>
Gets records from the ReportColumn table for the specified ids 
</summary>
<param name="ids">Ids of the Report's </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="False" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE [VC3Reporting].[ReportColumnGroupColumn_GetRecordsByReport] 
	@ids uniqueidentifierarray
AS
	SELECT
		r.Report, r.*, s.*
	FROM
		VC3Reporting.ReportColumn r INNER JOIN
		VC3Reporting.ReportOrderColumn s ON r.Id = s.Id INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.Report = Keys.Id
	WHERE
		Type = 'Y'
	ORDER BY
		Sequence

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

