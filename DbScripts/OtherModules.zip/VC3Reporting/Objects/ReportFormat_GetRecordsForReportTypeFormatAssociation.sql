IF EXISTS (SELECT name 
	   FROM   sysobjects 
	   WHERE  id = object_id('VC3Reporting.ReportFormat_GetRecordsForReportTypeFormatAssociation')
	   AND 	  type = 'P')
    DROP PROCEDURE VC3Reporting.ReportFormat_GetRecordsForReportTypeFormatAssociation
GO

 /*
<summary>
Gets records from the ReportFormat table for the specified association 
</summary>
<param name="ids">Ids of the ReportType(s) </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="False" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE VC3Reporting.ReportFormat_GetRecordsForReportTypeFormatAssociation
	@ids chararray
AS
	SELECT ab.ReportType, a.*
	FROM
		VC3Reporting.ReportTypeFormat ab INNER JOIN
		GetChars(@ids) AS Keys ON ab.ReportType = Keys.Id INNER JOIN
		VC3Reporting.ReportFormat a ON ab.ReportFormat = a.Id ORDER BY ab.Sequence
GO