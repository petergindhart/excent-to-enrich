SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3Reporting].[ReportSchemaDataType_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3Reporting].[ReportSchemaDataType_UpdateRecord]
GO


 /*
<summary>
Updates a record in the ReportSchemaDataType table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<param name="valueEditor">Value to assign to the ValueEditor field of the record</param>
<param name="optionEditor">Value to assign to the OptionEditor field of the record</param>
<param name="typeName">Value to assign to the TypeName field of the record</param>
<param name="format">Value to assign to the Format field of the record</param>
<param name="sqlExpression">Value to assign to the SqlExpression field of the record</param>
<param name="defaultColumnWidth">Value to assign to the DefaultColumnWidth field of the record</param>
<param name="controlName">Name of the control contained within the configuration settings</param>

<model isGenerated="False" returnType="System.Void" />
*/
CREATE PROCEDURE VC3Reporting.ReportSchemaDataType_UpdateRecord 
	@id char(1),
	@name varchar(20),
	@valueEditor varchar(200),
	@optionEditor varchar(200),
	@typeName varchar(50),
	@format varchar(20),
	@sqlExpression varchar(50),
	@defaultColumnWidth decimal,
	@controlName varchar(50)
AS
	UPDATE VC3Reporting.ReportSchemaDataType
	SET
		Name = @name,
		ValueEditor = @valueEditor,
		OptionEditor = @optionEditor,
		TypeName = @typeName,
		Format = @format,
		SqlExpression = @sqlExpression,
		DefaultColumnWidth = @defaultColumnWidth,
		ControlName = @controlName
	WHERE Id = @id

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

