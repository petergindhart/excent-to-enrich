SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3Reporting].[ReportSchemaTableParameter_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3Reporting].[ReportSchemaTableParameter_InsertRecord]
GO


 /*
<summary>
Inserts a new record into the ReportSchemaTableParameter table with the specified values
</summary>
<param name="name">Value to assign to the Name field of the record</param>
<param name="isRequired">Value to assign to the IsRequired field of the record</param>
<param name="sequence">Value to assign to the Sequence field of the record</param>
<param name="schemaColumn">Value to assign to the SchemaColumn field of the record</param>
<param name="schemaOperator">Value to assign to the SchemaOperator field of the record</param>
<param name="schemaTable">Value to assign to the SchemaTable field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="False" returnType="System.Guid" />
*/
CREATE PROCEDURE VC3Reporting.ReportSchemaTableParameter_InsertRecord 
	@name varchar(50),
	@isRequired bit,
	@sequence int,
	@schemaColumn uniqueidentifier,
	@schemaOperator uniqueidentifier,
	@schemaTable uniqueidentifier
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
INSERT INTO VC3Reporting.ReportSchemaTableParameter
	(

		Id,
		Name,
		IsRequired,
		Sequence,
		SchemaColumn,
		SchemaOperator,
		SchemaTable
	)
	VALUES
	(

		@id,
		@name,
		@isRequired,
		@sequence,
		@schemaColumn,
		@schemaOperator,
		@schemaTable
	)

	SELECT @id

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

