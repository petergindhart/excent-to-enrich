/****** Object:  StoredProcedure [VC3Reporting].[ReportSchemaColumnAllowedValue_DeleteRecord]    Script Date: 01/27/2009 13:56:21 ******/
IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[VC3Reporting].[ReportSchemaColumnAllowedValue_DeleteRecord]') AND type in (N'P', N'PC'))
DROP PROCEDURE [VC3Reporting].[ReportSchemaColumnAllowedValue_DeleteRecord]
GO

/****** Object:  StoredProcedure [VC3Reporting].[ReportSchemaColumnAllowedValue_DeleteRecord]    Script Date: 01/27/2009 13:56:21 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
<summary>
Deletes a ReportSchemaColumnAllowedValue record
</summary>

<model isGenerated="False" returnType="System.Void" />
*/
CREATE PROCEDURE [VC3Reporting].[ReportSchemaColumnAllowedValue_DeleteRecord]
	@id uniqueidentifier
AS
	DELETE FROM 
		ReportSchemaColumnAllowedValue
	WHERE
		Id = @id		


GO


