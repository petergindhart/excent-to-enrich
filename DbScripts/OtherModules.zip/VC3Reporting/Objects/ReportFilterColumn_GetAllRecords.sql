IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[VC3Reporting].[ReportFilterColumn_GetAllRecords]') AND type in (N'P', N'PC'))
DROP PROCEDURE [VC3Reporting].[ReportFilterColumn_GetAllRecords]

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

 /*
<summary>
Gets all records from the ReportFilterColumn table
</summary>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="False" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE [VC3Reporting].[ReportFilterColumn_GetAllRecords]
AS
	SELECT r.*, a.*
	FROM
		VC3Reporting.ReportFilterColumn r INNER jOIN
		VC3Reporting.ReportColumn a on r.id=a.id
