SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3Reporting].[ReportTypeTable_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3Reporting].[ReportTypeTable_UpdateRecord]
GO


 /*
<summary>
Updates a record in the ReportTypeTable table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<param name="sequence">Value to assign to the Sequence field of the record</param>
<param name="joinExpression">Value to assign to the JoinExpression field of the record</param>
<param name="columnPrefix">Value to assign to the ColumnPrefix field of the record</param>
<param name="joinMultiplicity">Value to assign to the JoinMultiplicity field of the record</param>
<param name="schemaTable">Value to assign to the SchemaTable field of the record</param>
<param name="reportType">Value to assign to the ReportType field of the record</param>
<param name="joinTable">Value to assign to the JoinTable field of the record</param>

<model isGenerated="False" returnType="System.Void" />
*/
CREATE PROCEDURE VC3Reporting.ReportTypeTable_UpdateRecord
	@id uniqueidentifier,
	@name varchar(50),
	@sequence int,
	@joinExpression varchar(200),
	@columnPrefix varchar(50),
	@joinMultiplicity char(1),
	@schemaTable uniqueidentifier,
	@reportType char(1),
	@joinTable uniqueidentifier,
	@mergeColumnsIntoJoinTable bit = 0
AS
	UPDATE VC3Reporting.ReportTypeTable
	SET
		Name = @name,
		Sequence = @sequence,
		JoinExpression = @joinExpression,
		ColumnPrefix = @columnPrefix,
		JoinMultiplicity = @joinMultiplicity,
		SchemaTable = @schemaTable,
		ReportType = @reportType,
		JoinTable = @joinTable,
		MergeColumnsIntoJoinTable = @mergeColumnsIntoJoinTable
	WHERE Id = @id		

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

