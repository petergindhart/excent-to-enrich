 IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[VC3Reporting].[Report_UpdateRecord]') AND type in (N'P', N'PC'))
DROP PROCEDURE [VC3Reporting].[Report_UpdateRecord]

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
 /*
<summary>
Updates a record in the Report table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="title">Value to assign to the Title field of the record</param>
<param name="query">Value to assign to the Query field of the record</param>
<param name="owner">Value to assign to the Owner field of the record</param>
<param name="type">Value to assign to the Type field of the record</param>
<param name="path">Value to assign to the Path field of the record</param>
<param name="description">Value to assign to the Description field of the record</param>
<param name="format">Value to assign to the Format field of the record</param>

<model isGenerated="False" returnType="System.Void" />
*/
CREATE PROCEDURE [VC3Reporting].[Report_UpdateRecord]
	@id uniqueidentifier, 
	@title varchar(200), 
	@query text,
	@type char(1), 
	@path varchar(300), 
	@description text, 
	@format char(1)
AS
	UPDATE VC3Reporting.Report
	SET
		Title = @title, 
		Query = @query, 
		Type = @type, 
		Path = @path, 
		Description = @description, 
		Format = @format
	WHERE 
		Id = @id