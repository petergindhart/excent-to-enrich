if exists (select * from dbo.sysobjects where id = object_id(N'[VC3Reporting].[Report_DeleteRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3Reporting].[Report_DeleteRecord]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Deletes a Report record
</summary>

<model isGenerated="False" returnType="System.Void" />
*/
CREATE PROCEDURE VC3Reporting.Report_DeleteRecord
	@id uniqueidentifier
AS
	DELETE FROM 
		VC3Reporting.Report
	WHERE
		Id = @id
