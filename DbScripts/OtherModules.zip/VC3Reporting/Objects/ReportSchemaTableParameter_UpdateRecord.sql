SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3Reporting].[ReportSchemaTableParameter_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3Reporting].[ReportSchemaTableParameter_UpdateRecord]
GO


 /*
<summary>
Updates a record in the ReportSchemaTableParameter table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<param name="isRequired">Value to assign to the IsRequired field of the record</param>
<param name="sequence">Value to assign to the Sequence field of the record</param>
<param name="schemaColumn">Value to assign to the SchemaColumn field of the record</param>
<param name="schemaOperator">Value to assign to the SchemaOperator field of the record</param>
<param name="schemaTable">Value to assign to the SchemaTable field of the record</param>

<model isGenerated="False" returnType="System.Void" />
*/
CREATE PROCEDURE VC3Reporting.ReportSchemaTableParameter_UpdateRecord 
	@id uniqueidentifier,
	@name varchar(50),
	@isRequired bit,
	@sequence int,
	@schemaColumn uniqueidentifier,
	@schemaOperator uniqueidentifier,
	@schemaTable uniqueidentifier
AS
	UPDATE VC3Reporting.ReportSchemaTableParameter
	SET
		Name = @name,
		IsRequired = @isRequired,
		Sequence = @sequence,
		SchemaColumn = @schemaColumn,
		SchemaOperator = @schemaOperator,
		SchemaTable = @schemaTable
	WHERE Id = @id

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

