/****** Object:  StoredProcedure [VC3Reporting].[ReportSchemaColumnAllowedValue_GetAllRecords]    Script Date: 01/27/2009 13:56:24 ******/
IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[VC3Reporting].[ReportSchemaColumnAllowedValue_GetAllRecords]') AND type in (N'P', N'PC'))
DROP PROCEDURE [VC3Reporting].[ReportSchemaColumnAllowedValue_GetAllRecords]
GO

/****** Object:  StoredProcedure [VC3Reporting].[ReportSchemaColumnAllowedValue_GetAllRecords]    Script Date: 01/27/2009 13:56:24 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

 /*
<summary>
Gets all records from the ReportSchemaColumnAllowedValue table
</summary>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="False" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE [VC3Reporting].[ReportSchemaColumnAllowedValue_GetAllRecords]
AS
	SELECT
		r.*
	FROM
		ReportSchemaColumnAllowedValue r
	ORDER BY r.Name
GO


