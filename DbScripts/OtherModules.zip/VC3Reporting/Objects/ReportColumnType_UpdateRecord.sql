SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3Reporting].[ReportColumnType_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3Reporting].[ReportColumnType_UpdateRecord]
GO


 /*
<summary>
Updates a record in the ReportColumnType table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>

<model isGenerated="False" returnType="System.Void" />
*/
CREATE PROCEDURE VC3Reporting.ReportColumnType_UpdateRecord
	@id char(1), 
	@name varchar(50)
AS
	UPDATE VC3Reporting.ReportColumnType
	SET
		Name = @name
	WHERE 
		Id = @id

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

