/****** Object:  StoredProcedure [VC3Reporting].[ReportSchemaColumnAllowedValue_UpdateRecord]    Script Date: 01/27/2009 13:56:38 ******/
IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[VC3Reporting].[ReportSchemaColumnAllowedValue_UpdateRecord]') AND type in (N'P', N'PC'))
DROP PROCEDURE [VC3Reporting].[ReportSchemaColumnAllowedValue_UpdateRecord]
GO

/****** Object:  StoredProcedure [VC3Reporting].[ReportSchemaColumnAllowedValue_UpdateRecord]    Script Date: 01/27/2009 13:56:38 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
<summary>
Updates a record in the ReportSchemaColumnAllowedValue table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="schemaColumn">Value to assign to the SchemaColumn field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<param name="value">Value to assign to the Value field of the record</param>
<param name="isDynamic">Value to assign to the IsDynamic field of the record</param>

<model isGenerated="False" returnType="System.Void" />
*/
CREATE PROCEDURE [VC3Reporting].[ReportSchemaColumnAllowedValue_UpdateRecord]
	@id uniqueidentifier, 
	@schemaColumn uniqueidentifier, 
	@name varchar(100), 
	@value varchar(100), 
	@isDynamic bit
AS
	UPDATE ReportSchemaColumnAllowedValue
	SET
		SchemaColumn = @schemaColumn, 
		Name = @name, 
		Value = @value, 
		IsDynamic = @isDynamic
	WHERE 
		Id = @id

GO


