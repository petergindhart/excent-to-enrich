ALTER TABLE vc3reporting.ReportSchemaOperator
	ALTER COLUMN Expression varchar(250) not null