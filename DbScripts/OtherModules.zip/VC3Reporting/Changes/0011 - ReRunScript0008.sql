/*
 * There was a bug in script 0008 that incorrectly joined syscolumns
 * while looking for inheritance constraints.  This ensures the corrected
 * version is executed on systems that have already run script 0008.
*/

--#include 0008 - CascadeDeleteReportSubclass.sql