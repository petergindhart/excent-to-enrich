ALTER TABLE VC3Reporting.ReportSchemaColumn
ADD ParentSchemaColumn uniqueidentifier
GO

ALTER TABLE VC3Reporting.ReportSchemaColumn ADD CONSTRAINT
FK_ReportSchemaColumn#Parent#Children FOREIGN KEY (ParentSchemaColumn) 
REFERENCES VC3Reporting.ReportSchemaColumn (Id) 
	ON UPDATE  NO ACTION 
	ON DELETE  NO ACTION
GO