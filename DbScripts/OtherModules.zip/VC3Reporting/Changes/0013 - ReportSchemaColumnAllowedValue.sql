CREATE TABLE VC3Reporting.ReportSchemaColumnAllowedValue
	(
	Id uniqueidentifier NOT NULL,
	SchemaColumn uniqueidentifier NOT NULL,
	Name varchar(100) NOT NULL,
	Value varchar(100) NOT NULL,
	IsDynamic bit NOT NULL
	)  ON [PRIMARY]
GO
ALTER TABLE VC3Reporting.ReportSchemaColumnAllowedValue ADD CONSTRAINT
	DF_ReportSchemaColumnAllowedValue_IsDynamic DEFAULT 0 FOR IsDynamic
GO
ALTER TABLE VC3Reporting.ReportSchemaColumnAllowedValue ADD CONSTRAINT
	PK_ReportSchemaColumnAllowedValue PRIMARY KEY CLUSTERED 
	(
	Id
	) ON [PRIMARY]

GO
ALTER TABLE VC3Reporting.ReportSchemaColumnAllowedValue ADD CONSTRAINT
	FK_ReportSchemaColumnAllowedValue#SchemaColumn#NonQueriedAllowedValues FOREIGN KEY
	(
	SchemaColumn
	) REFERENCES VC3Reporting.ReportSchemaColumn
	(
	Id
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE VC3Reporting.ReportFilterValue ADD
	IsDynamic bit NULL
GO
ALTER TABLE VC3Reporting.ReportFilterValue ADD CONSTRAINT
	DF_ReportFilterValue_IsDynamic DEFAULT 0 FOR IsDynamic
GO
UPDATE VC3Reporting.ReportFilterValue SET IsDynamic = 0
GO
alter table VC3Reporting.ReportFilterValue alter column IsDynamic bit not null
GO