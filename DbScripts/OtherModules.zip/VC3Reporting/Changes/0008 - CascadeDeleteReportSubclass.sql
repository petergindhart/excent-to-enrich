-- Ensure that the relationship between application and VC3Reporting tables for
-- classes implementing InheritanceScheme contain a cascade delete

-- Report
if exists( select * from sysobjects where id = object_id('[dbo].[Report]') )
begin
	if exists( 
		select *
		from
			sysconstraints n join
			syscolumns l on n.colid = l.colid and n.id = l.id join
			sysobjects c on c.id = n.constid
		where 
			n.id = object_id('[dbo].[Report]') and
			l.name = 'id' and
			c.name = 'FK_Report#VC3Reporting_Report')
		begin			
			ALTER TABLE [dbo].[Report] DROP 
			CONSTRAINT [FK_Report#VC3Reporting_Report]

			ALTER TABLE [dbo].[Report] ADD 
			CONSTRAINT [FK_Report#VC3Reporting_Report] FOREIGN KEY ([ID]) 
			REFERENCES [VC3Reporting].[Report] ([Id])
			ON DELETE CASCADE
		end
end

-- ReportColumn
if exists( select * from sysobjects where id = object_id('[dbo].[ReportColumn]') )
begin
	if exists( 
		select *
		from
			sysconstraints n join
			syscolumns l on n.colid = l.colid and n.id = l.id join
			sysobjects c on c.id = n.constid
		where 
			n.id = object_id('[dbo].[ReportColumn]') and
			l.name = 'id' and
			c.name = 'FK_ReportColumn#VC3Reporting_ReportColumn')
		begin			
			ALTER TABLE [dbo].[ReportColumn] DROP 
			CONSTRAINT [FK_ReportColumn#VC3Reporting_ReportColumn]

			ALTER TABLE [dbo].[ReportColumn] ADD 
			CONSTRAINT [FK_ReportColumn#VC3Reporting_ReportColumn] FOREIGN KEY ([ID]) 
			REFERENCES [VC3Reporting].[ReportColumn] ([Id])
			ON DELETE CASCADE
		end
end

-- ReportSchemaColumn
if exists( select * from sysobjects where id = object_id('[dbo].[ReportSchemaColumn]') )
begin
	if exists( 
		select *
		from
			sysconstraints n join
			syscolumns l on n.colid = l.colid and n.id = l.id join
			sysobjects c on c.id = n.constid
		where 
			n.id = object_id('[dbo].[ReportSchemaColumn]') and
			l.name = 'id' and
			c.name = 'FK_ReportSchemaColumn#VC3Reporting_ReportSchemaColumn')
		begin			
			ALTER TABLE [dbo].[ReportSchemaColumn] DROP 
			CONSTRAINT [FK_ReportSchemaColumn#VC3Reporting_ReportSchemaColumn]

			ALTER TABLE [dbo].[ReportSchemaColumn] ADD 
			CONSTRAINT [FK_ReportSchemaColumn#VC3Reporting_ReportSchemaColumn] FOREIGN KEY ([ID]) 
			REFERENCES [VC3Reporting].[ReportSchemaColumn] ([Id])
			ON DELETE CASCADE
		end
end

-- ReportSchemaTable
if exists( select * from sysobjects where id = object_id('[dbo].[ReportSchemaTable]') )
begin
	if exists( 
		select *
		from
			sysconstraints n join
			syscolumns l on n.colid = l.colid and n.id = l.id join
			sysobjects c on c.id = n.constid
		where 
			n.id = object_id('[dbo].[ReportSchemaTable]') and
			l.name = 'id' and
			c.name = 'FK_ReportSchemaTable#VC3Reporting_ReportSchemaTable')
		begin			
			ALTER TABLE [dbo].[ReportSchemaTable] DROP 
			CONSTRAINT [FK_ReportSchemaTable#VC3Reporting_ReportSchemaTable]

			ALTER TABLE [dbo].[ReportSchemaTable] ADD 
			CONSTRAINT [FK_ReportSchemaTable#VC3Reporting_ReportSchemaTable] FOREIGN KEY ([ID]) 
			REFERENCES [VC3Reporting].[ReportSchemaTable] ([Id])
			ON DELETE CASCADE
		end
end

-- ReportType
if exists( select * from sysobjects where id = object_id('[dbo].[ReportType]') )
begin
	if exists( 
		select *
		from
			sysconstraints n join
			syscolumns l on n.colid = l.colid and n.id = l.id join
			sysobjects c on c.id = n.constid
		where 
			n.id = object_id('[dbo].[ReportType]') and
			l.name = 'id' and
			c.name = 'FK_ReportType#VC3Reporting_ReportType')
		begin			
			ALTER TABLE [dbo].[ReportType] DROP 
			CONSTRAINT [FK_ReportType#VC3Reporting_ReportType]

			ALTER TABLE [dbo].[ReportType] ADD 
			CONSTRAINT [FK_ReportType#VC3Reporting_ReportType] FOREIGN KEY ([ID]) 
			REFERENCES [VC3Reporting].[ReportType] ([Id])
			ON DELETE CASCADE
		end
end