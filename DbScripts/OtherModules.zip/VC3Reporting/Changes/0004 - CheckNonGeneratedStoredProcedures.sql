IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportColumnGroupColumn_GetRecordsByReport]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[ReportColumnGroupColumn_GetRecordsByReport] 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportColumnParameterValue_GetRecordsByReportColumn]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[ReportColumnParameterValue_GetRecordsByReportColumn]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportColumn_GetRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[ReportColumn_GetRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportColumn_GetRecordsByAllowGrouping]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[ReportColumn_GetRecordsByAllowGrouping]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportColumn_GetRecordsForFilter]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[ReportColumn_GetRecordsForFilter]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportFilterOperator_GetAllRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[ReportFilterOperator_GetAllRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportFilterOperator_GetRecordsAllowedForColumn]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[ReportFilterOperator_GetRecordsAllowedForColumn]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportFilterValue_GetRecordsAllowedForColumn]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[ReportFilterValue_GetRecordsAllowedForColumn]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportGroupColumn_GetRecordsByReport]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[ReportGroupColumn_GetRecordsByReport]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaColumn_GetRecordsBySchemaTable]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[ReportSchemaColumn_GetRecordsBySchemaTable]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSummaryFunction_GetAllRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[ReportSummaryFunction_GetAllRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSummaryFunction_GetRecordsForCol]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[ReportSummaryFunction_GetRecordsForCol]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportTypeColumn_GetRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[ReportTypeColumn_GetRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportTypeColumn_GetRecordsByReportTypeTable]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[ReportTypeColumn_GetRecordsByReportTypeTable]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportViewer_GetAllRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[ReportViewer_GetAllRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Report_IsUniqueTitle]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Report_IsUniqueTitle]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Report_Search]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Report_Search]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Report_RunReport]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Report_RunReport]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Report_GetAllRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Report_GetAllRecords]
GO