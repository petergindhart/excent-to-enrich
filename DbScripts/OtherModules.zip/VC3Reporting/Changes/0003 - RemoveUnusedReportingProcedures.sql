/*Remove all the auto gen stored procedures that are not used anymore.*/

declare @procedureName as varchar(500)
declare procCursor cursor for
select so.name
from sysobjects so
	inner join syscomments sc on so.id = sc.id
where 
	so.name like 'Report_%' and 
	type='P' and 
	sc.colid = 1 and 
	charindex('isGenerated="True"', sc.text, 0) > 0
	and so.name in (	'ReportDataTypeOperator_DeleteRecord',
				'ReportDataTypeOperator_GetRecords',
				'ReportDataTypeOperator_InsertRecord',
				'ReportDataTypeOperator_UpdateRecord',
				'ReportDataType_DeleteRecord',
				'ReportDataType_GetRecords',
				'ReportDataType_InsertRecord',
				'ReportDataType_UpdateRecord',
				'ReportFilterOperator_DeleteRecord',
				'ReportFilterOperator_GetRecords',
				'ReportFilterOperator_InsertRecord',
				'ReportFilterOperator_UpdateRecord',
				'ReportFilterValue_DeleteRecord',
				'ReportFilterValue_GetAllRecords',
				'ReportFilterValue_GetRecords',
				'ReportFilterValue_GetRecordsByFilter',
				'ReportFilterValue_GetRecordsByFilterColumn',
				'ReportFilterValue_InsertRecord',
				'ReportFilterValue_UpdateRecord',
				'ReportFilter_DeleteRecord',
				'ReportFilter_GetRecords',
				'ReportFilter_GetRecordsByReportId',
				'ReportFilter_InsertRecord',
				'ReportFilter_UpdateRecord',
				'ReportSchemaJoinType_InsertRecord',
				'ReportSchemaJoinType_UpdateRecord',
				'ReportSchemaTableAssociation_DeleteRecord',
				'ReportSchemaTableAssociation_GetRecords',
				'ReportSchemaTableAssociation_InsertRecord',
				'ReportSchemaTableAssociation_UpdateRecord',
				'ReportSchemaTableParameter_DeleteRecord',
				'ReportSchemaTableParameter_GetAllRecords',
				'ReportSchemaTableParameter_GetRecords',
				'ReportSchemaTableParameter_GetRecordsBySchemaTable',
				'ReportSchemaTableParameter_GetRecordsByTable',
				'ReportSchemaTableParameter_InsertRecord',
				'ReportSchemaTableParameter_UpdateRecord',
				'ReportSortOrder_DeleteRecord',
				'ReportSortOrder_GetRecords',
				'ReportSortOrder_GetRecordsByReportId',
				'ReportSortOrder_InsertRecord',
				'ReportSortOrder_UpdateRecord',
				'ReportSummaryFunction_DeleteRecord',
				'ReportSummaryFunction_GetRecords',
				'ReportSummaryFunction_InsertRecord',
				'ReportSummaryFunction_UpdateRecord',
				'ReportTableAssociation_DeleteRecord',
				'ReportTableAssociation_GetRecords',
				'ReportTableAssociation_InsertRecord',
				'ReportTableAssociation_UpdateRecord',
				'ReportTable_DeleteRecord',
				'ReportTable_GetRecords',
				'ReportTable_InsertRecord',
				'ReportTable_UpdateRecord')

open procCursor
fetch next from procCursor into @procedureName
declare @sql varchar(8000)

WHILE @@Fetch_status = 0
BEGIN
	set @sql = 'IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N''[dbo].[' + @procedureName + ']'') AND type in (N''P'', N''PC''))
			DROP PROCEDURE [dbo].[' + @procedureName + ']'

	--print (@sql)
	exec (@sql)

	fetch next from procCursor into @procedureName
END
	
CLOSE procCursor
DEALLOCATE procCursor