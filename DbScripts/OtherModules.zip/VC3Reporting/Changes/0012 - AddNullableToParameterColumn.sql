alter table VC3Reporting.ReportFilterColumn add Nullable bit default 0
go
update VC3Reporting.ReportFilterColumn set Nullable = 0
go
alter table VC3Reporting.ReportFilterColumn alter column Nullable bit not null
go