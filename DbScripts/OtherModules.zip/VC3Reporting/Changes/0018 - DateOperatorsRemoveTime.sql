--Original Operator ID: 111CFCB0-55B3-4D4A-8F8C-046B7270B111
INSERT INTO VC3Reporting.ReportSchemaOperator
VALUES('57293193-B1B5-47A4-BB51-DFE9CCF7BEFB','After','CONVERT(DATETIME, CONVERT(CHAR, {0}, 106))>{1}','or',NULL,NULL,2,0)

INSERT INTO VC3Reporting.ReportSchemaDataTypeOperator
VALUES('D','57293193-B1B5-47A4-BB51-DFE9CCF7BEFB')

DELETE FROM VC3Reporting.ReportSchemaDataTypeOperator
WHERE SchemaDataType = 'D' AND SchemaOperator = '111CFCB0-55B3-4D4A-8F8C-046B7270B111'

UPDATE p
SET p.SchemaOperator = '57293193-B1B5-47A4-BB51-DFE9CCF7BEFB'
FROM VC3Reporting.ReportSchemaTableParameter p JOIN
VC3Reporting.ReportSchemaColumn sc ON sc.Id = p.SchemaColumn
WHERE sc.SchemaDataType = 'D' AND p.SchemaOperator = '111CFCB0-55B3-4D4A-8F8C-046B7270B111'

UPDATE f
SET f.SchemaOperator = '57293193-B1B5-47A4-BB51-DFE9CCF7BEFB'
FROM VC3Reporting.ReportFilterColumn f JOIN
VC3Reporting.ReportColumn rc ON rc.Id = f.Id JOIN
VC3Reporting.ReportSchemaColumn sc ON sc.Id = rc.SchemaColumn
WHERE sc.SchemaDataType = 'D' AND f.SchemaOperator = '111CFCB0-55B3-4D4A-8F8C-046B7270B111'


--Original Operator ID: 222CFCB0-55B3-4D4A-8F8C-046B7270B222
INSERT INTO VC3Reporting.ReportSchemaOperator
VALUES('F1639C3C-1703-4EFC-A3B2-CE08689B4665','Before','CONVERT(DATETIME, CONVERT(CHAR, {0}, 106))<{1}','or',NULL,NULL,4,0)

INSERT INTO VC3Reporting.ReportSchemaDataTypeOperator
VALUES('D','F1639C3C-1703-4EFC-A3B2-CE08689B4665')

DELETE FROM VC3Reporting.ReportSchemaDataTypeOperator
WHERE SchemaDataType = 'D' AND SchemaOperator = '222CFCB0-55B3-4D4A-8F8C-046B7270B222'

UPDATE p
SET p.SchemaOperator = 'F1639C3C-1703-4EFC-A3B2-CE08689B4665'
FROM VC3Reporting.ReportSchemaTableParameter p JOIN
VC3Reporting.ReportSchemaColumn sc ON sc.Id = p.SchemaColumn
WHERE sc.SchemaDataType = 'D' AND p.SchemaOperator = '222CFCB0-55B3-4D4A-8F8C-046B7270B222'

UPDATE f
SET f.SchemaOperator = 'F1639C3C-1703-4EFC-A3B2-CE08689B4665'
FROM VC3Reporting.ReportFilterColumn f JOIN
VC3Reporting.ReportColumn rc ON rc.Id = f.Id JOIN
VC3Reporting.ReportSchemaColumn sc ON sc.Id = rc.SchemaColumn
WHERE sc.SchemaDataType = 'D' AND f.SchemaOperator = '222CFCB0-55B3-4D4A-8F8C-046B7270B222'


--Original Operator ID: 41BA0544-6400-4E61-B1DD-378743A7D145
INSERT INTO VC3Reporting.ReportSchemaOperator
VALUES('9F755A20-CA54-4F27-9730-FDEC2C6AEE93','Is','CONVERT(DATETIME, CONVERT(CHAR, {0}, 106))={1}','or',NULL,NULL,0,1)

INSERT INTO VC3Reporting.ReportSchemaDataTypeOperator
VALUES('D','9F755A20-CA54-4F27-9730-FDEC2C6AEE93')

DELETE FROM VC3Reporting.ReportSchemaDataTypeOperator
WHERE SchemaDataType = 'D' AND SchemaOperator = '41BA0544-6400-4E61-B1DD-378743A7D145'

UPDATE p
SET p.SchemaOperator = '9F755A20-CA54-4F27-9730-FDEC2C6AEE93'
FROM VC3Reporting.ReportSchemaTableParameter p JOIN
VC3Reporting.ReportSchemaColumn sc ON sc.Id = p.SchemaColumn
WHERE sc.SchemaDataType = 'D' AND p.SchemaOperator = '41BA0544-6400-4E61-B1DD-378743A7D145'

UPDATE f
SET f.SchemaOperator = '9F755A20-CA54-4F27-9730-FDEC2C6AEE93'
FROM VC3Reporting.ReportFilterColumn f JOIN
VC3Reporting.ReportColumn rc ON rc.Id = f.Id JOIN
VC3Reporting.ReportSchemaColumn sc ON sc.Id = rc.SchemaColumn
WHERE sc.SchemaDataType = 'D' AND f.SchemaOperator = '41BA0544-6400-4E61-B1DD-378743A7D145'


--Original Operator ID: 15436771-0939-470B-8B4A-DCF650F56C3D
INSERT INTO VC3Reporting.ReportSchemaOperator
VALUES('E90E40FE-9828-4DCA-9E40-33E13FFAE9EE','Is Not','CONVERT(DATETIME, CONVERT(CHAR, {0}, 106))!={1}','and',NULL,NULL,1,1)

INSERT INTO VC3Reporting.ReportSchemaDataTypeOperator
VALUES('D','E90E40FE-9828-4DCA-9E40-33E13FFAE9EE')

DELETE FROM VC3Reporting.ReportSchemaDataTypeOperator
WHERE SchemaDataType = 'D' AND SchemaOperator = '15436771-0939-470B-8B4A-DCF650F56C3D'

UPDATE p
SET p.SchemaOperator = 'E90E40FE-9828-4DCA-9E40-33E13FFAE9EE'
FROM VC3Reporting.ReportSchemaTableParameter p JOIN
VC3Reporting.ReportSchemaColumn sc ON sc.Id = p.SchemaColumn
WHERE sc.SchemaDataType = 'D' AND p.SchemaOperator = '15436771-0939-470B-8B4A-DCF650F56C3D'

UPDATE f
SET f.SchemaOperator = 'E90E40FE-9828-4DCA-9E40-33E13FFAE9EE'
FROM VC3Reporting.ReportFilterColumn f JOIN
VC3Reporting.ReportColumn rc ON rc.Id = f.Id JOIN
VC3Reporting.ReportSchemaColumn sc ON sc.Id = rc.SchemaColumn
WHERE sc.SchemaDataType = 'D' AND f.SchemaOperator = '15436771-0939-470B-8B4A-DCF650F56C3D'


--Original Operator ID: 333CFCB0-55B3-4D4A-8F8C-046B7270B333
INSERT INTO VC3Reporting.ReportSchemaOperator
VALUES('C0101377-1648-4106-B16D-42662F7F260D','On Or After','CONVERT(DATETIME, CONVERT(CHAR, {0}, 106))>={1}','or',NULL,NULL,3,0)

INSERT INTO VC3Reporting.ReportSchemaDataTypeOperator
VALUES('D','C0101377-1648-4106-B16D-42662F7F260D')

DELETE FROM VC3Reporting.ReportSchemaDataTypeOperator
WHERE SchemaDataType = 'D' AND SchemaOperator = '333CFCB0-55B3-4D4A-8F8C-046B7270B333'

UPDATE p
SET p.SchemaOperator = 'C0101377-1648-4106-B16D-42662F7F260D'
FROM VC3Reporting.ReportSchemaTableParameter p JOIN
VC3Reporting.ReportSchemaColumn sc ON sc.Id = p.SchemaColumn
WHERE sc.SchemaDataType = 'D' AND p.SchemaOperator = '333CFCB0-55B3-4D4A-8F8C-046B7270B333'

UPDATE f
SET f.SchemaOperator = 'C0101377-1648-4106-B16D-42662F7F260D'
FROM VC3Reporting.ReportFilterColumn f JOIN
VC3Reporting.ReportColumn rc ON rc.Id = f.Id JOIN
VC3Reporting.ReportSchemaColumn sc ON sc.Id = rc.SchemaColumn
WHERE sc.SchemaDataType = 'D' AND f.SchemaOperator = '333CFCB0-55B3-4D4A-8F8C-046B7270B333'


--Original Operator ID: 444CFCB0-55B3-4D4A-8F8C-046B7270B444
INSERT INTO VC3Reporting.ReportSchemaOperator
VALUES('8E9920AE-07CE-4DAB-9262-CE90A76FCDFE','On Or Before','CONVERT(DATETIME, CONVERT(CHAR, {0}, 106))<={1}','or',NULL,NULL,5,0)

INSERT INTO VC3Reporting.ReportSchemaDataTypeOperator
VALUES('D','8E9920AE-07CE-4DAB-9262-CE90A76FCDFE')

DELETE FROM VC3Reporting.ReportSchemaDataTypeOperator
WHERE SchemaDataType = 'D' AND SchemaOperator = '444CFCB0-55B3-4D4A-8F8C-046B7270B444'

UPDATE p
SET p.SchemaOperator = '8E9920AE-07CE-4DAB-9262-CE90A76FCDFE'
FROM VC3Reporting.ReportSchemaTableParameter p JOIN
VC3Reporting.ReportSchemaColumn sc ON sc.Id = p.SchemaColumn
WHERE sc.SchemaDataType = 'D' AND p.SchemaOperator = '444CFCB0-55B3-4D4A-8F8C-046B7270B444'

UPDATE f
SET f.SchemaOperator = '8E9920AE-07CE-4DAB-9262-CE90A76FCDFE'
FROM VC3Reporting.ReportFilterColumn f JOIN
VC3Reporting.ReportColumn rc ON rc.Id = f.Id JOIN
VC3Reporting.ReportSchemaColumn sc ON sc.Id = rc.SchemaColumn
WHERE sc.SchemaDataType = 'D' AND f.SchemaOperator = '444CFCB0-55B3-4D4A-8F8C-046B7270B444'