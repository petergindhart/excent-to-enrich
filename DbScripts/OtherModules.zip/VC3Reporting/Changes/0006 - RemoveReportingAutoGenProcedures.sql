/*Remove all the auto gen stored procedures 
 They will be created with object scripts*/

declare @procedureName as varchar(500)
declare procCursor cursor for
select so.name
from sysobjects so
	inner join syscomments sc on so.id = sc.id
	inner join sysusers u on so.uid=u.uid
where 
	so.name like 'Report_%' and 
	type='P' and 
	sc.colid = 1 and 
	charindex('isGenerated="True"', sc.text, 0) > 0 and
	u.name = 'dbo'
	and so.name in (
'Report_GetRecords',
'Report_GetRecordsByFormat',
'Report_GetRecordsByType',
'Report_InsertRecord',
'Report_UpdateRecord',
'ReportColumn_DeleteRecord',
'ReportColumn_GetAllRecords',
'ReportColumn_GetRecords',
'ReportColumn_GetRecordsByReport',
'ReportColumn_GetRecordsByReportTypeTable',
'ReportColumn_UpdateRecord',
'ReportColumnGroupColumn_GetRecordsByReport',
'ReportColumnParameterValue_DeleteRecord',
'ReportColumnParameterValue_GetAllRecords',
'ReportColumnParameterValue_GetRecords',
'ReportColumnParameterValue_GetRecordsByParameter',
'ReportColumnParameterValue_InsertRecord',
'ReportColumnParameterValue_UpdateRecord',
'ReportColumnType_DeleteRecord',
'ReportColumnType_GetAllRecords',
'ReportColumnType_GetRecords',
'ReportColumnType_InsertRecord',
'ReportColumnType_UpdateRecord',
'ReportFilterColumn_DeleteRecord',
'ReportFilterColumn_GetAllRecords',
'ReportFilterColumn_GetRecords',
'ReportFilterColumn_GetRecordsByOperator',
'ReportFilterColumn_GetRecordsByReport',
'ReportFilterColumn_InsertRecord',
'ReportFilterColumn_UpdateRecord',
'ReportFormat_DeleteRecord',
'ReportFormat_GetAllRecords',
'ReportFormat_GetRecords',
'ReportFormat_InsertRecord',
'ReportFormat_UpdateRecord',
'ReportGroupColumn_GetRecordsByReport',
'ReportOrderColumn_DeleteRecord',
'ReportOrderColumn_GetAllRecords',
'ReportOrderColumn_GetRecords',
'ReportOrderColumn_GetRecordsByReport',
'ReportOrderColumn_InsertRecord',
'ReportOrderColumn_UpdateRecord',
'ReportParameterColumn_GetRecordsByReport',
'ReportSchemaColumn_DeleteRecord',
'ReportSchemaColumn_GetAllRecords',
'ReportSchemaColumn_GetRecords',
'ReportSchemaColumn_GetRecordsByTable',
'ReportSchemaColumn_InsertRecord',
'ReportSchemaColumn_UpdateRecord',
'ReportSchemaDataType_DeleteRecord',
'ReportSchemaDataType_DeleteRecordsForReportSchemaDataTypeOperatorAssociation',
'ReportSchemaDataType_DeleteRecordsForReportSchemaDataTypeSummaryFunctionAssociation',
'ReportSchemaDataType_GetAllRecords',
'ReportSchemaDataType_GetRecords',
'ReportSchemaDataType_GetRecordsForReportSchemaDataTypeOperatorAssociation',
'ReportSchemaDataType_GetRecordsForReportSchemaDataTypeSummaryFunctionAssociation',
'ReportSchemaDataType_InsertRecord',
'ReportSchemaDataType_InsertRecordsForReportSchemaDataTypeOperatorAssociation',
'ReportSchemaDataType_InsertRecordsForReportSchemaDataTypeSummaryFunctionAssociation',
'ReportSchemaDataType_UpdateRecord',
'ReportSchemaJoinMultiplicity_DeleteRecord',
'ReportSchemaJoinMultiplicity_GetAllRecords',
'ReportSchemaJoinMultiplicity_GetRecords',
'ReportSchemaJoinMultiplicity_InsertRecord',
'ReportSchemaJoinMultiplicity_UpdateRecord',
'ReportSchemaJoinType_DeleteRecord',
'ReportSchemaJoinType_GetRecords',
'ReportSchemaOperator_DeleteRecord',
'ReportSchemaOperator_DeleteRecordsForReportSchemaDataTypeOperatorAssociation',
'ReportSchemaOperator_GetAllRecords',
'ReportSchemaOperator_GetRecords',
'ReportSchemaOperator_GetRecordsForReportSchemaDataTypeOperatorAssociation',
'ReportSchemaOperator_InsertRecord',
'ReportSchemaOperator_InsertRecordsForReportSchemaDataTypeOperatorAssociation',
'ReportSchemaOperator_UpdateRecord',
'ReportSchemaSummaryFunction_DeleteRecord',
'ReportSchemaSummaryFunction_DeleteRecordsForReportSchemaDataTypeSummaryFunctionAssociation',
'ReportSchemaSummaryFunction_DeleteRecordsForReportSelectColumnSummaryFunctionAssociation',
'ReportSchemaSummaryFunction_GetAllRecords',
'ReportSchemaSummaryFunction_GetRecords',
'ReportSchemaSummaryFunction_GetRecordsForReportSchemaDataTypeSummaryFunctionAssociation',
'ReportSchemaSummaryFunction_GetRecordsForReportSelectColumnSummaryFunctionAssociation',
'ReportSchemaSummaryFunction_InsertRecord',
'ReportSchemaSummaryFunction_InsertRecordsForReportSchemaDataTypeSummaryFunctionAssociation',
'ReportSchemaSummaryFunction_InsertRecordsForReportSelectColumnSummaryFunctionAssociation',
'ReportSchemaSummaryFunction_UpdateRecord',
'ReportSchemaTable_DeleteRecord',
'ReportSchemaTable_GetAllRecords',
'ReportSchemaTable_GetRecords',
'ReportSchemaTable_InsertRecord',
'ReportSchemaTable_UpdateRecord',
'ReportSelectColumn_DeleteRecord',
'ReportSelectColumn_DeleteRecordsForReportSelectColumnSummaryFunctionAssociation',
'ReportSelectColumn_GetAllRecords',
'ReportSelectColumn_GetRecordsByReport',
'ReportSelectColumn_GetRecordsBySummaryFunction',
'ReportSelectColumn_GetRecordsForReportSelectColumnSummaryFunctionAssociation',
'ReportSelectColumn_InsertRecord',
'ReportSelectColumn_InsertRecordsForReportSelectColumnSummaryFunctionAssociation',
'ReportSelectColumn_UpdateRecord',
'ReportType_DeleteRecord',
'ReportType_InsertRecord',
'ReportType_UpdateRecord',
'ReportTypeColumn_DeleteRecord',
'ReportTypeColumn_GetAllRecords',
'ReportTypeColumn_GetRecordsByTable',
'ReportTypeColumn_InsertRecord',
'ReportTypeColumn_UpdateRecord',
'ReportTypeTable_DeleteRecord',
'ReportTypeTable_GetAllRecords',
'ReportTypeTable_GetRecords',
'ReportTypeTable_GetRecordsByJoinTable',
'ReportTypeTable_InsertRecord',
'ReportTypeTable_UpdateRecord')

open procCursor
fetch next from procCursor into @procedureName
declare @sql varchar(8000)

WHILE @@Fetch_status = 0
BEGIN
	set @sql = 'IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N''[dbo].[' + @procedureName + ']'') AND type in (N''P'', N''PC''))
			DROP PROCEDURE [dbo].[' + @procedureName + ']'

	--print (@sql)
	exec (@sql)

	fetch next from procCursor into @procedureName
END
	
CLOSE procCursor
DEALLOCATE procCursor