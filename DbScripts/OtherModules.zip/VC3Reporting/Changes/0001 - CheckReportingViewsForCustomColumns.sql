-- suppress errors

alter table ReportSchemaColumn drop constraint DF_ReportSchemaColumn_OrderExpression