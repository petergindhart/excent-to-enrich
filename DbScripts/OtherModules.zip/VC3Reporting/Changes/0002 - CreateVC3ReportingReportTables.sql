--#include ..\..\VC3Deployment\Objects\DropConstraints.sql

CREATE TABLE [VC3Reporting].[Report] (
	[Id] [uniqueidentifier] NOT NULL ,
	[Title] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Query] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Type] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Path] [varchar] (300) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Description] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Format] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

CREATE TABLE [VC3Reporting].[ReportColumn] (
	[Id]  uniqueidentifier ROWGUIDCOL  NOT NULL ,
	[Type] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Report] [uniqueidentifier] NOT NULL ,
	[ReportTypeTable] [uniqueidentifier] NOT NULL ,
	[SchemaColumn] [uniqueidentifier] NOT NULL ,
	[Sequence] [int] NOT NULL 
) ON [PRIMARY]

CREATE TABLE [VC3Reporting].[ReportColumnParameterValue] (
	[Id] [uniqueidentifier] NOT NULL ,
	[ReportColumn] [uniqueidentifier] NOT NULL ,
	[SchemaTableParameter] [uniqueidentifier] NOT NULL ,
	[ValueExpression] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]

CREATE TABLE [VC3Reporting].[ReportColumnType] (
	[Id] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Name] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]

CREATE TABLE [VC3Reporting].[ReportFilterColumn] (
	[Id] [uniqueidentifier] NOT NULL ,
	[SchemaOperator] [uniqueidentifier] NOT NULL 
) ON [PRIMARY]

CREATE TABLE [VC3Reporting].[ReportFilterValue] (
	[Id] [uniqueidentifier] NOT NULL ,
	[FilterColumn] [uniqueidentifier] NOT NULL ,
	[ValueExpression] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]

CREATE TABLE [VC3Reporting].[ReportFormat] (
	[Id] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Name] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Builder] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Template] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Datasource] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]

CREATE TABLE [VC3Reporting].[ReportOrderColumn] (
	[Id] [uniqueidentifier] NOT NULL ,
	[IsAscending] [bit] NOT NULL 
) ON [PRIMARY]

CREATE TABLE [VC3Reporting].[ReportSchemaColumn] (
	[Id] [uniqueidentifier] NOT NULL ,
	[Name] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[SchemaTable] [uniqueidentifier] NOT NULL ,
	[SchemaDataType] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[DisplayExpression] [varchar] (1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[ValueExpression] [varchar] (1000) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[OrderExpression] [varchar] (1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[LinkExpression] [varchar] (1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[LinkFormat] [varchar] (1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[IsSelectColumn] [bit] NOT NULL ,
	[IsFilterColumn] [bit] NOT NULL ,
	[IsParameterColumn] [bit] NOT NULL ,
	[IsGroupColumn] [bit] NOT NULL ,
	[IsOrderColumn] [bit] NOT NULL ,
	[IsAggregated] [bit] NOT NULL ,
	[AllowedValuesExpression] [varchar] (1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Sequence] [int] NOT NULL ,
	[Width] [decimal](18, 0) NULL 
) ON [PRIMARY]

CREATE TABLE [VC3Reporting].[ReportSchemaDataType] (
	[Id] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Name] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[ValueEditor] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[OptionEditor] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[TypeName] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Format] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[SqlExpression] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[DefaultColumnWidth] [decimal](18, 4) NOT NULL 
) ON [PRIMARY]

CREATE TABLE [VC3Reporting].[ReportSchemaDataTypeOperator] (
	[SchemaDataType] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[SchemaOperator] [uniqueidentifier] NOT NULL 
) ON [PRIMARY]


CREATE TABLE [VC3Reporting].[ReportSchemaDataTypeSummaryFunction] (
	[SchemaDataType] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[SchemaSummaryFunction] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]

CREATE TABLE [VC3Reporting].[ReportSchemaJoinMultiplicity] (
	[Id] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Name] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[LowerBound] [int] NOT NULL ,
	[UpperBound] [int] NOT NULL 
) ON [PRIMARY]

CREATE TABLE [VC3Reporting].[ReportSchemaOperator] (
	[Id] [uniqueidentifier] NOT NULL ,
	[Name] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Expression] [varchar] (85) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[ConcatExpression] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[FindRegex] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[ReplaceRegex] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Sequence] [int] NOT NULL ,
	[AllowMultipleValues] [bit] NOT NULL 
) ON [PRIMARY]

CREATE TABLE [VC3Reporting].[ReportSchemaSummaryFunction] (
	[Id] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Name] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Sequence] [int] NOT NULL ,
	[FunctionExpression] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]

CREATE TABLE [VC3Reporting].[ReportSchemaTable] (
	[Id] [uniqueidentifier] NOT NULL ,
	[Name] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[TableExpression] [varchar] (500) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[IdentityExpression] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]

CREATE TABLE [VC3Reporting].[ReportSchemaTableParameter] (
	[Id]  uniqueidentifier ROWGUIDCOL  NOT NULL ,
	[Name] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[SchemaTable] [uniqueidentifier] NOT NULL ,
	[SchemaColumn] [uniqueidentifier] NOT NULL ,
	[SchemaOperator] [uniqueidentifier] NOT NULL ,
	[IsRequired] [bit] NOT NULL ,
	[Sequence] [int] NOT NULL 
) ON [PRIMARY]

CREATE TABLE [VC3Reporting].[ReportSelectColumn] (
	[Id] [uniqueidentifier] NOT NULL ,
	[Label] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[SchemaSummaryFunction] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]

CREATE TABLE [VC3Reporting].[ReportSelectColumnSummaryFunction] (
	[SelectColumn] [uniqueidentifier] NOT NULL ,
	[SummaryFunction] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]

CREATE TABLE [VC3Reporting].[ReportType] (
	[Id] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Name] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[IsEditable] [bit] NOT NULL 
) ON [PRIMARY]

CREATE TABLE [VC3Reporting].[ReportTypeColumn] (
	[SchemaColumn] [uniqueidentifier] NOT NULL ,
	[ReportTypeTable] [uniqueidentifier] NOT NULL ,
	[Name] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Sequence] [int] NOT NULL 
) ON [PRIMARY]

CREATE TABLE [VC3Reporting].[ReportTypeTable] (
	[Id] [uniqueidentifier] NOT NULL ,
	[Name] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[ReportType] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Sequence] [int] NOT NULL ,
	[SchemaTable] [uniqueidentifier] NOT NULL ,
	[JoinTable] [uniqueidentifier] NULL ,
	[JoinMultiplicity] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[JoinExpression] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[ColumnPrefix] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]

CREATE TABLE [VC3Reporting].[ReportTypeFormat](
	[ReportType] [char](1) NOT NULL,
	[ReportFormat] [char](1) NOT NULL,
	[Sequence] [int] NULL
) ON [PRIMARY]

----------------- Add Constraints to [VC3Reporting] Tables ----------------
ALTER TABLE [VC3Reporting].[Report] WITH NOCHECK ADD 
	CONSTRAINT [PK_Report] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 


ALTER TABLE [VC3Reporting].[ReportColumn] WITH NOCHECK ADD 
	CONSTRAINT [PK_ReportColumn] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 


ALTER TABLE [VC3Reporting].[ReportColumnParameterValue] WITH NOCHECK ADD 
	CONSTRAINT [PK_ReportColumnParameterValue] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 


ALTER TABLE [VC3Reporting].[ReportColumnType] WITH NOCHECK ADD 
	CONSTRAINT [PK_ReportColumnType] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 


ALTER TABLE [VC3Reporting].[ReportFilterColumn] WITH NOCHECK ADD 
	CONSTRAINT [PK_ReportFilter] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 


ALTER TABLE [VC3Reporting].[ReportFilterValue] WITH NOCHECK ADD 
	CONSTRAINT [PK_ReportFilterValue] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 


ALTER TABLE [VC3Reporting].[ReportFormat] WITH NOCHECK ADD 
	CONSTRAINT [PK_ReportFormat] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 


ALTER TABLE [VC3Reporting].[ReportOrderColumn] WITH NOCHECK ADD 
	CONSTRAINT [PK_ReportSortOrder] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 


ALTER TABLE [VC3Reporting].[ReportSchemaColumn] WITH NOCHECK ADD 
	CONSTRAINT [PK_ReportFilterProperty] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 


ALTER TABLE [VC3Reporting].[ReportSchemaDataType] WITH NOCHECK ADD 
	CONSTRAINT [PK_ReportDataType] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 


ALTER TABLE [VC3Reporting].[ReportSchemaDataTypeOperator] WITH NOCHECK ADD 
	CONSTRAINT [PK_ReportDataTypeOperator] PRIMARY KEY  CLUSTERED 
	(
		[SchemaDataType],
		[SchemaOperator]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 


ALTER TABLE [VC3Reporting].[ReportSchemaDataTypeSummaryFunction] WITH NOCHECK ADD 
	CONSTRAINT [PK_ReportSchemaDataTypeSummaryFunction] PRIMARY KEY  CLUSTERED 
	(
		[SchemaDataType],
		[SchemaSummaryFunction]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 


ALTER TABLE [VC3Reporting].[ReportSchemaJoinMultiplicity] WITH NOCHECK ADD 
	CONSTRAINT [PK_ReportSchemaJoinType] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 


ALTER TABLE [VC3Reporting].[ReportSchemaOperator] WITH NOCHECK ADD 
	CONSTRAINT [PK_ReportFilterOperator] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 


ALTER TABLE [VC3Reporting].[ReportSchemaSummaryFunction] WITH NOCHECK ADD 
	CONSTRAINT [PK_ReportSchemaSummaryFunction] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 


ALTER TABLE [VC3Reporting].[ReportSchemaTable] WITH NOCHECK ADD 
	CONSTRAINT [PK_ReportDataSource] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 


ALTER TABLE [VC3Reporting].[ReportSchemaTableParameter] WITH NOCHECK ADD 
	CONSTRAINT [PK_ReportSchemaTableParameter] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 


ALTER TABLE [VC3Reporting].[ReportSelectColumn] WITH NOCHECK ADD 
	CONSTRAINT [PK_ReportSelectColumn] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 


ALTER TABLE [VC3Reporting].[ReportSelectColumnSummaryFunction] WITH NOCHECK ADD 
	CONSTRAINT [PK_ReportSelectColumnSummaryFunction] PRIMARY KEY  CLUSTERED 
	(
		[SelectColumn],
		[SummaryFunction]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 


ALTER TABLE [VC3Reporting].[ReportType] WITH NOCHECK ADD 
	CONSTRAINT [PK_ReportType] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 


ALTER TABLE [VC3Reporting].[ReportTypeColumn] WITH NOCHECK ADD 
	CONSTRAINT [PK_ReportTypeColumn] PRIMARY KEY  CLUSTERED 
	(
		[SchemaColumn],
		[ReportTypeTable]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 


ALTER TABLE [VC3Reporting].[ReportTypeTable] WITH NOCHECK ADD 
	CONSTRAINT [PK_ReportTableAssociation] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 

ALTER TABLE [VC3Reporting].[ReportTypeFormat] WITH NOCHECK ADD
	CONSTRAINT [PK_ReportTypeFormat] PRIMARY KEY CLUSTERED 
	(
		[ReportType] ASC,
		[ReportFormat] ASC
	)WITH FILLFACTOR = 90 ON [PRIMARY]

ALTER TABLE [VC3Reporting].[Report] ADD 
	CONSTRAINT [DF_Report_Id] DEFAULT (newid()) FOR [Id]


ALTER TABLE [VC3Reporting].[ReportColumn] ADD 
	CONSTRAINT [DF_ReportColumn_Id] DEFAULT (newid()) FOR [Id]


ALTER TABLE [VC3Reporting].[ReportFilterColumn] ADD 
	CONSTRAINT [DF_ReportFilter_ID] DEFAULT (newid()) FOR [Id]


ALTER TABLE [VC3Reporting].[ReportFilterValue] ADD 
	CONSTRAINT [DF_ReportFilterValue_ID] DEFAULT (newid()) FOR [Id]


ALTER TABLE [VC3Reporting].[ReportOrderColumn] ADD 
	CONSTRAINT [DF_ReportSortOrder_ID] DEFAULT (newid()) FOR [Id]


ALTER TABLE [VC3Reporting].[ReportSchemaColumn] ADD 
	CONSTRAINT [DF_ReportFilterProperty_ID] DEFAULT (newid()) FOR [Id],
	CONSTRAINT [DF_ReportColumn_DataType] DEFAULT ('t') FOR [SchemaDataType],
	CONSTRAINT [DF_ReportSchemaColumn_AllowSelectColumn] DEFAULT (1) FOR [IsSelectColumn],
	CONSTRAINT [DF_ReportSchemaColumn_IsSelectColumn1] DEFAULT (1) FOR [IsFilterColumn],
	CONSTRAINT [DF_ReportSchemaColumn_IsSelectColumn2] DEFAULT (1) FOR [IsParameterColumn],
	CONSTRAINT [DF_ReportSchemaColumn_IsSelectColumn3] DEFAULT (1) FOR [IsGroupColumn],
	CONSTRAINT [DF_ReportSchemaColumn_IsSelectColumn4] DEFAULT (1) FOR [IsOrderColumn],
	CONSTRAINT [DF_ReportSchemaColumn_IsAggregated] DEFAULT (0) FOR [IsAggregated],
	CONSTRAINT [DF_ReportSchemaColumn_Sequence] DEFAULT (0) FOR [Sequence]


ALTER TABLE [VC3Reporting].[ReportSchemaDataType] ADD 
	CONSTRAINT [DF_ReportSchemaDataType_DefaultColumnWidth] DEFAULT (1) FOR [DefaultColumnWidth]


ALTER TABLE [VC3Reporting].[ReportSchemaJoinMultiplicity] ADD 
	CONSTRAINT [DF_ReportSchemaJoinMultiplicity_IsOptional] DEFAULT (0) FOR [LowerBound],
	CONSTRAINT [DF_ReportSchemaJoinMultiplicity_UpperBound] DEFAULT (0) FOR [UpperBound]


ALTER TABLE [VC3Reporting].[ReportSchemaOperator] ADD 
	CONSTRAINT [DF_ReportFilterOperator] DEFAULT (newid()) FOR [Id],
	CONSTRAINT [DF_ReportSchemaOperator_Sequence] DEFAULT (0) FOR [Sequence],
	CONSTRAINT [DF_ReportSchemaOperator_AllowMultipleValues] DEFAULT (0) FOR [AllowMultipleValues]


ALTER TABLE [VC3Reporting].[ReportSchemaTable] ADD 
	CONSTRAINT [DF_ReportDataSource_ID] DEFAULT (newid()) FOR [Id]


ALTER TABLE [VC3Reporting].[ReportSchemaTableParameter] ADD 
	CONSTRAINT [DF_ReportSchemaTableParameter_Id] DEFAULT (newid()) FOR [Id],
	CONSTRAINT [DF_ReportSchemaTableParameter_Sequence] DEFAULT (0) FOR [Sequence]


ALTER TABLE [VC3Reporting].[ReportType] ADD 
	CONSTRAINT [DF_ReportType_IsEditable] DEFAULT (1) FOR [IsEditable]


ALTER TABLE [VC3Reporting].[ReportTypeColumn] ADD 
	CONSTRAINT [DF_ReportTypeColumn_Sequence] DEFAULT (0) FOR [Sequence]


ALTER TABLE [VC3Reporting].[ReportTypeTable] ADD 
	CONSTRAINT [DF_ReportTypeTable_Id] DEFAULT (newid()) FOR [Id],
	CONSTRAINT [DF_ReportTypeTable_Sequence] DEFAULT (0) FOR [Sequence]


ALTER TABLE [VC3Reporting].[Report] ADD 
	CONSTRAINT [FK_Report#Type#Reports] FOREIGN KEY 
	(
		[Type]
	) REFERENCES [VC3Reporting].[ReportType] (
		[Id]
	),
	CONSTRAINT [FK_Report_ReportFormat] FOREIGN KEY 
	(
		[Format]
	) REFERENCES [VC3Reporting].[ReportFormat] (
		[Id]
	)


ALTER TABLE [VC3Reporting].[ReportColumn] ADD 
	CONSTRAINT [FK_ReportColumn#Column#] FOREIGN KEY 
	(
		[SchemaColumn]
	) REFERENCES [VC3Reporting].[ReportSchemaColumn] (
		[Id]
	) ON DELETE CASCADE  NOT FOR REPLICATION ,
	CONSTRAINT [FK_ReportColumn#Report#Columns] FOREIGN KEY 
	(
		[Report]
	) REFERENCES [VC3Reporting].[Report] (
		[Id]
	) ON DELETE CASCADE  NOT FOR REPLICATION ,
	CONSTRAINT [FK_ReportColumn#Table] FOREIGN KEY 
	(
		[ReportTypeTable]
	) REFERENCES [VC3Reporting].[ReportTypeTable] (
		[Id]
	),
	CONSTRAINT [FK_ReportColumn#Type#] FOREIGN KEY 
	(
		[Type]
	) REFERENCES [VC3Reporting].[ReportColumnType] (
		[Id]
	) NOT FOR REPLICATION 


ALTER TABLE [VC3Reporting].[ReportColumnParameterValue] ADD 
	CONSTRAINT [FK_ReportColumnParameterValue#Column#ParameterValues] FOREIGN KEY 
	(
		[ReportColumn]
	) REFERENCES [VC3Reporting].[ReportColumn] (
		[Id]
	) ON DELETE CASCADE  NOT FOR REPLICATION ,
	CONSTRAINT [FK_ReportColumnParameterValue#Parameter#] FOREIGN KEY 
	(
		[SchemaTableParameter]
	) REFERENCES [VC3Reporting].[ReportSchemaTableParameter] (
		[Id]
	) NOT FOR REPLICATION 


ALTER TABLE [VC3Reporting].[ReportFilterColumn] ADD 
	CONSTRAINT [FK_ReportFilter#Operator#] FOREIGN KEY 
	(
		[SchemaOperator]
	) REFERENCES [VC3Reporting].[ReportSchemaOperator] (
		[Id]
	),
	CONSTRAINT [FK_ReportFilterColumn_ReportColumn] FOREIGN KEY 
	(
		[Id]
	) REFERENCES [VC3Reporting].[ReportColumn] (
		[Id]
	) ON DELETE CASCADE  NOT FOR REPLICATION 


ALTER TABLE [VC3Reporting].[ReportFilterValue] ADD 
	CONSTRAINT [FK_ReportFilterValue#Filter#Values] FOREIGN KEY 
	(
		[FilterColumn]
	) REFERENCES [VC3Reporting].[ReportFilterColumn] (
		[Id]
	) ON DELETE CASCADE 


ALTER TABLE [VC3Reporting].[ReportOrderColumn] ADD 
	CONSTRAINT [FK_ReportOrderColumn_ReportColumn] FOREIGN KEY 
	(
		[Id]
	) REFERENCES [VC3Reporting].[ReportColumn] (
		[Id]
	) ON DELETE CASCADE  NOT FOR REPLICATION 


ALTER TABLE [VC3Reporting].[ReportSchemaColumn] ADD 
	CONSTRAINT [FK_ReportColum#DataType#] FOREIGN KEY 
	(
		[SchemaDataType]
	) REFERENCES [VC3Reporting].[ReportSchemaDataType] (
		[Id]
	),
	CONSTRAINT [FK_ReportColumn#Table#Columns] FOREIGN KEY 
	(
		[SchemaTable]
	) REFERENCES [VC3Reporting].[ReportSchemaTable] (
		[Id]
	)


ALTER TABLE [VC3Reporting].[ReportSchemaDataTypeOperator] ADD 
	CONSTRAINT [FK_ReportDataTypeOperator#DataType#Operators] FOREIGN KEY 
	(
		[SchemaDataType]
	) REFERENCES [VC3Reporting].[ReportSchemaDataType] (
		[Id]
	),
	CONSTRAINT [FK_ReportDataTypeOperator#Operator#] FOREIGN KEY 
	(
		[SchemaOperator]
	) REFERENCES [VC3Reporting].[ReportSchemaOperator] (
		[Id]
	)


ALTER TABLE [VC3Reporting].[ReportSchemaDataTypeSummaryFunction] ADD 
	CONSTRAINT [FK_ReportSchemaDataTypeSummaryFunction#SummaryFunctions] FOREIGN KEY 
	(
		[SchemaDataType]
	) REFERENCES [VC3Reporting].[ReportSchemaDataType] (
		[Id]
	) NOT FOR REPLICATION ,
	CONSTRAINT [FK_ReportSchemaDataTypeSummaryFunction_ReportSchemaSummaryFunction] FOREIGN KEY 
	(
		[SchemaSummaryFunction]
	) REFERENCES [VC3Reporting].[ReportSchemaSummaryFunction] (
		[Id]
	) NOT FOR REPLICATION 


ALTER TABLE [VC3Reporting].[ReportSchemaTableParameter] ADD 
	CONSTRAINT [FK_ReportSchemaTableParameter#Column#] FOREIGN KEY 
	(
		[SchemaColumn]
	) REFERENCES [VC3Reporting].[ReportSchemaColumn] (
		[Id]
	) NOT FOR REPLICATION ,
	CONSTRAINT [FK_ReportSchemaTableParameter#Operator] FOREIGN KEY 
	(
		[SchemaOperator]
	) REFERENCES [VC3Reporting].[ReportSchemaOperator] (
		[Id]
	),
	CONSTRAINT [FK_ReportSchemaTableParameter#Table#Parameters] FOREIGN KEY 
	(
		[SchemaTable]
	) REFERENCES [VC3Reporting].[ReportSchemaTable] (
		[Id]
	)


ALTER TABLE [VC3Reporting].[ReportSelectColumn] ADD 
	CONSTRAINT [FK_ReportSelectColumn#SummaryFunction#] FOREIGN KEY 
	(
		[SchemaSummaryFunction]
	) REFERENCES [VC3Reporting].[ReportSchemaSummaryFunction] (
		[Id]
	) NOT FOR REPLICATION ,
	CONSTRAINT [FK_ReportSelectColumn_ReportColumn] FOREIGN KEY 
	(
		[Id]
	) REFERENCES [VC3Reporting].[ReportColumn] (
		[Id]
	) ON DELETE CASCADE  NOT FOR REPLICATION 


ALTER TABLE [VC3Reporting].[ReportSelectColumnSummaryFunction] ADD 
	CONSTRAINT [FK_ReportSelectColumnSummaryFunction#ReportSelectColumn#SummaryFunctions] FOREIGN KEY 
	(
		[SelectColumn]
	) REFERENCES [VC3Reporting].[ReportSelectColumn] (
		[Id]
	) ON DELETE CASCADE ,
	CONSTRAINT [FK_ReportSelectColumnSummaryFunction_ReportSchemaSummaryFunction] FOREIGN KEY 
	(
		[SummaryFunction]
	) REFERENCES [VC3Reporting].[ReportSchemaSummaryFunction] (
		[Id]
	)


ALTER TABLE [VC3Reporting].[ReportTypeColumn] ADD 
	CONSTRAINT [FK_ReportTypeColumn#Column] FOREIGN KEY 
	(
		[SchemaColumn]
	) REFERENCES [VC3Reporting].[ReportSchemaColumn] (
		[Id]
	) ON DELETE CASCADE ,
	CONSTRAINT [FK_ReportTypeColumn#Table#Columns] FOREIGN KEY 
	(
		[ReportTypeTable]
	) REFERENCES [VC3Reporting].[ReportTypeTable] (
		[Id]
	) ON DELETE CASCADE 


ALTER TABLE [VC3Reporting].[ReportTypeTable] ADD 
	CONSTRAINT [FK_ReportSchemaTableAssociation_ReportSchemaJoinType] FOREIGN KEY 
	(
		[JoinMultiplicity]
	) REFERENCES [VC3Reporting].[ReportSchemaJoinMultiplicity] (
		[Id]
	),
	CONSTRAINT [FK_ReportTypeTable#JoinTable#ChildTables] FOREIGN KEY 
	(
		[JoinTable]
	) REFERENCES [VC3Reporting].[ReportTypeTable] (
		[Id]
	),
	CONSTRAINT [FK_ReportTypeTable#Table] FOREIGN KEY 
	(
		[SchemaTable]
	) REFERENCES [VC3Reporting].[ReportSchemaTable] (
		[Id]
	) ON DELETE CASCADE ,
	CONSTRAINT [FK_ReportTypeTable_ReportType] FOREIGN KEY 
	(
		[ReportType]
	) REFERENCES [VC3Reporting].[ReportType] (
		[Id]
	)

ALTER TABLE [VC3Reporting].[ReportTypeFormat]  ADD  
	CONSTRAINT [FK_ReportTypeFormat_ReportFormat] FOREIGN KEY
	(
		[ReportFormat]
	) REFERENCES [VC3Reporting].[ReportFormat] (
		[Id]
	),
	CONSTRAINT [FK_ReportTypeFormat_ReportType#Formats] FOREIGN KEY
	(
		[ReportType]
	) REFERENCES [VC3Reporting].[ReportType] (
		[Id]
	)

	----------------- Copy data from dbo tables to VC3Reporting tables -------------------------
	IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportSchemaTable]') AND type in (N'U'))
	INSERT INTO [VC3Reporting].[ReportSchemaTable]
	SELECT
		[Id],
		[Name],
		[TableExpression],
		[IdentityExpression] 
	FROM [dbo].[ReportSchemaTable]

	IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportSchemaDataType]') AND type in (N'U'))
	INSERT INTO [VC3Reporting].[ReportSchemaDataType]
	SELECT
		[Id],
		[Name],
		[ValueEditor],
		[OptionEditor],
		[TypeName],
		[Format],
		[SqlExpression],
		[DefaultColumnWidth] 
	FROM [dbo].[ReportSchemaDataType]

	IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportSchemaColumn]') AND type in (N'U'))
	INSERT INTO [VC3Reporting].[ReportSchemaColumn]
	SELECT
		[Id],
		[Name],
		[SchemaTable],
		[SchemaDataType],
		[DisplayExpression],
		[ValueExpression],
		[OrderExpression],
		[LinkExpression],
		[LinkFormat],
		[IsSelectColumn],
		[IsFilterColumn],
		[IsParameterColumn],
		[IsGroupColumn],
		[IsOrderColumn],
		[IsAggregated],
		[AllowedValuesExpression],
		[Sequence],
		[Width]
	FROM [dbo].[ReportSchemaColumn] r

	IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportType]') AND type in (N'U'))
	INSERT INTO [VC3Reporting].[ReportType]
	SELECT
		[Id],
		[Name],
		[IsEditable]  
	FROM [dbo].[ReportType]

	IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportFormat]') AND type in (N'U'))
	INSERT INTO [VC3Reporting].[ReportFormat]
	SELECT
		[Id],
		[Name],
		[Builder],
		[Template],
		[Datasource]
	FROM [dbo].[ReportFormat]

	IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportTypeFormat]') AND type in (N'U'))
	INSERT INTO [VC3Reporting].[ReportTypeFormat]
	SELECT
		[ReportType],
		[ReportFormat],
		[Sequence]
	FROM [dbo].[ReportTypeFormat]

	IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[Report]') AND type in (N'U'))
	INSERT INTO [VC3Reporting].[Report]
	SELECT
		[Id],
		[Title],
		[Query],
		[Type],
		[Path],
		[Description],
		[Format]  
	FROM [dbo].[Report]

	IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportSchemaJoinMultiplicity]') AND type in (N'U'))
	INSERT INTO [VC3Reporting].[ReportSchemaJoinMultiplicity]
	SELECT
		[Id],
		[Name],
		[LowerBound],
		[UpperBound]   
	FROM [dbo].[ReportSchemaJoinMultiplicity]

	IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportTypeTable]') AND type in (N'U'))
	INSERT INTO [VC3Reporting].[ReportTypeTable]
	SELECT
		[Id],
		[Name],
		[ReportType],
		[Sequence],
		[SchemaTable],
		[JoinTable],
		[JoinMultiplicity],
		[JoinExpression],
		[ColumnPrefix] 
	FROM [dbo].[ReportTypeTable]

	IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportColumnType]') AND type in (N'U'))
	INSERT INTO [VC3Reporting].[ReportColumnType]
	SELECT
		[Id],
		[Name]  
	FROM [dbo].[ReportColumnType] r

	IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportColumn]') AND type in (N'U'))
	INSERT INTO [VC3Reporting].[ReportColumn]
	SELECT
		[Id],
		[Type],
		[Report],
		[ReportTypeTable],
		[SchemaColumn],
		[Sequence]   
	FROM [dbo].[ReportColumn]

	IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportTypeColumn]') AND type in (N'U'))
	INSERT INTO [VC3Reporting].[ReportTypeColumn]
	SELECT
		[SchemaColumn],
		[ReportTypeTable],
		[Name],
		[Sequence]   
	FROM [dbo].[ReportTypeColumn] r

	IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportSchemaOperator]') AND type in (N'U'))
	INSERT INTO [VC3Reporting].[ReportSchemaOperator]
	SELECT
		[Id],
		[Name],
		[Expression],
		[ConcatExpression],
		[FindRegex],
		[ReplaceRegex],
		[Sequence],
		[AllowMultipleValues]  
	FROM [dbo].[ReportSchemaOperator]

	IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportSchemaSummaryFunction]') AND type in (N'U'))
	INSERT INTO [VC3Reporting].[ReportSchemaSummaryFunction]
	SELECT
		[Id],
		[Name],
		[Sequence],
		[FunctionExpression]  
	FROM [dbo].[ReportSchemaSummaryFunction]

	IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportSelectColumn]') AND type in (N'U'))
	INSERT INTO [VC3Reporting].[ReportSelectColumn]
	SELECT
		[Id],
		[Label],
		[SchemaSummaryFunction] 
	FROM [dbo].[ReportSelectColumn]

	IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportSchemaTableParameter]') AND type in (N'U'))
	INSERT INTO [VC3Reporting].[ReportSchemaTableParameter]
	SELECT
		[Id],
		[Name],
		[SchemaTable],
		[SchemaColumn],
		[SchemaOperator],
		[IsRequired],
		[Sequence]   
	FROM [dbo].[ReportSchemaTableParameter]

	IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportColumnParameterValue]') AND type in (N'U'))
	INSERT INTO [VC3Reporting].[ReportColumnParameterValue]
	SELECT
		[Id],
		[ReportColumn],
		[SchemaTableParameter],
		[ValueExpression] 
	FROM [dbo].[ReportColumnParameterValue] r

	IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportFilterColumn]') AND type in (N'U'))
	INSERT INTO [VC3Reporting].[ReportFilterColumn]
	SELECT
		[Id],
		[SchemaOperator]
	FROM [dbo].[ReportFilterColumn] r

	IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportFilterValue]') AND type in (N'U'))
	INSERT INTO [VC3Reporting].[ReportFilterValue]
	SELECT
		[Id],
		[FilterColumn],
		[ValueExpression]  
	FROM [dbo].[ReportFilterValue]

	IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportOrderColumn]') AND type in (N'U'))
	INSERT INTO [VC3Reporting].[ReportOrderColumn]
	SELECT
		[Id],
		[IsAscending]  
	FROM [dbo].[ReportOrderColumn]	

	IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportSchemaDataTypeOperator]') AND type in (N'U'))
	INSERT INTO [VC3Reporting].[ReportSchemaDataTypeOperator]
	SELECT
		[SchemaDataType],
		[SchemaOperator]
	FROM [dbo].[ReportSchemaDataTypeOperator] r

	IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportSchemaDataTypeSummaryFunction]') AND type in (N'U'))
	INSERT INTO [VC3Reporting].[ReportSchemaDataTypeSummaryFunction]
	SELECT
		[SchemaDataType],
		[SchemaSummaryFunction]  
	FROM [dbo].[ReportSchemaDataTypeSummaryFunction] r

	IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportSelectColumnSummaryFunction]') AND type in (N'U'))
	INSERT INTO [VC3Reporting].[ReportSelectColumnSummaryFunction]
	SELECT
		[SelectColumn],
		[SummaryFunction]  
	FROM [dbo].[ReportSelectColumnSummaryFunction] r

	------------- Drop Duplicate Constraints on SubClassed Tables ------------------
	IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[Report]') AND type in (N'U'))
	BEGIN
		EXEC [VC3Deployment].[DropConstraints] @table='Report', @owner='dbo', @column='Type'
		EXEC [VC3Deployment].[DropConstraints] @table='Report', @owner='dbo', @column='Format'
	END

	IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportColumn]') AND type in (N'U'))
	BEGIN
		EXEC [VC3Deployment].[DropConstraints] @table='ReportColumn', @owner='dbo', @column='Report'
		EXEC [VC3Deployment].[DropConstraints] @table='ReportColumn', @owner='dbo', @column='ReportTypeTable'
		EXEC [VC3Deployment].[DropConstraints] @table='ReportColumn', @owner='dbo', @column='SchemaColumn'
		EXEC [VC3Deployment].[DropConstraints] @table='ReportColumn', @owner='dbo', @column='Type'
		EXEC [VC3Deployment].[DropConstraints] @table='ReportColumn', @owner='dbo', @column='Id', @constraintType='F'
	END

	IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportSchemaColumn]') AND type in (N'U'))
	BEGIN
		EXEC [VC3Deployment].[DropConstraints] @table='ReportSchemaColumn', @owner='dbo', @column='SchemaDataType'
		EXEC [VC3Deployment].[DropConstraints] @table='ReportSchemaColumn', @owner='dbo', @column='SchemaTable'
		EXEC [VC3Deployment].[DropConstraints] @table='ReportSchemaColumn', @owner='dbo', @column='IsSelectColumn'
		EXEC [VC3Deployment].[DropConstraints] @table='ReportSchemaColumn', @owner='dbo', @column='IsFilterColumn'
		EXEC [VC3Deployment].[DropConstraints] @table='ReportSchemaColumn', @owner='dbo', @column='IsParameterColumn'
		EXEC [VC3Deployment].[DropConstraints] @table='ReportSchemaColumn', @owner='dbo', @column='IsGroupColumn'
		EXEC [VC3Deployment].[DropConstraints] @table='ReportSchemaColumn', @owner='dbo', @column='IsOrderColumn'
		EXEC [VC3Deployment].[DropConstraints] @table='ReportSchemaColumn', @owner='dbo', @column='IsAggregated'
		EXEC [VC3Deployment].[DropConstraints] @table='ReportSchemaColumn', @owner='dbo', @column='Sequence'
		EXEC [VC3Deployment].[DropConstraints] @table='ReportSchemaColumn', @owner='dbo', @column='Id', @constraintType='F'
	END

	IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportType]') AND type in (N'U'))
	BEGIN
		EXEC [VC3Deployment].[DropConstraints] @table='ReportType', @owner='dbo', @column='IsEditable'
	END

	IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportSelectColumnSummaryFunction]') AND type in (N'U'))
	BEGIN
		EXEC [VC3Deployment].[DropConstraints] @table='ReportSelectColumnSummaryFunction', @owner='dbo'
	END

	IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportFilterValue]') AND type in (N'U'))
	BEGIN
		EXEC [VC3Deployment].[DropConstraints] @table='ReportFilterValue', @owner='dbo', @column='FilterColumn'
	END

	IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportFilterColumn]') AND type in (N'U'))
	BEGIN
		EXEC [VC3Deployment].[DropConstraints] @table='ReportFilterColumn', @owner='dbo', @column='SchemaOperator', @constraintType='F'
		EXEC [VC3Deployment].[DropConstraints] @table='ReportFilterColumn', @owner='dbo', @column='Id', @constraintType='F'
	END

	IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportColumnParameterValue]') AND type in (N'U'))
	BEGIN
		EXEC [VC3Deployment].[DropConstraints] @table='ReportColumnParameterValue', @owner='dbo', @column='ReportColumn'
		EXEC [VC3Deployment].[DropConstraints] @table='ReportColumnParameterValue', @owner='dbo', @column='SchemaTableParameter'
	END

	IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportOrderColumn]') AND type in (N'U'))
	BEGIN
		EXEC [VC3Deployment].[DropConstraints] @table='ReportOrderColumn', @owner='dbo', @column='Id', @constraintType='F'
	END

	IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportSchemaTableParameter]') AND type in (N'U'))
	BEGIN
		EXEC [VC3Deployment].[DropConstraints] @table='ReportSchemaTableParameter', @owner='dbo', @column='SchemaTable'
		EXEC [VC3Deployment].[DropConstraints] @table='ReportSchemaTableParameter', @owner='dbo', @column='SchemaColumn'
		EXEC [VC3Deployment].[DropConstraints] @table='ReportSchemaTableParameter', @owner='dbo', @column='SchemaOperator'
		EXEC [VC3Deployment].[DropConstraints] @table='ReportSchemaTableParameter', @owner='dbo', @column='Sequence'
	END

	IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportSelectColumn]') AND type in (N'U'))
	BEGIN
		EXEC [VC3Deployment].[DropConstraints] @table='ReportSelectColumn', @owner='dbo', @column='SchemaSummaryFunction'
		EXEC [VC3Deployment].[DropConstraints] @table='ReportSelectColumn', @owner='dbo', @column='Id', @constraintType='F'
	END

	IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportTypeColumn]') AND type in (N'U'))
	BEGIN
		EXEC [VC3Deployment].[DropConstraints] @table='ReportTypeColumn', @owner='dbo', @column='Sequence'
	END

	IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportTypeTable]') AND type in (N'U'))
	BEGIN
		EXEC [VC3Deployment].[DropConstraints] @table='ReportTypeTable', @owner='dbo', @column='ReportType'
		EXEC [VC3Deployment].[DropConstraints] @table='ReportTypeTable', @owner='dbo', @column='SchemaTable'
		EXEC [VC3Deployment].[DropConstraints] @table='ReportTypeTable', @owner='dbo', @column='JoinTable'
		EXEC [VC3Deployment].[DropConstraints] @table='ReportTypeTable', @owner='dbo', @column='JoinMultiplicity'
		EXEC [VC3Deployment].[DropConstraints] @table='ReportTypeTable', @owner='dbo', @column='Sequence'
	END

	IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportSchemaDataType]') AND type in (N'U'))
	BEGIN
		EXEC [VC3Deployment].[DropConstraints] @table='ReportSchemaDataType', @owner='dbo', @column='DefaultColumnWidth'
	END

	IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportSchemaJoinMultiplicity]') AND type in (N'U'))
	BEGIN
		EXEC [VC3Deployment].[DropConstraints] @table='ReportSchemaJoinMultiplicity', @owner='dbo', @column='LowerBound'
		EXEC [VC3Deployment].[DropConstraints] @table='ReportSchemaJoinMultiplicity', @owner='dbo', @column='UpperBound'
	END

	IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportSchemaOperator]') AND type in (N'U'))
	BEGIN
		EXEC [VC3Deployment].[DropConstraints] @table='ReportSchemaOperator', @owner='dbo', @column='UpperBound'
		EXEC [VC3Deployment].[DropConstraints] @table='ReportSchemaOperator', @owner='dbo', @column='Sequence'
		EXEC [VC3Deployment].[DropConstraints] @table='ReportSchemaOperator', @owner='dbo', @column='AllowMultipleValues'
	END
GO
	
	----------- Drop Tables And Columns From Inherited [dbo] Tables -------------------
	IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[Report]') AND type in (N'U'))
BEGIN
	ALTER TABLE [dbo].[Report] 
	DROP COLUMN Title, Query, Type, Path, Description, Format
	IF NOT EXISTS (SELECT * FROM syscolumns where id = object_id(N'[dbo].[Report]') and name!='Id')
	BEGIN
		exec MigrateForeignKeys @targetTableOwner='VC3Reporting', @targetTable='Report', @sourceTableOwner	= 'dbo', @sourceTable='Report'
		DROP TABLE [dbo].[Report] 
	END
end

IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportSchemaColumn]') AND type in (N'U'))
BEGIN
	ALTER TABLE [dbo].[ReportSchemaColumn] 
		DROP COLUMN Name, SchemaTable, SchemaDataType,
		DisplayExpression, ValueExpression,  OrderExpression,  LinkExpression, LinkFormat, IsSelectColumn,
		IsFilterColumn, IsParameterColumn, IsGroupColumn, IsOrderColumn, IsAggregated, AllowedValuesExpression, Sequence, Width
	IF NOT EXISTS (SELECT * FROM syscolumns where id = object_id(N'[dbo].[ReportSchemaColumn]') and name!='Id')
	BEGIN
		exec MigrateForeignKeys @targetTableOwner='VC3Reporting', @targetTable='ReportSchemaColumn', @sourceTableOwner	= 'dbo', @sourceTable='ReportSchemaColumn'
		DROP TABLE [dbo].[ReportSchemaColumn] 
	END
end

IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportSchemaTable]') AND type in (N'U'))
BEGIN
	ALTER TABLE  [dbo].[ReportSchemaTable] 
		DROP COLUMN Name, TableExpression, IdentityExpression
	IF NOT EXISTS (SELECT * FROM syscolumns where id = object_id(N'[dbo].[ReportSchemaTable]') and name!='Id')
	BEGIN
		exec MigrateForeignKeys @targetTableOwner='VC3Reporting', @targetTable='ReportSchemaTable', @sourceTableOwner	= 'dbo', @sourceTable='ReportSchemaTable'
		DROP TABLE [dbo].[ReportSchemaTable] 
	END
end

IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportType]') AND type in (N'U'))
BEGIN
	ALTER TABLE [dbo].[ReportType] 
		DROP COLUMN Name, IsEditable
	IF NOT EXISTS (SELECT * FROM syscolumns where id = object_id(N'[dbo].[ReportType]') and name!='Id')
	BEGIN
		exec MigrateForeignKeys @targetTableOwner='VC3Reporting', @targetTable='ReportType', @sourceTableOwner	= 'dbo', @sourceTable='ReportType'		
		DROP TABLE [dbo].[ReportType] 
	END
end

IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportColumnType]') AND type in (N'U'))
BEGIN
	ALTER TABLE [dbo].[ReportColumnType]
		DROP COLUMN Name
	IF NOT EXISTS (SELECT * FROM syscolumns where id = object_id(N'[dbo].[ReportColumnType]') and name!='Id')
	BEGIN
		exec MigrateForeignKeys @targetTableOwner='VC3Reporting', @targetTable='ReportColumnType', @sourceTableOwner	= 'dbo', @sourceTable='ReportColumnType'
		DROP TABLE [dbo].[ReportColumnType] 
	END
end

IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportTypeTable]') AND type in (N'U'))
BEGIN
	ALTER TABLE [dbo].[ReportTypeTable]
		DROP COLUMN NAME, REPORTTYPE, SEQUENCE, SCHEMATABLE, JOINTABLE, JOINMULTIPLICITY, JOINEXPRESSION, COLUMNPREFIX
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[ReportTypeTable]') and name!='Id')
	BEGIN
		exec MigrateForeignKeys @targetTableOwner='VC3Reporting', @targetTable='ReportTypeTable', @sourceTableOwner	= 'dbo', @sourceTable='ReportTypeTable'
		DROP TABLE [dbo].[ReportTypeTable] 
	END
end

IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportTypeColumn]') AND type in (N'U'))
BEGIN
	ALTER TABLE [dbo].[ReportTypeColumn]
		DROP COLUMN NAME, SEQUENCE
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[ReportTypeColumn]') and name!='SchemaColumn' and name!='ReportTypeTable')
	BEGIN
		exec MigrateForeignKeys @targetTableOwner='VC3Reporting', @targetTable='ReportTypeColumn', @sourceTableOwner='dbo', @sourceTable='ReportTypeColumn'
		DROP TABLE [dbo].[ReportTypeColumn] 
	END
end

IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportSelectColumnSummaryFunction]') AND type in (N'U'))
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[ReportSelectColumnSummaryFunction]')  and name!='SelectColumn' and name!='SummaryFunction')
	BEGIN
		exec MigrateForeignKeys @targetTableOwner='VC3Reporting', @targetTable='ReportSelectColumnSummaryFunction', @sourceTableOwner	= 'dbo', @sourceTable='ReportSelectColumnSummaryFunction'
		DROP TABLE [dbo].[ReportSelectColumnSummaryFunction] 
	END
end

IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportSchemaTableParameter]') AND type in (N'U'))
BEGIN
	ALTER TABLE [dbo].[ReportSchemaTableParameter]
		DROP COLUMN Name, SchemaTable, SchemaColumn, SchemaOperator, IsRequired, Sequence
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[ReportSchemaTableParameter]') and name!='Id')
	BEGIN
		exec MigrateForeignKeys @targetTableOwner='VC3Reporting', @targetTable='ReportSchemaTableParameter', @sourceTableOwner	= 'dbo', @sourceTable='ReportSchemaTableParameter'
		DROP TABLE [dbo].[ReportSchemaTableParameter] 
	END
end

IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportSelectColumn]') AND type in (N'U'))
BEGIN
	ALTER TABLE [dbo].[ReportSelectColumn]
		DROP COLUMN Label, SchemaSummaryFunction
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[ReportSelectColumn]') AND name!='Id')
	BEGIN	
		exec MigrateForeignKeys @targetTableOwner='VC3Reporting', @targetTable='ReportSelectColumn', @sourceTableOwner	= 'dbo', @sourceTable='ReportSelectColumn'
		DROP TABLE [dbo].[ReportSelectColumn] 
	END
end

IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportSchemaDataTypeSummaryFunction]') AND type in (N'U'))
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[ReportSchemaDataTypeSummaryFunction]') AND name!='SchemaDataType' and name!='SchemaSummaryFunction')
	Begin
		exec MigrateForeignKeys @targetTableOwner='VC3Reporting', @targetTable='ReportSchemaDataTypeSummaryFunction', @sourceTableOwner	= 'dbo', @sourceTable='ReportSchemaDataTypeSummaryFunction'
		DROP TABLE [dbo].[ReportSchemaDataTypeSummaryFunction] 
	End
end

IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportSchemaJoinMultiplicity]') AND type in (N'U'))
BEGIN
	ALTER TABLE [dbo].[ReportSchemaJoinMultiplicity]
		DROP COLUMN Name, LowerBound, UpperBound
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[ReportSchemaJoinMultiplicity]') AND name!='Id')
	Begin
		exec MigrateForeignKeys @targetTableOwner='VC3Reporting', @targetTable='ReportSchemaJoinMultiplicity', @sourceTableOwner	= 'dbo', @sourceTable='ReportSchemaJoinMultiplicity'
		DROP TABLE [dbo].[ReportSchemaJoinMultiplicity]
	end
end

IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportSchemaOperator]') AND type in (N'U'))
BEGIN
	ALTER TABLE [dbo].[ReportSchemaOperator]
		DROP COLUMN Name, Expression, ConcatExpression, FindRegex, ReplaceRegex, Sequence, AllowMultipleValues
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[ReportSchemaOperator]') AND name!='Id')
	Begin
		exec MigrateForeignKeys @targetTableOwner='VC3Reporting', @targetTable='ReportSchemaOperator', @sourceTableOwner	= 'dbo', @sourceTable='ReportSchemaOperator'
		DROP TABLE [dbo].[ReportSchemaOperator] 
	end
end

IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportSchemaSummaryFunction]') AND type in (N'U'))
BEGIN
	ALTER TABLE [dbo].[ReportSchemaSummaryFunction]
		DROP COLUMN Name, Sequence, FunctionExpression
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[ReportSchemaSummaryFunction]') AND name!='Id')
	Begin
		exec MigrateForeignKeys @targetTableOwner='VC3Reporting', @targetTable='ReportSchemaSummaryFunction', @sourceTableOwner	= 'dbo', @sourceTable='ReportSchemaSummaryFunction'
		DROP TABLE [dbo].[ReportSchemaSummaryFunction] 
	end
end

IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportSchemaDataTypeOperator]') AND type in (N'U'))
BEGIN	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[ReportSchemaDataTypeOperator]') AND name!='SchemaDataType' and name!='SchemaOperator')
	Begin
		exec MigrateForeignKeys @targetTableOwner='VC3Reporting', @targetTable='ReportSchemaDataTypeOperator', @sourceTableOwner	= 'dbo', @sourceTable='ReportSchemaDataTypeOperator'
		DROP TABLE [dbo].[ReportSchemaDataTypeOperator] 
	end
end

IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportOrderColumn]') AND type in (N'U'))
BEGIN	
	ALTER TABLE [dbo].[ReportOrderColumn]
		DROP COLUMN IsAscending
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[ReportOrderColumn]') AND name!='Id')
	Begin
		exec MigrateForeignKeys @targetTableOwner='VC3Reporting', @targetTable='ReportOrderColumn', @sourceTableOwner	= 'dbo', @sourceTable='ReportOrderColumn'
		DROP TABLE [dbo].[ReportOrderColumn] 
	end
end

IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportSchemaDataType]') AND type in (N'U'))
BEGIN	
	ALTER TABLE [dbo].[ReportSchemaDataType]
		DROP COLUMN	Name, ValueEditor, OptionEditor, TypeName, Format, SqlExpression, DefaultColumnWidth
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[ReportSchemaDataType]') AND name!='Id')
	Begin
		exec MigrateForeignKeys @targetTableOwner='VC3Reporting', @targetTable='ReportSchemaDataType', @sourceTableOwner	= 'dbo', @sourceTable='ReportSchemaDataType'
		DROP TABLE [dbo].[ReportSchemaDataType] 
	end
end

IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportFilterValue]') AND type in (N'U'))
BEGIN	
	ALTER TABLE [dbo].[ReportFilterValue]
		DROP COLUMN FilterColumn, ValueExpression
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[ReportFilterValue]') AND name!='Id')
	Begin
		exec MigrateForeignKeys @targetTableOwner='VC3Reporting', @targetTable='ReportFilterValue', @sourceTableOwner	= 'dbo', @sourceTable='ReportFilterValue'
		DROP TABLE [dbo].[ReportFilterValue] 
	end
end

IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportFormat]') AND type in (N'U'))
BEGIN	
	ALTER TABLE [dbo].[ReportFormat]
		DROP COLUMN Name, Builder, Template, Datasource
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[ReportFormat]') AND name!='Id')
	Begin
		exec MigrateForeignKeys @targetTableOwner='VC3Reporting', @targetTable='ReportFormat', @sourceTableOwner	= 'dbo', @sourceTable='ReportFormat'
		DROP TABLE [dbo].[ReportFormat] 
	end
end

IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportTypeFormat]') AND type in (N'U'))
BEGIN	
	ALTER TABLE [dbo].[ReportTypeFormat] 	
		DROP COLUMN Sequence
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[ReportTypeFormat]') AND name!='ReportType' and name!='ReportFormat')
	Begin
		exec MigrateForeignKeys @targetTableOwner='VC3Reporting', @targetTable='ReportTypeFormat', @sourceTableOwner	= 'dbo', @sourceTable='ReportTypeFormat'
		DROP TABLE [dbo].[ReportTypeFormat] 
	end
end

IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportColumnParameterValue]') AND type in (N'U'))
BEGIN	
	ALTER TABLE [dbo].[ReportColumnParameterValue]
		DROP COLUMN ReportColumn, SchemaTableParameter, ValueExpression
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[ReportColumnParameterValue]') and name!='Id')
	BEGIN
		exec MigrateForeignKeys @targetTableOwner='VC3Reporting', @targetTable='ReportColumnParameterValue', @sourceTableOwner	= 'dbo', @sourceTable='ReportColumnParameterValue'
		DROP TABLE [dbo].[ReportColumnParameterValue] 
	END
end

IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportFilterColumn]') AND type in (N'U'))
BEGIN	
	ALTER TABLE [dbo].[ReportFilterColumn]
		DROP COLUMN SchemaOperator
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[ReportFilterColumn]') AND name!='Id')
	Begin
		exec MigrateForeignKeys @targetTableOwner='VC3Reporting', @targetTable='ReportFilterColumn', @sourceTableOwner	= 'dbo', @sourceTable='ReportFilterColumn'
		DROP TABLE [dbo].[ReportFilterColumn] 
	end
end

IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportColumn]') AND type in (N'U'))
BEGIN	
	ALTER TABLE [dbo].[ReportColumn] 
		DROP COLUMN Type, Report, ReportTypeTable, SchemaColumn, Sequence
	IF NOT EXISTS (SELECT * FROM syscolumns where id = object_id(N'[dbo].[ReportColumn]') and name!='Id')
	BEGIN
		exec MigrateForeignKeys @targetTableOwner='VC3Reporting', @targetTable='ReportColumn', @sourceTableOwner	= 'dbo', @sourceTable='ReportColumn'
		DROP TABLE [dbo].[ReportColumn] 
	END
END
	-------------------- Add VC3Reporting Relationships To SubClassed Tables -------------------------
	IF EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[Report]') AND type in (N'U'))
	BEGIN
		IF EXISTS (SELECT * FROM syscolumns where id = object_id(N'[dbo].[Report]') AND [Name]='Id')
			ALTER TABLE [dbo].[Report] ADD 
			CONSTRAINT [FK_Report#VC3Reporting_Report] FOREIGN KEY ([ID]) 
			REFERENCES [VC3Reporting].[Report] ([Id])
	END

	IF EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportColumn]') AND type in (N'U'))
	BEGIN
		IF EXISTS (SELECT * FROM syscolumns where id = object_id(N'[dbo].[ReportColumn]') AND [Name]='Id')
			ALTER TABLE [dbo].[ReportColumn] ADD 
			CONSTRAINT [FK_ReportColumn#VC3Reporting_ReportColumn] FOREIGN KEY ([ID]) 
			REFERENCES [VC3Reporting].[ReportColumn] ([Id])
	END

	IF EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportSchemaTable]') AND type in (N'U'))
	BEGIN
		IF EXISTS (SELECT * FROM syscolumns where id = object_id(N'[dbo].[ReportSchemaTable]') AND [Name]='Id')
		ALTER TABLE [dbo].[ReportSchemaTable] ADD 
		CONSTRAINT [FK_ReportSchemaTable#VC3Reporting_ReportSchemaTable] FOREIGN KEY ([ID]) 
		REFERENCES [VC3Reporting].[ReportSchemaTable] ([Id])
	END

	IF EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportType]') AND type in (N'U'))
	BEGIN
		IF EXISTS (SELECT * FROM syscolumns where id = object_id(N'[dbo].[ReportType]') AND [Name]='Id')
			ALTER TABLE [dbo].[ReportType] ADD 
			CONSTRAINT [FK_ReportType#VC3Reporting_ReportType] FOREIGN KEY ([ID]) 
			REFERENCES [VC3Reporting].[ReportType] ([Id])
	END	
	
	IF EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportSchemaColumn]') AND type in (N'U'))
	BEGIN
		IF EXISTS (SELECT * FROM syscolumns where id = object_id(N'[dbo].[ReportSchemaColumn]') AND [Name]='Id')
		ALTER TABLE [dbo].[ReportSchemaColumn] ADD 
		CONSTRAINT [FK_ReportSchemaColumn#VC3Reporting_ReportSchemaColumn] FOREIGN KEY ([ID]) 
		REFERENCES [VC3Reporting].[ReportSchemaColumn] ([Id])
	END

	IF EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportColumnParameterValue]') AND type in (N'U'))
	BEGIN
		IF EXISTS (SELECT * FROM syscolumns where id = object_id(N'[dbo].[ReportColumnParameterValue]') AND [Name]='Id')
		ALTER TABLE [dbo].[ReportColumnParameterValue] ADD 
		CONSTRAINT [FK_ReportColumnParameterValue#VC3Reporting_ReportColumnParameterValue] FOREIGN KEY ([ID]) 
		REFERENCES [VC3Reporting].[ReportColumnParameterValue] ([Id])
	END

	IF EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportColumnType]') AND type in (N'U'))
	BEGIN
		IF EXISTS (SELECT * FROM syscolumns where id = object_id(N'[dbo].[ReportColumnType]') AND [Name]='Id')
		ALTER TABLE [dbo].[ReportColumnType] ADD 
		CONSTRAINT [FK_ReportColumnType#VC3Reporting_ReportColumnType] FOREIGN KEY ([ID]) 
		REFERENCES [VC3Reporting].[ReportColumnType] ([Id])
	END

	IF EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportFilterColumn]') AND type in (N'U'))
	BEGIN
		IF EXISTS (SELECT * FROM syscolumns where id = object_id(N'[dbo].[ReportFilterColumn]') AND [Name]='Id')
		ALTER TABLE [dbo].[ReportFilterColumn] ADD 
		CONSTRAINT [FK_ReportFilterColumn#VC3Reporting_ReportFilterColumn] FOREIGN KEY ([ID]) 
		REFERENCES [VC3Reporting].[ReportFilterColumn] ([Id])
	END

	IF EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportFilterValue]') AND type in (N'U'))
	BEGIN
		IF EXISTS (SELECT * FROM syscolumns where id = object_id(N'[dbo].[ReportFilterValue]') AND [Name]='Id')
		ALTER TABLE [dbo].[ReportFilterValue] ADD 
		CONSTRAINT [FK_ReportFilterValue#VC3Reporting_ReportFilterValue] FOREIGN KEY ([ID]) 
		REFERENCES [VC3Reporting].[ReportFilterValue] ([Id])
	END

	IF EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportFormat]') AND type in (N'U'))
	BEGIN
		IF EXISTS (SELECT * FROM syscolumns where id = object_id(N'[dbo].[ReportFormat]') AND [Name]='Id')
		ALTER TABLE [dbo].[ReportFormat] ADD 
		CONSTRAINT [FK_ReportFormat#VC3Reporting_ReportFormat] FOREIGN KEY ([ID]) 
		REFERENCES [VC3Reporting].[ReportFormat] ([Id])
	END

	IF EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportOrderColumn]') AND type in (N'U'))
	BEGIN
		IF EXISTS (SELECT * FROM syscolumns where id = object_id(N'[dbo].[ReportOrderColumn]') AND [Name]='Id')
		ALTER TABLE [dbo].[ReportOrderColumn] ADD 
		CONSTRAINT [FK_ReportOrderColumn#VC3Reporting_ReportOrderColumn] FOREIGN KEY ([ID]) 
		REFERENCES [VC3Reporting].[ReportOrderColumn] ([Id])
	END

	IF EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportSchemaDataType]') AND type in (N'U'))
	BEGIN
		IF EXISTS (SELECT * FROM syscolumns where id = object_id(N'[dbo].[ReportSchemaDataType]') AND [Name]='Id')
		ALTER TABLE [dbo].[ReportSchemaDataType] ADD 
		CONSTRAINT [FK_ReportSchemaDataType#VC3Reporting_ReportSchemaDataType] FOREIGN KEY ([ID]) 
		REFERENCES [VC3Reporting].[ReportSchemaDataType] ([Id])
	END
	
	IF EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportSchemaJoinMultiplicity]') AND type in (N'U'))
	BEGIN
		IF EXISTS (SELECT * FROM syscolumns where id = object_id(N'[dbo].[ReportSchemaJoinMultiplicity]') AND [Name]='Id')
		ALTER TABLE [dbo].[ReportSchemaJoinMultiplicity] ADD 
		CONSTRAINT [FK_ReportSchemaJoinMultiplicity#VC3Reporting_ReportSchemaJoinMultiplicity] FOREIGN KEY ([ID]) 
		REFERENCES [VC3Reporting].[ReportSchemaJoinMultiplicity] ([Id])
	END

	IF EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportSchemaOperator]') AND type in (N'U'))
	BEGIN
		IF EXISTS (SELECT * FROM syscolumns where id = object_id(N'[dbo].[ReportSchemaOperator]') AND [Name]='Id')
		ALTER TABLE [dbo].[ReportSchemaOperator] ADD 
		CONSTRAINT [FK_ReportSchemaOperator#VC3Reporting_ReportSchemaOperator] FOREIGN KEY ([ID]) 
		REFERENCES [VC3Reporting].[ReportSchemaOperator] ([Id])
	END

	IF EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportSchemaSummaryFunction]') AND type in (N'U'))
	BEGIN
		IF EXISTS (SELECT * FROM syscolumns where id = object_id(N'[dbo].[ReportSchemaSummaryFunction]') AND [Name]='Id')
		ALTER TABLE [dbo].[ReportSchemaSummaryFunction] ADD 
		CONSTRAINT [FK_ReportSchemaSummaryFunction#VC3Reporting_ReportSchemaSummaryFunction] FOREIGN KEY ([ID]) 
		REFERENCES [VC3Reporting].[ReportSchemaSummaryFunction] ([Id])
	END

	IF EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportSchemaTableParameter]') AND type in (N'U'))
	BEGIN
		IF EXISTS (SELECT * FROM syscolumns where id = object_id(N'[dbo].[ReportSchemaTableParameter]') AND [Name]='Id')
		ALTER TABLE [dbo].[ReportSchemaTableParameter] ADD 
		CONSTRAINT [FK_ReportSchemaTableParameter#VC3Reporting_ReportSchemaTableParameter] FOREIGN KEY ([ID]) 
		REFERENCES [VC3Reporting].[ReportSchemaTableParameter] ([Id])
	END

	IF EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportSelectColumn]') AND type in (N'U'))
	BEGIN
		IF EXISTS (SELECT * FROM syscolumns where id = object_id(N'[dbo].[ReportSelectColumn]') AND [Name]='Id')
		ALTER TABLE [dbo].[ReportSelectColumn] ADD 
		CONSTRAINT [FK_ReportSelectColumn#VC3Reporting_ReportSelectColumn] FOREIGN KEY ([ID]) 
		REFERENCES [VC3Reporting].[ReportSelectColumn] ([Id])
	END

	IF EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportSelectColumnSummaryFunction]') AND type in (N'U'))
	BEGIN
		IF EXISTS (SELECT * FROM syscolumns where id = object_id(N'[dbo].[ReportSelectColumnSummaryFunction]') AND [Name]='Id')
		ALTER TABLE [dbo].[ReportSelectColumnSummaryFunction] ADD 
		CONSTRAINT [FK_ReportSelectColumnSummaryFunction#VC3Reporting_ReportSelectColumnSummaryFunction] FOREIGN KEY ([ID]) 
		REFERENCES [VC3Reporting].[ReportSelectColumnSummaryFunction] ([Id])
	END

	IF EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportTypeColumn]') AND type in (N'U'))
	BEGIN
		IF EXISTS (SELECT * FROM syscolumns where id = object_id(N'[dbo].[ReportTypeColumn]') AND [Name]='Id')
		ALTER TABLE [dbo].[ReportTypeColumn] ADD 
		CONSTRAINT [FK_ReportTypeColumn#VC3Reporting_ReportTypeColumn] FOREIGN KEY ([ID]) 
		REFERENCES [VC3Reporting].[ReportTypeColumn] ([Id])
	END

	IF EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportTypeTable]') AND type in (N'U'))
	BEGIN
		IF EXISTS (SELECT * FROM syscolumns where id = object_id(N'[dbo].[ReportTypeTable]') AND [Name]='Id')
		ALTER TABLE [dbo].[ReportTypeTable] ADD 
		CONSTRAINT [FK_ReportTypeTable#VC3Reporting_ReportTypeTable] FOREIGN KEY ([ID]) 
		REFERENCES [VC3Reporting].[ReportTypeTable] ([Id])
	END

	IF EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ReportTypeFormat]') AND type in (N'U'))
	BEGIN
		IF EXISTS (SELECT * FROM syscolumns where id = object_id(N'[dbo].[ReportTypeFormat]') AND [Name]='Id')
		ALTER TABLE [dbo].[ReportTypeFormat] ADD 
		CONSTRAINT [FK_ReportTypeFormat#VC3Reporting_ReportTypeFormat] FOREIGN KEY ([ID]) 
		REFERENCES [VC3Reporting].[ReportTypeFormat] ([Id])
	END

drop proc MigrateForeignKeys