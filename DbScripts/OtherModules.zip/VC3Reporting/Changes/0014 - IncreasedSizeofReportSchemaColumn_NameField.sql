ALTER TABLE VC3Reporting.ReportSchemaColumn ALTER COLUMN
	Name varchar(150) not null