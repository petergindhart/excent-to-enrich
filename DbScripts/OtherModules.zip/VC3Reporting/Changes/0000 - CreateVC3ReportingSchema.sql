--create the scema so that it can recognize it later
exec VC3Deployment.CreateSchema 'VC3Reporting'

-- Setup basic modules
exec VC3Deployment.AddModule 'VC3Reporting'
exec VC3Deployment.AddModuleDependency @usedBy='dbo', @uses='VC3Reporting'
GO

create procedure MigrateForeignKeys
	@targetTableOwner	varchar(100),
	@targetTable		varchar(100),
	@sourceTableOwner	varchar(100),
	@sourceTable		varchar(100)
AS
begin
	declare @target varchar(500)
	declare @source varchar(500)
	set @source = '['+ isnull(@sourceTableOwner, 'dbo') + '].[' + @sourceTable +']'
	set @target = '['+ isnull(@targetTableOwner, 'dbo') + '].[' + @targetTable +']'

	-- Get all current Foreign Keys and store their name and parent table
	declare @ForeignKeys table (keyName varchar(100), fkTable varchar(100), fkColumn varchar(100), pkColumn varchar(100))
	insert into @ForeignKeys
	select fk.name, fkt.name, fkc.name, pkc.name
	from sysforeignkeys k
		inner join sysobjects fk on fk.id = k.constid
		inner join sysobjects fkt on fkt.id = k.fkeyid
		inner join sysobjects pkt on pkt.id = k.rkeyid
		inner join syscolumns fkc on fkc.id = fkt.id and k.fkey=fkc.colid
		inner join syscolumns pkc on pkc.id = pkt.id and k.rkey=pkc.colid
	where pkt.id=object_id(@source)
	and pkc.name in (select c.name from syscolumns c where id=object_id(@target))

	declare @key varchar(100)
	declare @fkTable varchar(100)
	declare fkDropCursor cursor for
		select keyName, fkTable from @ForeignKeys

	open fkDropCursor
	fetch next from fkDropCursor into @key, @fkTable

	-- Drop All Foreign Keys that point to the source table
	While @@FETCH_STATUS = 0
	BEGIN
		exec ('ALTER TABLE [' + @sourceTableOwner +'].['+ @fkTable +'] DROP CONSTRAINT [' + @key + ']')
		fetch next from fkDropCursor into @key, @fkTable
	END

	close fkDropCursor
	deallocate fkDropCursor

	-- Recreate the Foreign Keys with the Target Table
	declare @fkColumn varchar(500)
	declare @pkColumn varchar(500)	
	declare fkCreateCursor cursor for
	select keyName, fkTable, fkColumn, pkColumn from @ForeignKeys

	open fkCreateCursor
	fetch next from fkCreateCursor into @key, @fkTable, @fkColumn, @pkColumn
	
	While @@FETCH_STATUS = 0
	BEGIN
		exec(	'ALTER TABLE [' + @sourceTableOwner + '].[' + @fkTable + ']  WITH CHECK 
				ADD  CONSTRAINT [' + @key + '] FOREIGN KEY([' + @fkColumn + '])
				REFERENCES ' + @target + ' ([' + @pkColumn + '])
				ALTER TABLE [' + @sourceTableOwner + '].[' + @fkTable + ']
				CHECK CONSTRAINT [' + @key + ']')
		fetch next from fkCreateCursor into @key, @fkTable, @fkColumn, @pkColumn
	END

	close fkCreateCursor 
	deallocate fkCreateCursor 
end
GO