ALTER TABLE VC3Reporting.ReportTypeTable
ADD MergeColumnsIntoJoinTable BIT
GO

UPDATE VC3Reporting.ReportTypeTable
SET MergeColumnsIntoJoinTable = 0
GO

ALTER TABLE VC3Reporting.ReportTypeTable
ALTER COLUMN MergeColumnsIntoJoinTable BIT NOT NULL
GO

ALTER TABLE VC3Reporting.ReportType
ADD Description TEXT
GO

ALTER TABLE VC3Reporting.ReportSchemaColumn
ADD Description TEXT
GO