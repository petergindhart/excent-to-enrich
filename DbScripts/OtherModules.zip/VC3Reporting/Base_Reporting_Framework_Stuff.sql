if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_ReportColumn#Report#Columns]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[ReportColumn] DROP CONSTRAINT FK_ReportColumn#Report#Columns
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_ReportColumnParameterValue#Column#ParameterValues]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[ReportColumnParameterValue] DROP CONSTRAINT FK_ReportColumnParameterValue#Column#ParameterValues
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_ReportFilterColumn_ReportColumn]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[ReportFilterColumn] DROP CONSTRAINT FK_ReportFilterColumn_ReportColumn
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_ReportOrderColumn_ReportColumn]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[ReportOrderColumn] DROP CONSTRAINT FK_ReportOrderColumn_ReportColumn
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_ReportSelectColumn_ReportColumn]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[ReportSelectColumn] DROP CONSTRAINT FK_ReportSelectColumn_ReportColumn
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_ReportColumn#Type#]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[ReportColumn] DROP CONSTRAINT FK_ReportColumn#Type#
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_ReportFilterValue#Filter#Values]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[ReportFilterValue] DROP CONSTRAINT FK_ReportFilterValue#Filter#Values
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_Report_ReportFormat]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[Report] DROP CONSTRAINT FK_Report_ReportFormat
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_ReportColumn#Column#]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[ReportColumn] DROP CONSTRAINT FK_ReportColumn#Column#
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_ReportSchemaTableParameter#Column#]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[ReportSchemaTableParameter] DROP CONSTRAINT FK_ReportSchemaTableParameter#Column#
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_ReportTypeColumn#Column]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[ReportTypeColumn] DROP CONSTRAINT FK_ReportTypeColumn#Column
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_ReportColum#DataType#]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[ReportSchemaColumn] DROP CONSTRAINT FK_ReportColum#DataType#
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_ReportDataTypeOperator#DataType#Operators]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[ReportSchemaDataTypeOperator] DROP CONSTRAINT FK_ReportDataTypeOperator#DataType#Operators
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_ReportSchemaDataTypeSummaryFunction#SummaryFunctions]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[ReportSchemaDataTypeSummaryFunction] DROP CONSTRAINT FK_ReportSchemaDataTypeSummaryFunction#SummaryFunctions
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_ReportSchemaTableAssociation_ReportSchemaJoinType]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[ReportTypeTable] DROP CONSTRAINT FK_ReportSchemaTableAssociation_ReportSchemaJoinType
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_ReportFilter#Operator#]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[ReportFilterColumn] DROP CONSTRAINT FK_ReportFilter#Operator#
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_ReportDataTypeOperator#Operator#]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[ReportSchemaDataTypeOperator] DROP CONSTRAINT FK_ReportDataTypeOperator#Operator#
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_ReportSchemaTableParameter#Operator]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[ReportSchemaTableParameter] DROP CONSTRAINT FK_ReportSchemaTableParameter#Operator
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_ReportSchemaDataTypeSummaryFunction_ReportSchemaSummaryFunction]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[ReportSchemaDataTypeSummaryFunction] DROP CONSTRAINT FK_ReportSchemaDataTypeSummaryFunction_ReportSchemaSummaryFunction
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_ReportSelectColumn#SummaryFunction#]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[ReportSelectColumn] DROP CONSTRAINT FK_ReportSelectColumn#SummaryFunction#
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_ReportSelectColumnSummaryFunction_ReportSchemaSummaryFunction]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[ReportSelectColumnSummaryFunction] DROP CONSTRAINT FK_ReportSelectColumnSummaryFunction_ReportSchemaSummaryFunction
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_ReportColumn#Table#Columns]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[ReportSchemaColumn] DROP CONSTRAINT FK_ReportColumn#Table#Columns
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_ReportSchemaTableParameter#Table#Parameters]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[ReportSchemaTableParameter] DROP CONSTRAINT FK_ReportSchemaTableParameter#Table#Parameters
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_ReportTypeTable#Table]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[ReportTypeTable] DROP CONSTRAINT FK_ReportTypeTable#Table
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_ReportColumnParameterValue#Parameter#]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[ReportColumnParameterValue] DROP CONSTRAINT FK_ReportColumnParameterValue#Parameter#
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_ReportSelectColumnSummaryFunction#ReportSelectColumn#SummaryFunctions]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[ReportSelectColumnSummaryFunction] DROP CONSTRAINT FK_ReportSelectColumnSummaryFunction#ReportSelectColumn#SummaryFunctions
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_Report#Type#Reports]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[Report] DROP CONSTRAINT FK_Report#Type#Reports
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_ReportTypeTable_ReportType]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[ReportTypeTable] DROP CONSTRAINT FK_ReportTypeTable_ReportType
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_ReportColumn#Table]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[ReportColumn] DROP CONSTRAINT FK_ReportColumn#Table
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_ReportTypeColumn#Table#Columns]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[ReportTypeColumn] DROP CONSTRAINT FK_ReportTypeColumn#Table#Columns
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_ReportTypeTable#JoinTable#ChildTables]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[ReportTypeTable] DROP CONSTRAINT FK_ReportTypeTable#JoinTable#ChildTables
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[CharIndexText]') and xtype in (N'FN', N'IF', N'TF'))
drop function [dbo].[CharIndexText]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetChar1s]') and xtype in (N'FN', N'IF', N'TF'))
drop function [dbo].[GetChar1s]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetChars]') and xtype in (N'FN', N'IF', N'TF'))
drop function [dbo].[GetChars]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetUniqueidentifiers]') and xtype in (N'FN', N'IF', N'TF'))
drop function [dbo].[GetUniqueidentifiers]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetVarchars]') and xtype in (N'FN', N'IF', N'TF'))
drop function [dbo].[GetVarchars]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportColumnGroupColumn_GetRecordsByReport]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportColumnGroupColumn_GetRecordsByReport]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportColumnParameterValue_DeleteRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportColumnParameterValue_DeleteRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportColumnParameterValue_GetAllRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportColumnParameterValue_GetAllRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportColumnParameterValue_GetRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportColumnParameterValue_GetRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportColumnParameterValue_GetRecordsByParameter]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportColumnParameterValue_GetRecordsByParameter]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportColumnParameterValue_GetRecordsByReportColumn]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportColumnParameterValue_GetRecordsByReportColumn]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportColumnParameterValue_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportColumnParameterValue_InsertRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportColumnParameterValue_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportColumnParameterValue_UpdateRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportColumnType_DeleteRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportColumnType_DeleteRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportColumnType_GetAllRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportColumnType_GetAllRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportColumnType_GetRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportColumnType_GetRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportColumnType_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportColumnType_InsertRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportColumnType_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportColumnType_UpdateRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportColumn_DeleteRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportColumn_DeleteRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportColumn_GetAllRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportColumn_GetAllRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportColumn_GetRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportColumn_GetRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportColumn_GetRecordsByReport]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportColumn_GetRecordsByReport]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportColumn_GetRecordsByReportTypeTable]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportColumn_GetRecordsByReportTypeTable]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportColumn_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportColumn_InsertRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportColumn_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportColumn_UpdateRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportDataTypeOperator_DeleteRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportDataTypeOperator_DeleteRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportDataTypeOperator_GetRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportDataTypeOperator_GetRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportDataTypeOperator_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportDataTypeOperator_InsertRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportDataTypeOperator_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportDataTypeOperator_UpdateRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportDataType_DeleteRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportDataType_DeleteRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportDataType_GetRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportDataType_GetRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportDataType_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportDataType_InsertRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportDataType_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportDataType_UpdateRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportFilterColumn_DeleteRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportFilterColumn_DeleteRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportFilterColumn_GetAllRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportFilterColumn_GetAllRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportFilterColumn_GetRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportFilterColumn_GetRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportFilterColumn_GetRecordsByOperator]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportFilterColumn_GetRecordsByOperator]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportFilterColumn_GetRecordsByReport]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportFilterColumn_GetRecordsByReport]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportFilterColumn_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportFilterColumn_InsertRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportFilterColumn_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportFilterColumn_UpdateRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportFilterOperator_DeleteRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportFilterOperator_DeleteRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportFilterOperator_GetRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportFilterOperator_GetRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportFilterOperator_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportFilterOperator_InsertRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportFilterOperator_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportFilterOperator_UpdateRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportFilterValue_DeleteRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportFilterValue_DeleteRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportFilterValue_GetAllRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportFilterValue_GetAllRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportFilterValue_GetRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportFilterValue_GetRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportFilterValue_GetRecordsByFilter]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportFilterValue_GetRecordsByFilter]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportFilterValue_GetRecordsByFilterColumn]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportFilterValue_GetRecordsByFilterColumn]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportFilterValue_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportFilterValue_InsertRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportFilterValue_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportFilterValue_UpdateRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportFilter_DeleteRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportFilter_DeleteRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportFilter_GetRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportFilter_GetRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportFilter_GetRecordsByReportId]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportFilter_GetRecordsByReportId]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportFilter_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportFilter_InsertRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportFilter_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportFilter_UpdateRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportFormat_DeleteRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportFormat_DeleteRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportFormat_GetAllRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportFormat_GetAllRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportFormat_GetRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportFormat_GetRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportFormat_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportFormat_InsertRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportFormat_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportFormat_UpdateRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportGroupColumn_GetRecordsByReport]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportGroupColumn_GetRecordsByReport]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportOrderColumn_DeleteRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportOrderColumn_DeleteRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportOrderColumn_GetAllRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportOrderColumn_GetAllRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportOrderColumn_GetRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportOrderColumn_GetRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportOrderColumn_GetRecordsByReport]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportOrderColumn_GetRecordsByReport]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportOrderColumn_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportOrderColumn_InsertRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportOrderColumn_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportOrderColumn_UpdateRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportParameterColumn_GetRecordsByReport]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportParameterColumn_GetRecordsByReport]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaColumn_DeleteRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaColumn_DeleteRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaColumn_GetAllRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaColumn_GetAllRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaColumn_GetRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaColumn_GetRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaColumn_GetRecordsByTable]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaColumn_GetRecordsByTable]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaColumn_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaColumn_InsertRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaColumn_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaColumn_UpdateRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaDataType_DeleteRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaDataType_DeleteRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaDataType_DeleteRecordsForReportSchemaDataTypeOperatorAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaDataType_DeleteRecordsForReportSchemaDataTypeOperatorAssociation]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaDataType_DeleteRecordsForReportSchemaDataTypeSummaryFunctionAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaDataType_DeleteRecordsForReportSchemaDataTypeSummaryFunctionAssociation]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaDataType_GetAllRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaDataType_GetAllRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaDataType_GetRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaDataType_GetRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaDataType_GetRecordsForReportSchemaDataTypeOperatorAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaDataType_GetRecordsForReportSchemaDataTypeOperatorAssociation]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaDataType_GetRecordsForReportSchemaDataTypeSummaryFunctionAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaDataType_GetRecordsForReportSchemaDataTypeSummaryFunctionAssociation]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaDataType_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaDataType_InsertRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaDataType_InsertRecordsForReportSchemaDataTypeOperatorAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaDataType_InsertRecordsForReportSchemaDataTypeOperatorAssociation]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaDataType_InsertRecordsForReportSchemaDataTypeSummaryFunctionAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaDataType_InsertRecordsForReportSchemaDataTypeSummaryFunctionAssociation]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaDataType_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaDataType_UpdateRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaJoinMultiplicity_DeleteRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaJoinMultiplicity_DeleteRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaJoinMultiplicity_GetAllRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaJoinMultiplicity_GetAllRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaJoinMultiplicity_GetRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaJoinMultiplicity_GetRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaJoinMultiplicity_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaJoinMultiplicity_InsertRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaJoinMultiplicity_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaJoinMultiplicity_UpdateRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaJoinType_DeleteRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaJoinType_DeleteRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaJoinType_GetRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaJoinType_GetRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaJoinType_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaJoinType_InsertRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaJoinType_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaJoinType_UpdateRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaOperator_DeleteRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaOperator_DeleteRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaOperator_DeleteRecordsForReportSchemaDataTypeOperatorAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaOperator_DeleteRecordsForReportSchemaDataTypeOperatorAssociation]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaOperator_GetAllRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaOperator_GetAllRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaOperator_GetRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaOperator_GetRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaOperator_GetRecordsForReportSchemaDataTypeOperatorAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaOperator_GetRecordsForReportSchemaDataTypeOperatorAssociation]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaOperator_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaOperator_InsertRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaOperator_InsertRecordsForReportSchemaDataTypeOperatorAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaOperator_InsertRecordsForReportSchemaDataTypeOperatorAssociation]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaOperator_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaOperator_UpdateRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaSummaryFunction_DeleteRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaSummaryFunction_DeleteRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaSummaryFunction_DeleteRecordsForReportSchemaDataTypeSummaryFunctionAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaSummaryFunction_DeleteRecordsForReportSchemaDataTypeSummaryFunctionAssociation]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaSummaryFunction_DeleteRecordsForReportSelectColumnSummaryFunctionAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaSummaryFunction_DeleteRecordsForReportSelectColumnSummaryFunctionAssociation]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaSummaryFunction_GetAllRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaSummaryFunction_GetAllRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaSummaryFunction_GetRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaSummaryFunction_GetRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaSummaryFunction_GetRecordsForReportSchemaDataTypeSummaryFunctionAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaSummaryFunction_GetRecordsForReportSchemaDataTypeSummaryFunctionAssociation]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaSummaryFunction_GetRecordsForReportSelectColumnSummaryFunctionAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaSummaryFunction_GetRecordsForReportSelectColumnSummaryFunctionAssociation]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaSummaryFunction_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaSummaryFunction_InsertRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaSummaryFunction_InsertRecordsForReportSchemaDataTypeSummaryFunctionAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaSummaryFunction_InsertRecordsForReportSchemaDataTypeSummaryFunctionAssociation]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaSummaryFunction_InsertRecordsForReportSelectColumnSummaryFunctionAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaSummaryFunction_InsertRecordsForReportSelectColumnSummaryFunctionAssociation]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaSummaryFunction_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaSummaryFunction_UpdateRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaTableAssociation_DeleteRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaTableAssociation_DeleteRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaTableAssociation_GetRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaTableAssociation_GetRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaTableAssociation_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaTableAssociation_InsertRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaTableAssociation_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaTableAssociation_UpdateRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaTableParameter_DeleteRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaTableParameter_DeleteRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaTableParameter_GetAllRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaTableParameter_GetAllRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaTableParameter_GetRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaTableParameter_GetRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaTableParameter_GetRecordsBySchemaTable]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaTableParameter_GetRecordsBySchemaTable]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaTableParameter_GetRecordsByTable]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaTableParameter_GetRecordsByTable]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaTableParameter_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaTableParameter_InsertRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaTableParameter_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaTableParameter_UpdateRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaTable_DeleteRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaTable_DeleteRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaTable_GetAllRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaTable_GetAllRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaTable_GetRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaTable_GetRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaTable_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaTable_InsertRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaTable_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSchemaTable_UpdateRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSelectColumn_DeleteRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSelectColumn_DeleteRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSelectColumn_DeleteRecordsForReportSelectColumnSummaryFunctionAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSelectColumn_DeleteRecordsForReportSelectColumnSummaryFunctionAssociation]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSelectColumn_GetAllRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSelectColumn_GetAllRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSelectColumn_GetRecordsByReport]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSelectColumn_GetRecordsByReport]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSelectColumn_GetRecordsBySummaryFunction]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSelectColumn_GetRecordsBySummaryFunction]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSelectColumn_GetRecordsForReportSelectColumnSummaryFunctionAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSelectColumn_GetRecordsForReportSelectColumnSummaryFunctionAssociation]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSelectColumn_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSelectColumn_InsertRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSelectColumn_InsertRecordsForReportSelectColumnSummaryFunctionAssociation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSelectColumn_InsertRecordsForReportSelectColumnSummaryFunctionAssociation]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSelectColumn_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSelectColumn_UpdateRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSortOrder_DeleteRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSortOrder_DeleteRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSortOrder_GetRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSortOrder_GetRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSortOrder_GetRecordsByReportId]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSortOrder_GetRecordsByReportId]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSortOrder_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSortOrder_InsertRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSortOrder_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSortOrder_UpdateRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSummaryFunction_DeleteRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSummaryFunction_DeleteRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSummaryFunction_GetRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSummaryFunction_GetRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSummaryFunction_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSummaryFunction_InsertRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSummaryFunction_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSummaryFunction_UpdateRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportTableAssociation_DeleteRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportTableAssociation_DeleteRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportTableAssociation_GetRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportTableAssociation_GetRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportTableAssociation_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportTableAssociation_InsertRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportTableAssociation_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportTableAssociation_UpdateRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportTable_DeleteRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportTable_DeleteRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportTable_GetRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportTable_GetRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportTable_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportTable_InsertRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportTable_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportTable_UpdateRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportTypeColumn_DeleteRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportTypeColumn_DeleteRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportTypeColumn_GetAllRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportTypeColumn_GetAllRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportTypeColumn_GetRecordsByReportTypeTable]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportTypeColumn_GetRecordsByReportTypeTable]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportTypeColumn_GetRecordsByTable]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportTypeColumn_GetRecordsByTable]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportTypeColumn_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportTypeColumn_InsertRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportTypeColumn_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportTypeColumn_UpdateRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportTypeTable_DeleteRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportTypeTable_DeleteRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportTypeTable_GetAllRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportTypeTable_GetAllRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportTypeTable_GetRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportTypeTable_GetRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportTypeTable_GetRecordsByJoinTable]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportTypeTable_GetRecordsByJoinTable]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportTypeTable_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportTypeTable_InsertRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportTypeTable_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportTypeTable_UpdateRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportType_DeleteRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportType_DeleteRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportType_GetAllRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportType_GetAllRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportType_GetRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportType_GetRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportType_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportType_InsertRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportType_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportType_UpdateRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Report_DeleteRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Report_DeleteRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Report_GetAllRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Report_GetAllRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Report_GetRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Report_GetRecords]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Report_GetRecordsByOwner]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Report_GetRecordsByOwner]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Report_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Report_InsertRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Report_IsUniqueTitle]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Report_IsUniqueTitle]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Report_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Report_UpdateRecord]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportTypeColumnView]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[ReportTypeColumnView]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportTypeView]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[ReportTypeView]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Report]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[Report]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportColumn]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ReportColumn]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportColumnParameterValue]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ReportColumnParameterValue]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportColumnType]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ReportColumnType]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportFilterColumn]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ReportFilterColumn]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportFilterValue]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ReportFilterValue]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportFormat]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ReportFormat]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportOrderColumn]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ReportOrderColumn]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaColumn]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ReportSchemaColumn]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaDataType]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ReportSchemaDataType]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaDataTypeOperator]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ReportSchemaDataTypeOperator]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaDataTypeSummaryFunction]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ReportSchemaDataTypeSummaryFunction]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaJoinMultiplicity]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ReportSchemaJoinMultiplicity]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaOperator]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ReportSchemaOperator]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaSummaryFunction]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ReportSchemaSummaryFunction]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaTable]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ReportSchemaTable]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSchemaTableParameter]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ReportSchemaTableParameter]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSelectColumn]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ReportSelectColumn]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSelectColumnSummaryFunction]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ReportSelectColumnSummaryFunction]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportType]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ReportType]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportTypeColumn]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ReportTypeColumn]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportTypeTable]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ReportTypeTable]
GO

if exists (select * from dbo.systypes where name = N'char1array')
exec sp_droptype N'char1array'
GO

if exists (select * from dbo.systypes where name = N'char1uniqueidentifierarray')
exec sp_droptype N'char1uniqueidentifierarray'
GO

if exists (select * from dbo.systypes where name = N'chararray')
exec sp_droptype N'chararray'
GO

if exists (select * from dbo.systypes where name = N'uniqueidentifierarray')
exec sp_droptype N'uniqueidentifierarray'
GO

if exists (select * from dbo.systypes where name = N'uniqueidentifieruniqueidentifierarray')
exec sp_droptype N'uniqueidentifieruniqueidentifierarray'
GO

if exists (select * from dbo.systypes where name = N'varchararray')
exec sp_droptype N'varchararray'
GO

setuser
GO

EXEC sp_addtype N'char1array', N'text', N'null'
GO

setuser
GO

setuser
GO

EXEC sp_addtype N'char1uniqueidentifierarray', N'text', N'null'
GO

setuser
GO

setuser
GO

EXEC sp_addtype N'chararray', N'text', N'null'
GO

setuser
GO

setuser
GO

EXEC sp_addtype N'uniqueidentifierarray', N'text', N'null'
GO

setuser
GO

setuser
GO

EXEC sp_addtype N'uniqueidentifieruniqueidentifierarray', N'text', N'null'
GO

setuser
GO

setuser
GO

EXEC sp_addtype N'varchararray', N'text', N'null'
GO

setuser
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

Create FUNCTION dbo.CharIndexText(@search char, @idArray text, @start int )  
RETURNS int AS  
BEGIN

	declare @ret int

	if datalength(@idArray) <= 8000
	begin
		-- Use real charindex if possible
		set @ret = charindex(@search, @idArray, @start)
	end
	else if @idArray is null or @search is null
	begin
		set @ret = null
	end
	else
	begin
		-- search string manually
		set @ret = @start

		while substring(@idArray, @ret, 1) <> @search and @ret <= datalength(@idArray)
		begin
			set @ret = @ret + 1
		end

		if @ret > datalength(@idArray)
			set @ret = 0
	end

	return @ret
end


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO






CREATE   FUNCTION dbo.GetChar1s (@idArray char1array)  
	RETURNS @idTable table(id char(1)) AS  
	BEGIN 

	if (@idArray is null)
		return

	declare @start int
	declare @finish int

	set @start = 1
	set @finish = charindex('|', @idArray)

	while @finish > 0
	begin
		insert into @idTable
		values (cast(substring(@idArray, @start, @finish-@start) as char(1)))
		set @start = @finish + 1
		set @finish = charindex('|', @idArray, @start)
	end

	insert into @idTable
	values (cast(substring(@idArray, @start, datalength(@idArray)-@start+1) as char(1)))

	return 
	END
					



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

 CREATE FUNCTION dbo.GetChars (@idArray chararray)  
			RETURNS @idTable table(id char(1)) AS  
		BEGIN 
			if (@idArray is null)
				return

			declare @start int
			declare @finish int

			set @start = 1
			set @finish = dbo.CharIndexText('|', @idArray, @start)

			while @finish > 0
			begin
				insert into @idTable
				values (cast(substring(@idArray, @start, @finish-@start) as char(1)))
				set @start = @finish + 1
				set @finish = dbo.CharIndexText('|', @idArray, @start)
			end

			insert into @idTable
			values (cast(substring(@idArray, @start, datalength(@idArray)-@start+1) as char(1)))

			return 
		END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE FUNCTION dbo.GetUniqueidentifiers (@idArray uniqueidentifierarray)  
			RETURNS @idTable table(id uniqueidentifier) AS  
		BEGIN 
			if (@idArray is null)
				return

			declare @start int
			declare @finish int

			set @start = 1
			set @finish = dbo.CharIndexText('|', @idArray, @start)

			while @finish > 0
			begin
				insert into @idTable
				values (cast(substring(@idArray, @start, @finish-@start) as uniqueidentifier))
				set @start = @finish + 1
				set @finish = charindex('|', @idArray, @start)
			end

			insert into @idTable
			values (cast(substring(@idArray, @start, datalength(@idArray)-@start+1) as uniqueidentifier))

			return 
		END


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO


CREATE FUNCTION dbo.GetVarchars (@idArray varchararray)  
			RETURNS @idTable table(id varchar(50)) AS  
		BEGIN 
			if (@idArray is null)
				return

			declare @start int
			declare @finish int

			set @start = 1
			set @finish = dbo.CharIndexText('|', @idArray, @start)

			while @finish > 0
			begin
				insert into @idTable
				values (cast(substring(@idArray, @start, @finish-@start) as varchar(50)))
				set @start = @finish + 1
				set @finish = charindex('|', @idArray, @start)
			end

			insert into @idTable
			values (cast(substring(@idArray, @start, datalength(@idArray)-@start+1) as varchar(50)))

			return 
		END


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE TABLE [dbo].[Report] (
	[Id] [uniqueidentifier] NOT NULL ,
	[Title] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Query] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Owner] [uniqueidentifier] NULL ,
	[Type] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Path] [varchar] (300) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Description] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Format] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[ReportColumn] (
	[Id]  uniqueidentifier ROWGUIDCOL  NOT NULL ,
	[Type] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Report] [uniqueidentifier] NOT NULL ,
	[ReportTypeTable] [uniqueidentifier] NOT NULL ,
	[SchemaColumn] [uniqueidentifier] NOT NULL ,
	[Sequence] [int] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ReportColumnParameterValue] (
	[Id] [uniqueidentifier] NOT NULL ,
	[ReportColumn] [uniqueidentifier] NOT NULL ,
	[SchemaTableParameter] [uniqueidentifier] NOT NULL ,
	[ValueExpression] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ReportColumnType] (
	[Id] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Name] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ReportFilterColumn] (
	[Id] [uniqueidentifier] NOT NULL ,
	[SchemaOperator] [uniqueidentifier] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ReportFilterValue] (
	[Id] [uniqueidentifier] NOT NULL ,
	[FilterColumn] [uniqueidentifier] NOT NULL ,
	[ValueExpression] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ReportFormat] (
	[Id] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Name] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Builder] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Template] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Datasource] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ReportOrderColumn] (
	[Id] [uniqueidentifier] NOT NULL ,
	[IsAscending] [bit] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ReportSchemaColumn] (
	[Id] [uniqueidentifier] NOT NULL ,
	[Name] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[SchemaTable] [uniqueidentifier] NOT NULL ,
	[SchemaDataType] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[DisplayExpression] [varchar] (1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[ValueExpression] [varchar] (1000) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[OrderExpression] [varchar] (1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[LinkExpression] [varchar] (1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[LinkFormat] [varchar] (1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[IsSelectColumn] [bit] NOT NULL ,
	[IsFilterColumn] [bit] NOT NULL ,
	[IsParameterColumn] [bit] NOT NULL ,
	[IsGroupColumn] [bit] NOT NULL ,
	[IsOrderColumn] [bit] NOT NULL ,
	[IsAggregated] [bit] NOT NULL ,
	[AllowedValuesExpression] [varchar] (1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Sequence] [int] NOT NULL ,
	[Width] [decimal](18, 0) NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ReportSchemaDataType] (
	[Id] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Name] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[ValueEditor] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[OptionEditor] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[TypeName] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Format] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[SqlExpression] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[DefaultColumnWidth] [decimal](18, 4) NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ReportSchemaDataTypeOperator] (
	[SchemaDataType] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[SchemaOperator] [uniqueidentifier] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ReportSchemaDataTypeSummaryFunction] (
	[SchemaDataType] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[SchemaSummaryFunction] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ReportSchemaJoinMultiplicity] (
	[Id] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Name] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[LowerBound] [int] NOT NULL ,
	[UpperBound] [int] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ReportSchemaOperator] (
	[Id] [uniqueidentifier] NOT NULL ,
	[Name] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Expression] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[ConcatExpression] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[FindRegex] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[ReplaceRegex] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Sequence] [int] NOT NULL ,
	[AllowMultipleValues] [bit] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ReportSchemaSummaryFunction] (
	[Id] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Name] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Sequence] [int] NOT NULL ,
	[FunctionExpression] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ReportSchemaTable] (
	[Id] [uniqueidentifier] NOT NULL ,
	[Name] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[TableExpression] [varchar] (500) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[IdentityExpression] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ReportSchemaTableParameter] (
	[Id]  uniqueidentifier ROWGUIDCOL  NOT NULL ,
	[Name] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[SchemaTable] [uniqueidentifier] NOT NULL ,
	[SchemaColumn] [uniqueidentifier] NOT NULL ,
	[SchemaOperator] [uniqueidentifier] NOT NULL ,
	[IsRequired] [bit] NOT NULL ,
	[Sequence] [int] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ReportSelectColumn] (
	[Id] [uniqueidentifier] NOT NULL ,
	[Label] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[SchemaSummaryFunction] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ReportSelectColumnSummaryFunction] (
	[SelectColumn] [uniqueidentifier] NOT NULL ,
	[SummaryFunction] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ReportType] (
	[Id] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Name] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[IsEditable] [bit] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ReportTypeColumn] (
	[SchemaColumn] [uniqueidentifier] NOT NULL ,
	[ReportTypeTable] [uniqueidentifier] NOT NULL ,
	[Name] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Sequence] [int] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ReportTypeTable] (
	[Id] [uniqueidentifier] NOT NULL ,
	[Name] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[ReportType] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Sequence] [int] NOT NULL ,
	[SchemaTable] [uniqueidentifier] NOT NULL ,
	[JoinTable] [uniqueidentifier] NULL ,
	[JoinMultiplicity] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[JoinExpression] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[ColumnPrefix] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Report] WITH NOCHECK ADD 
	CONSTRAINT [PK_Report] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[ReportColumn] WITH NOCHECK ADD 
	CONSTRAINT [PK_ReportColumn] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[ReportColumnParameterValue] WITH NOCHECK ADD 
	CONSTRAINT [PK_ReportColumnParameterValue] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[ReportColumnType] WITH NOCHECK ADD 
	CONSTRAINT [PK_ReportColumnType] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[ReportFilterColumn] WITH NOCHECK ADD 
	CONSTRAINT [PK_ReportFilter] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[ReportFilterValue] WITH NOCHECK ADD 
	CONSTRAINT [PK_ReportFilterValue] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[ReportFormat] WITH NOCHECK ADD 
	CONSTRAINT [PK_ReportFormat] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[ReportOrderColumn] WITH NOCHECK ADD 
	CONSTRAINT [PK_ReportSortOrder] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[ReportSchemaColumn] WITH NOCHECK ADD 
	CONSTRAINT [PK_ReportFilterProperty] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[ReportSchemaDataType] WITH NOCHECK ADD 
	CONSTRAINT [PK_ReportDataType] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[ReportSchemaDataTypeOperator] WITH NOCHECK ADD 
	CONSTRAINT [PK_ReportDataTypeOperator] PRIMARY KEY  CLUSTERED 
	(
		[SchemaDataType],
		[SchemaOperator]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[ReportSchemaDataTypeSummaryFunction] WITH NOCHECK ADD 
	CONSTRAINT [PK_ReportSchemaDataTypeSummaryFunction] PRIMARY KEY  CLUSTERED 
	(
		[SchemaDataType],
		[SchemaSummaryFunction]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[ReportSchemaJoinMultiplicity] WITH NOCHECK ADD 
	CONSTRAINT [PK_ReportSchemaJoinType] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[ReportSchemaOperator] WITH NOCHECK ADD 
	CONSTRAINT [PK_ReportFilterOperator] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[ReportSchemaSummaryFunction] WITH NOCHECK ADD 
	CONSTRAINT [PK_ReportSchemaSummaryFunction] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[ReportSchemaTable] WITH NOCHECK ADD 
	CONSTRAINT [PK_ReportDataSource] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[ReportSchemaTableParameter] WITH NOCHECK ADD 
	CONSTRAINT [PK_ReportSchemaTableParameter] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[ReportSelectColumn] WITH NOCHECK ADD 
	CONSTRAINT [PK_ReportSelectColumn] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[ReportSelectColumnSummaryFunction] WITH NOCHECK ADD 
	CONSTRAINT [PK_ReportSelectColumnSummaryFunction] PRIMARY KEY  CLUSTERED 
	(
		[SelectColumn],
		[SummaryFunction]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[ReportType] WITH NOCHECK ADD 
	CONSTRAINT [PK_ReportType] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[ReportTypeColumn] WITH NOCHECK ADD 
	CONSTRAINT [PK_ReportTypeColumn] PRIMARY KEY  CLUSTERED 
	(
		[SchemaColumn],
		[ReportTypeTable]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[ReportTypeTable] WITH NOCHECK ADD 
	CONSTRAINT [PK_ReportTableAssociation] PRIMARY KEY  CLUSTERED 
	(
		[Id]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Report] ADD 
	CONSTRAINT [DF_Report_Id] DEFAULT (newid()) FOR [Id]
GO

ALTER TABLE [dbo].[ReportColumn] ADD 
	CONSTRAINT [DF_ReportColumn_Id] DEFAULT (newid()) FOR [Id]
GO

ALTER TABLE [dbo].[ReportFilterColumn] ADD 
	CONSTRAINT [DF_ReportFilter_ID] DEFAULT (newid()) FOR [Id]
GO

ALTER TABLE [dbo].[ReportFilterValue] ADD 
	CONSTRAINT [DF_ReportFilterValue_ID] DEFAULT (newid()) FOR [Id]
GO

ALTER TABLE [dbo].[ReportOrderColumn] ADD 
	CONSTRAINT [DF_ReportSortOrder_ID] DEFAULT (newid()) FOR [Id]
GO

ALTER TABLE [dbo].[ReportSchemaColumn] ADD 
	CONSTRAINT [DF_ReportFilterProperty_ID] DEFAULT (newid()) FOR [Id],
	CONSTRAINT [DF_ReportColumn_DataType] DEFAULT ('t') FOR [SchemaDataType],
	CONSTRAINT [DF_ReportSchemaColumn_AllowSelectColumn] DEFAULT (1) FOR [IsSelectColumn],
	CONSTRAINT [DF_ReportSchemaColumn_IsSelectColumn1] DEFAULT (1) FOR [IsFilterColumn],
	CONSTRAINT [DF_ReportSchemaColumn_IsSelectColumn2] DEFAULT (1) FOR [IsParameterColumn],
	CONSTRAINT [DF_ReportSchemaColumn_IsSelectColumn3] DEFAULT (1) FOR [IsGroupColumn],
	CONSTRAINT [DF_ReportSchemaColumn_IsSelectColumn4] DEFAULT (1) FOR [IsOrderColumn],
	CONSTRAINT [DF_ReportSchemaColumn_IsAggregated] DEFAULT (0) FOR [IsAggregated],
	CONSTRAINT [DF_ReportSchemaColumn_Sequence] DEFAULT (0) FOR [Sequence]
GO

ALTER TABLE [dbo].[ReportSchemaDataType] ADD 
	CONSTRAINT [DF_ReportSchemaDataType_DefaultColumnWidth] DEFAULT (1) FOR [DefaultColumnWidth]
GO

ALTER TABLE [dbo].[ReportSchemaJoinMultiplicity] ADD 
	CONSTRAINT [DF_ReportSchemaJoinMultiplicity_IsOptional] DEFAULT (0) FOR [LowerBound],
	CONSTRAINT [DF_ReportSchemaJoinMultiplicity_UpperBound] DEFAULT (0) FOR [UpperBound]
GO

ALTER TABLE [dbo].[ReportSchemaOperator] ADD 
	CONSTRAINT [DF_ReportFilterOperator] DEFAULT (newid()) FOR [Id],
	CONSTRAINT [DF_ReportSchemaOperator_Sequence] DEFAULT (0) FOR [Sequence],
	CONSTRAINT [DF_ReportSchemaOperator_AllowMultipleValues] DEFAULT (0) FOR [AllowMultipleValues]
GO

ALTER TABLE [dbo].[ReportSchemaTable] ADD 
	CONSTRAINT [DF_ReportDataSource_ID] DEFAULT (newid()) FOR [Id]
GO

ALTER TABLE [dbo].[ReportSchemaTableParameter] ADD 
	CONSTRAINT [DF_ReportSchemaTableParameter_Id] DEFAULT (newid()) FOR [Id],
	CONSTRAINT [DF_ReportSchemaTableParameter_Sequence] DEFAULT (0) FOR [Sequence]
GO

ALTER TABLE [dbo].[ReportType] ADD 
	CONSTRAINT [DF_ReportType_IsEditable] DEFAULT (1) FOR [IsEditable]
GO

ALTER TABLE [dbo].[ReportTypeColumn] ADD 
	CONSTRAINT [DF_ReportTypeColumn_Sequence] DEFAULT (0) FOR [Sequence]
GO

ALTER TABLE [dbo].[ReportTypeTable] ADD 
	CONSTRAINT [DF_ReportTypeTable_Id] DEFAULT (newid()) FOR [Id],
	CONSTRAINT [DF_ReportTypeTable_Sequence] DEFAULT (0) FOR [Sequence]
GO

ALTER TABLE [dbo].[Report] ADD 
	CONSTRAINT [FK_Report#Type#Reports] FOREIGN KEY 
	(
		[Type]
	) REFERENCES [dbo].[ReportType] (
		[Id]
	),
	CONSTRAINT [FK_Report_ReportFormat] FOREIGN KEY 
	(
		[Format]
	) REFERENCES [dbo].[ReportFormat] (
		[Id]
	)
GO

ALTER TABLE [dbo].[ReportColumn] ADD 
	CONSTRAINT [FK_ReportColumn#Column#] FOREIGN KEY 
	(
		[SchemaColumn]
	) REFERENCES [dbo].[ReportSchemaColumn] (
		[Id]
	) ON DELETE CASCADE  NOT FOR REPLICATION ,
	CONSTRAINT [FK_ReportColumn#Report#Columns] FOREIGN KEY 
	(
		[Report]
	) REFERENCES [dbo].[Report] (
		[Id]
	) ON DELETE CASCADE  NOT FOR REPLICATION ,
	CONSTRAINT [FK_ReportColumn#Table] FOREIGN KEY 
	(
		[ReportTypeTable]
	) REFERENCES [dbo].[ReportTypeTable] (
		[Id]
	),
	CONSTRAINT [FK_ReportColumn#Type#] FOREIGN KEY 
	(
		[Type]
	) REFERENCES [dbo].[ReportColumnType] (
		[Id]
	) NOT FOR REPLICATION 
GO

ALTER TABLE [dbo].[ReportColumnParameterValue] ADD 
	CONSTRAINT [FK_ReportColumnParameterValue#Column#ParameterValues] FOREIGN KEY 
	(
		[ReportColumn]
	) REFERENCES [dbo].[ReportColumn] (
		[Id]
	) ON DELETE CASCADE  NOT FOR REPLICATION ,
	CONSTRAINT [FK_ReportColumnParameterValue#Parameter#] FOREIGN KEY 
	(
		[SchemaTableParameter]
	) REFERENCES [dbo].[ReportSchemaTableParameter] (
		[Id]
	) NOT FOR REPLICATION 
GO

ALTER TABLE [dbo].[ReportFilterColumn] ADD 
	CONSTRAINT [FK_ReportFilter#Operator#] FOREIGN KEY 
	(
		[SchemaOperator]
	) REFERENCES [dbo].[ReportSchemaOperator] (
		[Id]
	),
	CONSTRAINT [FK_ReportFilterColumn_ReportColumn] FOREIGN KEY 
	(
		[Id]
	) REFERENCES [dbo].[ReportColumn] (
		[Id]
	) ON DELETE CASCADE  NOT FOR REPLICATION 
GO

ALTER TABLE [dbo].[ReportFilterValue] ADD 
	CONSTRAINT [FK_ReportFilterValue#Filter#Values] FOREIGN KEY 
	(
		[FilterColumn]
	) REFERENCES [dbo].[ReportFilterColumn] (
		[Id]
	) ON DELETE CASCADE 
GO

ALTER TABLE [dbo].[ReportOrderColumn] ADD 
	CONSTRAINT [FK_ReportOrderColumn_ReportColumn] FOREIGN KEY 
	(
		[Id]
	) REFERENCES [dbo].[ReportColumn] (
		[Id]
	) ON DELETE CASCADE  NOT FOR REPLICATION 
GO

ALTER TABLE [dbo].[ReportSchemaColumn] ADD 
	CONSTRAINT [FK_ReportColum#DataType#] FOREIGN KEY 
	(
		[SchemaDataType]
	) REFERENCES [dbo].[ReportSchemaDataType] (
		[Id]
	),
	CONSTRAINT [FK_ReportColumn#Table#Columns] FOREIGN KEY 
	(
		[SchemaTable]
	) REFERENCES [dbo].[ReportSchemaTable] (
		[Id]
	)
GO

ALTER TABLE [dbo].[ReportSchemaDataTypeOperator] ADD 
	CONSTRAINT [FK_ReportDataTypeOperator#DataType#Operators] FOREIGN KEY 
	(
		[SchemaDataType]
	) REFERENCES [dbo].[ReportSchemaDataType] (
		[Id]
	),
	CONSTRAINT [FK_ReportDataTypeOperator#Operator#] FOREIGN KEY 
	(
		[SchemaOperator]
	) REFERENCES [dbo].[ReportSchemaOperator] (
		[Id]
	)
GO

ALTER TABLE [dbo].[ReportSchemaDataTypeSummaryFunction] ADD 
	CONSTRAINT [FK_ReportSchemaDataTypeSummaryFunction#SummaryFunctions] FOREIGN KEY 
	(
		[SchemaDataType]
	) REFERENCES [dbo].[ReportSchemaDataType] (
		[Id]
	) NOT FOR REPLICATION ,
	CONSTRAINT [FK_ReportSchemaDataTypeSummaryFunction_ReportSchemaSummaryFunction] FOREIGN KEY 
	(
		[SchemaSummaryFunction]
	) REFERENCES [dbo].[ReportSchemaSummaryFunction] (
		[Id]
	) NOT FOR REPLICATION 
GO

ALTER TABLE [dbo].[ReportSchemaTableParameter] ADD 
	CONSTRAINT [FK_ReportSchemaTableParameter#Column#] FOREIGN KEY 
	(
		[SchemaColumn]
	) REFERENCES [dbo].[ReportSchemaColumn] (
		[Id]
	) NOT FOR REPLICATION ,
	CONSTRAINT [FK_ReportSchemaTableParameter#Operator] FOREIGN KEY 
	(
		[SchemaOperator]
	) REFERENCES [dbo].[ReportSchemaOperator] (
		[Id]
	),
	CONSTRAINT [FK_ReportSchemaTableParameter#Table#Parameters] FOREIGN KEY 
	(
		[SchemaTable]
	) REFERENCES [dbo].[ReportSchemaTable] (
		[Id]
	)
GO

ALTER TABLE [dbo].[ReportSelectColumn] ADD 
	CONSTRAINT [FK_ReportSelectColumn#SummaryFunction#] FOREIGN KEY 
	(
		[SchemaSummaryFunction]
	) REFERENCES [dbo].[ReportSchemaSummaryFunction] (
		[Id]
	) NOT FOR REPLICATION ,
	CONSTRAINT [FK_ReportSelectColumn_ReportColumn] FOREIGN KEY 
	(
		[Id]
	) REFERENCES [dbo].[ReportColumn] (
		[Id]
	) ON DELETE CASCADE  NOT FOR REPLICATION 
GO

ALTER TABLE [dbo].[ReportSelectColumnSummaryFunction] ADD 
	CONSTRAINT [FK_ReportSelectColumnSummaryFunction#ReportSelectColumn#SummaryFunctions] FOREIGN KEY 
	(
		[SelectColumn]
	) REFERENCES [dbo].[ReportSelectColumn] (
		[Id]
	) ON DELETE CASCADE ,
	CONSTRAINT [FK_ReportSelectColumnSummaryFunction_ReportSchemaSummaryFunction] FOREIGN KEY 
	(
		[SummaryFunction]
	) REFERENCES [dbo].[ReportSchemaSummaryFunction] (
		[Id]
	)
GO

ALTER TABLE [dbo].[ReportTypeColumn] ADD 
	CONSTRAINT [FK_ReportTypeColumn#Column] FOREIGN KEY 
	(
		[SchemaColumn]
	) REFERENCES [dbo].[ReportSchemaColumn] (
		[Id]
	) ON DELETE CASCADE ,
	CONSTRAINT [FK_ReportTypeColumn#Table#Columns] FOREIGN KEY 
	(
		[ReportTypeTable]
	) REFERENCES [dbo].[ReportTypeTable] (
		[Id]
	) ON DELETE CASCADE 
GO

ALTER TABLE [dbo].[ReportTypeTable] ADD 
	CONSTRAINT [FK_ReportSchemaTableAssociation_ReportSchemaJoinType] FOREIGN KEY 
	(
		[JoinMultiplicity]
	) REFERENCES [dbo].[ReportSchemaJoinMultiplicity] (
		[Id]
	),
	CONSTRAINT [FK_ReportTypeTable#JoinTable#ChildTables] FOREIGN KEY 
	(
		[JoinTable]
	) REFERENCES [dbo].[ReportTypeTable] (
		[Id]
	),
	CONSTRAINT [FK_ReportTypeTable#Table] FOREIGN KEY 
	(
		[SchemaTable]
	) REFERENCES [dbo].[ReportSchemaTable] (
		[Id]
	) ON DELETE CASCADE ,
	CONSTRAINT [FK_ReportTypeTable_ReportType] FOREIGN KEY 
	(
		[ReportType]
	) REFERENCES [dbo].[ReportType] (
		[Id]
	)
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


CREATE VIEW dbo.ReportTypeView
AS 
	SELECT rt.*, rtt.Id PrimaryTable
	FROM
		ReportType rt left join
		ReportTypeTable rtt on rtt.ReportType = rt.Id
	WHERE
		rtt.JoinTable is null

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


CREATE VIEW dbo.ReportTypeColumnView
AS 
	SELECT
		rtc.*
	FROM
		ReportTypeColumn rtc

	UNION


	SELECT 
		rsc.Id,
		rtt.Id,
		rsc.Name,
		rsc.Sequence
	FROM
		ReportSchemaColumn rsc JOIN
		ReportSchemaTable rst ON rsc.SchemaTable = rst.Id JOIN
		ReportTypeTable rtt ON rst.Id = rtt.SchemaTable LEFT JOIN
		ReportTypeColumn rtc ON rtt.Id = rtc.ReportTypeTable
	WHERE
		rtc.SchemaColumn IS NULL

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportColumn table for the specified ids 
</summary>
<param name="ids">Ids of the Report's </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE [dbo].[ReportColumnGroupColumn_GetRecordsByReport] 
	@ids uniqueidentifierarray
AS
	SELECT
		r.Report, r.*, s.*
	FROM
		ReportColumn r INNER JOIN
		ReportOrderColumn s ON r.Id = s.Id INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.Report = Keys.Id
	WHERE
		Type = 'Y'
	ORDER BY
		Sequence
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Deletes a ReportColumnParameterValue record
</summary>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportColumnParameterValue_DeleteRecord
	@id uniqueidentifier
AS
	DELETE FROM 
		ReportColumnParameterValue
	WHERE
		Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets all records from the ReportColumnParameterValue table
</summary>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportColumnParameterValue_GetAllRecords
AS
	SELECT r.*
	FROM
		ReportColumnParameterValue r
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportColumnParameterValue table with the specified id's
</summary>
<param name="ids">Ids of the records to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportColumnParameterValue_GetRecords
	@ids	uniqueidentifierarray
AS
	SELECT r.*
	FROM
		ReportColumnParameterValue r INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.Id = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportColumnParameterValue table with the specified ids
</summary>
<param name="ids">Ids of the ReportSchemaTableParameter(s) to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportColumnParameterValue_GetRecordsByParameter
	@ids	uniqueidentifierarray
AS
	SELECT r.SchemaTableParameter, r.*
	FROM
		ReportColumnParameterValue r INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.SchemaTableParameter = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportColumnParameterValue table for the specified ids 
</summary>
<param name="ids">Ids of the ReportColumn's </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="False" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportColumnParameterValue_GetRecordsByReportColumn 
	@ids uniqueidentifierarray
AS
	SELECT r.ReportColumn, r.*
	FROM
		ReportColumnParameterValue r INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.ReportColumn = Keys.Id INNER JOIN
		ReportSchemaTableParameter p ON r.SchemaTableParameter = p.Id
	ORDER BY
		p.Sequence
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Inserts a new record into the ReportColumnParameterValue table with the specified values
</summary>
<param name="reportColumn">Value to assign to the ReportColumn field of the record</param>
<param name="schemaTableParameter">Value to assign to the SchemaTableParameter field of the record</param>
<param name="valueExpression">Value to assign to the ValueExpression field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE dbo.ReportColumnParameterValue_InsertRecord
	@reportColumn uniqueidentifier, 
	@schemaTableParameter uniqueidentifier, 
	@valueExpression varchar(100)
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
	
	INSERT INTO ReportColumnParameterValue
	(
		Id, 
		ReportColumn, 
		SchemaTableParameter, 
		ValueExpression
	)
	VALUES
	(
		@id, 
		@reportColumn, 
		@schemaTableParameter, 
		@valueExpression
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Updates a record in the ReportColumnParameterValue table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="reportColumn">Value to assign to the ReportColumn field of the record</param>
<param name="schemaTableParameter">Value to assign to the SchemaTableParameter field of the record</param>
<param name="valueExpression">Value to assign to the ValueExpression field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportColumnParameterValue_UpdateRecord
	@id uniqueidentifier, 
	@reportColumn uniqueidentifier, 
	@schemaTableParameter uniqueidentifier, 
	@valueExpression varchar(100)
AS
	UPDATE ReportColumnParameterValue
	SET
		ReportColumn = @reportColumn, 
		SchemaTableParameter = @schemaTableParameter, 
		ValueExpression = @valueExpression
	WHERE 
		Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Deletes a ReportColumnType record
</summary>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportColumnType_DeleteRecord
	@id char(1)
AS
	DELETE FROM 
		ReportColumnType
	WHERE
		Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets all records from the ReportColumnType table
</summary>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportColumnType_GetAllRecords
AS
	SELECT r.*
	FROM
		ReportColumnType r
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportColumnType table with the specified id's
</summary>
<param name="ids">Ids of the records to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportColumnType_GetRecords
	@ids	chararray
AS
	SELECT r.*
	FROM
		ReportColumnType r INNER JOIN
		GetChars(@ids) AS Keys ON r.Id = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Inserts a new record into the ReportColumnType table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportColumnType_InsertRecord
	@id char(1), 
	@name varchar(50)
AS
	INSERT INTO ReportColumnType
	(
		Id, 
		Name
	)
	VALUES
	(
		@id, 
		@name
	)
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Updates a record in the ReportColumnType table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportColumnType_UpdateRecord
	@id char(1), 
	@name varchar(50)
AS
	UPDATE ReportColumnType
	SET
		Name = @name
	WHERE 
		Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Deletes a ReportColumn record
</summary>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportColumn_DeleteRecord
	@id uniqueidentifier
AS
	DELETE FROM 
		ReportColumn
	WHERE
		Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets all records from the ReportColumn table
</summary>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportColumn_GetAllRecords
AS
	SELECT r.*
	FROM
		ReportColumn r
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportColumn table with the specified id's
</summary>
<param name="ids">Ids of the records to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportColumn_GetRecords
	@ids	uniqueidentifierarray
AS
	SELECT r.*
	FROM
		ReportColumn r INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.Id = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportColumn table for the specified ids 
</summary>
<param name="ids">Ids of the Report's </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportColumn_GetRecordsByReport 
	@ids uniqueidentifierarray
AS
	SELECT r.Report, r.*
	FROM
		ReportColumn r INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.Report = Keys.Id
	ORDER BY Sequence
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportColumn table with the specified ids
</summary>
<param name="ids">Ids of the ReportTypeTable(s) to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportColumn_GetRecordsByReportTypeTable
	@ids	uniqueidentifierarray
AS
	SELECT r.ReportTypeTable, r.*
	FROM
		ReportColumn r INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.ReportTypeTable = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Inserts a new record into the ReportColumn table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="sequence">Value to assign to the Sequence field of the record</param>
<param name="report">Value to assign to the Report field of the record</param>
<param name="type">Value to assign to the Type field of the record</param>
<param name="schemaColumn">Value to assign to the SchemaColumn field of the record</param>
<param name="reportTypeTable">Value to assign to the ReportTypeTable field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model returnType="System.Guid" />
*/
CREATE PROCEDURE dbo.ReportColumn_InsertRecord 
	@sequence int,
	@report uniqueidentifier,
	@type char(1),
	@schemaColumn uniqueidentifier,
	@reportTypeTable uniqueidentifier
AS
declare @id uniqueidentifier 

set @id = newid()

INSERT INTO ReportColumn
	(
		Id,
		Sequence,
		Report,
		Type,
		SchemaColumn,
		ReportTypeTable
	)
	VALUES
	(

		@id,
		@sequence,
		@report,
		@type,
		@schemaColumn,
		@reportTypeTable
	)

select @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Updates a record in the ReportColumn table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="sequence">Value to assign to the Sequence field of the record</param>
<param name="report">Value to assign to the Report field of the record</param>
<param name="type">Value to assign to the Type field of the record</param>
<param name="schemaColumn">Value to assign to the SchemaColumn field of the record</param>
<param name="reportTypeTable">Value to assign to the ReportTypeTable field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportColumn_UpdateRecord 
	@id uniqueidentifier,
	@sequence int,
	@report uniqueidentifier,
	@type char(1),
	@schemaColumn uniqueidentifier,
	@reportTypeTable uniqueidentifier
AS
	UPDATE ReportColumn
	SET
		Sequence = @sequence,
		Report = @report,
		Type = @type,
		SchemaColumn = @schemaColumn,
		ReportTypeTable = @reportTypeTable
	WHERE Id = @id AND Id = @id AND Id = @id AND Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Deletes a ReportDataTypeOperator record
</summary>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportDataTypeOperator_DeleteRecord 
	@dataType char(1),
	@operatorId uniqueidentifier
AS
	DELETE FROM ReportDataTypeOperator
	WHERE DataType = @dataType AND OperatorId = @operatorId
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportDataTypeOperator table with the specified id's
</summary>
<param name="ids">Ids of the records to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportDataTypeOperator_GetRecords 
	@ids char1uniqueidentifierarray
AS
	SELECT r.*
	FROM
		ReportDataTypeOperator r INNER JOIN
		GetChar1Uniqueidentifiers(@ids) AS Keys ON r.DataType = Keys.Id0 AND r.OperatorID = Keys.Id1
	ORDER BY Sequence
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Inserts a new record into the ReportDataTypeOperator table with the specified values
</summary>
<param name="sequence">Value to assign to the Sequence field of the record</param>
<param name="dataType">Value to assign to the DataType field of the record</param>
<param name="operatorId">Value to assign to the OperatorID field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="IDataReader" />
*/
CREATE PROCEDURE dbo.ReportDataTypeOperator_InsertRecord 
	@sequence int,
	@dataType char(1),
	@operatorId uniqueidentifier
AS
INSERT INTO ReportDataTypeOperator
	(

		Sequence,
		DataType,
		OperatorID
	)
	VALUES
	(

		@sequence,
		@dataType,
		@operatorId
	)
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Updates a record in the ReportDataTypeOperator table with the specified values
</summary>
<param name="sequence">Value to assign to the Sequence field of the record</param>
<param name="dataType">Value to assign to the DataType field of the record</param>
<param name="operatorId">Value to assign to the OperatorID field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportDataTypeOperator_UpdateRecord 
	@sequence int,
	@dataType char(1),
	@operatorId uniqueidentifier
AS
	UPDATE ReportDataTypeOperator
	SET
		Sequence = @sequence
	WHERE DataType = @dataType AND OperatorId = @operatorId
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Deletes a ReportDataType record
</summary>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportDataType_DeleteRecord 
	@id char(1)
AS
	DELETE FROM ReportDataType
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportDataType table with the specified id's
</summary>
<param name="ids">Ids of the records to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportDataType_GetRecords 
	@ids char1array
AS
	SELECT r.*
	FROM
		ReportDataType r INNER JOIN
		GetChar1s(@ids) AS Keys ON r.ID = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Inserts a new record into the ReportDataType table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Char" />
*/
CREATE PROCEDURE dbo.ReportDataType_InsertRecord 
	@id char(1),
	@name varchar(20)
AS
INSERT INTO ReportDataType
	(

		ID,
		Name
	)
	VALUES
	(

		@id,
		@name
	)
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Updates a record in the ReportDataType table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportDataType_UpdateRecord 
	@id char(1),
	@name varchar(20)
AS
	UPDATE ReportDataType
	SET
		Name = @name
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Deletes a ReportFilterColumn record
</summary>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportFilterColumn_DeleteRecord
	@id uniqueidentifier
AS
	DELETE FROM 
		ReportFilterColumn
	WHERE
		Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets all records from the ReportFilterColumn table
</summary>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportFilterColumn_GetAllRecords
AS
	SELECT r.*
	FROM
		ReportFilterColumn r
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportFilterColumn table with the specified id's
</summary>
<param name="ids">Ids of the records to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportFilterColumn_GetRecords
	@ids	uniqueidentifierarray
AS
	SELECT r.*
	FROM
		ReportFilterColumn r INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.Id = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportFilterColumn table with the specified ids
</summary>
<param name="ids">Ids of the ReportSchemaOperator(s) to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportFilterColumn_GetRecordsByOperator
	@ids	uniqueidentifierarray
AS
	SELECT r.SchemaOperator, r.*
	FROM
		ReportFilterColumn r INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.SchemaOperator = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportColumn table for the specified ids 
</summary>
<param name="ids">Ids of the Report's </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportFilterColumn_GetRecordsByReport 
	@ids uniqueidentifierarray
AS
	SELECT
		r.Report, r.*, s.*
	FROM
		ReportColumn r INNER JOIN
		ReportFilterColumn s ON r.Id = s.Id INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.Report = Keys.Id
	WHERE
		Type = 'F'
	ORDER BY
		Sequence
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Inserts a new record into the ReportFilterColumn table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="schemaOperator">Value to assign to the SchemaOperator field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="False" returnType="ReportColumn" />
*/
CREATE PROCEDURE dbo.ReportFilterColumn_InsertRecord 
	@id uniqueidentifier,
	@schemaOperator uniqueidentifier
AS
INSERT INTO ReportFilterColumn
	(

		Id,
		SchemaOperator
	)
	VALUES
	(

		@id,
		@schemaOperator
	)
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Updates a record in the ReportFilterColumn table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="schemaOperator">Value to assign to the SchemaOperator field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportFilterColumn_UpdateRecord
	@id uniqueidentifier, 
	@schemaOperator uniqueidentifier
AS
	UPDATE ReportFilterColumn
	SET
		SchemaOperator = @schemaOperator
	WHERE 
		Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Deletes a ReportFilterOperator record
</summary>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportFilterOperator_DeleteRecord 
	@id uniqueidentifier
AS
	DELETE FROM ReportFilterOperator
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportFilterOperator table with the specified id's
</summary>
<param name="ids">Ids of the records to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportFilterOperator_GetRecords 
	@ids uniqueidentifierarray
AS
	SELECT r.*
	FROM
		ReportFilterOperator r INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.ID = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Inserts a new record into the ReportFilterOperator table with the specified values
</summary>
<param name="name">Value to assign to the Name field of the record</param>
<param name="expression">Value to assign to the Expression field of the record</param>
<param name="concatExpression">Value to assign to the ConcatExpression field of the record</param>
<param name="findRegex">Value to assign to the FindRegex field of the record</param>
<param name="replaceRegex">Value to assign to the ReplaceRegex field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE dbo.ReportFilterOperator_InsertRecord 
	@name varchar(20),
	@expression varchar(40),
	@concatExpression varchar(3),
	@findRegex varchar(20),
	@replaceRegex varchar(20)
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
INSERT INTO ReportFilterOperator
	(

		ID,
		Name,
		Expression,
		ConcatExpression,
		FindRegex,
		ReplaceRegex
	)
	VALUES
	(

		@id,
		@name,
		@expression,
		@concatExpression,
		@findRegex,
		@replaceRegex
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Updates a record in the ReportFilterOperator table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<param name="expression">Value to assign to the Expression field of the record</param>
<param name="concatExpression">Value to assign to the ConcatExpression field of the record</param>
<param name="findRegex">Value to assign to the FindRegex field of the record</param>
<param name="replaceRegex">Value to assign to the ReplaceRegex field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportFilterOperator_UpdateRecord 
	@id uniqueidentifier,
	@name varchar(20),
	@expression varchar(40),
	@concatExpression varchar(3),
	@findRegex varchar(20),
	@replaceRegex varchar(20)
AS
	UPDATE ReportFilterOperator
	SET
		Name = @name,
		Expression = @expression,
		ConcatExpression = @concatExpression,
		FindRegex = @findRegex,
		ReplaceRegex = @replaceRegex
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Deletes a ReportFilterValue record
</summary>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportFilterValue_DeleteRecord
	@id uniqueidentifier
AS
	DELETE FROM 
		ReportFilterValue
	WHERE
		Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets all records from the ReportFilterValue table
</summary>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportFilterValue_GetAllRecords
AS
	SELECT r.*
	FROM
		ReportFilterValue r
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportFilterValue table with the specified id's
</summary>
<param name="ids">Ids of the records to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportFilterValue_GetRecords
	@ids	uniqueidentifierarray
AS
	SELECT r.*
	FROM
		ReportFilterValue r INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.Id = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportFilterValue table with the specified ids
</summary>
<param name="ids">Ids of the ReportFilterColumn(s) to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportFilterValue_GetRecordsByFilter
	@ids	uniqueidentifierarray
AS
	SELECT r.FilterColumn, r.*
	FROM
		ReportFilterValue r INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.FilterColumn = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportFilterValue table for the specified ids 
</summary>
<param name="ids">Ids of the ReportFilterColumn's </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportFilterValue_GetRecordsByFilterColumn 
	@ids uniqueidentifierarray
AS
	SELECT r.FilterColumn, r.*
	FROM
		ReportFilterValue r INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.FilterColumn = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Inserts a new record into the ReportFilterValue table with the specified values
</summary>
<param name="filterColumn">Value to assign to the FilterColumn field of the record</param>
<param name="valueExpression">Value to assign to the ValueExpression field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE dbo.ReportFilterValue_InsertRecord
	@filterColumn uniqueidentifier, 
	@valueExpression varchar(100)
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
	
	INSERT INTO ReportFilterValue
	(
		Id, 
		FilterColumn, 
		ValueExpression
	)
	VALUES
	(
		@id, 
		@filterColumn, 
		@valueExpression
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Updates a record in the ReportFilterValue table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="filterColumn">Value to assign to the FilterColumn field of the record</param>
<param name="valueExpression">Value to assign to the ValueExpression field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportFilterValue_UpdateRecord
	@id uniqueidentifier, 
	@filterColumn uniqueidentifier, 
	@valueExpression varchar(100)
AS
	UPDATE ReportFilterValue
	SET
		FilterColumn = @filterColumn, 
		ValueExpression = @valueExpression
	WHERE 
		Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Deletes a ReportFilter record
</summary>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportFilter_DeleteRecord 
	@id uniqueidentifier
AS
	DELETE FROM ReportFilter
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportFilter table with the specified id's
</summary>
<param name="ids">Ids of the records to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportFilter_GetRecords 
	@ids uniqueidentifierarray
AS
	SELECT r.*
	FROM
		ReportFilter r INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.ID = Keys.Id
	ORDER BY Sequence
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportFilter table for the specified ids 
</summary>
<param name="ids">Ids of the Report's </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportFilter_GetRecordsByReportId 
	@ids uniqueidentifierarray
AS
	SELECT r.ReportID, r.*
	FROM
		ReportFilter r INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.ReportID = Keys.Id
	ORDER BY Sequence
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Inserts a new record into the ReportFilter table with the specified values
</summary>
<param name="sequence">Value to assign to the Sequence field of the record</param>
<param name="reportId">Value to assign to the ReportID field of the record</param>
<param name="columnId">Value to assign to the ColumnID field of the record</param>
<param name="operatorId">Value to assign to the OperatorID field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE dbo.ReportFilter_InsertRecord 
	@sequence int,
	@reportId uniqueidentifier,
	@columnId uniqueidentifier,
	@operatorId uniqueidentifier
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
INSERT INTO ReportFilter
	(

		ID,
		Sequence,
		ReportID,
		ColumnID,
		OperatorID
	)
	VALUES
	(

		@id,
		@sequence,
		@reportId,
		@columnId,
		@operatorId
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Updates a record in the ReportFilter table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="sequence">Value to assign to the Sequence field of the record</param>
<param name="reportId">Value to assign to the ReportID field of the record</param>
<param name="columnId">Value to assign to the ColumnID field of the record</param>
<param name="operatorId">Value to assign to the OperatorID field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportFilter_UpdateRecord 
	@id uniqueidentifier,
	@sequence int,
	@reportId uniqueidentifier,
	@columnId uniqueidentifier,
	@operatorId uniqueidentifier
AS
	UPDATE ReportFilter
	SET
		Sequence = @sequence,
		ReportID = @reportId,
		ColumnID = @columnId,
		OperatorID = @operatorId
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Deletes a ReportFormat record
</summary>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportFormat_DeleteRecord
	@id char(1)
AS
	DELETE FROM 
		ReportFormat
	WHERE
		Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets all records from the ReportFormat table
</summary>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportFormat_GetAllRecords
AS
	SELECT r.*
	FROM
		ReportFormat r
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportFormat table with the specified id's
</summary>
<param name="ids">Ids of the records to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportFormat_GetRecords
	@ids	chararray
AS
	SELECT r.*
	FROM
		ReportFormat r INNER JOIN
		GetChars(@ids) AS Keys ON r.Id = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Inserts a new record into the ReportFormat table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<param name="builder">Value to assign to the Builder field of the record</param>
<param name="template">Value to assign to the Template field of the record</param>
<param name="datasource">Value to assign to the Datasource field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportFormat_InsertRecord
	@id char(1), 
	@name varchar(30), 
	@builder varchar(200), 
	@template varchar(200), 
	@datasource varchar(200)
AS
	INSERT INTO ReportFormat
	(
		Id, 
		Name, 
		Builder, 
		Template, 
		Datasource
	)
	VALUES
	(
		@id, 
		@name, 
		@builder, 
		@template, 
		@datasource
	)
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Updates a record in the ReportFormat table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<param name="builder">Value to assign to the Builder field of the record</param>
<param name="template">Value to assign to the Template field of the record</param>
<param name="datasource">Value to assign to the Datasource field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportFormat_UpdateRecord
	@id char(1), 
	@name varchar(30), 
	@builder varchar(200), 
	@template varchar(200), 
	@datasource varchar(200)
AS
	UPDATE ReportFormat
	SET
		Name = @name, 
		Builder = @builder, 
		Template = @template, 
		Datasource = @datasource
	WHERE 
		Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


/*
<summary>
Gets records from the ReportColumn table for the specified ids 
</summary>
<param name="ids">Ids of the Report's </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="False" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportGroupColumn_GetRecordsByReport 
	@ids uniqueidentifierarray
AS
	SELECT
		r.Report, r.*, s.*
	FROM
		ReportColumn r INNER JOIN
		ReportOrderColumn s ON r.Id = s.Id INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.Report = Keys.Id
	WHERE
		Type in ('G', 'Y')
	ORDER BY
		Sequence

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Deletes a ReportOrderColumn record
</summary>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportOrderColumn_DeleteRecord
	@id uniqueidentifier
AS
	DELETE FROM 
		ReportOrderColumn
	WHERE
		Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets all records from the ReportOrderColumn table
</summary>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportOrderColumn_GetAllRecords
AS
	SELECT r.*
	FROM
		ReportOrderColumn r
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportOrderColumn table with the specified id's
</summary>
<param name="ids">Ids of the records to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportOrderColumn_GetRecords
	@ids	uniqueidentifierarray
AS
	SELECT r.*
	FROM
		ReportOrderColumn r INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.Id = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportColumn table for the specified ids 
</summary>
<param name="ids">Ids of the Report's </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportOrderColumn_GetRecordsByReport 
	@ids uniqueidentifierarray
AS
	SELECT
		r.Report, r.*, s.*
	FROM
		ReportColumn r INNER JOIN
		ReportOrderColumn s ON r.Id = s.Id INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.Report = Keys.Id
	WHERE
		Type = 'O'
	ORDER BY
		Sequence
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Inserts a new record into the ReportOrderColumn table with the specified values
</summary>
<param name="isAscending">Value to assign to the IsAscending field of the record</param>
<param name="id">Value to assign to the Id field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="False" returnType="ReportColumn" />
*/
CREATE PROCEDURE dbo.ReportOrderColumn_InsertRecord 
	@isAscending bit,
	@id uniqueidentifier
AS
INSERT INTO ReportOrderColumn
	(

		IsAscending,
		Id
	)
	VALUES
	(

		@isAscending,
		@id
	)
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Updates a record in the ReportOrderColumn table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="isAscending">Value to assign to the IsAscending field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportOrderColumn_UpdateRecord
	@id uniqueidentifier, 
	@isAscending bit
AS
	UPDATE ReportOrderColumn
	SET
		IsAscending = @isAscending
	WHERE 
		Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportColumn table for the specified ids 
</summary>
<param name="ids">Ids of the Report's </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportParameterColumn_GetRecordsByReport 
	@ids uniqueidentifierarray
AS
	SELECT
		r.Report, r.*, s.*
	FROM
		ReportColumn r INNER JOIN
		ReportFilterColumn s ON r.Id = s.Id INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.Report = Keys.Id
	WHERE
		Type = 'P'
	ORDER BY
		Sequence
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Deletes a ReportSchemaColumn record
</summary>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportSchemaColumn_DeleteRecord
	@id uniqueidentifier
AS
	DELETE FROM 
		ReportSchemaColumn
	WHERE
		Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets all records from the ReportSchemaColumn table
</summary>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportSchemaColumn_GetAllRecords
AS
	SELECT r.*
	FROM
		ReportSchemaColumn r
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportSchemaColumn table with the specified id's
</summary>
<param name="ids">Ids of the records to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportSchemaColumn_GetRecords
	@ids	uniqueidentifierarray
AS
	SELECT r.*
	FROM
		ReportSchemaColumn r INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.Id = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportSchemaColumn table with the specified ids
</summary>
<param name="ids">Ids of the ReportSchemaTable(s) to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportSchemaColumn_GetRecordsByTable
	@ids	uniqueidentifierarray
AS
	SELECT r.SchemaTable, r.*
	FROM
		ReportSchemaColumn r INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.SchemaTable = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Inserts a new record into the ReportSchemaColumn table with the specified values
</summary>
<param name="name">Value to assign to the Name field of the record</param>
<param name="schemaTable">Value to assign to the SchemaTable field of the record</param>
<param name="schemaDataType">Value to assign to the SchemaDataType field of the record</param>
<param name="displayExpression">Value to assign to the DisplayExpression field of the record</param>
<param name="valueExpression">Value to assign to the ValueExpression field of the record</param>
<param name="linkExpression">Value to assign to the LinkExpression field of the record</param>
<param name="linkFormat">Value to assign to the LinkFormat field of the record</param>
<param name="isSelectColumn">Value to assign to the IsSelectColumn field of the record</param>
<param name="isFilterColumn">Value to assign to the IsFilterColumn field of the record</param>
<param name="isParameterColumn">Value to assign to the IsParameterColumn field of the record</param>
<param name="isGroupColumn">Value to assign to the IsGroupColumn field of the record</param>
<param name="isOrderColumn">Value to assign to the IsOrderColumn field of the record</param>
<param name="isAggregated">Value to assign to the IsAggregated field of the record</param>
<param name="allowedValuesExpression">Value to assign to the AllowedValuesExpression field of the record</param>
<param name="sequence">Value to assign to the Sequence field of the record</param>
<param name="width">Value to assign to the Width field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE  PROCEDURE dbo.ReportSchemaColumn_InsertRecord
	@name varchar(100), 
	@schemaTable uniqueidentifier, 
	@schemaDataType char(1), 
	@displayExpression varchar(1000), 
	@valueExpression varchar(1000), 
	@orderExpression varchar(1000), 
	@linkExpression varchar(1000), 
	@linkFormat varchar(1000), 
	@isSelectColumn bit, 
	@isFilterColumn bit, 
	@isParameterColumn bit, 
	@isGroupColumn bit, 
	@isOrderColumn bit, 
	@isAggregated bit, 
	@allowedValuesExpression varchar(1000), 
	@sequence int, 
	@width decimal(18, 0)
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
	
	INSERT INTO ReportSchemaColumn
	(
		Id, 
		Name, 
		SchemaTable, 
		SchemaDataType, 
		DisplayExpression, 
		ValueExpression, 
		OrderExpression, 
		LinkExpression, 
		LinkFormat, 
		IsSelectColumn, 
		IsFilterColumn, 
		IsParameterColumn, 
		IsGroupColumn, 
		IsOrderColumn, 
		IsAggregated, 
		AllowedValuesExpression, 
		Sequence, 
		Width
	)
	VALUES
	(
		@id, 
		@name, 
		@schemaTable, 
		@schemaDataType, 
		@displayExpression, 
		@valueExpression, 
		@orderExpression, 
		@linkExpression, 
		@linkFormat, 
		@isSelectColumn, 
		@isFilterColumn, 
		@isParameterColumn, 
		@isGroupColumn, 
		@isOrderColumn, 
		@isAggregated, 
		@allowedValuesExpression, 
		@sequence, 
		@width
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Updates a record in the ReportSchemaColumn table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<param name="schemaTable">Value to assign to the SchemaTable field of the record</param>
<param name="schemaDataType">Value to assign to the SchemaDataType field of the record</param>
<param name="displayExpression">Value to assign to the DisplayExpression field of the record</param>
<param name="valueExpression">Value to assign to the ValueExpression field of the record</param>
<param name="linkExpression">Value to assign to the LinkExpression field of the record</param>
<param name="linkFormat">Value to assign to the LinkFormat field of the record</param>
<param name="isSelectColumn">Value to assign to the IsSelectColumn field of the record</param>
<param name="isFilterColumn">Value to assign to the IsFilterColumn field of the record</param>
<param name="isParameterColumn">Value to assign to the IsParameterColumn field of the record</param>
<param name="isGroupColumn">Value to assign to the IsGroupColumn field of the record</param>
<param name="isOrderColumn">Value to assign to the IsOrderColumn field of the record</param>
<param name="isAggregated">Value to assign to the IsAggregated field of the record</param>
<param name="allowedValuesExpression">Value to assign to the AllowedValuesExpression field of the record</param>
<param name="sequence">Value to assign to the Sequence field of the record</param>
<param name="width">Value to assign to the Width field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE  PROCEDURE dbo.ReportSchemaColumn_UpdateRecord
	@id uniqueidentifier, 
	@name varchar(100), 
	@schemaTable uniqueidentifier, 
	@schemaDataType char(1), 
	@displayExpression varchar(1000), 
	@valueExpression varchar(1000), 
	@orderExpression varchar(1000), 
	@linkExpression varchar(1000), 
	@linkFormat varchar(1000), 
	@isSelectColumn bit, 
	@isFilterColumn bit, 
	@isParameterColumn bit, 
	@isGroupColumn bit, 
	@isOrderColumn bit, 
	@isAggregated bit, 
	@allowedValuesExpression varchar(1000), 
	@sequence int, 
	@width decimal(18, 0)
AS
	UPDATE ReportSchemaColumn
	SET
		Name = @name, 
		SchemaTable = @schemaTable, 
		SchemaDataType = @schemaDataType, 
		DisplayExpression = @displayExpression, 
		ValueExpression = @valueExpression, 
		OrderExpression = @orderExpression,
		LinkExpression = @linkExpression, 
		LinkFormat = @linkFormat, 
		IsSelectColumn = @isSelectColumn, 
		IsFilterColumn = @isFilterColumn, 
		IsParameterColumn = @isParameterColumn, 
		IsGroupColumn = @isGroupColumn, 
		IsOrderColumn = @isOrderColumn, 
		IsAggregated = @isAggregated, 
		AllowedValuesExpression = @allowedValuesExpression, 
		Sequence = @sequence, 
		Width = @width
	WHERE 
		Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Deletes a ReportSchemaDataType record
</summary>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportSchemaDataType_DeleteRecord 
	@id char(1)
AS
	DELETE FROM ReportSchemaDataType
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Deletes records from the ReportSchemaDataTypeOperator table for the specified ids 
</summary>
<param name="schemaOperator">The id of the associated ReportSchemaOperator</param>
<param name="ids">The ids of the ReportSchemaDataType's to insert</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportSchemaDataType_DeleteRecordsForReportSchemaDataTypeOperatorAssociation 
	@schemaOperator uniqueidentifier,
	@ids char1array
AS
	DELETE ReportSchemaDataTypeOperator
	FROM
		ReportSchemaDataTypeOperator r INNER JOIN
		GetChar1s(@ids) AS Keys ON r.SchemaDataType = Keys.Id	WHERE r.SchemaOperator = @schemaOperator
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Deletes records from the ReportSchemaDataTypeSummaryFunction table for the specified ids 
</summary>
<param name="schemaSummaryFunction">The id of the associated ReportSchemaSummaryFunction</param>
<param name="ids">The ids of the ReportSchemaDataType's to delete</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportSchemaDataType_DeleteRecordsForReportSchemaDataTypeSummaryFunctionAssociation
	@schemaSummaryFunction char(1), 
	@ids chararray
AS
	DELETE ReportSchemaDataTypeSummaryFunction
	FROM 
		ReportSchemaDataTypeSummaryFunction ab INNER JOIN
		GetChars(@ids) AS Keys ON ab.SchemaDataType = Keys.Id
	WHERE
		ab.SchemaSummaryFunction = @schemaSummaryFunction
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets all records from the ReportSchemaDataType table
</summary>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportSchemaDataType_GetAllRecords
AS
	SELECT r.*
	FROM
		ReportSchemaDataType r
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportSchemaDataType table with the specified id's
</summary>
<param name="ids">Ids of the records to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportSchemaDataType_GetRecords 
	@ids char1array
AS
	SELECT r.*
	FROM
		ReportSchemaDataType r INNER JOIN
		GetChar1s(@ids) AS Keys ON r.Id = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportSchemaDataType table for the specified association 
</summary>
<param name="ids">Ids of the ReportSchemaOperator's </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportSchemaDataType_GetRecordsForReportSchemaDataTypeOperatorAssociation 
	@ids uniqueidentifierarray
AS
	SELECT r1.SchemaOperator, r2.*
	FROM
		ReportSchemaDataTypeOperator r1 INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r1.SchemaOperator = Keys.Id INNER JOIN
		ReportSchemaDataType r2 ON r1.SchemaDataType = r2.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportSchemaDataType table for the specified association 
</summary>
<param name="ids">Ids of the ReportSchemaSummaryFunction(s) </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportSchemaDataType_GetRecordsForReportSchemaDataTypeSummaryFunctionAssociation
	@ids chararray
AS
	SELECT ab.SchemaSummaryFunction, a.*
	FROM
		ReportSchemaDataTypeSummaryFunction ab INNER JOIN
		GetChars(@ids) AS Keys ON ab.SchemaSummaryFunction = Keys.Id INNER JOIN
		ReportSchemaDataType a ON ab.SchemaDataType = a.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Inserts a new record into the ReportSchemaDataType table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<param name="valueEditor">Value to assign to the ValueEditor field of the record</param>
<param name="optionEditor">Value to assign to the OptionEditor field of the record</param>
<param name="typeName">Value to assign to the TypeName field of the record</param>
<param name="format">Value to assign to the Format field of the record</param>
<param name="sqlExpression">Value to assign to the SqlExpression field of the record</param>
<param name="defaultColumnWidth">Value to assign to the DefaultColumnWidth field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Char" />
*/
CREATE PROCEDURE dbo.ReportSchemaDataType_InsertRecord 
	@id char(1),
	@name varchar(20),
	@valueEditor varchar(200),
	@optionEditor varchar(200),
	@typeName varchar(50),
	@format varchar(20),
	@sqlExpression varchar(50),
	@defaultColumnWidth decimal
AS
INSERT INTO ReportSchemaDataType
	(

		Id,
		Name,
		ValueEditor,
		OptionEditor,
		TypeName,
		Format,
		SqlExpression,
		DefaultColumnWidth
	)
	VALUES
	(

		@id,
		@name,
		@valueEditor,
		@optionEditor,
		@typeName,
		@format,
		@sqlExpression,
		@defaultColumnWidth
	)
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Insert records in the ReportSchemaDataTypeOperator table for the specified ids 
</summary>
<param name="id">The id of the associated ReportSchemaOperator</param>
<param name="ids">The ids of the ReportSchemaDataType's to insert</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportSchemaDataType_InsertRecordsForReportSchemaDataTypeOperatorAssociation 
	@id uniqueidentifier,
	@ids char1array
AS
	INSERT INTO ReportSchemaDataTypeOperator
	SELECT @id, Keys.*	FROM
		GetChar1s(@ids) AS Keys
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Insert records in the ReportSchemaDataTypeSummaryFunction table for the specified ids 
</summary>
<param name="schemaSummaryFunction">The id of the associated ReportSchemaSummaryFunction</param>
<param name="ids">The ids of the ReportSchemaDataType's to insert</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportSchemaDataType_InsertRecordsForReportSchemaDataTypeSummaryFunctionAssociation
	@schemaSummaryFunction char(1), 
	@ids chararray
AS
	INSERT INTO ReportSchemaDataTypeSummaryFunction ( SchemaSummaryFunction, SchemaDataType)
	SELECT @schemaSummaryFunction, Keys.* FROM
		GetChars(@ids) AS Keys
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Updates a record in the ReportSchemaDataType table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<param name="valueEditor">Value to assign to the ValueEditor field of the record</param>
<param name="optionEditor">Value to assign to the OptionEditor field of the record</param>
<param name="typeName">Value to assign to the TypeName field of the record</param>
<param name="format">Value to assign to the Format field of the record</param>
<param name="sqlExpression">Value to assign to the SqlExpression field of the record</param>
<param name="defaultColumnWidth">Value to assign to the DefaultColumnWidth field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportSchemaDataType_UpdateRecord 
	@id char(1),
	@name varchar(20),
	@valueEditor varchar(200),
	@optionEditor varchar(200),
	@typeName varchar(50),
	@format varchar(20),
	@sqlExpression varchar(50),
	@defaultColumnWidth decimal
AS
	UPDATE ReportSchemaDataType
	SET
		Name = @name,
		ValueEditor = @valueEditor,
		OptionEditor = @optionEditor,
		TypeName = @typeName,
		Format = @format,
		SqlExpression = @sqlExpression,
		DefaultColumnWidth = @defaultColumnWidth
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Deletes a ReportSchemaJoinMultiplicity record
</summary>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportSchemaJoinMultiplicity_DeleteRecord 
	@id char(1)
AS
	DELETE FROM ReportSchemaJoinMultiplicity
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets all records from the ReportSchemaJoinMultiplicity table
</summary>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportSchemaJoinMultiplicity_GetAllRecords
AS
	SELECT r.*
	FROM
		ReportSchemaJoinMultiplicity r
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportSchemaJoinMultiplicity table with the specified id's
</summary>
<param name="ids">Ids of the records to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportSchemaJoinMultiplicity_GetRecords 
	@ids char1array
AS
	SELECT r.*
	FROM
		ReportSchemaJoinMultiplicity r INNER JOIN
		GetChar1s(@ids) AS Keys ON r.Id = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Inserts a new record into the ReportSchemaJoinMultiplicity table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<param name="lowerBound">Value to assign to the LowerBound field of the record</param>
<param name="upperBound">Value to assign to the UpperBound field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Char" />
*/
CREATE PROCEDURE dbo.ReportSchemaJoinMultiplicity_InsertRecord 
	@id char(1),
	@name varchar(50),
	@lowerBound int,
	@upperBound int
AS
INSERT INTO ReportSchemaJoinMultiplicity
	(

		Id,
		Name,
		LowerBound,
		UpperBound
	)
	VALUES
	(

		@id,
		@name,
		@lowerBound,
		@upperBound
	)
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Updates a record in the ReportSchemaJoinMultiplicity table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<param name="lowerBound">Value to assign to the LowerBound field of the record</param>
<param name="upperBound">Value to assign to the UpperBound field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportSchemaJoinMultiplicity_UpdateRecord 
	@id char(1),
	@name varchar(50),
	@lowerBound int,
	@upperBound int
AS
	UPDATE ReportSchemaJoinMultiplicity
	SET
		Name = @name,
		LowerBound = @lowerBound,
		UpperBound = @upperBound
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Deletes a ReportSchemaJoinType record
</summary>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportSchemaJoinType_DeleteRecord 
	@id char(1)
AS
	DELETE FROM ReportSchemaJoinType
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportSchemaJoinType table with the specified id's
</summary>
<param name="ids">Ids of the records to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportSchemaJoinType_GetRecords 
	@ids char1array
AS
	SELECT r.*
	FROM
		ReportSchemaJoinType r INNER JOIN
		GetChar1s(@ids) AS Keys ON r.Id = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Inserts a new record into the ReportSchemaJoinType table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="expression">Value to assign to the Expression field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Char" />
*/
CREATE PROCEDURE dbo.ReportSchemaJoinType_InsertRecord 
	@id char(1),
	@expression varchar(50)
AS
INSERT INTO ReportSchemaJoinType
	(

		Id,
		Expression
	)
	VALUES
	(

		@id,
		@expression
	)
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Updates a record in the ReportSchemaJoinType table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="expression">Value to assign to the Expression field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportSchemaJoinType_UpdateRecord 
	@id char(1),
	@expression varchar(50)
AS
	UPDATE ReportSchemaJoinType
	SET
		Expression = @expression
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Deletes a ReportSchemaOperator record
</summary>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportSchemaOperator_DeleteRecord 
	@id uniqueidentifier
AS
	DELETE FROM ReportSchemaOperator
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Deletes records from the ReportSchemaDataTypeOperator table for the specified ids 
</summary>
<param name="schemaDataType">The id of the associated ReportSchemaDataType</param>
<param name="ids">The ids of the ReportSchemaOperator's to delete</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportSchemaOperator_DeleteRecordsForReportSchemaDataTypeOperatorAssociation
	@schemaDataType char(1), 
	@ids uniqueidentifierarray
AS
	DELETE ReportSchemaDataTypeOperator
	FROM 
		ReportSchemaDataTypeOperator ab INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON ab.SchemaOperator = Keys.Id
	WHERE
		ab.SchemaDataType = @schemaDataType
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets all records from the ReportSchemaOperator table
</summary>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportSchemaOperator_GetAllRecords
AS
	SELECT r.*
	FROM
		ReportSchemaOperator r
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportSchemaOperator table with the specified id's
</summary>
<param name="ids">Ids of the records to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportSchemaOperator_GetRecords 
	@ids uniqueidentifierarray
AS
	SELECT r.*
	FROM
		ReportSchemaOperator r INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.Id = Keys.Id
	ORDER BY Sequence
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportSchemaOperator table for the specified association 
</summary>
<param name="ids">Ids of the ReportSchemaDataType(s) </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportSchemaOperator_GetRecordsForReportSchemaDataTypeOperatorAssociation
	@ids chararray
AS
	SELECT ab.SchemaDataType, a.*
	FROM
		ReportSchemaDataTypeOperator ab INNER JOIN
		GetChars(@ids) AS Keys ON ab.SchemaDataType = Keys.Id INNER JOIN
		ReportSchemaOperator a ON ab.SchemaOperator = a.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Inserts a new record into the ReportSchemaOperator table with the specified values
</summary>
<param name="name">Value to assign to the Name field of the record</param>
<param name="expression">Value to assign to the Expression field of the record</param>
<param name="concatExpression">Value to assign to the ConcatExpression field of the record</param>
<param name="findRegex">Value to assign to the FindRegex field of the record</param>
<param name="replaceRegex">Value to assign to the ReplaceRegex field of the record</param>
<param name="sequence">Value to assign to the Sequence field of the record</param>
<param name="allowMultipleValues">Value to assign to the AllowMultipleValues field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE dbo.ReportSchemaOperator_InsertRecord 
	@name varchar(20),
	@expression varchar(40),
	@concatExpression varchar(3),
	@findRegex varchar(20),
	@replaceRegex varchar(20),
	@sequence int,
	@allowMultipleValues bit
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
INSERT INTO ReportSchemaOperator
	(

		Id,
		Name,
		Expression,
		ConcatExpression,
		FindRegex,
		ReplaceRegex,
		Sequence,
		AllowMultipleValues
	)
	VALUES
	(

		@id,
		@name,
		@expression,
		@concatExpression,
		@findRegex,
		@replaceRegex,
		@sequence,
		@allowMultipleValues
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Insert records in the ReportSchemaDataTypeOperator table for the specified ids 
</summary>
<param name="schemaDataType">The id of the associated ReportSchemaDataType</param>
<param name="ids">The ids of the ReportSchemaOperator's to insert</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportSchemaOperator_InsertRecordsForReportSchemaDataTypeOperatorAssociation
	@schemaDataType char(1), 
	@ids uniqueidentifierarray
AS
	INSERT INTO ReportSchemaDataTypeOperator ( SchemaDataType, SchemaOperator)
	SELECT @schemaDataType, Keys.* FROM
		GetUniqueidentifiers(@ids) AS Keys
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Updates a record in the ReportSchemaOperator table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<param name="expression">Value to assign to the Expression field of the record</param>
<param name="concatExpression">Value to assign to the ConcatExpression field of the record</param>
<param name="findRegex">Value to assign to the FindRegex field of the record</param>
<param name="replaceRegex">Value to assign to the ReplaceRegex field of the record</param>
<param name="sequence">Value to assign to the Sequence field of the record</param>
<param name="allowMultipleValues">Value to assign to the AllowMultipleValues field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportSchemaOperator_UpdateRecord 
	@id uniqueidentifier,
	@name varchar(20),
	@expression varchar(40),
	@concatExpression varchar(3),
	@findRegex varchar(20),
	@replaceRegex varchar(20),
	@sequence int,
	@allowMultipleValues bit
AS
	UPDATE ReportSchemaOperator
	SET
		Name = @name,
		Expression = @expression,
		ConcatExpression = @concatExpression,
		FindRegex = @findRegex,
		ReplaceRegex = @replaceRegex,
		Sequence = @sequence,
		AllowMultipleValues = @allowMultipleValues
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Deletes a ReportSchemaSummaryFunction record
</summary>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportSchemaSummaryFunction_DeleteRecord 
	@id char(1)
AS
	DELETE FROM ReportSchemaSummaryFunction
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Deletes records from the ReportSchemaDataTypeSummaryFunction table for the specified ids 
</summary>
<param name="schemaDataType">The id of the associated ReportSchemaDataType</param>
<param name="ids">The ids of the ReportSchemaSummaryFunction's to insert</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportSchemaSummaryFunction_DeleteRecordsForReportSchemaDataTypeSummaryFunctionAssociation 
	@schemaDataType char(1),
	@ids char1array
AS
	DELETE ReportSchemaDataTypeSummaryFunction
	FROM
		ReportSchemaDataTypeSummaryFunction r INNER JOIN
		GetChar1s(@ids) AS Keys ON r.SchemaSummaryFunction = Keys.Id	WHERE r.SchemaDataType = @schemaDataType
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Deletes records from the ReportSelectColumnSummaryFunction table for the specified ids 
</summary>
<param name="selectColumn">The id of the associated ReportSelectColumn</param>
<param name="ids">The ids of the ReportSchemaSummaryFunction's to delete</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportSchemaSummaryFunction_DeleteRecordsForReportSelectColumnSummaryFunctionAssociation
	@selectColumn uniqueidentifier, 
	@ids chararray
AS
	DELETE ReportSelectColumnSummaryFunction
	FROM 
		ReportSelectColumnSummaryFunction ab INNER JOIN
		GetChars(@ids) AS Keys ON ab.SummaryFunction = Keys.Id
	WHERE
		ab.SelectColumn = @selectColumn
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets all records from the ReportSchemaSummaryFunction table
</summary>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportSchemaSummaryFunction_GetAllRecords
AS
	SELECT r.*
	FROM
		ReportSchemaSummaryFunction r
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportSchemaSummaryFunction table with the specified id's
</summary>
<param name="ids">Ids of the records to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportSchemaSummaryFunction_GetRecords 
	@ids char1array
AS
	SELECT r.*
	FROM
		ReportSchemaSummaryFunction r INNER JOIN
		GetChar1s(@ids) AS Keys ON r.Id = Keys.Id
	ORDER BY Sequence
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportSchemaSummaryFunction table for the specified association 
</summary>
<param name="ids">Ids of the ReportSchemaDataType's </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportSchemaSummaryFunction_GetRecordsForReportSchemaDataTypeSummaryFunctionAssociation 
	@ids char1array
AS
	SELECT r1.SchemaDataType, r2.*
	FROM
		ReportSchemaDataTypeSummaryFunction r1 INNER JOIN
		GetChar1s(@ids) AS Keys ON r1.SchemaDataType = Keys.Id INNER JOIN
		ReportSchemaSummaryFunction r2 ON r1.SchemaSummaryFunction = r2.Id
	ORDER BY Sequence
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportSchemaSummaryFunction table for the specified association 
</summary>
<param name="ids">Ids of the ReportSelectColumn(s) </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportSchemaSummaryFunction_GetRecordsForReportSelectColumnSummaryFunctionAssociation
	@ids uniqueidentifierarray
AS
	SELECT ab.SelectColumn, a.*
	FROM
		ReportSelectColumnSummaryFunction ab INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON ab.SelectColumn = Keys.Id INNER JOIN
		ReportSchemaSummaryFunction a ON ab.SummaryFunction = a.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Inserts a new record into the ReportSchemaSummaryFunction table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<param name="sequence">Value to assign to the Sequence field of the record</param>
<param name="functionExpression">Value to assign to the FunctionExpression field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Char" />
*/
CREATE PROCEDURE dbo.ReportSchemaSummaryFunction_InsertRecord 
	@id char(1),
	@name varchar(20),
	@sequence int,
	@functionExpression varchar(50)
AS
INSERT INTO ReportSchemaSummaryFunction
	(

		Id,
		Name,
		Sequence,
		FunctionExpression
	)
	VALUES
	(

		@id,
		@name,
		@sequence,
		@functionExpression
	)
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Insert records in the ReportSchemaDataTypeSummaryFunction table for the specified ids 
</summary>
<param name="id">The id of the associated ReportSchemaDataType</param>
<param name="ids">The ids of the ReportSchemaSummaryFunction's to insert</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportSchemaSummaryFunction_InsertRecordsForReportSchemaDataTypeSummaryFunctionAssociation 
	@id char(1),
	@ids char1array
AS
	INSERT INTO ReportSchemaDataTypeSummaryFunction
	SELECT @id, Keys.*	FROM
		GetChar1s(@ids) AS Keys
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Insert records in the ReportSelectColumnSummaryFunction table for the specified ids 
</summary>
<param name="selectColumn">The id of the associated ReportSelectColumn</param>
<param name="ids">The ids of the ReportSchemaSummaryFunction's to insert</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportSchemaSummaryFunction_InsertRecordsForReportSelectColumnSummaryFunctionAssociation
	@selectColumn uniqueidentifier, 
	@ids chararray
AS
	INSERT INTO ReportSelectColumnSummaryFunction ( SelectColumn, SummaryFunction)
	SELECT @selectColumn, Keys.* FROM
		GetChars(@ids) AS Keys
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Updates a record in the ReportSchemaSummaryFunction table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<param name="sequence">Value to assign to the Sequence field of the record</param>
<param name="functionExpression">Value to assign to the FunctionExpression field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportSchemaSummaryFunction_UpdateRecord 
	@id char(1),
	@name varchar(20),
	@sequence int,
	@functionExpression varchar(50)
AS
	UPDATE ReportSchemaSummaryFunction
	SET
		Name = @name,
		Sequence = @sequence,
		FunctionExpression = @functionExpression
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Deletes a ReportSchemaTableAssociation record
</summary>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportSchemaTableAssociation_DeleteRecord 
	@id uniqueidentifier
AS
	DELETE FROM ReportSchemaTableAssociation
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportSchemaTableAssociation table with the specified id's
</summary>
<param name="ids">Ids of the records to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportSchemaTableAssociation_GetRecords 
	@ids uniqueidentifierarray
AS
	SELECT r.*
	FROM
		ReportSchemaTableAssociation r INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.Id = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Inserts a new record into the ReportSchemaTableAssociation table with the specified values
</summary>
<param name="name">Value to assign to the Name field of the record</param>
<param name="joinExpression">Value to assign to the JoinExpression field of the record</param>
<param name="joinType">Value to assign to the JoinType field of the record</param>
<param name="leftTable">Value to assign to the LeftTable field of the record</param>
<param name="rightTable">Value to assign to the RightTable field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE dbo.ReportSchemaTableAssociation_InsertRecord 
	@name varchar(50),
	@joinExpression varchar(200),
	@joinType char(1),
	@leftTable uniqueidentifier,
	@rightTable uniqueidentifier
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
INSERT INTO ReportSchemaTableAssociation
	(

		Id,
		Name,
		JoinExpression,
		JoinType,
		LeftTable,
		RightTable
	)
	VALUES
	(

		@id,
		@name,
		@joinExpression,
		@joinType,
		@leftTable,
		@rightTable
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Updates a record in the ReportSchemaTableAssociation table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<param name="joinExpression">Value to assign to the JoinExpression field of the record</param>
<param name="joinType">Value to assign to the JoinType field of the record</param>
<param name="leftTable">Value to assign to the LeftTable field of the record</param>
<param name="rightTable">Value to assign to the RightTable field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportSchemaTableAssociation_UpdateRecord 
	@id uniqueidentifier,
	@name varchar(50),
	@joinExpression varchar(200),
	@joinType char(1),
	@leftTable uniqueidentifier,
	@rightTable uniqueidentifier
AS
	UPDATE ReportSchemaTableAssociation
	SET
		Name = @name,
		JoinExpression = @joinExpression,
		JoinType = @joinType,
		LeftTable = @leftTable,
		RightTable = @rightTable
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Deletes a ReportSchemaTableParameter record
</summary>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportSchemaTableParameter_DeleteRecord 
	@id uniqueidentifier
AS
	DELETE FROM ReportSchemaTableParameter
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets all records from the ReportSchemaTableParameter table
</summary>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportSchemaTableParameter_GetAllRecords
AS
	SELECT r.*
	FROM
		ReportSchemaTableParameter r
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportSchemaTableParameter table with the specified id's
</summary>
<param name="ids">Ids of the records to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportSchemaTableParameter_GetRecords 
	@ids uniqueidentifierarray
AS
	SELECT r.*
	FROM
		ReportSchemaTableParameter r INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.Id = Keys.Id
	ORDER BY Sequence
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportSchemaTableParameter table for the specified ids 
</summary>
<param name="ids">Ids of the ReportSchemaTable's </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportSchemaTableParameter_GetRecordsBySchemaTable 
	@ids uniqueidentifierarray
AS
	SELECT r.SchemaTable, r.*
	FROM
		ReportSchemaTableParameter r INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.SchemaTable = Keys.Id
	ORDER BY Sequence
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportSchemaTableParameter table with the specified ids
</summary>
<param name="ids">Ids of the ReportSchemaTable(s) to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportSchemaTableParameter_GetRecordsByTable
	@ids	uniqueidentifierarray
AS
	SELECT r.SchemaTable, r.*
	FROM
		ReportSchemaTableParameter r INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.SchemaTable = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Inserts a new record into the ReportSchemaTableParameter table with the specified values
</summary>
<param name="name">Value to assign to the Name field of the record</param>
<param name="isRequired">Value to assign to the IsRequired field of the record</param>
<param name="sequence">Value to assign to the Sequence field of the record</param>
<param name="schemaColumn">Value to assign to the SchemaColumn field of the record</param>
<param name="schemaOperator">Value to assign to the SchemaOperator field of the record</param>
<param name="schemaTable">Value to assign to the SchemaTable field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE dbo.ReportSchemaTableParameter_InsertRecord 
	@name varchar(50),
	@isRequired bit,
	@sequence int,
	@schemaColumn uniqueidentifier,
	@schemaOperator uniqueidentifier,
	@schemaTable uniqueidentifier
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
INSERT INTO ReportSchemaTableParameter
	(

		Id,
		Name,
		IsRequired,
		Sequence,
		SchemaColumn,
		SchemaOperator,
		SchemaTable
	)
	VALUES
	(

		@id,
		@name,
		@isRequired,
		@sequence,
		@schemaColumn,
		@schemaOperator,
		@schemaTable
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Updates a record in the ReportSchemaTableParameter table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<param name="isRequired">Value to assign to the IsRequired field of the record</param>
<param name="sequence">Value to assign to the Sequence field of the record</param>
<param name="schemaColumn">Value to assign to the SchemaColumn field of the record</param>
<param name="schemaOperator">Value to assign to the SchemaOperator field of the record</param>
<param name="schemaTable">Value to assign to the SchemaTable field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportSchemaTableParameter_UpdateRecord 
	@id uniqueidentifier,
	@name varchar(50),
	@isRequired bit,
	@sequence int,
	@schemaColumn uniqueidentifier,
	@schemaOperator uniqueidentifier,
	@schemaTable uniqueidentifier
AS
	UPDATE ReportSchemaTableParameter
	SET
		Name = @name,
		IsRequired = @isRequired,
		Sequence = @sequence,
		SchemaColumn = @schemaColumn,
		SchemaOperator = @schemaOperator,
		SchemaTable = @schemaTable
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Deletes a ReportSchemaTable record
</summary>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportSchemaTable_DeleteRecord 
	@id uniqueidentifier
AS
	DELETE FROM ReportSchemaTable
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets all records from the ReportSchemaTable table
</summary>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportSchemaTable_GetAllRecords
AS
	SELECT r.*
	FROM
		ReportSchemaTable r
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportSchemaTable table with the specified id's
</summary>
<param name="ids">Ids of the records to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportSchemaTable_GetRecords 
	@ids uniqueidentifierarray
AS
	SELECT r.*
	FROM
		ReportSchemaTable r INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.Id = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Inserts a new record into the ReportSchemaTable table with the specified values
</summary>
<param name="name">Value to assign to the Name field of the record</param>
<param name="tableExpression">Value to assign to the TableExpression field of the record</param>
<param name="identityExpression">Value to assign to the IdentityExpression field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE dbo.ReportSchemaTable_InsertRecord 
	@name varchar(50),
	@tableExpression varchar(500),
	@identityExpression varchar(50)
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
INSERT INTO ReportSchemaTable
	(

		Id,
		Name,
		TableExpression,
		IdentityExpression
	)
	VALUES
	(

		@id,
		@name,
		@tableExpression,
		@identityExpression
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Updates a record in the ReportSchemaTable table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<param name="tableExpression">Value to assign to the TableExpression field of the record</param>
<param name="identityExpression">Value to assign to the IdentityExpression field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportSchemaTable_UpdateRecord 
	@id uniqueidentifier,
	@name varchar(50),
	@tableExpression varchar(500),
	@identityExpression varchar(50)
AS
	UPDATE ReportSchemaTable
	SET
		Name = @name,
		TableExpression = @tableExpression,
		IdentityExpression = @identityExpression
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Deletes a ReportSelectColumn record
</summary>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportSelectColumn_DeleteRecord 
	@id uniqueidentifier
AS
	DELETE FROM ReportSelectColumn
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Deletes records from the ReportSelectColumnSummaryFunction table for the specified ids 
</summary>
<param name="summaryFunction">The id of the associated ReportSchemaSummaryFunction</param>
<param name="ids">The ids of the ReportSelectColumn's to delete</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportSelectColumn_DeleteRecordsForReportSelectColumnSummaryFunctionAssociation
	@summaryFunction char(1), 
	@ids uniqueidentifierarray
AS
	DELETE ReportSelectColumnSummaryFunction
	FROM 
		ReportSelectColumnSummaryFunction ab INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON ab.SelectColumn = Keys.Id
	WHERE
		ab.SummaryFunction = @summaryFunction
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets all records from the ReportSelectColumn table
</summary>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportSelectColumn_GetAllRecords
AS
	SELECT r.*
	FROM
		ReportSelectColumn r
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportColumn table for the specified ids 
</summary>
<param name="ids">Ids of the Report's </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportSelectColumn_GetRecordsByReport 
	@ids uniqueidentifierarray
AS
	SELECT
		r.Report, r.*, s.*
	FROM
		ReportColumn r INNER JOIN
		ReportSelectColumn s ON r.Id = s.Id INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.Report = Keys.Id
	WHERE
		Type = 'S'
	ORDER BY
		Sequence
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportSelectColumn table with the specified ids
</summary>
<param name="ids">Ids of the ReportSchemaSummaryFunction(s) to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportSelectColumn_GetRecordsBySummaryFunction
	@ids	chararray
AS
	SELECT r.SchemaSummaryFunction, r.*
	FROM
		ReportSelectColumn r INNER JOIN
		GetChars(@ids) AS Keys ON r.SchemaSummaryFunction = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportSelectColumn table for the specified association 
</summary>
<param name="ids">Ids of the ReportSchemaSummaryFunction(s) </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportSelectColumn_GetRecordsForReportSelectColumnSummaryFunctionAssociation
	@ids chararray
AS
	SELECT ab.SummaryFunction, a.*
	FROM
		ReportSelectColumnSummaryFunction ab INNER JOIN
		GetChars(@ids) AS Keys ON ab.SummaryFunction = Keys.Id INNER JOIN
		ReportSelectColumn a ON ab.SelectColumn = a.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Inserts a new record into the ReportSelectColumn table with the specified values
</summary>
<param name="label">Value to assign to the Label field of the record</param>
<param name="id">Value to assign to the Id field of the record</param>
<param name="schemaSummaryFunction">Value to assign to the SchemaSummaryFunction field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="IDataReader" />
*/
CREATE PROCEDURE dbo.ReportSelectColumn_InsertRecord 
	@label varchar(50),
	@id uniqueidentifier,
	@schemaSummaryFunction char(1)
AS
INSERT INTO ReportSelectColumn
	(

		Label,
		Id,
		SchemaSummaryFunction
	)
	VALUES
	(

		@label,
		@id,
		@schemaSummaryFunction
	)
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Insert records in the ReportSelectColumnSummaryFunction table for the specified ids 
</summary>
<param name="summaryFunction">The id of the associated ReportSchemaSummaryFunction</param>
<param name="ids">The ids of the ReportSelectColumn's to insert</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportSelectColumn_InsertRecordsForReportSelectColumnSummaryFunctionAssociation
	@summaryFunction char(1), 
	@ids uniqueidentifierarray
AS
	INSERT INTO ReportSelectColumnSummaryFunction ( SummaryFunction, SelectColumn)
	SELECT @summaryFunction, Keys.* FROM
		GetUniqueidentifiers(@ids) AS Keys
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Updates a record in the ReportSelectColumn table with the specified values
</summary>
<param name="label">Value to assign to the Label field of the record</param>
<param name="id">Value to assign to the Id field of the record</param>
<param name="schemaSummaryFunction">Value to assign to the SchemaSummaryFunction field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportSelectColumn_UpdateRecord 
	@label varchar(50),
	@id uniqueidentifier,
	@schemaSummaryFunction char(1)
AS
	UPDATE ReportSelectColumn
	SET
		Label = @label,
		SchemaSummaryFunction = @schemaSummaryFunction
	WHERE Id = @id AND Id = @id AND Id = @id AND Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Deletes a ReportSortOrder record
</summary>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportSortOrder_DeleteRecord 
	@id uniqueidentifier
AS
	DELETE FROM ReportSortOrder
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportSortOrder table with the specified id's
</summary>
<param name="ids">Ids of the records to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportSortOrder_GetRecords 
	@ids uniqueidentifierarray
AS
	SELECT r.*
	FROM
		ReportSortOrder r INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.ID = Keys.Id
	ORDER BY Sequence
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportSortOrder table for the specified ids 
</summary>
<param name="ids">Ids of the Report's </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportSortOrder_GetRecordsByReportId 
	@ids uniqueidentifierarray
AS
	SELECT r.ReportID, r.*
	FROM
		ReportSortOrder r INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.ReportID = Keys.Id
	ORDER BY Sequence
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Inserts a new record into the ReportSortOrder table with the specified values
</summary>
<param name="sequence">Value to assign to the Sequence field of the record</param>
<param name="isAscending">Value to assign to the IsAscending field of the record</param>
<param name="reportId">Value to assign to the ReportID field of the record</param>
<param name="columnId">Value to assign to the ColumnID field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE dbo.ReportSortOrder_InsertRecord 
	@sequence int,
	@isAscending bit,
	@reportId uniqueidentifier,
	@columnId uniqueidentifier
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
INSERT INTO ReportSortOrder
	(

		ID,
		Sequence,
		IsAscending,
		ReportID,
		ColumnID
	)
	VALUES
	(

		@id,
		@sequence,
		@isAscending,
		@reportId,
		@columnId
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Updates a record in the ReportSortOrder table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="sequence">Value to assign to the Sequence field of the record</param>
<param name="isAscending">Value to assign to the IsAscending field of the record</param>
<param name="reportId">Value to assign to the ReportID field of the record</param>
<param name="columnId">Value to assign to the ColumnID field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportSortOrder_UpdateRecord 
	@id uniqueidentifier,
	@sequence int,
	@isAscending bit,
	@reportId uniqueidentifier,
	@columnId uniqueidentifier
AS
	UPDATE ReportSortOrder
	SET
		Sequence = @sequence,
		IsAscending = @isAscending,
		ReportID = @reportId,
		ColumnID = @columnId
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Deletes a ReportSummaryFunction record
</summary>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportSummaryFunction_DeleteRecord 
	@id uniqueidentifier
AS
	DELETE FROM ReportSummaryFunction
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportSummaryFunction table with the specified id's
</summary>
<param name="ids">Ids of the records to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportSummaryFunction_GetRecords 
	@ids uniqueidentifierarray
AS
	SELECT r.*
	FROM
		ReportSummaryFunction r INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.ID = Keys.Id
	ORDER BY Sequence
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Inserts a new record into the ReportSummaryFunction table with the specified values
</summary>
<param name="sequence">Value to assign to the Sequence field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<param name="functionExpression">Value to assign to the FunctionExpression field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE dbo.ReportSummaryFunction_InsertRecord 
	@sequence int,
	@name varchar(20),
	@functionExpression varchar(50)
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
INSERT INTO ReportSummaryFunction
	(

		ID,
		Sequence,
		Name,
		FunctionExpression
	)
	VALUES
	(

		@id,
		@sequence,
		@name,
		@functionExpression
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Updates a record in the ReportSummaryFunction table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="sequence">Value to assign to the Sequence field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<param name="functionExpression">Value to assign to the FunctionExpression field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportSummaryFunction_UpdateRecord 
	@id uniqueidentifier,
	@sequence int,
	@name varchar(20),
	@functionExpression varchar(50)
AS
	UPDATE ReportSummaryFunction
	SET
		Sequence = @sequence,
		Name = @name,
		FunctionExpression = @functionExpression
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Deletes a ReportTableAssociation record
</summary>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportTableAssociation_DeleteRecord 
	@id uniqueidentifier
AS
	DELETE FROM ReportTableAssociation
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportTableAssociation table with the specified id's
</summary>
<param name="ids">Ids of the records to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportTableAssociation_GetRecords 
	@ids uniqueidentifierarray
AS
	SELECT r.*
	FROM
		ReportTableAssociation r INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.Id = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Inserts a new record into the ReportTableAssociation table with the specified values
</summary>
<param name="name">Value to assign to the Name field of the record</param>
<param name="joinExpression">Value to assign to the JoinExpression field of the record</param>
<param name="leftTableId">Value to assign to the LeftTableID field of the record</param>
<param name="rightTableId">Value to assign to the RightTableID field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE dbo.ReportTableAssociation_InsertRecord 
	@name varchar(50),
	@joinExpression varchar(200),
	@leftTableId uniqueidentifier,
	@rightTableId uniqueidentifier
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
INSERT INTO ReportTableAssociation
	(

		Id,
		Name,
		JoinExpression,
		LeftTableID,
		RightTableID
	)
	VALUES
	(

		@id,
		@name,
		@joinExpression,
		@leftTableId,
		@rightTableId
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Updates a record in the ReportTableAssociation table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<param name="joinExpression">Value to assign to the JoinExpression field of the record</param>
<param name="leftTableId">Value to assign to the LeftTableID field of the record</param>
<param name="rightTableId">Value to assign to the RightTableID field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportTableAssociation_UpdateRecord 
	@id uniqueidentifier,
	@name varchar(50),
	@joinExpression varchar(200),
	@leftTableId uniqueidentifier,
	@rightTableId uniqueidentifier
AS
	UPDATE ReportTableAssociation
	SET
		Name = @name,
		JoinExpression = @joinExpression,
		LeftTableID = @leftTableId,
		RightTableID = @rightTableId
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Deletes a ReportTable record
</summary>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportTable_DeleteRecord 
	@id uniqueidentifier
AS
	DELETE FROM ReportTable
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportTable table with the specified id's
</summary>
<param name="ids">Ids of the records to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportTable_GetRecords 
	@ids uniqueidentifierarray
AS
	SELECT r.*
	FROM
		ReportTable r INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.ID = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Inserts a new record into the ReportTable table with the specified values
</summary>
<param name="tableExpression">Value to assign to the TableExpression field of the record</param>
<param name="identityExpression">Value to assign to the IdentityExpression field of the record</param>
<param name="notes">Value to assign to the Notes field of the record</param>
<param name="baseTableId">Value to assign to the BaseTableID field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE dbo.ReportTable_InsertRecord 
	@tableExpression varchar(500),
	@identityExpression varchar(50),
	@notes varchar(50),
	@baseTableId uniqueidentifier
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
INSERT INTO ReportTable
	(

		ID,
		TableExpression,
		IdentityExpression,
		Notes,
		BaseTableID
	)
	VALUES
	(

		@id,
		@tableExpression,
		@identityExpression,
		@notes,
		@baseTableId
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Updates a record in the ReportTable table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="tableExpression">Value to assign to the TableExpression field of the record</param>
<param name="identityExpression">Value to assign to the IdentityExpression field of the record</param>
<param name="notes">Value to assign to the Notes field of the record</param>
<param name="baseTableId">Value to assign to the BaseTableID field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportTable_UpdateRecord 
	@id uniqueidentifier,
	@tableExpression varchar(500),
	@identityExpression varchar(50),
	@notes varchar(50),
	@baseTableId uniqueidentifier
AS
	UPDATE ReportTable
	SET
		TableExpression = @tableExpression,
		IdentityExpression = @identityExpression,
		Notes = @notes,
		BaseTableID = @baseTableId
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Deletes a ReportTypeColumn record
</summary>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportTypeColumn_DeleteRecord 
	@schemaColumn uniqueidentifier,
	@reportTypeTable uniqueidentifier
AS
	DELETE FROM ReportTypeColumn
	WHERE SchemaColumn = @schemaColumn AND ReportTypeTable = @reportTypeTable
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets all records from the ReportTypeColumn table
</summary>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportTypeColumn_GetAllRecords
AS
	SELECT r.*
	FROM
		ReportTypeColumn r
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportTypeColumn table for the specified ids 
</summary>
<param name="ids">Ids of the ReportTypeTable's </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportTypeColumn_GetRecordsByReportTypeTable 
	@ids uniqueidentifierarray
AS
	SELECT r.ReportTypeTable, r.*
	FROM
		ReportTypeColumnView r INNER JOIN
		ReportSchemaColumn rsc on rsc.Id = r.SchemaColumn INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.ReportTypeTable = Keys.Id
	ORDER BY r.Sequence, isnull(r.Name, rsc.Name)
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportTypeColumn table with the specified ids
</summary>
<param name="ids">Ids of the ReportTypeTable(s) to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportTypeColumn_GetRecordsByTable
	@ids	uniqueidentifierarray
AS
	SELECT r.ReportTypeTable, r.*
	FROM
		ReportTypeColumn r INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.ReportTypeTable = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Inserts a new record into the ReportTypeColumn table with the specified values
</summary>
<param name="name">Value to assign to the Name field of the record</param>
<param name="sequence">Value to assign to the Sequence field of the record</param>
<param name="schemaColumn">Value to assign to the SchemaColumn field of the record</param>
<param name="reportTypeTable">Value to assign to the ReportTypeTable field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="IDataReader" />
*/
CREATE PROCEDURE dbo.ReportTypeColumn_InsertRecord 
	@name varchar(100),
	@sequence int,
	@schemaColumn uniqueidentifier,
	@reportTypeTable uniqueidentifier
AS
INSERT INTO ReportTypeColumn
	(

		Name,
		Sequence,
		SchemaColumn,
		ReportTypeTable
	)
	VALUES
	(

		@name,
		@sequence,
		@schemaColumn,
		@reportTypeTable
	)
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Updates a record in the ReportTypeColumn table with the specified values
</summary>
<param name="name">Value to assign to the Name field of the record</param>
<param name="sequence">Value to assign to the Sequence field of the record</param>
<param name="schemaColumn">Value to assign to the SchemaColumn field of the record</param>
<param name="reportTypeTable">Value to assign to the ReportTypeTable field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportTypeColumn_UpdateRecord 
	@name varchar(100),
	@sequence int,
	@schemaColumn uniqueidentifier,
	@reportTypeTable uniqueidentifier
AS
	UPDATE ReportTypeColumn
	SET
		Name = @name,
		Sequence = @sequence
	WHERE SchemaColumn = @schemaColumn AND ReportTypeTable = @reportTypeTable
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Deletes a ReportTypeTable record
</summary>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportTypeTable_DeleteRecord 
	@id uniqueidentifier
AS
	DELETE FROM ReportTypeTable
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets all records from the ReportTypeTable table
</summary>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportTypeTable_GetAllRecords
AS
	SELECT r.*
	FROM
		ReportTypeTable r
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportTypeTable table with the specified id's
</summary>
<param name="ids">Ids of the records to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportTypeTable_GetRecords 
	@ids uniqueidentifierarray
AS
	SELECT r.*
	FROM
		ReportTypeTable r INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.Id = Keys.Id
	ORDER BY Sequence
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportTypeTable table with the specified ids
</summary>
<param name="ids">Ids of the ReportTypeTable(s) to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportTypeTable_GetRecordsByJoinTable
	@ids	uniqueidentifierarray
AS
	SELECT r.JoinTable, r.*
	FROM
		ReportTypeTable r INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.JoinTable = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Inserts a new record into the ReportTypeTable table with the specified values
</summary>
<param name="name">Value to assign to the Name field of the record</param>
<param name="sequence">Value to assign to the Sequence field of the record</param>
<param name="joinExpression">Value to assign to the JoinExpression field of the record</param>
<param name="columnPrefix">Value to assign to the ColumnPrefix field of the record</param>
<param name="joinMultiplicity">Value to assign to the JoinMultiplicity field of the record</param>
<param name="schemaTable">Value to assign to the SchemaTable field of the record</param>
<param name="reportType">Value to assign to the ReportType field of the record</param>
<param name="joinTable">Value to assign to the JoinTable field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE dbo.ReportTypeTable_InsertRecord 
	@name varchar(50),
	@sequence int,
	@joinExpression varchar(200),
	@columnPrefix varchar(50),
	@joinMultiplicity char(1),
	@schemaTable uniqueidentifier,
	@reportType char(1),
	@joinTable uniqueidentifier
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
INSERT INTO ReportTypeTable
	(

		Id,
		Name,
		Sequence,
		JoinExpression,
		ColumnPrefix,
		JoinMultiplicity,
		SchemaTable,
		ReportType,
		JoinTable
	)
	VALUES
	(

		@id,
		@name,
		@sequence,
		@joinExpression,
		@columnPrefix,
		@joinMultiplicity,
		@schemaTable,
		@reportType,
		@joinTable
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Updates a record in the ReportTypeTable table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<param name="sequence">Value to assign to the Sequence field of the record</param>
<param name="joinExpression">Value to assign to the JoinExpression field of the record</param>
<param name="columnPrefix">Value to assign to the ColumnPrefix field of the record</param>
<param name="joinMultiplicity">Value to assign to the JoinMultiplicity field of the record</param>
<param name="schemaTable">Value to assign to the SchemaTable field of the record</param>
<param name="reportType">Value to assign to the ReportType field of the record</param>
<param name="joinTable">Value to assign to the JoinTable field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportTypeTable_UpdateRecord 
	@id uniqueidentifier,
	@name varchar(50),
	@sequence int,
	@joinExpression varchar(200),
	@columnPrefix varchar(50),
	@joinMultiplicity char(1),
	@schemaTable uniqueidentifier,
	@reportType char(1),
	@joinTable uniqueidentifier
AS
	UPDATE ReportTypeTable
	SET
		Name = @name,
		Sequence = @sequence,
		JoinExpression = @joinExpression,
		ColumnPrefix = @columnPrefix,
		JoinMultiplicity = @joinMultiplicity,
		SchemaTable = @schemaTable,
		ReportType = @reportType,
		JoinTable = @joinTable
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Deletes a ReportType record
</summary>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportType_DeleteRecord 
	@id char(1)
AS
	DELETE FROM ReportType
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

 /*
<summary>
Gets all records from the ReportType table
</summary>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="False" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportType_GetAllRecords 
AS
	SELECT c.*
	FROM
		ReportTypeView c
	WHERE
		c.IsEditable = 1
	ORDER BY
		Name
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the ReportType table with the specified id's
</summary>
<param name="ids">Ids of the records to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.ReportType_GetRecords 
	@ids char1array
AS
	SELECT r.*
	FROM
		ReportTypeView r INNER JOIN
		GetChar1s(@ids) AS Keys ON r.Id = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Inserts a new record into the ReportType table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<param name="isEditable">Value to assign to the IsEditable field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Char" />
*/
CREATE PROCEDURE dbo.ReportType_InsertRecord 
	@id char(1),
	@name varchar(30),
	@isEditable bit
AS
INSERT INTO ReportType
	(

		Id,
		Name,
		IsEditable
	)
	VALUES
	(

		@id,
		@name,
		@isEditable
	)
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Updates a record in the ReportType table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<param name="isEditable">Value to assign to the IsEditable field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.ReportType_UpdateRecord 
	@id char(1),
	@name varchar(30),
	@isEditable bit
AS
	UPDATE ReportType
	SET
		Name = @name,
		IsEditable = @isEditable
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Deletes a Report record
</summary>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.Report_DeleteRecord
	@id uniqueidentifier
AS
	DELETE FROM 
		Report
	WHERE
		Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets all records from the Report table.
</summary>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="False" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.Report_GetAllRecords 
AS
	SELECT
		*
	FROM
		Report
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the Report table with the specified id's
</summary>
<param name="ids">Ids of the records to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.Report_GetRecords
	@ids	uniqueidentifierarray
AS
	SELECT r.*
	FROM
		Report r INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.Id = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Gets records from the Report table with the specified ids
</summary>
<param name="ids">Ids of the Staff(s) to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE dbo.Report_GetRecordsByOwner
	@ids	uniqueidentifierarray
AS
	SELECT r.Owner, r.*
	FROM
		Report r INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON r.Owner = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Inserts a new record into the Report table with the specified values
</summary>
<param name="title">Value to assign to the Title field of the record</param>
<param name="query">Value to assign to the Query field of the record</param>
<param name="type">Value to assign to the Type field of the record</param>
<param name="path">Value to assign to the Path field of the record</param>
<param name="description">Value to assign to the Description field of the record</param>
<param name="format">Value to assign to the Format field of the record</param>
<param name="owner">Value to assign to the Owner field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="False" returnType="System.Guid" />
*/
CREATE PROCEDURE dbo.Report_InsertRecord 
	@title varchar(200),
	@query text,
	@type char(1),
	@path varchar(300),
	@description text,
	@format char(1),
	@owner uniqueidentifier
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
INSERT INTO Report
	(

		Id,
		Title,
		Query,
		Type,
		Path,
		Description,
		Format,
		Owner
	)
	VALUES
	(

		@id,
		@title,
		@query,
		@type,
		@path,
		@description,
		@format,
		@owner
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Ensures that the title is unique and may be used for the specified report.
</summary>
<param name="title">The title of the report to check</param>
<param name="ids">The id of the report the title is for</param>
<returns>True if the report title is unique, otherwise False</returns>
<model isGenerated="False" returnType="System.Boolean" />
*/
CREATE PROCEDURE dbo.Report_IsUniqueTitle
	@title varchar(200),
	@report uniqueidentifier
AS
	IF EXISTS 
	(
		SELECT
			Id
		FROM
			Report
		WHERE
			Title = @title AND (@report IS NULL OR @report != Id)
	)
		SELECT CAST(0 AS BIT)
	ELSE
		SELECT CAST(1 AS BIT)
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

 /*
<summary>
Updates a record in the Report table with the specified values
</summary>
<param name="id">Value to assign to the Id field of the record</param>
<param name="title">Value to assign to the Title field of the record</param>
<param name="query">Value to assign to the Query field of the record</param>
<param name="isShared">Value to assign to the IsShared field of the record</param>
<param name="type">Value to assign to the Type field of the record</param>
<param name="path">Value to assign to the Path field of the record</param>
<param name="description">Value to assign to the Description field of the record</param>
<param name="format">Value to assign to the Format field of the record</param>
<param name="owner">Value to assign to the Owner field of the record</param>

<model isGenerated="False" returnType="System.Void" />
*/
CREATE PROCEDURE dbo.Report_UpdateRecord 
	@id uniqueidentifier,
	@title varchar(200),
	@query text,
	@type char(1),
	@path varchar(300),
	@description text,
	@format char(1),
	@owner uniqueidentifier
AS
	UPDATE Report
	SET
		Title = @title,
		Query = @query,
		Type = @type,
		Path = @path,
		Description = @description,
		Format = @format,
		Owner = @owner
	WHERE Id = @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

