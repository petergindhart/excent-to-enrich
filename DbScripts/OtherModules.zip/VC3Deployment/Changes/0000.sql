-- Register VC3Deployment module


--
-- Create Version and Module tables
--
if @@version like 'Microsoft SQL Server  2000%'
begin
	-- NOTE: Current user must be in sysadmin role
	if 0 = (select IS_SRVROLEMEMBER('sysadmin'))
	begin
		declare @user nvarchar(256)
		set @user = user_name()
		raiserror ('User %s must be in the sysadmin server role when this script VC3Deployment/0000.sql is run on a SQL 2000 server', 16, 1, @user)
	end

	-- ensure system catalog updates are allowed
	declare @updatesAllowed bit
	
	select
		@updatesAllowed = cast(c.value as bit)
	from
		master.dbo.spt_values join
		master.dbo.sysconfigures c on number = c.config join
		master.dbo.syscurconfigs cc on number = c.config and number = cc.config
	where
		name = 'allow updates'

	if @updatesAllowed = 0
	begin
        exec sp_configure 'allow updates', '1'
        reconfigure with override
	end

	exec('
		-- Create temp login
		EXEC sp_addlogin ''__schema_temp__'', ''123908123Temp''

		-- Add the user to simulate the schema
		EXEC sp_adduser ''__schema_temp__'', ''VC3Deployment''

		-- Dissassociate the login from the user
		update sysusers
		set sid = null, updatedate = getdate()
		where name = ''VC3Deployment''

		-- delete the temp login
		EXEC sp_droplogin ''__schema_temp__''')

	if @updatesAllowed = 0
	begin
        exec sp_configure 'allow updates', '0'
        reconfigure with override
	end
end
else  -- >= SQL 2005
	exec('create schema VC3Deployment authorization dbo')
GO



CREATE TABLE [VC3Deployment].[Module](
	[Id] [varchar](100) NOT NULL,
	PRIMARY KEY CLUSTERED 
	(
		[Id] ASC
	)
)
GO

CREATE TABLE [VC3Deployment].[Version](
	[Module] [varchar](100) NOT NULL,
	[Script] [int] NOT NULL,
	[DateApplied] [datetime] NOT NULL,
	PRIMARY KEY CLUSTERED
	(
		Script ASC, Module ASC
	)
)

CREATE TABLE VC3Deployment.ModuleDependency
	(
	UsedBy varchar(100) NOT NULL,
	Uses varchar(100) NOT NULL
	)  ON [PRIMARY]
GO
ALTER TABLE VC3Deployment.ModuleDependency ADD CONSTRAINT
	PK_ModuleDependency PRIMARY KEY CLUSTERED 
	(
	UsedBy,
	Uses
	)
GO
ALTER TABLE VC3Deployment.ModuleDependency ADD CONSTRAINT
	FK_ModuleDependency_Uses FOREIGN KEY
	(
	Uses
	) REFERENCES VC3Deployment.Module
	(
	Id
	) 
GO
ALTER TABLE VC3Deployment.ModuleDependency ADD CONSTRAINT
	FK_ModuleDependency_UsedBy FOREIGN KEY
	(
	UsedBy
	) REFERENCES VC3Deployment.Module
	(
	Id
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
GO

ALTER TABLE [VC3Deployment].[Version]  WITH CHECK ADD FOREIGN KEY([Module])
REFERENCES [VC3Deployment].[Module] ([Id])
GO

--#include ..\Objects\AddModule.sql
--#include ..\Objects\AddModuleDependency.sql
--#include ..\Objects\CreateSchema.{SqlServerVersion}.sql
--#include ..\Objects\DropSchema.{SqlServerVersion}.sql
GO

-- Setup basic modules
exec VC3Deployment.AddModule 'dbo'
exec VC3Deployment.AddModule 'VC3Deployment'
exec VC3Deployment.AddModuleDependency @usedBy='dbo', @uses='VC3Deployment'

GO

-- try to upgrade from old Version table
if exists(select * from INFORMATION_SCHEMA.tables where TABLE_SCHEMA = 'dbo' and TABLE_NAME = 'Version')
	exec('	insert into VC3Deployment.Version(Module, Script, DateApplied) select ''dbo'', Number, DateApplied from dbo.Version
			drop table dbo.Version')
