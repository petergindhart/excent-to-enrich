ALTER TABLE VC3Deployment.Module
ADD LastUpdatedDate datetime