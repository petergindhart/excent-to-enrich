IF EXISTS (
  SELECT * 
    FROM INFORMATION_SCHEMA.ROUTINES 
   WHERE SPECIFIC_SCHEMA = N'VC3Deployment'
     AND SPECIFIC_NAME = N'CreateSchema' 
)
   DROP PROCEDURE VC3Deployment.CreateSchema
GO

CREATE PROCEDURE VC3Deployment.CreateSchema
	@name sysname,
	@owner sysname = null
AS
	declare @sql varchar(max) 

	if @owner is null
		set @sql = 'CREATE SCHEMA ' + @name
	else
		set @sql = 'CREATE SCHEMA ' + @name + '  AUTHORIZATION ' + @owner

	exec(@sql)
GO

--VC3Deployment.CreateSchema 'test'
