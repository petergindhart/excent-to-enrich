IF EXISTS (
  SELECT * 
    FROM INFORMATION_SCHEMA.ROUTINES 
   WHERE SPECIFIC_SCHEMA = N'VC3Deployment'
     AND SPECIFIC_NAME = N'CreateSchema' 
)
   DROP PROCEDURE VC3Deployment.CreateSchema
GO

CREATE PROCEDURE VC3Deployment.CreateSchema
	@name sysname
AS
	if exists(select * from sysusers where name = @name)
	begin
		RAISERROR( 'There is already an object named ''%s'' in the database', 16, 6, @name )
	end
	else
	begin
	
		-- ensure system catalog updates are allowed
		declare @updatesAllowed bit
		
		select
			@updatesAllowed = cast(c.value as bit)
		from
			master.dbo.spt_values join
			master.dbo.sysconfigures c on number = c.config join
			master.dbo.syscurconfigs cc on number = c.config and number = cc.config
		where
			name = 'allow updates'

		if @updatesAllowed = 0
		begin
			exec sp_configure 'allow updates', '1'
			reconfigure with override
		end
		
		declare @sql varchar(8000)
		
		set @sql = '
			-- Create temp login
			EXEC sp_addlogin ''__schema_temp__'', ''123908123Temp''
	
			-- Add the user to simulate the schema
			EXEC sp_adduser ''__schema_temp__'', ''' + @name + '''
	
			-- Dissassociate the login from the user
			update sysusers
			set sid = null, updatedate = getdate()
			where name = ''' + @name + '''
	
			-- delete the temp login
			EXEC sp_droplogin ''__schema_temp__'''
		
		exec(@sql)
		
		if @updatesAllowed = 0
		begin
			exec sp_configure 'allow updates', '0'
			reconfigure with override
		end
	end
GO

--VC3Deployment.CreateSchema 'test'