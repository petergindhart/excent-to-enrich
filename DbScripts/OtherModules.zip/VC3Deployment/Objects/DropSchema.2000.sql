IF EXISTS (
  SELECT * 
    FROM INFORMATION_SCHEMA.ROUTINES 
   WHERE SPECIFIC_SCHEMA = N'VC3Deployment'
     AND SPECIFIC_NAME = N'DropSchema' 
)
   DROP PROCEDURE VC3Deployment.DropSchema
GO

CREATE PROCEDURE VC3Deployment.DropSchema
	@name sysname
AS
	exec sp_dropuser @name
GO

/*
exec vc3deployment.createschema 'test'
exec vc3deployment.dropschema 'test'
exec vc3deployment.createschema 'test'
exec vc3deployment.dropschema 'test'
*/