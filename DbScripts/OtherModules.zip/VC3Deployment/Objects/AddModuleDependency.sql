-- =============================================
-- Create basic stored procedure template
-- =============================================

-- Drop stored procedure if it already exists
IF EXISTS (
  SELECT * 
    FROM INFORMATION_SCHEMA.ROUTINES 
   WHERE SPECIFIC_SCHEMA = N'VC3Deployment'
     AND SPECIFIC_NAME = N'AddModuleDependency' 
)
   DROP PROCEDURE VC3Deployment.AddModuleDependency
GO

CREATE PROCEDURE VC3Deployment.AddModuleDependency
	@uses varchar(100), 
	@usedBy varchar(100)
AS
	-- Ensure both modules have been added.
	-- This is needed b/c module registration scripts are run in
	-- alpha order rather than dependency order.
	exec VC3Deployment.AddModule @uses
	exec VC3Deployment.AddModule @usedBy

	insert into ModuleDependency (Uses, UsedBy)
	values(@uses, @usedBy)
GO
