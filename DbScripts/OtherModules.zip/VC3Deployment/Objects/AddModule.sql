-- =============================================
-- Create basic stored procedure template
-- =============================================

-- Drop stored procedure if it already exists
IF EXISTS (
  SELECT * 
    FROM INFORMATION_SCHEMA.ROUTINES 
   WHERE SPECIFIC_SCHEMA = N'VC3Deployment'
     AND SPECIFIC_NAME = N'AddModule' 
)
   DROP PROCEDURE VC3Deployment.AddModule
GO

CREATE PROCEDURE VC3Deployment.AddModule
	@name varchar(100)
AS
	-- Ensure this can be called multiple times without problems.
	-- This is needed b/c module registration scripts are run in
	-- alpha order rather than dependency order.
	if not(exists(select * from Module where Id=@name))
		insert into Module(Id) values(@name)
GO


