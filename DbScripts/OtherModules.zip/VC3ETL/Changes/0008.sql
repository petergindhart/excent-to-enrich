ALTER TABLE VC3ETL.LoadTable ADD
	PurgeCondition varchar(1000) NULL
GO
