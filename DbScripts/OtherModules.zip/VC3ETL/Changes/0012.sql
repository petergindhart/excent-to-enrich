ALTER TABLE VC3ETL.LoadTable ADD
	StartNewTransaction bit NOT NULL CONSTRAINT DF_LoadTable_StartNewTransaction DEFAULT 0,
	LastLoadDate datetime NULL
GO