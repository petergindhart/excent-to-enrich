/*
	Separates ExtractType into ExtractType and ExtractDatabaseType

	Originally we consolidated ExtractType and ExtractDatabaseType into one table.  This script separates the table again
	to allow us to separate database specific (SQL Server, DBase) implementations from extract type specific (SASI, IGPro)
	implementations using the bridge design pattern.	
*/


-- #############################################################################
-- Initial creation with allowable null ExtractDatabase.DatabaseType

SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON

GO
ALTER TABLE VC3ETL.ExtractDatabase
	DROP CONSTRAINT FK_ExtractDatabase#Type#Databases
GO

CREATE TABLE VC3ETL.DatabaseType
	(
	ID uniqueidentifier NOT NULL,
	Name varchar(50) NOT NULL
	)  ON [PRIMARY]
GO
ALTER TABLE VC3ETL.DatabaseType ADD CONSTRAINT
	PK_DatabaseType PRIMARY KEY CLUSTERED 
	(
	ID
	) 

GO

CREATE TABLE VC3ETL.Tmp_ExtractDatabase
	(
	ID uniqueidentifier NOT NULL,
	Type uniqueidentifier NOT NULL,
	DatabaseType uniqueidentifier NULL,
	Server varchar(64) NULL,
	DatabaseOwner varchar(64) NULL,
	DatabaseName varchar(128) NULL,
	Username varchar(32) NULL,
	Password varchar(32) NULL,
	LinkedServer varchar(16) NULL,
	IsLinkedServerManaged bit NULL,
	LastExtractDate datetime NULL,
	LastLoadDate datetime NULL,
	SucceededEmail varchar(500) NULL,
	SucceededSubject text NULL,
	SucceededMessage text NULL,
	FailedEmail varchar(500) NULL,
	FailedSubject text NULL,
	FailedMessage text NULL
	)  ON [PRIMARY]
	 TEXTIMAGE_ON [PRIMARY]
GO
IF EXISTS(SELECT * FROM VC3ETL.ExtractDatabase)
	 EXEC('INSERT INTO VC3ETL.Tmp_ExtractDatabase (ID, Type, Server, DatabaseOwner, DatabaseName, Username, Password, LinkedServer, IsLinkedServerManaged, LastExtractDate, LastLoadDate, SucceededEmail, SucceededSubject, SucceededMessage, FailedEmail, FailedSubject, FailedMessage)
		SELECT ID, Type, Server, DatabaseOwner, DatabaseName, Username, Password, LinkedServer, IsLinkedServerManaged, LastExtractDate, LastLoadDate, SucceededEmail, SucceededSubject, SucceededMessage, FailedEmail, FailedSubject, FailedMessage FROM VC3ETL.ExtractDatabase WITH (HOLDLOCK TABLOCKX)')
GO
ALTER TABLE VC3ETL.PearsonExtractDatabase
	DROP CONSTRAINT FK_PearsonExtractDatabase_ExtractDatabase
GO
ALTER TABLE VC3ETL.LoadTable
	DROP CONSTRAINT FK_LoadTable#Database#LoadTables
GO
ALTER TABLE VC3ETL.ExtractTable
	DROP CONSTRAINT FK_ExtractTable#Database#Tables
GO
DROP TABLE VC3ETL.ExtractDatabase
GO
EXECUTE sp_rename N'VC3ETL.Tmp_ExtractDatabase', N'ExtractDatabase', 'OBJECT' 
GO
ALTER TABLE VC3ETL.ExtractDatabase ADD CONSTRAINT
	PK_ExtractDatabase PRIMARY KEY CLUSTERED 
	(
	ID
	) 

GO
ALTER TABLE VC3ETL.ExtractDatabase ADD CONSTRAINT
	FK_ExtractDatabase#Type#Databases FOREIGN KEY
	(
	Type
	) REFERENCES VC3ETL.ExtractType
	(
	ID
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE VC3ETL.ExtractDatabase ADD CONSTRAINT
	FK_ExtractDatabase#DatabaseType#Databases FOREIGN KEY
	(
	DatabaseType
	) REFERENCES VC3ETL.DatabaseType
	(
	ID
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO

ALTER TABLE VC3ETL.ExtractTable ADD CONSTRAINT
	FK_ExtractTable#Database#Tables FOREIGN KEY
	(
	ExtractDatabase
	) REFERENCES VC3ETL.ExtractDatabase
	(
	ID
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO

ALTER TABLE VC3ETL.LoadTable ADD CONSTRAINT
	FK_LoadTable#Database#LoadTables FOREIGN KEY
	(
	ExtractDatabase
	) REFERENCES VC3ETL.ExtractDatabase
	(
	ID
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO

ALTER TABLE VC3ETL.PearsonExtractDatabase ADD CONSTRAINT
	FK_PearsonExtractDatabase_ExtractDatabase FOREIGN KEY
	(
	ID
	) REFERENCES VC3ETL.ExtractDatabase
	(
	ID
	) ON UPDATE  NO ACTION 
	 ON DELETE  CASCADE 
	
GO


-- #############################################################################
-- DML for ExtractType, DatabaseType and ExtractDatabase
-- This is ParentPortal specific, changes of this nature 
-- may require a 2 version release.

GO


-- #############################################################################
-- Changes ExtractDatabase.DatabaseType to not allow nulls

ALTER TABLE VC3ETL.ExtractDatabase
	DROP CONSTRAINT FK_ExtractDatabase#DatabaseType#Databases
GO

ALTER TABLE VC3ETL.ExtractDatabase
	DROP CONSTRAINT FK_ExtractDatabase#Type#Databases
GO

CREATE TABLE VC3ETL.Tmp_ExtractDatabase
	(
	ID uniqueidentifier NOT NULL,
	Type uniqueidentifier NOT NULL,
	DatabaseType uniqueidentifier NOT NULL,
	Server varchar(64) NULL,
	DatabaseOwner varchar(64) NULL,
	DatabaseName varchar(128) NULL,
	Username varchar(32) NULL,
	Password varchar(32) NULL,
	LinkedServer varchar(16) NULL,
	IsLinkedServerManaged bit NULL,
	LastExtractDate datetime NULL,
	LastLoadDate datetime NULL,
	SucceededEmail varchar(500) NULL,
	SucceededSubject text NULL,
	SucceededMessage text NULL,
	FailedEmail varchar(500) NULL,
	FailedSubject text NULL,
	FailedMessage text NULL
	)  ON [PRIMARY]
	 TEXTIMAGE_ON [PRIMARY]
GO
IF EXISTS(SELECT * FROM VC3ETL.ExtractDatabase)
	 EXEC('INSERT INTO VC3ETL.Tmp_ExtractDatabase (ID, Type, DatabaseType, Server, DatabaseOwner, DatabaseName, Username, Password, LinkedServer, IsLinkedServerManaged, LastExtractDate, LastLoadDate, SucceededEmail, SucceededSubject, SucceededMessage, FailedEmail, FailedSubject, FailedMessage)
		SELECT ID, Type, DatabaseType, Server, DatabaseOwner, DatabaseName, Username, Password, LinkedServer, IsLinkedServerManaged, LastExtractDate, LastLoadDate, SucceededEmail, SucceededSubject, SucceededMessage, FailedEmail, FailedSubject, FailedMessage FROM VC3ETL.ExtractDatabase WITH (HOLDLOCK TABLOCKX)')
GO
ALTER TABLE VC3ETL.PearsonExtractDatabase
	DROP CONSTRAINT FK_PearsonExtractDatabase_ExtractDatabase
GO
ALTER TABLE VC3ETL.LoadTable
	DROP CONSTRAINT FK_LoadTable#Database#LoadTables
GO
ALTER TABLE VC3ETL.ExtractTable
	DROP CONSTRAINT FK_ExtractTable#Database#Tables
GO
DROP TABLE VC3ETL.ExtractDatabase
GO
EXECUTE sp_rename N'VC3ETL.Tmp_ExtractDatabase', N'ExtractDatabase', 'OBJECT' 
GO
ALTER TABLE VC3ETL.ExtractDatabase ADD CONSTRAINT
	PK_ExtractDatabase PRIMARY KEY CLUSTERED 
	(
	ID
	) 

GO
ALTER TABLE VC3ETL.ExtractDatabase ADD CONSTRAINT
	FK_ExtractDatabase#Type#Databases FOREIGN KEY
	(
	Type
	) REFERENCES VC3ETL.ExtractType
	(
	ID
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE VC3ETL.ExtractDatabase ADD CONSTRAINT
	FK_ExtractDatabase#DatabaseType#Databases FOREIGN KEY
	(
	DatabaseType
	) REFERENCES VC3ETL.DatabaseType
	(
	ID
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	

ALTER TABLE VC3ETL.ExtractTable ADD CONSTRAINT
	FK_ExtractTable#Database#Tables FOREIGN KEY
	(
	ExtractDatabase
	) REFERENCES VC3ETL.ExtractDatabase
	(
	ID
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO

ALTER TABLE VC3ETL.LoadTable ADD CONSTRAINT
	FK_LoadTable#Database#LoadTables FOREIGN KEY
	(
	ExtractDatabase
	) REFERENCES VC3ETL.ExtractDatabase
	(
	ID
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO

ALTER TABLE VC3ETL.PearsonExtractDatabase ADD CONSTRAINT
	FK_PearsonExtractDatabase_ExtractDatabase FOREIGN KEY
	(
	ID
	) REFERENCES VC3ETL.ExtractDatabase
	(
	ID
	) ON UPDATE  NO ACTION 
	 ON DELETE  CASCADE 
	
GO

