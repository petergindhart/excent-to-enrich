ALTER TABLE VC3ETL.ExtractDatabase ADD
	RetainSnapshot bit NOT NULL CONSTRAINT DF_ExtractDatabase_RetainSnapshot DEFAULT 0
GO