/*
	Changes PearsonExtractDatabase roster year columns from type int to uniqueidentifier.
 */

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/

SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON

ALTER TABLE VC3ETL.PearsonExtractDatabase
	DROP CONSTRAINT FK_PearsonExtractDatabase_ExtractDatabase
GO

CREATE TABLE VC3ETL.Tmp_PearsonExtractDatabase
	(
	ID uniqueidentifier NOT NULL,
	AbsentCodes varchar(128) NULL,
	LastExtractRosterYear uniqueidentifier NULL,
	LastLoadRosterYear uniqueidentifier NULL
	)  ON [PRIMARY]
GO
IF EXISTS(SELECT * FROM VC3ETL.PearsonExtractDatabase)
	 EXEC('INSERT INTO VC3ETL.Tmp_PearsonExtractDatabase (ID, AbsentCodes)
		SELECT ID, AbsentCodes FROM VC3ETL.PearsonExtractDatabase WITH (HOLDLOCK TABLOCKX)')
GO
DROP TABLE VC3ETL.PearsonExtractDatabase
GO
EXECUTE sp_rename N'VC3ETL.Tmp_PearsonExtractDatabase', N'PearsonExtractDatabase', 'OBJECT' 
GO
ALTER TABLE VC3ETL.PearsonExtractDatabase ADD CONSTRAINT
	PK_PearsonExtractDatabase PRIMARY KEY CLUSTERED 
	(
	ID
	) 

GO
ALTER TABLE VC3ETL.PearsonExtractDatabase ADD CONSTRAINT
	FK_PearsonExtractDatabase_ExtractDatabase FOREIGN KEY
	(
	ID
	) REFERENCES VC3ETL.ExtractDatabase
	(
	ID
	) ON UPDATE  NO ACTION 
	 ON DELETE  CASCADE 
	
GO
