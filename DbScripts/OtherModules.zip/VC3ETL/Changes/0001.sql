/****** Object:  Table [VC3ETL].[ExtractDatabase]    Script Date: 02/24/2009 13:21:10 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [VC3ETL].[ExtractDatabase](
	[ID] [uniqueidentifier] NOT NULL,
	[Type] [uniqueidentifier] NOT NULL,
	[DatabaseType] [uniqueidentifier] NOT NULL,
	[Server] [varchar](64) NULL,
	[DatabaseOwner] [varchar](64) NULL,
	[DatabaseName] [varchar](128) NULL,
	[Username] [varchar](32) NULL,
	[Password] [varchar](32) NULL,
	[LinkedServer] [varchar](16) NULL,
	[IsLinkedServerManaged] [bit] NULL,
	[LastExtractDate] [datetime] NULL,
	[LastLoadDate] [datetime] NULL,
	[SucceededEmail] [varchar](500) NULL,
	[SucceededSubject] [text] NULL,
	[SucceededMessage] [text] NULL,
	[FailedEmail] [varchar](500) NULL,
	[FailedSubject] [text] NULL,
	[FailedMessage] [text] NULL,
 CONSTRAINT [PK_ExtractDatabase] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [VC3ETL].[ExtractTable]    Script Date: 02/24/2009 13:21:10 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [VC3ETL].[ExtractTable](
	[ID] [uniqueidentifier] NOT NULL,
	[ExtractDatabase] [uniqueidentifier] NOT NULL,
	[SourceTable] [varchar](50) NULL,
	[DestSchema] [varchar](50) NULL,
	[DestTable] [varchar](50) NULL,
	[PrimaryKey] [varchar](100) NULL,
	[Indexes] [varchar](200) NULL,
	[LastSuccessfulCount] [int] NULL,
	[CurrentCount] [int] NULL,
	[Filter] [varchar](1000) NULL,
	[Enabled] [bit] NOT NULL CONSTRAINT [DF_ExtractTable_Enabled]  DEFAULT ((1)),
 CONSTRAINT [PK_ExtractTable] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [VC3ETL].[ExtractType]    Script Date: 02/24/2009 13:21:10 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [VC3ETL].[ExtractType](
	[ID] [uniqueidentifier] NOT NULL,
	[Name] [varchar](50) NOT NULL,
 CONSTRAINT [PK_ExtractType] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [VC3ETL].[LoadColumn]    Script Date: 02/24/2009 13:21:10 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [VC3ETL].[LoadColumn](
	[ID] [uniqueidentifier] NOT NULL,
	[LoadTable] [uniqueidentifier] NOT NULL,
	[SourceColumn] [varchar](500) NOT NULL,
	[DestColumn] [varchar](500) NOT NULL,
	[ColumnType] [char](1) NOT NULL,
	[UpdateOnDelete] [bit] NOT NULL,
	[DeletedValue] [varchar](500) NULL,
	[NullValue] [varchar](500) NULL,
 CONSTRAINT [PK_LoadColumn] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [VC3ETL].[LoadTable]    Script Date: 02/24/2009 13:21:10 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [VC3ETL].[LoadTable](
	[ID] [uniqueidentifier] NOT NULL,
	[ExtractDatabase] [uniqueidentifier] NULL,
	[Sequence] [int] NOT NULL,
	[SourceTable] [varchar](100) NOT NULL,
	[DestTable] [varchar](100) NULL,
	[HasMapTable] [bit] NOT NULL,
	[MapTable] [varchar](100) NULL,
	[KeyField] [varchar](250) NULL,
	[DeleteKey] [varchar](50) NULL,
	[ImportType] [int] NOT NULL,
	[DeleteTrans] [bit] NOT NULL,
	[UpdateTrans] [bit] NOT NULL,
	[InsertTrans] [bit] NOT NULL,
	[Enabled] [bit] NOT NULL,
	[SourceTableFilter] [varchar](1000) NULL,
	[DestTableFilter] [varchar](1000) NULL,
 CONSTRAINT [PK_LoadTable] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [VC3ETL].[PearsonExtractDatabase]    Script Date: 02/24/2009 13:21:10 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [VC3ETL].[PearsonExtractDatabase](
	[ID] [uniqueidentifier] NOT NULL,
	[AbsentCodes] [varchar](128) NULL,
	[LastExtractRosterYear] [uniqueidentifier] NULL,
	[LastLoadRosterYear] [uniqueidentifier] NULL,
	[CurrentRosterYearOffset] [int] NOT NULL CONSTRAINT [DF_PearsonExtractDatabase_CurrentRosterYearOffset]  DEFAULT ((0)),
	[RosterYearRolloverSQL] [varchar](4000) NULL,
 CONSTRAINT [PK_PearsonExtractDatabase] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [VC3ETL].[PearsonExtractTable]    Script Date: 02/24/2009 13:21:10 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [VC3ETL].[PearsonExtractTable](
	[ID] [uniqueidentifier] NOT NULL,
	[AddSuffix] [bit] NOT NULL CONSTRAINT [DF_PearsonExtractTable_AddSuffix]  DEFAULT ((0)),
	[SchoolNumColumn] [varchar](50) NULL,
 CONSTRAINT [PK_PearsonExtractTable] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO
--ALTER TABLE [VC3ETL].[ExtractDatabase]  WITH CHECK ADD  CONSTRAINT [FK_ExtractDatabase#DatabaseType#Databases] FOREIGN KEY([DatabaseType])
--REFERENCES [VC3ETL].[DatabaseType] ([ID])
--GO
--ALTER TABLE [VC3ETL].[ExtractDatabase] CHECK CONSTRAINT [FK_ExtractDatabase#DatabaseType#Databases]
--GO

--ALTER TABLE [VC3ETL].[ExtractDatabase]  WITH CHECK ADD  CONSTRAINT [FK_ExtractDatabase#ScheduledTaskSchedule#Schedule] FOREIGN KEY([Schedule])
--REFERENCES [VC3TaskScheduler].[ScheduledTaskSchedule] ([ID])
--GO
--ALTER TABLE [VC3ETL].[ExtractDatabase] CHECK CONSTRAINT [FK_ExtractDatabase#ScheduledTaskSchedule#Schedule]
--GO
ALTER TABLE [VC3ETL].[ExtractDatabase]  WITH CHECK ADD  CONSTRAINT [FK_ExtractDatabase#Type#Databases] FOREIGN KEY([Type])
REFERENCES [VC3ETL].[ExtractType] ([ID])
GO
ALTER TABLE [VC3ETL].[ExtractDatabase] CHECK CONSTRAINT [FK_ExtractDatabase#Type#Databases]
GO
ALTER TABLE [VC3ETL].[ExtractTable]  WITH CHECK ADD  CONSTRAINT [FK_ExtractTable#Database#Tables] FOREIGN KEY([ExtractDatabase])
REFERENCES [VC3ETL].[ExtractDatabase] ([ID])
GO
ALTER TABLE [VC3ETL].[ExtractTable] CHECK CONSTRAINT [FK_ExtractTable#Database#Tables]
GO
ALTER TABLE [VC3ETL].[LoadColumn]  WITH CHECK ADD  CONSTRAINT [FK_LoadColumn#Table#Columns] FOREIGN KEY([LoadTable])
REFERENCES [VC3ETL].[LoadTable] ([ID])
GO
ALTER TABLE [VC3ETL].[LoadColumn] CHECK CONSTRAINT [FK_LoadColumn#Table#Columns]
GO
ALTER TABLE [VC3ETL].[LoadTable]  WITH CHECK ADD  CONSTRAINT [FK_LoadTable#Database#LoadTables] FOREIGN KEY([ExtractDatabase])
REFERENCES [VC3ETL].[ExtractDatabase] ([ID])
GO
ALTER TABLE [VC3ETL].[LoadTable] CHECK CONSTRAINT [FK_LoadTable#Database#LoadTables]
GO
ALTER TABLE [VC3ETL].[PearsonExtractDatabase]  WITH CHECK ADD  CONSTRAINT [FK_PearsonExtractDatabase_ExtractDatabase] FOREIGN KEY([ID])
REFERENCES [VC3ETL].[ExtractDatabase] ([ID])
ON DELETE CASCADE
GO
ALTER TABLE [VC3ETL].[PearsonExtractDatabase] CHECK CONSTRAINT [FK_PearsonExtractDatabase_ExtractDatabase]
GO
ALTER TABLE [VC3ETL].[PearsonExtractTable]  WITH CHECK ADD  CONSTRAINT [FK_PearsonExtractTable_ExtractTable] FOREIGN KEY([ID])
REFERENCES [VC3ETL].[ExtractTable] ([ID])
ON DELETE CASCADE
GO
ALTER TABLE [VC3ETL].[PearsonExtractTable] CHECK CONSTRAINT [FK_PearsonExtractTable_ExtractTable]