ALTER TABLE VC3ETL.ExtractDatabase ADD
	DestTableTempSuffix varchar(30) NULL,
	DestTableFinalSuffix varchar(30) NULL
GO
ALTER TABLE VC3ETL.ExtractDatabase ADD CONSTRAINT
	DF_ExtractDatabase_DestTableTempSuffix DEFAULT '_NEW' FOR DestTableTempSuffix
GO
ALTER TABLE VC3ETL.ExtractDatabase ADD CONSTRAINT
	DF_ExtractDatabase_DestTableFinalSuffix DEFAULT '_LOCAL' FOR DestTableFinalSuffix
GO
UPDATE VC3ETL.ExtractDatabase SET DestTableTempSuffix = '_NEW'
UPDATE VC3ETL.ExtractDatabase SET DestTableFinalSuffix = '_LOCAL'
GO