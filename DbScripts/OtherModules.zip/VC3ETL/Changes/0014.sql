ALTER TABLE VC3ETL.ExtractDatabase ADD
	FileGroup varchar(64) NULL
GO