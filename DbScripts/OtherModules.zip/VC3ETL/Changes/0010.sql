ALTER TABLE VC3ETL.LoadTable ADD
	KeepMappingAfterDelete bit NOT NULL CONSTRAINT DF_LoadTable_DeleteMappings DEFAULT 0
GO