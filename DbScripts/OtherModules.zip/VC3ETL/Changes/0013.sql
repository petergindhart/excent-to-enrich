ALTER TABLE VC3ETL.PearsonExtractDatabase ADD
	CurrentRosterYearOffset int NOT NULL CONSTRAINT DF_PearsonExtractDatabase_CurrentRosterYearOffset DEFAULT 0
GO

ALTER TABLE VC3ETL.PearsonExtractDatabase ADD
	RosterYearRolloverSQL varchar(4000) NULL
GO