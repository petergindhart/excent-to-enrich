/*
	Add validation schema to VC3ETL

	Tuesday, June 12, 20073:47:51 PM
	User: 
	Server: DEV-SQL-2005
	Database: VC3_Shared
	Application: 
*/

SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON

CREATE TABLE VC3ETL.ExtractValidatorType
	(
	ID uniqueidentifier NOT NULL,
	Name varchar(50) NOT NULL,
	Description varchar(500) NULL
	)  ON [PRIMARY]
GO
ALTER TABLE VC3ETL.ExtractValidatorType ADD CONSTRAINT
	PK_ExtractValidatorType PRIMARY KEY CLUSTERED 
	(
	ID
	) 

GO

CREATE TABLE VC3ETL.ExtractValidator
	(
	ID uniqueidentifier NOT NULL,
	Type uniqueidentifier NOT NULL,
	ExtractTable uniqueidentifier NOT NULL,
	Enabled bit NOT NULL
	)  ON [PRIMARY]
GO
ALTER TABLE VC3ETL.ExtractValidator ADD CONSTRAINT
	DF_ExtractValidator_Enabled DEFAULT 1 FOR Enabled
GO
ALTER TABLE VC3ETL.ExtractValidator ADD CONSTRAINT
	PK_ExtractValidator PRIMARY KEY CLUSTERED 
	(
	ID
	) 

GO
ALTER TABLE VC3ETL.ExtractValidator ADD CONSTRAINT
	FK_ExtractValidator#Type#Validators FOREIGN KEY
	(
	Type
	) REFERENCES VC3ETL.ExtractValidatorType
	(
	ID
	) ON UPDATE  NO ACTION 
	 ON DELETE  CASCADE 
	
GO
ALTER TABLE VC3ETL.ExtractValidator ADD CONSTRAINT
	FK_ExtractValidator#Table#Validators FOREIGN KEY
	(
	ExtractTable
	) REFERENCES VC3ETL.ExtractTable
	(
	ID
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO

CREATE TABLE VC3ETL.UniquenessExtractValidator
	(
	ID uniqueidentifier NOT NULL,
	Columns varchar(50) NOT NULL
	)  ON [PRIMARY]
GO
ALTER TABLE VC3ETL.UniquenessExtractValidator ADD CONSTRAINT
	PK_UniquenessExtractValidator PRIMARY KEY CLUSTERED 
	(
	ID
	) 

GO
ALTER TABLE VC3ETL.UniquenessExtractValidator ADD CONSTRAINT
	FK_UniquenessExtractValidator_ExtractValidator FOREIGN KEY
	(
	ID
	) REFERENCES VC3ETL.ExtractValidator
	(
	ID
	) ON UPDATE  NO ACTION 
	 ON DELETE  CASCADE 
	
GO

CREATE TABLE VC3ETL.TableSizeExtractValidator
	(
	ID uniqueidentifier NOT NULL,
	MinPercentChange decimal(18, 0) NULL,
	MaxPercentChange decimal(18, 0) NOT NULL
	)  ON [PRIMARY]
GO
ALTER TABLE VC3ETL.TableSizeExtractValidator ADD CONSTRAINT
	PK_TableSizeExtractValidator PRIMARY KEY CLUSTERED 
	(
	ID
	)

GO
ALTER TABLE VC3ETL.TableSizeExtractValidator ADD CONSTRAINT
	FK_TableSizeExtractValidator_ExtractValidator FOREIGN KEY
	(
	ID
	) REFERENCES VC3ETL.ExtractValidator
	(
	ID
	) ON UPDATE  NO ACTION 
	 ON DELETE  CASCADE 
	
GO

CREATE TABLE VC3ETL.ExtractIssue
	(
	ID uniqueidentifier NOT NULL,
	Validator uniqueidentifier NOT NULL,
	CanOverride bit NOT NULL,
	Description varchar(2000) NOT NULL
	)  ON [PRIMARY]
GO
ALTER TABLE VC3ETL.ExtractIssue ADD CONSTRAINT
	PK_ExtractIssue PRIMARY KEY CLUSTERED 
	(
	ID
	) 

GO
ALTER TABLE VC3ETL.ExtractIssue ADD CONSTRAINT
	FK_ExtractIssue#Validator#Issues FOREIGN KEY
	(
	Validator
	) REFERENCES VC3ETL.ExtractValidator
	(
	ID
	) ON UPDATE  NO ACTION 
	 ON DELETE  CASCADE 
	
GO

DROP TABLE VC3ETL.UniquenessExtractValidator
GO

DROP TABLE VC3ETL.TableSizeExtractValidator
GO

ALTER TABLE VC3ETL.ExtractValidator ADD
	MinPercentChange decimal(18, 0) NULL,
	MaxPercentChange decimal(18, 0) NULL,
	Columns varchar(100) NULL
GO
