--#assume VC3TaskScheduler:1

CREATE TABLE VC3ETL.ExtractTask
	(
	ExtractDatabase uniqueidentifier NOT NULL,
	ScheduledTask uniqueidentifier NOT NULL
	)  ON [PRIMARY]
GO
ALTER TABLE VC3ETL.ExtractTask ADD CONSTRAINT
	PK_ExtractTask PRIMARY KEY CLUSTERED 
	(
	ExtractDatabase,
	ScheduledTask
	) 

GO
ALTER TABLE VC3ETL.ExtractTask ADD CONSTRAINT
	FK_ExtractTask#ExtractDatabase#Tasks FOREIGN KEY
	(
	ExtractDatabase
	) REFERENCES VC3ETL.ExtractDatabase
	(
	ID
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO


ALTER TABLE VC3ETL.ExtractTask ADD CONSTRAINT
	FK_ExtractTask#ScheduledTask#Database FOREIGN KEY
	(
	ScheduledTask
	) REFERENCES VC3TaskScheduler.ScheduledTask
	(
	ID
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE VC3ETL.ExtractTask
	DROP CONSTRAINT FK_ExtractTask#ScheduledTask#Database
GO
ALTER TABLE VC3ETL.ExtractTask
	DROP CONSTRAINT FK_ExtractTask#ExtractDatabase#Tasks
GO
ALTER TABLE VC3ETL.ExtractDatabase ADD
	Schedule uniqueidentifier NULL
GO

ALTER TABLE VC3ETL.ExtractTask ADD CONSTRAINT
	FK_ExtractTask_ExtractDatabase FOREIGN KEY
	(
	ExtractDatabase
	) REFERENCES VC3ETL.ExtractDatabase
	(
	ID
	) ON UPDATE  NO ACTION 
	 ON DELETE  CASCADE 
	
GO
ALTER TABLE VC3ETL.ExtractTask ADD CONSTRAINT
	FK_ExtractTask_ScheduledTask FOREIGN KEY
	(
	ScheduledTask
	) REFERENCES VC3TaskScheduler.ScheduledTask
	(
	ID
	) ON UPDATE  NO ACTION 
	 ON DELETE  CASCADE 
	
GO
