
--create the scema so that it can recognize it later
exec VC3DEployment.CreateSchema 'VC3ETL'

-- Setup basic modules
exec VC3Deployment.AddModule 'VC3ETL'
exec VC3Deployment.AddModuleDependency @usedBy='dbo', @uses='VC3ETL'
