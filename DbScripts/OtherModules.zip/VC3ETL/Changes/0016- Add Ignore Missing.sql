ALTER TABLE VC3ETL.LoadTable
	ALTER COLUMN SourceTable varchar(100) not null
GO

ALTER TABLE VC3ETL.ExtractTable ADD
	IgnoreMissing bit NOT NULL CONSTRAINT DF_ExtractTable_IgnoreMissing DEFAULT 0
GO