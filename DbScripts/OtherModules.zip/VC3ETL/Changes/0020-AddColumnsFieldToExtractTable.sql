ALTER TABLE VC3ETL.ExtractTable ADD
	Columns varchar(4000) NULL
GO