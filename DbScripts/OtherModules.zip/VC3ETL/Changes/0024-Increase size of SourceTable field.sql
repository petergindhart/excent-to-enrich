ALTER TABLE VC3ETL.ExtractTable ALTER COLUMN
	SourceTable varchar(100) null