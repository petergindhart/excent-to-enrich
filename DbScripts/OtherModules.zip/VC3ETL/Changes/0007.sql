ALTER TABLE VC3ETL.ExtractValidator
	DROP CONSTRAINT FK_ExtractValidator#Table#Validators
GO
ALTER TABLE VC3ETL.ExtractValidator
	DROP CONSTRAINT FK_ExtractValidator#Type#Validators
GO
 
ALTER TABLE VC3ETL.ExtractValidator
	DROP CONSTRAINT DF_ExtractValidator_Enabled
GO
CREATE TABLE VC3ETL.Tmp_ExtractValidator
	(
	ID uniqueidentifier NOT NULL,
	Type uniqueidentifier NOT NULL,
	ExtractTable uniqueidentifier NOT NULL,
	Enabled bit NOT NULL,
	MinPercentChange decimal(7, 4) NULL,
	MaxPercentChange decimal(7, 4) NULL,
	Columns varchar(100) NULL
	)  ON [PRIMARY]
GO
ALTER TABLE VC3ETL.Tmp_ExtractValidator ADD CONSTRAINT
	DF_ExtractValidator_Enabled DEFAULT ((1)) FOR Enabled
GO
IF EXISTS(SELECT * FROM VC3ETL.ExtractValidator)
	 EXEC('INSERT INTO VC3ETL.Tmp_ExtractValidator (ID, Type, ExtractTable, Enabled, MinPercentChange, MaxPercentChange, Columns)
		SELECT ID, Type, ExtractTable, Enabled, CONVERT(decimal(7, 4), MinPercentChange), CONVERT(decimal(7, 4), MaxPercentChange), Columns FROM VC3ETL.ExtractValidator WITH (HOLDLOCK TABLOCKX)')
GO
ALTER TABLE VC3ETL.ExtractIssue
	DROP CONSTRAINT FK_ExtractIssue#Validator#Issues
GO
DROP TABLE VC3ETL.ExtractValidator
GO
EXECUTE sp_rename N'VC3ETL.Tmp_ExtractValidator', N'ExtractValidator', 'OBJECT' 
GO
ALTER TABLE VC3ETL.ExtractValidator ADD CONSTRAINT
	PK_ExtractValidator PRIMARY KEY CLUSTERED 
	(
	ID
	) 

GO
ALTER TABLE VC3ETL.ExtractValidator ADD CONSTRAINT
	FK_ExtractValidator#Type#Validators FOREIGN KEY
	(
	Type
	) REFERENCES VC3ETL.ExtractValidatorType
	(
	ID
	) ON UPDATE  NO ACTION 
	 ON DELETE  CASCADE 
	
GO
ALTER TABLE VC3ETL.ExtractValidator ADD CONSTRAINT
	FK_ExtractValidator#Table#Validators FOREIGN KEY
	(
	ExtractTable
	) REFERENCES VC3ETL.ExtractTable
	(
	ID
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
 
ALTER TABLE VC3ETL.ExtractIssue ADD CONSTRAINT
	FK_ExtractIssue#Validator#Issues FOREIGN KEY
	(
	Validator
	) REFERENCES VC3ETL.ExtractValidator
	(
	ID
	) ON UPDATE  NO ACTION 
	 ON DELETE  CASCADE 
	
GO