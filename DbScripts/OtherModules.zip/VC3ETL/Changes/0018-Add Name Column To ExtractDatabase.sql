ALTER TABLE VC3ETL.ExtractDatabase ADD
	Name varchar(100) null
GO

ALTER TABLE VC3ETL.ExtractDatabase ADD
	Enabled bit NOT NULL CONSTRAINT DF_ExtractDatabase_Enabled DEFAULT 1
GO

ALTER TABLE VC3ETL.PearsonExtractDatabase ADD
	AbsenceRecordOffset int NOT NULL CONSTRAINT DF_PearsonExtractDatabase_AbsenceRecordOffset DEFAULT 0
GO
