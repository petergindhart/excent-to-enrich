ALTER TABLE VC3ETL.FlatFileExtractTableType ADD
	TextQualifier char(1) NULL
GO