UPDATE vc3etl.DatabaseType
SET Name = 'Oracle', DBPRovider = 'VC3.ETL.Business.OracleDBProvider,VC3.ETL'
WHERE ID = '256BEEB5-D6B4-4FA9-9854-8ACCAE51FF2E'