SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [VC3ETL].[FlatFileExtractColumn](
	[ID] [uniqueidentifier] NOT NULL,
	[ExtractFile] [uniqueidentifier] NOT NULL,
	[SourceColumn] [varchar](100) NOT NULL,
	[DestColumn] [varchar](100) NOT NULL,
	[DataType] [char](1) NOT NULL,
	[DataLength] [int] NULL,
 CONSTRAINT [PK_FlatFileExtractColumn] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [VC3ETL].[FlatFileExtractColumnDataType](
	[ID] [char](1) NOT NULL,
	[Name] [varchar](50) NOT NULL,
	[SQLTypeName] [varchar](50) NOT NULL,
	[RequiresLength] [bit] NOT NULL,
 CONSTRAINT [PK_FlatFileExtractColumnType] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [VC3ETL].[FlatFileExtractDatabase](
	[ID] [uniqueidentifier] NOT NULL,
	[LocalCopyPath] [varchar](1000) NOT NULL,
 CONSTRAINT [PK_FlatFileExtractDatabase] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [VC3ETL].[FlatFileExtractTable](
	[ID] [uniqueidentifier] NOT NULL,
	[Type] [char](1) NULL,
	[FileName] [varchar](50) NOT NULL,
 CONSTRAINT [PK_FlatFileExtractTable] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [VC3ETL].[FlatFileExtractTableType](
	[ID] [char](1) NOT NULL,
	[Name] [varchar](50) NOT NULL,
 CONSTRAINT [PK_FlatFileExtractTableType] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [VC3ETL].[FlatFileExtractColumn]  WITH CHECK ADD  CONSTRAINT [FK_FlatFileExtractColumn_FlatFileExtractColumnType] FOREIGN KEY([DataType])
REFERENCES [VC3ETL].[FlatFileExtractColumnDataType] ([ID])
GO

ALTER TABLE [VC3ETL].[FlatFileExtractColumn] CHECK CONSTRAINT [FK_FlatFileExtractColumn_FlatFileExtractColumnType]
GO

ALTER TABLE [VC3ETL].[FlatFileExtractColumn]  WITH CHECK ADD  CONSTRAINT [FK_FlatFileExtractColumn_FlatFileExtractTable] FOREIGN KEY([ExtractFile])
REFERENCES [VC3ETL].[FlatFileExtractTable] ([ID])
ON DELETE CASCADE
GO

ALTER TABLE [VC3ETL].[FlatFileExtractColumn] CHECK CONSTRAINT [FK_FlatFileExtractColumn_FlatFileExtractTable]
GO

ALTER TABLE [VC3ETL].[FlatFileExtractColumnDataType] ADD  CONSTRAINT [DF_FlatFileExtractColumnType_RequiresLength]  DEFAULT ((1)) FOR [RequiresLength]
GO

ALTER TABLE [VC3ETL].[FlatFileExtractDatabase]  WITH CHECK ADD  CONSTRAINT [FK_FlatFileExtractDatabase_ExtractDatabase] FOREIGN KEY([ID])
REFERENCES [VC3ETL].[ExtractDatabase] ([ID])
ON DELETE CASCADE
GO

ALTER TABLE [VC3ETL].[FlatFileExtractDatabase] CHECK CONSTRAINT [FK_FlatFileExtractDatabase_ExtractDatabase]
GO

ALTER TABLE [VC3ETL].[FlatFileExtractTable]  WITH CHECK ADD  CONSTRAINT [FK_FlatFileExtractTable#Type#] FOREIGN KEY([Type])
REFERENCES [VC3ETL].[FlatFileExtractTableType] ([ID])
GO

ALTER TABLE [VC3ETL].[FlatFileExtractTable] CHECK CONSTRAINT [FK_FlatFileExtractTable#Type#]
GO

ALTER TABLE [VC3ETL].[FlatFileExtractTable]  WITH CHECK ADD  CONSTRAINT [FK_FlatFileExtractTable_ExtractTable] FOREIGN KEY([ID])
REFERENCES [VC3ETL].[ExtractTable] ([ID])
ON DELETE CASCADE
GO

ALTER TABLE [VC3ETL].[FlatFileExtractTable] CHECK CONSTRAINT [FK_FlatFileExtractTable_ExtractTable]
GO

ALTER TABLE VC3ETL.FlatFileExtractColumn ADD
	Sequence int NOT NULL CONSTRAINT DF_FlatFileExtractColumn_Sequence DEFAULT 0
GO

INSERT INTO VC3ETL.DatabaseType VALUES ('58BA0C59-5087-4F38-B00B-F3480C93064B', 'Flat File','VC3.ETL.Business.FlatFileDBProvider,VC3.ETL')

INSERT INTO VC3ETL.FlatFileExtractTableType VALUES ('C','Comma Delimitted File (CSV)')
INSERT INTO VC3ETL.FlatFileExtractColumnDataType VALUES ('V','VARCHAR','VARCHAR',1)
INSERT INTO VC3ETL.FlatFileExtractColumnDataType VALUES ('D','DateTime','DATETIME',0)