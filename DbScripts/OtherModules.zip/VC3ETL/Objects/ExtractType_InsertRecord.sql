SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3ETL].[ExtractType_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3ETL].[ExtractType_InsertRecord]
GO

 /*
<summary>
Inserts a new record into the ExtractType table with the specified values
</summary>
<param name="name">Value to assign to the Name field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE VC3ETL.ExtractType_InsertRecord	
	@name varchar(50)
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
	
	INSERT INTO ExtractType
	(
		Id, 
		Name
	)
	VALUES
	(
		@id, 
		@name
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

