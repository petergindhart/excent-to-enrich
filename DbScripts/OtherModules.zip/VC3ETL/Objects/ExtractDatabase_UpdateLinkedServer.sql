IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[VC3ETL].[ExtractDatabase_UpdateLinkedServer]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [VC3ETL].[ExtractDatabase_UpdateLinkedServer]
GO

 /*
<summary>
Ensures that the linked server for this ExtractDatabase is configured
based on the current settings.
</summary>

<returns></returns>

<model  isGenerated="false" 
        returnType="System.Data.IDataReader" 
        />
*/
CREATE PROCEDURE [VC3ETL].[ExtractDatabase_UpdateLinkedServer] 
	@extractDatabase 		uniqueidentifier,
	@linkedServer_orig 	varchar(100)
AS

declare @linkedServer 		varchar(16)
declare @dbTypeID		uniqueidentifier
declare @isLinkedServerManaged	bit
declare @dbServer		varchar(64)
declare @dbUser			varchar(32)
declare @dbPassword		varchar(32)

select 
	@linkedServer 		= LinkedServer,
	@dbTypeID 		= DatabaseType,
	@dbServer		= Server,
	@dbUser			= Username,
	@dbPassword		= Password,
	@isLinkedServerManaged	= IsLinkedServerManaged
from 
	VC3ETL.ExtractDatabase
where 
	Id = @extractDatabase

if @isLinkedServerManaged = 1
begin

	-- Delete the original linked server if needed
	if @linkedServer_orig is not null AND exists(select * from master..sysservers where srvname = @linkedServer_orig)
		exec master..sp_dropserver @linkedServer_orig, 'droplogins'
	
	-- Create the new linked server
	if @linkedServer is not null
	begin
		if exists(select * from master..sysservers where srvname = @linkedServer)
			exec master..sp_dropserver @linkedServer, 'droplogins'

		if @dbTypeID = '72DD6335-955B-46D2-96AA-58A18CBB5327'
		begin
			declare @connStr varchar(1000)
			set @connStr = 'Driver={Microsoft dBASE Driver (*.dbf)};DriverID=277;Dbq=' + dbo.DbDirectory() + @linkedServer
		
			-- Use ODBC datasource
			exec master..sp_addlinkedserver 
				@server 	= @linkedServer,
				@srvproduct 	= '',
				@provider 	= 'MSDASQL',
				@provstr 	= @connStr
		end
		else if @dbTypeID in ('CBE6E716-95F0-44BC-837C-BBC4FD59506C')  --, 'AD859884-E947-4B61-A441-E34E1582C228') --Sql server, OpenQuery
		begin
			-- Use linked SQL server
			exec master..sp_addlinkedserver 
				@server 	= @linkedServer,
				@srvproduct 	= '-',
				@provider 	= 'SQLOLEDB',
				@datasrc 	= @dbServer
	
			if @dbuser is not null
				exec master..sp_addlinkedsrvlogin
					@useself 	= 'false',
					@rmtsrvname 	= @linkedServer,
					@rmtuser 	= @dbuser,
					@rmtpassword	= @dbpassword
		end
	end
end