IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[VC3ETL].[DBaseDBProvider_CopyPhysicalFileToLinkedServerDirectory]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [VC3ETL].[DBaseDBProvider_CopyPhysicalFileToLinkedServerDirectory]
GO

CREATE PROCEDURE VC3ETL.DBaseDBProvider_CopyPhysicalFileToLinkedServerDirectory
	@extractDatabase		uniqueidentifier,
	@sourceTable			varchar(64)
AS
BEGIN
	declare
		@destDir varchar(256), 		/* The local folder that will contain the table files */
		@command varchar (4000), 	/* Dos command to be executed to set up UNC path, etc */
		@exitCode int,
		@linkedServer varchar (16), /* Linked server name, eg. 'L2' */
		@dbServer varchar (64), 	/* The name of the database server */
		@attempts int,	
		@dbName varchar (128), 		/* The name of the database */
		@uncPath varchar (128), 	/* The unc path pointing to the data files directory */
		@dbUser varchar (32), 
		@dbPassword varchar (32),
		@fileName varchar (64) 		/* The file name of contains the original data */

	SELECT
			@linkedServer 		= LinkedServer,
			@dbServer			= Server,
			@dbName				= isnull(DatabaseName, '')	,
			@dbUser				= isnull(Username, ''),
			@dbPassword			= isnull(Password, '')
	FROM	
		VC3ETL.ExtractDatabase d 
	where 
		d.ID = @extractDatabase

	set @destDir = '"' + dbo.DbDirectory() + @linkedServer + '"'
	set @exitCode = 1
	set @attempts = 0
	set @uncPath = IsNUll(@dbServer,'') + IsNull(@dbName,'')

	declare @MAX_RETRIES int
	set @MAX_RETRIES = 1

	declare @RETRY_DELAY varchar(100)
	set @RETRY_DELAY = '00:00:05' -- 5 second

	TRYAGAIN:
	while @exitCode <> 0 AND @attempts <= @MAX_RETRIES 
	BEGIN
		set @attempts = @attempts + 1

		if @attempts > 1
		begin
			-- This is a retry attempt...
			-- Pause for a moment to let the situation fix itself (hopefully)
			waitfor delay @RETRY_DELAY

			-- Make sure connection is re-established
			--print('Attempting to locate file ' + @uncPath + '\' + @sourceTable + '.dbf... (attempt ' + cast(@attempts-1 as varchar(1000)) + ' of ' + cast(@MAX_RETRIES as varchar(1000)) + ')')
			set @command = 'net use ' + @uncPath + isnull(' /user:' + @dbUser + ' ' + @dbPassword, '') + ' && dir ' + @uncPath + '\' + @sourceTable + '.dbf'
			exec @exitCode = master..xp_cmdshell @command, no_output
			if (@exitCode <> 0)
			begin
				--print 'File not found'
				goto TRYAGAIN
			end
			--print('File found')
		end

		-- Copy the source data file to the local directory. 
		-- Don't use XCOPY since XCOPY file.* when no file exists. 
--		--print('uncPath: ' + @uncPath)
--		--print('destDir: ' + @destDir)
	
		-- Copy index files first. These files are not always present so ignore exitCode
		set @command = 'COPY /Y ' + @uncPath + '\' + @sourceTable + '.mdx '+ @destDir
		--print(@command)
		exec master..xp_cmdshell @command, no_output

		set @command = 'COPY /Y ' + @uncPath + '\' + @sourceTable + '.dbt '+ @destDir
		--print(@command)
		exec master..xp_cmdshell @command, no_output

		-- Copy data file second and check exitCode
		exec @exitCode = master..xp_cmdshell @command, no_output
		set @command = 'COPY /Y ' + @uncPath + '\' + @sourceTable + '.dbf '+ @destDir
		--print(@command)
		exec @exitCode = master..xp_cmdshell @command, no_output
	END

	if (@exitCode <> 0)
	begin		
		select 1
	end
	else
		select 0
END
