IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[VC3ETL].[DBaseDBProvider_EnsureLinkedServerFolderExists]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [VC3ETL].[DBaseDBProvider_EnsureLinkedServerFolderExists]
GO

CREATE PROCEDURE VC3ETL.DBaseDBProvider_EnsureLinkedServerFolderExists
	@extractDatabase uniqueidentifier,
	@testFilename	   varchar(100) = null
AS
BEGIN
	declare
		@destDir varchar(256), 		/* The local folder that will contain the table files */
		@command varchar (4000), 	/* Dos command to be executed to set up UNC path, etc */
		@exitCode int,
		@linkedServer varchar (16), /* Linked server name, eg. 'L2' */
		@dbServer varchar (64), 	/* The name of the database server */
		@attempts int,	
		@dbName varchar (128), 		/* The name of the database */
		@uncPath varchar (128), 	/* The unc path pointing to the data files directory */
		@dbUser varchar (32), 
		@dbPassword varchar (32)

	declare @MAX_RETRIES int
	set @MAX_RETRIES = 4

	declare @RETRY_DELAY varchar(100)
	set @RETRY_DELAY = '00:00:05' -- 5 second

SELECT
		@linkedServer 		= LinkedServer,
		@dbServer			= Server,
		@dbName				= isnull(DatabaseName, '')	,
		@dbUser				= isnull(Username, ''),
		@dbPassword			= isnull(Password, '')
FROM	
	VC3ETL.ExtractDatabase d 
where 
	d.ID = @extractDatabase

	-- determine the path to the local dbase directory
	-- Use a sub directory relative to the TestView database
	set @destDir = '"' + dbo.DbDirectory() + @linkedServer + '"'

	if @destdir is null
	begin
		raiserror('Couldn''t determine path of the application database. Make sure the file ends in .mdf', 16, 1)
		return 1
	end

	set @command = 'if not exist ' + @destDir + ' (mkdir ' + @destDir + ')'
	exec @exitCode = master..xp_cmdshell @command, no_output	
	if (@exitCode <> 0)
	begin
		raiserror('Couldn''t create directory %s. Create it manually if needed. Command: %s', 16, 1, @destDir, @command)
		return 1
	end

	IF (@testFilename is not null)
	BEGIN
			set @uncPath = @dbServer + @dbName
			set @exitCode = 1
			set @attempts = 0

			while @exitCode <> 0 AND @attempts <= @MAX_RETRIES
			BEGIN
				set @attempts = @attempts + 1

				-- If this is a retry attempt pause for a moment to let the situation fix itself (hopefully)
				if @attempts > 1
					waitfor delay @RETRY_DELAY
		
				-- Connect
				print('Connecting to ' + @uncPath + '...')
				set @command = 'net use ' + @uncPath + isnull(' /user:' + @dbUser + ' ' + @dbPassword, '') + ' && dir ' + @uncPath + '\' + @testFilename + '.dbf'
				exec @exitCode = master..xp_cmdshell @command, no_output
			END

			if (@exitCode <> 0)
			begin
				raiserror('Couldn''t access %s', 16, 1, @uncPath)
				return 1
			end

			print('Connection successful')
	END
END