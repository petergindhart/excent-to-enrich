IF EXISTS(
	SELECT * 
	FROM SYSOBJECTS 
	WHERE ID = OBJECT_ID('VC3ETL.ExtractDatabaseTrigger_InsertRecord') AND
	TYPE = 'P')
DROP PROCEDURE VC3ETL.ExtractDatabaseTrigger_InsertRecord
GO

/*
<summary>
Inserts a new record into the ExtractDatabaseTrigger table with the specified values
</summary>
<param name="typeId">Value to assign to the TypeID field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<param name="enabled">Value to assign to the Enabled field of the record</param>
<param name="sequence">Value to assign to the Sequence field of the record</param>
<param name="destTable">Value to assign to the DestTable field of the record</param>
<param name="sqlProcedureName">Value to assign to the SQLProcedureName field of the record</param>
<param name="typeName">Value to assign to the TypeName field of the record</param>
<param name="succeededMessage">Value to assign to the SucceededMessage field of the record</param>
<param name="failedMessage">Value to assign to the FailedMessage field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE VC3ETL.ExtractDatabaseTrigger_InsertRecord	
	@typeId char(1), 
	@name varchar(100), 
	@enabled bit, 
	@sequence int, 
	@destTable varchar(100), 
	@sqlProcedureName varchar(1000), 
	@typeName varchar(1000), 
	@succeededMessage varchar(2000), 
	@failedMessage varchar(2000)
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
	
	INSERT INTO ExtractDatabaseTrigger
	(
		Id, 
		TypeId, 
		Name, 
		Enabled, 
		Sequence, 
		DestTable, 
		SqlProcedureName, 
		TypeName, 
		SucceededMessage, 
		FailedMessage
	)
	VALUES
	(
		@id, 
		@typeId, 
		@name, 
		@enabled, 
		@sequence, 
		@destTable, 
		@sqlProcedureName, 
		@typeName, 
		@succeededMessage, 
		@failedMessage
	)

	SELECT @id
GO

