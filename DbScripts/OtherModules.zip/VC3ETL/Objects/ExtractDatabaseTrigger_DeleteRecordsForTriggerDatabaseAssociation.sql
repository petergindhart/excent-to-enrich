IF (NOT EXISTS(SELECT * FROM systypes WHERE name = 'uniqueidentifierarray'))
	EXEC sp_addtype 'uniqueidentifierarray', 'text', 'NULL' 
GO

declare @sql varchar(8000)

IF (NOT EXISTS(SELECT * FROM sysobjects WHERE name = 'CharIndexText' AND xtype = 'FN'))
begin
	set @sql = 
		'Create FUNCTION dbo.CharIndexText(@search char, @idArray text, @start int )  
			RETURNS int AS  
		BEGIN
			declare @ret int

			if datalength(@idArray) <= 8000
			begin
				-- Use real charindex if possible
				set @ret = charindex(@search, @idArray, @start)
			end
			else if @idArray is null or @search is null
			begin
				set @ret = null
			end
			else
			begin
				-- search string manually
				set @ret = @start

				while substring(@idArray, @ret, 1) <> @search and @ret <= datalength(@idArray)
				begin
					set @ret = @ret + 1
				end

				if @ret > datalength(@idArray)
					set @ret = 0
			end

			return @ret
		end'
	
	exec(@sql)
end


IF (NOT EXISTS(SELECT * FROM sysobjects WHERE name = 'GetUniqueidentifiers' AND xtype = 'TF'))
begin
	set @sql = 
		'CREATE FUNCTION dbo.GetUniqueidentifiers (@idArray uniqueidentifierarray)  
			RETURNS @idTable table(id uniqueidentifier) AS  
		BEGIN 
			if (@idArray is null)
				return

			declare @start int
			declare @finish int

			set @start = 1
			set @finish = dbo.CharIndexText(''|'', @idArray, @start)

			while @finish > 0
			begin
				insert into @idTable
				values (cast(substring(@idArray, @start, @finish-@start) as uniqueidentifier))
				set @start = @finish + 1
				set @finish = dbo.CharIndexText(''|'', @idArray, @start)
			end

			insert into @idTable
			values (cast(substring(@idArray, @start, datalength(@idArray)-@start+1) as uniqueidentifier))

			return 
		END'
	exec(@sql)
end


IF EXISTS(
	SELECT * 
	FROM SYSOBJECTS 
	WHERE ID = OBJECT_ID('VC3ETL.ExtractDatabaseTrigger_DeleteRecordsForTriggerDatabaseAssociation') AND
	TYPE = 'P')
DROP PROCEDURE VC3ETL.ExtractDatabaseTrigger_DeleteRecordsForTriggerDatabaseAssociation
GO

/*
<summary>
Deletes records from the TriggerDatabase table for the specified ids 
</summary>
<param name="databaseId">The id of the associated ExtractDatabase</param>
<param name="ids">The ids of the ExtractDatabaseTrigger's to delete</param>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE VC3ETL.ExtractDatabaseTrigger_DeleteRecordsForTriggerDatabaseAssociation
	@databaseId uniqueidentifier, 
	@ids uniqueidentifierarray
AS
	DELETE TriggerDatabase
	FROM 
		TriggerDatabase ab INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON ab.TriggerId = Keys.Id
	WHERE
		ab.DatabaseId = @databaseId
GO
