SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3ETL].[ExtractIssue_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3ETL].[ExtractIssue_InsertRecord]
GO

 /*
<summary>
Inserts a new record into the ExtractIssue table with the specified values
</summary>
<param name="validator">Value to assign to the Validator field of the record</param>
<param name="canOverride">Value to assign to the CanOverride field of the record</param>
<param name="description">Value to assign to the Description field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE VC3ETL.ExtractIssue_InsertRecord	
	@validator uniqueidentifier, 
	@canOverride bit, 
	@description varchar(2000)
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
	
	INSERT INTO ExtractIssue
	(
		Id, 
		Validator, 
		CanOverride, 
		Description
	)
	VALUES
	(
		@id, 
		@validator, 
		@canOverride, 
		@description
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

