IF EXISTS(
	SELECT * 
	FROM SYSOBJECTS 
	WHERE ID = OBJECT_ID('VC3ETL.ExtractDatabaseTriggerType_DeleteRecord') AND
	TYPE = 'P')
DROP PROCEDURE VC3ETL.ExtractDatabaseTriggerType_DeleteRecord
GO

/*
<summary>
Deletes a ExtractDatabaseTriggerType record
</summary>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE VC3ETL.ExtractDatabaseTriggerType_DeleteRecord
	@id char(1)
AS
	DELETE FROM 
		ExtractDatabaseTriggerType
	WHERE
		Id = @id

GO
