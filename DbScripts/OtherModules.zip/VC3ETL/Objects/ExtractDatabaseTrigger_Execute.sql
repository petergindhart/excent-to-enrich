if exists (select * from dbo.sysobjects where id = object_id(N'[VC3ETL].[ExtractDatabaseTrigger_Execute]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3ETL].[ExtractDatabaseTrigger_Execute]
GO

CREATE PROCEDURE VC3ETL.ExtractDatabaseTrigger_Execute 
(
	@trigger uniqueidentifier, 
	@ConstantsSql varchar(1000)
)
AS

DECLARE
	@crlf varchar(2),
	@sql varchar(8000)

SET @crlf = char(13) + char(10)

SELECT
	@sql = IsNull(@ConstantsSql + @crlf,'') + ' exec ' + SqlProcedureName
FROM
	VC3ETL.ExtractDatabaseTrigger
where
	ID = @trigger
	
exec(@sql)