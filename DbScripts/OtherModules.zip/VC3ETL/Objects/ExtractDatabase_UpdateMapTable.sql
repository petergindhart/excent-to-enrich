IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[VC3ETL].[ExtractDatabase_UpdateMapTable]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [VC3ETL].[ExtractDatabase_UpdateMapTable]
GO

 /*
<summary>
Updates the records for the mapTable for a destination table
</summary>

<returns></returns>

<model  isGenerated="false" />
*/
CREATE PROCEDURE [VC3ETL].[ExtractDatabase_UpdateMapTable] 
	@extractDatabaseID			uniqueidentifier,
	@destinationTableName 		varchar(100),
	@newID						uniqueidentifier,
	@ids						uniqueidentifierarray
AS

DECLARE 
	@sql varchar(8000),
	@mapTableName varchar(100),
	@mapTableKeyField varchar(100)
	
SELECT
	@mapTableName = MapTable,
	@mapTableKeyField = DeleteKey
FROM
	VC3ETL.LoadTable
WHERE
	ExtractDatabase = @extractDatabaseID AND
	HasMapTable = 1 and
	DestTable = @destinationTableName
	
SELECT
@sql = ISNULL(@sql,'') + 
'
UPDATE ' + @mapTableName + ' 
SET ' + @mapTableKeyField + ' = ''' + cast(@newID as varchar(36)) + ''' 
WHERE ' + @mapTableKeyField + ' = ''' + CAST(Keys.ID as varchar(36)) + '''

'
FROM
	GetUniqueidentifiers(@ids) Keys
	
exec(@sql)
