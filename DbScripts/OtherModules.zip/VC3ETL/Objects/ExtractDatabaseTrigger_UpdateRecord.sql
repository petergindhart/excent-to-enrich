IF EXISTS(
	SELECT * 
	FROM SYSOBJECTS 
	WHERE ID = OBJECT_ID('VC3ETL.ExtractDatabaseTrigger_UpdateRecord') AND
	TYPE = 'P')
DROP PROCEDURE VC3ETL.ExtractDatabaseTrigger_UpdateRecord
GO

/*
<summary>
Updates a record in the ExtractDatabaseTrigger table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="typeId">Value to assign to the TypeID field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<param name="enabled">Value to assign to the Enabled field of the record</param>
<param name="sequence">Value to assign to the Sequence field of the record</param>
<param name="destTable">Value to assign to the DestTable field of the record</param>
<param name="sqlProcedureName">Value to assign to the SQLProcedureName field of the record</param>
<param name="typeName">Value to assign to the TypeName field of the record</param>
<param name="succeededMessage">Value to assign to the SucceededMessage field of the record</param>
<param name="failedMessage">Value to assign to the FailedMessage field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE VC3ETL.ExtractDatabaseTrigger_UpdateRecord
	@id uniqueidentifier, 
	@typeId char(1), 
	@name varchar(100), 
	@enabled bit, 
	@sequence int, 
	@destTable varchar(100), 
	@sqlProcedureName varchar(1000), 
	@typeName varchar(1000), 
	@succeededMessage varchar(2000), 
	@failedMessage varchar(2000)
AS
	UPDATE ExtractDatabaseTrigger
	SET
		TypeID = @typeId, 
		Name = @name, 
		Enabled = @enabled, 
		Sequence = @sequence, 
		DestTable = @destTable, 
		SQLProcedureName = @sqlProcedureName, 
		TypeName = @typeName, 
		SucceededMessage = @succeededMessage, 
		FailedMessage = @failedMessage
	WHERE 
		ID = @id
GO

