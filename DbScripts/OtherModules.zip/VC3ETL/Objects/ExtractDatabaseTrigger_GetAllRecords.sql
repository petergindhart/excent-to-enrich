IF EXISTS(
	SELECT * 
	FROM SYSOBJECTS 
	WHERE ID = OBJECT_ID('VC3ETL.ExtractDatabaseTrigger_GetAllRecords') AND
	TYPE = 'P')
DROP PROCEDURE VC3ETL.ExtractDatabaseTrigger_GetAllRecords
GO

/*
<summary>
Gets all records from the ExtractDatabaseTrigger table
</summary>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE VC3ETL.ExtractDatabaseTrigger_GetAllRecords
AS
	SELECT
		e.*
	FROM
		ExtractDatabaseTrigger e

GO

