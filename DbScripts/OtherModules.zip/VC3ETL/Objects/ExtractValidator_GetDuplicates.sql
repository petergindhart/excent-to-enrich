IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[VC3ETL].[ExtractValidator_GetDuplicates]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [VC3ETL].[ExtractValidator_GetDuplicates]
GO

 /*
<summary>
Returns a dump of all duplicate values based upon a validator
</summary>

<returns>List of duplicate values</returns>

<model  isGenerated="false" 
        returnType="System.Data.IDataReader" 
        />
*/
CREATE PROCEDURE [VC3ETL].[ExtractValidator_GetDuplicates] 
	@extractTable uniqueidentifier,
	@uniqueColumns varchar(8000)
AS

-- Fetch view name
DECLARE @viewName varchar(300)

SELECT @viewName = DestTable 
FROM VC3ETL.ExtractTable
WHERE ID = @extractTable

-- Create dynamic parts of the final statement
DECLARE @dynSql VARCHAR(8000)
DECLARE @columnName VARCHAR(200)

DECLARE itemCursor CURSOR FOR 
select Item from split(@uniqueColumns, ',')

OPEN itemCursor

DECLARE @dynJoin VARCHAR(2000)
SET @dynJoin = ' '

DECLARE @dynOrderBy VARCHAR(2000)
SET @dynOrderBy = ' '

FETCH NEXT FROM itemCursor INTO @columnName
WHILE @@FETCH_STATUS = 0
BEGIN
	SET @dynJoin = @dynJoin + ' AND a.' + @columnName + ' = b.' + @columnName
	SET @dynOrderBy = @dynOrderBy + ' a.' + @columnName + ','
	FETCH NEXT FROM itemCursor INTO @columnName
END

CLOSE itemCursor
DEALLOCATE itemCursor

-- Generate final sql
SET @dynSql =	'select a.* 
		from ' + @viewName + ' a,
		(select  ' + @uniqueColumns + '
		from ' + @viewName + '
		group by ' + @uniqueColumns + '
		having count(*) > 1) b 
		where 1 = 1 ' + @dynJoin + '
		order by ' + left(@dynOrderBy, len(@dynOrderBy) - 1)

exec(@dynSql)