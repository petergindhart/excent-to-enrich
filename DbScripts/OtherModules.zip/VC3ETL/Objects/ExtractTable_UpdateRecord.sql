IF EXISTS(
	SELECT * 
	FROM SYSOBJECTS 
	WHERE ID = OBJECT_ID('VC3ETL.ExtractTable_UpdateRecord') AND
	TYPE = 'P')
DROP PROCEDURE VC3ETL.ExtractTable_UpdateRecord
GO

/*
<summary>
Updates a record in the ExtractTable table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="extractDatabase">Value to assign to the ExtractDatabase field of the record</param>
<param name="sourceTable">Value to assign to the SourceTable field of the record</param>
<param name="destSchema">Value to assign to the DestSchema field of the record</param>
<param name="destTable">Value to assign to the DestTable field of the record</param>
<param name="primaryKey">Value to assign to the PrimaryKey field of the record</param>
<param name="indexes">Value to assign to the Indexes field of the record</param>
<param name="lastSuccessfulCount">Value to assign to the LastSuccessfulCount field of the record</param>
<param name="currentCount">Value to assign to the CurrentCount field of the record</param>
<param name="filter">Value to assign to the Filter field of the record</param>
<param name="enabled">Value to assign to the Enabled field of the record</param>
<param name="ignoreMissing">Value to assign to the IgnoreMissing field of the record</param>
<param name="columns">Value to assign to the Columns field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE VC3ETL.ExtractTable_UpdateRecord
	@id uniqueidentifier, 
	@extractDatabase uniqueidentifier, 
	@sourceTable varchar(100), 
	@destSchema varchar(50), 
	@destTable varchar(50), 
	@primaryKey varchar(100), 
	@indexes varchar(200), 
	@lastSuccessfulCount int, 
	@currentCount int, 
	@filter varchar(1000), 
	@enabled bit, 
	@ignoreMissing bit, 
	@columns varchar(8000)
AS
	UPDATE ExtractTable
	SET
		ExtractDatabase = @extractDatabase, 
		SourceTable = @sourceTable, 
		DestSchema = @destSchema, 
		DestTable = @destTable, 
		PrimaryKey = @primaryKey, 
		Indexes = @indexes, 
		LastSuccessfulCount = @lastSuccessfulCount, 
		CurrentCount = @currentCount, 
		Filter = @filter, 
		Enabled = @enabled, 
		IgnoreMissing = @ignoreMissing, 
		Columns = @columns
	WHERE 
		ID = @id
GO

