IF EXISTS(
	SELECT * 
	FROM SYSOBJECTS 
	WHERE ID = OBJECT_ID('VC3ETL.ExtractDatabase_InsertRecord') AND
	TYPE = 'P')
DROP PROCEDURE VC3ETL.ExtractDatabase_InsertRecord
GO

/*
<summary>
Inserts a new record into the ExtractDatabase table with the specified values
</summary>
<param name="type">Value to assign to the Type field of the record</param>
<param name="databaseType">Value to assign to the DatabaseType field of the record</param>
<param name="server">Value to assign to the Server field of the record</param>
<param name="databaseOwner">Value to assign to the DatabaseOwner field of the record</param>
<param name="databaseName">Value to assign to the DatabaseName field of the record</param>
<param name="username">Value to assign to the Username field of the record</param>
<param name="password">Value to assign to the Password field of the record</param>
<param name="linkedServer">Value to assign to the LinkedServer field of the record</param>
<param name="isLinkedServerManaged">Value to assign to the IsLinkedServerManaged field of the record</param>
<param name="lastExtractDate">Value to assign to the LastExtractDate field of the record</param>
<param name="lastLoadDate">Value to assign to the LastLoadDate field of the record</param>
<param name="succeededEmail">Value to assign to the SucceededEmail field of the record</param>
<param name="succeededSubject">Value to assign to the SucceededSubject field of the record</param>
<param name="succeededMessage">Value to assign to the SucceededMessage field of the record</param>
<param name="failedEmail">Value to assign to the FailedEmail field of the record</param>
<param name="failedSubject">Value to assign to the FailedSubject field of the record</param>
<param name="failedMessage">Value to assign to the FailedMessage field of the record</param>
<param name="retainSnapshot">Value to assign to the RetainSnapshot field of the record</param>
<param name="destTableTempSuffix">Value to assign to the DestTableTempSuffix field of the record</param>
<param name="destTableFinalSuffix">Value to assign to the DestTableFinalSuffix field of the record</param>
<param name="fileGroup">Value to assign to the FileGroup field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="False" returnType="System.Guid" />
*/
CREATE PROCEDURE VC3ETL.ExtractDatabase_InsertRecord	
	@type uniqueidentifier, 
	@databaseType uniqueidentifier, 
	@server varchar(64), 
	@databaseOwner varchar(64), 
	@databaseName varchar(128), 
	@username varchar(32), 
	@password varchar(32), 
	@linkedServer varchar(16), 
	@isLinkedServerManaged bit, 
	@lastExtractDate datetime, 
	@lastLoadDate datetime, 
	@succeededEmail varchar(500), 
	@succeededSubject text, 
	@succeededMessage text, 
	@failedEmail varchar(500), 
	@failedSubject text, 
	@failedMessage text, 
	@retainSnapshot bit, 
	@destTableTempSuffix varchar(30), 
	@destTableFinalSuffix varchar(30), 
	@fileGroup varchar(64),
	@schedule uniqueidentifier,
	@name	varchar(100),
	@enabled	bit
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
	
	INSERT INTO ExtractDatabase
	(
		Id, 
		Type, 
		DatabaseType, 
		Server, 
		DatabaseOwner, 
		DatabaseName, 
		Username, 
		Password, 
		LinkedServer, 
		IsLinkedServerManaged, 
		LastExtractDate, 
		LastLoadDate, 
		SucceededEmail, 
		SucceededSubject, 
		SucceededMessage, 
		FailedEmail, 
		FailedSubject, 
		FailedMessage, 
		RetainSnapshot, 
		DestTableTempSuffix, 
		DestTableFinalSuffix, 
		FileGroup,
		Schedule,
		Name,
		Enabled
	)
	VALUES
	(
		@id, 
		@type, 
		@databaseType, 
		@server, 
		@databaseOwner, 
		@databaseName, 
		@username, 
		@password, 
		@linkedServer, 
		@isLinkedServerManaged, 
		@lastExtractDate, 
		@lastLoadDate, 
		@succeededEmail, 
		@succeededSubject, 
		@succeededMessage, 
		@failedEmail, 
		@failedSubject, 
		@failedMessage, 
		@retainSnapshot, 
		@destTableTempSuffix, 
		@destTableFinalSuffix, 
		@fileGroup,
		@schedule,
		@Name,
		@Enabled
	)

	SELECT @id
GO

