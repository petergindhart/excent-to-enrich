SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3ETL].[ExtractDatabase_GetRecordsByType]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3ETL].[ExtractDatabase_GetRecordsByType]
GO

 /*
<summary>
Gets records from the ExtractDatabase table
with the specified ids
</summary>
<param name="ids">Ids of the ExtractType(s) to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE VC3ETL.ExtractDatabase_GetRecordsByType
	@ids	uniqueidentifierarray
AS
	SELECT
		e.Type,
		e.*
	FROM
		ExtractDatabase e INNER JOIN
		GetUniqueidentifiers(@ids) Keys ON e.Type = Keys.Id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

