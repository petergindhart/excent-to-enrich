IF EXISTS(
	SELECT * 
	FROM SYSOBJECTS 
	WHERE ID = OBJECT_ID('VC3ETL.ExtractDatabaseTrigger_DeleteRecord') AND
	TYPE = 'P')
DROP PROCEDURE VC3ETL.ExtractDatabaseTrigger_DeleteRecord
GO

/*
<summary>
Deletes a ExtractDatabaseTrigger record
</summary>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE VC3ETL.ExtractDatabaseTrigger_DeleteRecord
	@id uniqueidentifier
AS
	DELETE FROM 
		ExtractDatabaseTrigger
	WHERE
		Id = @id

GO
