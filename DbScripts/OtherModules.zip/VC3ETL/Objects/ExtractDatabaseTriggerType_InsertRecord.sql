IF EXISTS(
	SELECT * 
	FROM SYSOBJECTS 
	WHERE ID = OBJECT_ID('VC3ETL.ExtractDatabaseTriggerType_InsertRecord') AND
	TYPE = 'P')
DROP PROCEDURE VC3ETL.ExtractDatabaseTriggerType_InsertRecord
GO

/*
<summary>
Inserts a new record into the ExtractDatabaseTriggerType table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE VC3ETL.ExtractDatabaseTriggerType_InsertRecord
	@id char(1), 
	@name varchar(100)
AS
	INSERT INTO ExtractDatabaseTriggerType
	(
		Id, 
		Name
	)
	VALUES
	(
		@id, 
		@name
	)

GO

