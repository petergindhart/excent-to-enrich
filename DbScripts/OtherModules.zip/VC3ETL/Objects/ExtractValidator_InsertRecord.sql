SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3ETL].[ExtractValidator_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3ETL].[ExtractValidator_InsertRecord]
GO

 /*
<summary>
Inserts a new record into the ExtractValidator table with the specified values
</summary>
<param name="type">Value to assign to the Type field of the record</param>
<param name="extractTable">Value to assign to the ExtractTable field of the record</param>
<param name="enabled">Value to assign to the Enabled field of the record</param>
<param name="minPercentChange">Value to assign to the MinPercentChange field of the record</param>
<param name="maxPercentChange">Value to assign to the MaxPercentChange field of the record</param>
<param name="columns">Value to assign to the Columns field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="False" returnType="System.Guid" />
*/
CREATE PROCEDURE VC3ETL.ExtractValidator_InsertRecord	
	@type uniqueidentifier, 
	@extractTable uniqueidentifier, 
	@enabled bit, 
	@minPercentChange decimal(7, 4), 
	@maxPercentChange decimal(7, 4), 
	@columns varchar(100)
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
	
	INSERT INTO ExtractValidator
	(
		Id, 
		Type, 
		ExtractTable, 
		Enabled, 
		MinPercentChange, 
		MaxPercentChange, 
		Columns
	)
	VALUES
	(
		@id, 
		@type, 
		@extractTable, 
		@enabled, 
		@minPercentChange, 
		@maxPercentChange, 
		@columns
	)

	SELECT @id
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

