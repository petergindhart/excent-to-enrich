IF (NOT EXISTS(SELECT * FROM systypes WHERE name = 'uniqueidentifierarray'))
	EXEC sp_addtype 'uniqueidentifierarray', 'text', 'NULL' 
GO

declare @sql varchar(8000)

IF (NOT EXISTS(SELECT * FROM sysobjects WHERE name = 'CharIndexText' AND xtype = 'FN'))
begin
	set @sql = 
		'Create FUNCTION dbo.CharIndexText(@search char, @idArray text, @start int )  
			RETURNS int AS  
		BEGIN
			declare @ret int

			if datalength(@idArray) <= 8000
			begin
				-- Use real charindex if possible
				set @ret = charindex(@search, @idArray, @start)
			end
			else if @idArray is null or @search is null
			begin
				set @ret = null
			end
			else
			begin
				-- search string manually
				set @ret = @start

				while substring(@idArray, @ret, 1) <> @search and @ret <= datalength(@idArray)
				begin
					set @ret = @ret + 1
				end

				if @ret > datalength(@idArray)
					set @ret = 0
			end

			return @ret
		end'
	
	exec(@sql)
end


IF (NOT EXISTS(SELECT * FROM sysobjects WHERE name = 'GetUniqueidentifiers' AND xtype = 'TF'))
begin
	set @sql = 
		'CREATE FUNCTION dbo.GetUniqueidentifiers (@idArray uniqueidentifierarray)  
			RETURNS @idTable table(id uniqueidentifier) AS  
		BEGIN 
			if (@idArray is null)
				return

			declare @start int
			declare @finish int

			set @start = 1
			set @finish = dbo.CharIndexText(''|'', @idArray, @start)

			while @finish > 0
			begin
				insert into @idTable
				values (cast(substring(@idArray, @start, @finish-@start) as uniqueidentifier))
				set @start = @finish + 1
				set @finish = dbo.CharIndexText(''|'', @idArray, @start)
			end

			insert into @idTable
			values (cast(substring(@idArray, @start, datalength(@idArray)-@start+1) as uniqueidentifier))

			return 
		END'
	exec(@sql)
end


IF EXISTS(
	SELECT * 
	FROM SYSOBJECTS 
	WHERE ID = OBJECT_ID('VC3ETL.ExtractDatabaseTrigger_GetRecordsByType') AND
	TYPE = 'P')
DROP PROCEDURE VC3ETL.ExtractDatabaseTrigger_GetRecordsByType
GO

/*
<summary>
Gets records from the ExtractDatabaseTrigger table
with the specified ids
</summary>
<param name="ids">Ids of the ExtractDatabaseTriggerType(s) to retrieve</param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE VC3ETL.ExtractDatabaseTrigger_GetRecordsByType
	@ids	chararray
AS
	SELECT
		e.TypeId,
		e.*
	FROM
		ExtractDatabaseTrigger e INNER JOIN
		GetChars(@ids) Keys ON e.TypeId = Keys.Id

GO

