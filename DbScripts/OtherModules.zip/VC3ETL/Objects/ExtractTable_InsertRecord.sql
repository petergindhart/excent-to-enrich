IF EXISTS(
	SELECT * 
	FROM SYSOBJECTS 
	WHERE ID = OBJECT_ID('VC3ETL.ExtractTable_InsertRecord') AND
	TYPE = 'P')
DROP PROCEDURE VC3ETL.ExtractTable_InsertRecord
GO

/*
<summary>
Inserts a new record into the ExtractTable table with the specified values
</summary>
<param name="extractDatabase">Value to assign to the ExtractDatabase field of the record</param>
<param name="sourceTable">Value to assign to the SourceTable field of the record</param>
<param name="destSchema">Value to assign to the DestSchema field of the record</param>
<param name="destTable">Value to assign to the DestTable field of the record</param>
<param name="primaryKey">Value to assign to the PrimaryKey field of the record</param>
<param name="indexes">Value to assign to the Indexes field of the record</param>
<param name="lastSuccessfulCount">Value to assign to the LastSuccessfulCount field of the record</param>
<param name="currentCount">Value to assign to the CurrentCount field of the record</param>
<param name="filter">Value to assign to the Filter field of the record</param>
<param name="enabled">Value to assign to the Enabled field of the record</param>
<param name="ignoreMissing">Value to assign to the IgnoreMissing field of the record</param>
<param name="columns">Value to assign to the Columns field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE VC3ETL.ExtractTable_InsertRecord	
	@extractDatabase uniqueidentifier, 
	@sourceTable varchar(50), 
	@destSchema varchar(50), 
	@destTable varchar(50), 
	@primaryKey varchar(100), 
	@indexes varchar(200), 
	@lastSuccessfulCount int, 
	@currentCount int, 
	@filter varchar(1000), 
	@enabled bit, 
	@ignoreMissing bit, 
	@columns varchar(8000)
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
	
	INSERT INTO ExtractTable
	(
		Id, 
		ExtractDatabase, 
		SourceTable, 
		DestSchema, 
		DestTable, 
		PrimaryKey, 
		Indexes, 
		LastSuccessfulCount, 
		CurrentCount, 
		Filter, 
		Enabled, 
		IgnoreMissing, 
		Columns
	)
	VALUES
	(
		@id, 
		@extractDatabase, 
		@sourceTable, 
		@destSchema, 
		@destTable, 
		@primaryKey, 
		@indexes, 
		@lastSuccessfulCount, 
		@currentCount, 
		@filter, 
		@enabled, 
		@ignoreMissing, 
		@columns
	)

	SELECT @id
GO

