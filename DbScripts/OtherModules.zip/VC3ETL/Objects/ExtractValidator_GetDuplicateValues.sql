SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3ETL].[ExtractValidator_GetDuplicateValues]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3ETL].[ExtractValidator_GetDuplicateValues]
GO


/*
<summary>
Verifies that the columns specified do not have duplicate values
</summary>

<returns>List of Validation issues</returns>

<model  isGenerated="false" 
        returnType="System.Data.IDataReader" 
        />
*/
CREATE PROCEDURE [VC3ETL].[ExtractValidator_GetDuplicateValues] 
	@extractTable	uniqueidentifier,
	@columns		varchar(8000)
AS
	declare @destination varchar(300)

	select @destination = isnull(DestSchema + '.','') + DestTable
	from ExtractTable
	where Id = @extractTable

	declare @sql varchar(8000)
	set @sql = 
		'select count(*) DupCount, ' + @columns + '
		from ' + @destination + '
		group by ' + @columns + '
		having count(*) > 1'

	exec(@sql)

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

