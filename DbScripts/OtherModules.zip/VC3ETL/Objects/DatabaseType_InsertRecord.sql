IF EXISTS(
	SELECT * 
	FROM SYSOBJECTS 
	WHERE ID = OBJECT_ID('VC3ETL.DatabaseType_InsertRecord') AND
	TYPE = 'P')
DROP PROCEDURE VC3ETL.DatabaseType_InsertRecord
GO

/*
<summary>
Inserts a new record into the DatabaseType table with the specified values
</summary>
<param name="name">Value to assign to the Name field of the record</param>
<param name="dbProvider">Value to assign to the DBProvider field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE VC3ETL.DatabaseType_InsertRecord	
	@name varchar(50), 
	@dbProvider varchar(256)
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
	
	INSERT INTO DatabaseType
	(
		Id, 
		Name, 
		DbProvider
	)
	VALUES
	(
		@id, 
		@name, 
		@dbProvider
	)

	SELECT @id
GO

