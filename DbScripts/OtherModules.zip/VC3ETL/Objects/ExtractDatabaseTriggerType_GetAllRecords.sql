IF EXISTS(
	SELECT * 
	FROM SYSOBJECTS 
	WHERE ID = OBJECT_ID('VC3ETL.ExtractDatabaseTriggerType_GetAllRecords') AND
	TYPE = 'P')
DROP PROCEDURE VC3ETL.ExtractDatabaseTriggerType_GetAllRecords
GO

/*
<summary>
Gets all records from the ExtractDatabaseTriggerType table
</summary>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="True" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE VC3ETL.ExtractDatabaseTriggerType_GetAllRecords
AS
	SELECT
		e.*
	FROM
		ExtractDatabaseTriggerType e

GO

