IF EXISTS(
	SELECT * 
	FROM SYSOBJECTS 
	WHERE ID = OBJECT_ID('VC3ETL.ExtractDatabaseTriggerType_UpdateRecord') AND
	TYPE = 'P')
DROP PROCEDURE VC3ETL.ExtractDatabaseTriggerType_UpdateRecord
GO

/*
<summary>
Updates a record in the ExtractDatabaseTriggerType table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE VC3ETL.ExtractDatabaseTriggerType_UpdateRecord
	@id char(1), 
	@name varchar(100)
AS
	UPDATE ExtractDatabaseTriggerType
	SET
		Name = @name
	WHERE 
		ID = @id
GO

