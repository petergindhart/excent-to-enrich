SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3ETL].[ExtractTable_GetAllRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3ETL].[ExtractTable_GetAllRecords]
GO


 /*
<summary>
Gets all records from the ExtractTable table
</summary>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="False" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE [VC3ETL].[ExtractTable_GetAllRecords]
AS
	SELECT
		e.*,
		db.Type
	FROM
		ExtractTable e
		INNER JOIN ExtractDatabase db on e.ExtractDatabase = db.Id


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

