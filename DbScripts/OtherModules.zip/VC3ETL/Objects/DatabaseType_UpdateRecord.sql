IF EXISTS(
	SELECT * 
	FROM SYSOBJECTS 
	WHERE ID = OBJECT_ID('VC3ETL.DatabaseType_UpdateRecord') AND
	TYPE = 'P')
DROP PROCEDURE VC3ETL.DatabaseType_UpdateRecord
GO

/*
<summary>
Updates a record in the DatabaseType table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<param name="dbProvider">Value to assign to the DBProvider field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE VC3ETL.DatabaseType_UpdateRecord
	@id uniqueidentifier, 
	@name varchar(50), 
	@dbProvider varchar(256)
AS
	UPDATE DatabaseType
	SET
		Name = @name, 
		DBProvider = @dbProvider
	WHERE 
		ID = @id
GO

