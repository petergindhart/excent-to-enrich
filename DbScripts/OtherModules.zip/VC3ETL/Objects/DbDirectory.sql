SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DbDirectory]') and xtype in (N'FN', N'IF', N'TF'))
drop function [dbo].[DbDirectory]
GO


CREATE FUNCTION dbo.DbDirectory()
RETURNS nvarchar(4000)
AS
BEGIN
	declare @dir nvarchar(4000)
	-- determine the path to the local dbase directory
	-- Use a sub directory relative to the TestView database
	select @dir = reverse(substring(reverse(rtrim(filename)), charindex('\', reverse(rtrim(filename)), 1), 4000 ))
	from sysfiles 
	where rtrim(filename) like '%.mdf'

	return @dir
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

