--if the database has an existing [dbo].[ScheduledTask] table 
--assume the task tables already exist and transfer the schema, else
--create new tables
IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ScheduledTask]') AND type in (N'U'))
BEGIN

	if @@version like 'Microsoft SQL Server  2000%'
	begin
		exec sp_changeobjectowner 'dbo.ScheduledTask', 'VC3TaskScheduler'
		exec sp_changeobjectowner 'dbo.ScheduledTaskSchedule', 'VC3TaskScheduler'
		exec sp_changeobjectowner 'dbo.ScheduledTaskScheduleFrequency', 'VC3TaskScheduler'
		exec sp_changeobjectowner 'dbo.ScheduledTaskStatus', 'VC3TaskScheduler'
		exec sp_changeobjectowner 'dbo.ScheduledTaskType', 'VC3TaskScheduler'
	end
	else
	begin
		--alter existing table
		exec('ALTER SCHEMA VC3TaskScheduler TRANSFER dbo.ScheduledTask')
		exec('ALTER SCHEMA VC3TaskScheduler TRANSFER dbo.ScheduledTaskSchedule')
		exec('ALTER SCHEMA VC3TaskScheduler TRANSFER dbo.ScheduledTaskScheduleFrequency')
		exec('ALTER SCHEMA VC3TaskScheduler TRANSFER dbo.ScheduledTaskStatus')
		exec('ALTER SCHEMA VC3TaskScheduler TRANSFER dbo.ScheduledTaskType')
	end
	
END
ELSE
BEGIN

	--create new tables
	CREATE TABLE [VC3TaskScheduler].[ScheduledTask] (
	[ID]  uniqueidentifier ROWGUIDCOL  NOT NULL ,
	[TaskTypeID] [uniqueidentifier] NOT NULL ,
	[ScheduleID] [uniqueidentifier] NULL ,
	[Parameters] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[StatusID] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[StatusMessage] [varchar] (1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[StartTime] [datetime] NULL ,
	[EndTime] [datetime] NULL ,
	[FullLog] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
	) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
	
	
	CREATE TABLE [VC3TaskScheduler].[ScheduledTaskSchedule] (
	[ID]  uniqueidentifier ROWGUIDCOL  NOT NULL ,
	[TaskTypeID] [uniqueidentifier] NOT NULL ,
	[Parameters] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[IsEnabled] [bit] NOT NULL ,
	[EnabledDate] [datetime] NULL ,
	[LastRunTime] [datetime] NULL ,
	[FrequencyAmount] [int] NOT NULL ,
	[FrequencyTypeID] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[YearTrigger] [int] NULL ,
	[MonthTrigger] [int] NULL ,
	[DayTrigger] [int] NULL ,
	[HourTrigger] [int] NULL ,
	[MinuteTrigger] [int] NULL ,
	[MonTrigger] [bit] NOT NULL ,
	[TuesTrigger] [bit] NOT NULL ,
	[WedsTrigger] [bit] NOT NULL ,
	[ThursTrigger] [bit] NOT NULL ,
	[FriTrigger] [bit] NOT NULL ,
	[SatTrigger] [bit] NOT NULL ,
	[SunTrigger] [bit] NOT NULL 
	) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
	
	
	CREATE TABLE [VC3TaskScheduler].[ScheduledTaskScheduleFrequency] (
		[ID] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
		[Name] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
	) ON [PRIMARY]
	
	
	CREATE TABLE [VC3TaskScheduler].[ScheduledTaskStatus] (
	[ID] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Name] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
	) ON [PRIMARY]
	
	
	CREATE TABLE [VC3TaskScheduler].[ScheduledTaskType] (
	[ID]  uniqueidentifier ROWGUIDCOL  NOT NULL ,
	[Name] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[TypeName] [varchar] (300) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
	) ON [PRIMARY]
	

	ALTER TABLE [VC3TaskScheduler].[ScheduledTask] ADD 
		CONSTRAINT [DF_ScheduledTask_ID] DEFAULT (newid()) FOR [ID],
		CONSTRAINT [PK_ScheduledTask] PRIMARY KEY  CLUSTERED 
		(
			[ID]
		)  ON [PRIMARY] 
	

	ALTER TABLE [VC3TaskScheduler].[ScheduledTaskSchedule] ADD 
		CONSTRAINT [DF_ScheduledTaskSchedule_ID] DEFAULT (newid()) FOR [ID],
		CONSTRAINT [PK_ScheduledTaskSchedule] PRIMARY KEY  CLUSTERED 
		(
				[ID]
			)  ON [PRIMARY] 
	

	ALTER TABLE [VC3TaskScheduler].[ScheduledTaskScheduleFrequency] ADD 
		CONSTRAINT [PK_ScheduledTaskScheduleFrequency] PRIMARY KEY  CLUSTERED 
		(
			[ID]
		)  ON [PRIMARY] 
	

	ALTER TABLE [VC3TaskScheduler].[ScheduledTaskStatus] ADD 
		CONSTRAINT [PK_ScheduledTaskStatus] PRIMARY KEY  CLUSTERED 
		(
			[ID]
		)  ON [PRIMARY] 
	

	ALTER TABLE [VC3TaskScheduler].[ScheduledTaskType] ADD 
		CONSTRAINT [DF_ScheduledTaskType_ID] DEFAULT (newid()) FOR [ID],
		CONSTRAINT [PK_ScheduledTaskType] PRIMARY KEY  CLUSTERED 
		(
			[ID]
		)  ON [PRIMARY] 
	

	ALTER TABLE [VC3TaskScheduler].[ScheduledTask] ADD 
		CONSTRAINT [FK_ScheduledTask#Schedule#TaskHistory] FOREIGN KEY 
		(
			[ScheduleID]
		) REFERENCES [VC3TaskScheduler].[ScheduledTaskSchedule] (
			[ID]
		),
		CONSTRAINT [FK_ScheduledTask#Status#] FOREIGN KEY 
		(
			[StatusID]
		) REFERENCES [VC3TaskScheduler].[ScheduledTaskStatus] (
			[ID]
		),
		CONSTRAINT [FK_ScheduledTask#Type#TaskHistory] FOREIGN KEY 
		(
			[TaskTypeID]
		) REFERENCES [VC3TaskScheduler].[ScheduledTaskType] (
			[ID]
		) ON DELETE CASCADE 
	

	ALTER TABLE [VC3TaskScheduler].[ScheduledTaskSchedule] ADD 
		CONSTRAINT [FK_ScheduledTaskSchedule#FrequencyType#] FOREIGN KEY 
		(
			[FrequencyTypeID]
		) REFERENCES [VC3TaskScheduler].[ScheduledTaskScheduleFrequency] (
			[ID]
		),
		CONSTRAINT [FK_ScheduledTaskSchedule#TaskType#Schedules] FOREIGN KEY 
		(
			[TaskTypeID]
		) REFERENCES [VC3TaskScheduler].[ScheduledTaskType] (
			[ID]
		) ON DELETE CASCADE 
		
	-- Populate lookups
	insert into VC3TaskScheduler.ScheduledTaskStatus values ('C', 'Cancelled')
	insert into VC3TaskScheduler.ScheduledTaskStatus values ('F', 'Failed')
	insert into VC3TaskScheduler.ScheduledTaskStatus values ('P', 'Pending')
	insert into VC3TaskScheduler.ScheduledTaskStatus values ('R', 'Running')
	insert into VC3TaskScheduler.ScheduledTaskStatus values ('S', 'Succeeded')
	
	
	insert into VC3TaskScheduler.ScheduledTaskScheduleFrequency values ('D', 'Daily')
	insert into VC3TaskScheduler.ScheduledTaskScheduleFrequency values ('H', 'Hour')
	insert into VC3TaskScheduler.ScheduledTaskScheduleFrequency values ('M', 'Minute')
	insert into VC3TaskScheduler.ScheduledTaskScheduleFrequency values ('O', 'Once')
	insert into VC3TaskScheduler.ScheduledTaskScheduleFrequency values ('W', 'Weekly')
	
END


--drop existing stored procs, these should be recreated by the object scripts


/****** Object:  StoredProcedure [dbo].[ScheduledTask_DeleteRecord]    Script Date: 07/03/2007 14:14:43 ******/
IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ScheduledTaskScheduleFrequency_DeleteRecord]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ScheduledTaskScheduleFrequency_DeleteRecord]



/****** Object:  StoredProcedure [dbo].[ScheduledTask_DeleteRecord]    Script Date: 07/03/2007 14:14:43 ******/
IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ScheduledTaskScheduleFrequency_GetRecords]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ScheduledTaskScheduleFrequency_GetRecords]



/****** Object:  StoredProcedure [dbo].[ScheduledTask_DeleteRecord]    Script Date: 07/03/2007 14:14:43 ******/
IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ScheduledTaskScheduleFrequency_InsertRecord]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ScheduledTaskScheduleFrequency_InsertRecord]



/****** Object:  StoredProcedure [dbo].[ScheduledTask_DeleteRecord]    Script Date: 07/03/2007 14:14:43 ******/
IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ScheduledTaskScheduleFrequency_UpdateRecord]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ScheduledTaskScheduleFrequency_UpdateRecord]



/****** Object:  StoredProcedure [dbo].[ScheduledTask_DeleteRecord]    Script Date: 07/03/2007 14:14:43 ******/
IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ScheduledTaskSchedule_DeleteRecord]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ScheduledTaskSchedule_DeleteRecord]



/****** Object:  StoredProcedure [dbo].[ScheduledTask_DeleteRecord]    Script Date: 07/03/2007 14:14:43 ******/
IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ScheduledTaskSchedule_GetAllRecords]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ScheduledTaskSchedule_GetAllRecords]



/****** Object:  StoredProcedure [dbo].[ScheduledTask_DeleteRecord]    Script Date: 07/03/2007 14:14:43 ******/
IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ScheduledTaskSchedule_GetEnabledSchedules]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ScheduledTaskSchedule_GetEnabledSchedules]



/****** Object:  StoredProcedure [dbo].[ScheduledTask_DeleteRecord]    Script Date: 07/03/2007 14:14:43 ******/
IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ScheduledTaskSchedule_GetRecords]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ScheduledTaskSchedule_GetRecords]



/****** Object:  StoredProcedure [dbo].[ScheduledTask_DeleteRecord]    Script Date: 07/03/2007 14:14:43 ******/
IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ScheduledTaskSchedule_GetRecordsByTaskTypeId]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ScheduledTaskSchedule_GetRecordsByTaskTypeId]



/****** Object:  StoredProcedure [dbo].[ScheduledTask_DeleteRecord]    Script Date: 07/03/2007 14:14:43 ******/
IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ScheduledTaskSchedule_InsertRecord]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ScheduledTaskSchedule_InsertRecord]



/****** Object:  StoredProcedure [dbo].[ScheduledTask_DeleteRecord]    Script Date: 07/03/2007 14:14:43 ******/
IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ScheduledTaskSchedule_UpdateRecord]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ScheduledTaskSchedule_UpdateRecord]



/****** Object:  StoredProcedure [dbo].[ScheduledTask_DeleteRecord]    Script Date: 07/03/2007 14:14:43 ******/
IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ScheduledTaskStatus_DeleteRecord]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ScheduledTaskStatus_DeleteRecord]



/****** Object:  StoredProcedure [dbo].[ScheduledTask_DeleteRecord]    Script Date: 07/03/2007 14:14:43 ******/
IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ScheduledTaskStatus_GetRecords]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ScheduledTaskStatus_GetRecords]



/****** Object:  StoredProcedure [dbo].[ScheduledTask_DeleteRecord]    Script Date: 07/03/2007 14:14:43 ******/
IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ScheduledTaskStatus_InsertRecord]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ScheduledTaskStatus_InsertRecord]



/****** Object:  StoredProcedure [dbo].[ScheduledTask_DeleteRecord]    Script Date: 07/03/2007 14:14:43 ******/
IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ScheduledTaskStatus_UpdateRecord]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ScheduledTaskStatus_UpdateRecord]



/****** Object:  StoredProcedure [dbo].[ScheduledTask_DeleteRecord]    Script Date: 07/03/2007 14:14:43 ******/
IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ScheduledTaskType_DeleteRecord]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ScheduledTaskType_DeleteRecord]



/****** Object:  StoredProcedure [dbo].[ScheduledTask_DeleteRecord]    Script Date: 07/03/2007 14:14:43 ******/
IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ScheduledTaskType_GetRecords]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ScheduledTaskType_GetRecords]



/****** Object:  StoredProcedure [dbo].[ScheduledTask_DeleteRecord]    Script Date: 07/03/2007 14:14:43 ******/
IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ScheduledTaskType_InsertRecord]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ScheduledTaskType_InsertRecord]



/****** Object:  StoredProcedure [dbo].[ScheduledTask_DeleteRecord]    Script Date: 07/03/2007 14:14:43 ******/
IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ScheduledTaskType_UpdateRecord]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ScheduledTaskType_UpdateRecord]



/****** Object:  StoredProcedure [dbo].[ScheduledTask_DeleteRecord]    Script Date: 07/03/2007 14:14:43 ******/
IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ScheduledTask_DeleteRecord]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ScheduledTask_DeleteRecord]



/****** Object:  StoredProcedure [dbo].[ScheduledTask_DeleteRecord]    Script Date: 07/03/2007 14:14:43 ******/
IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ScheduledTask_GetLast]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ScheduledTask_GetLast]



/****** Object:  StoredProcedure [dbo].[ScheduledTask_DeleteRecord]    Script Date: 07/03/2007 14:14:43 ******/
IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ScheduledTask_GetRecords]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ScheduledTask_GetRecords]



/****** Object:  StoredProcedure [dbo].[ScheduledTask_DeleteRecord]    Script Date: 07/03/2007 14:14:43 ******/
IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ScheduledTask_GetRecordsByScheduleId]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ScheduledTask_GetRecordsByScheduleId]



/****** Object:  StoredProcedure [dbo].[ScheduledTask_DeleteRecord]    Script Date: 07/03/2007 14:14:43 ******/
IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ScheduledTask_GetTasks]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ScheduledTask_GetTasks]



/****** Object:  StoredProcedure [dbo].[ScheduledTask_DeleteRecord]    Script Date: 07/03/2007 14:14:43 ******/
IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ScheduledTask_InsertRecord]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ScheduledTask_InsertRecord]



/****** Object:  StoredProcedure [dbo].[ScheduledTask_DeleteRecord]    Script Date: 07/03/2007 14:14:43 ******/
IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ScheduledTask_UpdateRecord]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ScheduledTask_UpdateRecord]



/****** Object:  StoredProcedure [dbo].[ScheduledTask_DeleteRecord]    Script Date: 07/03/2007 14:14:43 ******/
IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[ScheduledTask_UpdateRunningTask]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ScheduledTask_UpdateRunningTask]
