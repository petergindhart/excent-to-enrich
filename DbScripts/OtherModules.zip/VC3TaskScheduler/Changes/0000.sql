--create the scema so that it can recognize it later
exec VC3DEployment.CreateSchema 'VC3TaskScheduler'

-- Setup basic modules
exec VC3Deployment.AddModule 'VC3TaskScheduler'
exec VC3Deployment.AddModuleDependency @usedBy='dbo', @uses='VC3TaskScheduler'
GO
