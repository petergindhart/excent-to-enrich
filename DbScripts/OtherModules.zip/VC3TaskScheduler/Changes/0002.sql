insert into VC3TaskScheduler.ScheduledTaskScheduleFrequency values ('N', 'Monthly')
GO