SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3TaskScheduler].[ScheduledTask_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3TaskScheduler].[ScheduledTask_InsertRecord]
GO



/*
<summary>
Inserts a new record into the ScheduledTask table with the specified values
</summary>
<param name="parameters">Value to assign to the Parameters field of the record</param>
<param name="statusMessage">Value to assign to the StatusMessage field of the record</param>
<param name="startTime">Value to assign to the StartTime field of the record</param>
<param name="endTime">Value to assign to the EndTime field of the record</param>
<param name="fullLog">Value to assign to the FullLog field of the record</param>
<param name="scheduleId">Value to assign to the ScheduleID field of the record</param>
<param name="statusId">Value to assign to the StatusID field of the record</param>
<param name="taskTypeId">Value to assign to the TaskTypeID field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE VC3TaskScheduler.ScheduledTask_InsertRecord 
	@parameters text,
	@statusMessage varchar(1000),
	@startTime datetime,
	@endTime datetime,
	@fullLog text,
	@scheduleId uniqueidentifier,
	@statusId char(1),
	@taskTypeId uniqueidentifier
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
INSERT INTO [VC3TaskScheduler].[ScheduledTask]
	(

		ID,
		Parameters,
		StatusMessage,
		StartTime,
		EndTime,
		FullLog,
		ScheduleID,
		StatusID,
		TaskTypeID
	)
	VALUES
	(

		@id,
		@parameters,
		@statusMessage,
		@startTime,
		@endTime,
		@fullLog,
		@scheduleId,
		@statusId,
		@taskTypeId
	)

	SELECT @id


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

