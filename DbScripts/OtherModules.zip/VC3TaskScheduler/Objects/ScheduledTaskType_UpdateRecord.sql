SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3TaskScheduler].[ScheduledTaskType_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3TaskScheduler].[ScheduledTaskType_UpdateRecord]
GO



/*
<summary>
Updates a record in the ScheduledTaskType table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<param name="typeName">Value to assign to the TypeName field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE VC3TaskScheduler.ScheduledTaskType_UpdateRecord 
	@id uniqueidentifier,
	@name varchar(50),
	@typeName varchar(300)
AS
	UPDATE [VC3TaskScheduler].[ScheduledTaskType]
	SET
		Name = @name,
		TypeName = @typeName
	WHERE Id = @id


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

