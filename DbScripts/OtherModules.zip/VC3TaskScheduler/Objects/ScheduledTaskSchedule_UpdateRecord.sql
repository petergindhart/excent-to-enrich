SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3TaskScheduler].[ScheduledTaskSchedule_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3TaskScheduler].[ScheduledTaskSchedule_UpdateRecord]
GO



/*
<summary>
Updates a record in the ScheduledTaskSchedule table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="parameters">Value to assign to the Parameters field of the record</param>
<param name="isEnabled">Value to assign to the IsEnabled field of the record</param>
<param name="enabledDate">Value to assign to the EnabledDate field of the record</param>
<param name="lastRunTime">Value to assign to the LastRunTime field of the record</param>
<param name="frequencyAmount">Value to assign to the FrequencyAmount field of the record</param>
<param name="yearTrigger">Value to assign to the YearTrigger field of the record</param>
<param name="monthTrigger">Value to assign to the MonthTrigger field of the record</param>
<param name="dayTrigger">Value to assign to the DayTrigger field of the record</param>
<param name="hourTrigger">Value to assign to the HourTrigger field of the record</param>
<param name="minuteTrigger">Value to assign to the MinuteTrigger field of the record</param>
<param name="monTrigger">Value to assign to the MonTrigger field of the record</param>
<param name="tuesTrigger">Value to assign to the TuesTrigger field of the record</param>
<param name="wedsTrigger">Value to assign to the WedsTrigger field of the record</param>
<param name="thursTrigger">Value to assign to the ThursTrigger field of the record</param>
<param name="friTrigger">Value to assign to the FriTrigger field of the record</param>
<param name="satTrigger">Value to assign to the SatTrigger field of the record</param>
<param name="sunTrigger">Value to assign to the SunTrigger field of the record</param>
<param name="frequencyTypeId">Value to assign to the FrequencyTypeID field of the record</param>
<param name="taskTypeId">Value to assign to the TaskTypeID field of the record</param>

<model isGenerated="True" returnType="System.Void" />
*/
CREATE PROCEDURE VC3TaskScheduler.ScheduledTaskSchedule_UpdateRecord 
	@id uniqueidentifier,
	@parameters text,
	@isEnabled bit,
	@enabledDate datetime,
	@lastRunTime datetime,
	@frequencyAmount int,
	@yearTrigger int,
	@monthTrigger int,
	@dayTrigger int,
	@hourTrigger int,
	@minuteTrigger int,
	@monTrigger bit,
	@tuesTrigger bit,
	@wedsTrigger bit,
	@thursTrigger bit,
	@friTrigger bit,
	@satTrigger bit,
	@sunTrigger bit,
	@frequencyTypeId char(1),
	@taskTypeId uniqueidentifier
AS
	UPDATE [VC3TaskScheduler].[ScheduledTaskSchedule]
	SET
		Parameters = @parameters,
		IsEnabled = @isEnabled,
		EnabledDate = @enabledDate,
		LastRunTime = @lastRunTime,
		FrequencyAmount = @frequencyAmount,
		YearTrigger = @yearTrigger,
		MonthTrigger = @monthTrigger,
		DayTrigger = @dayTrigger,
		HourTrigger = @hourTrigger,
		MinuteTrigger = @minuteTrigger,
		MonTrigger = @monTrigger,
		TuesTrigger = @tuesTrigger,
		WedsTrigger = @wedsTrigger,
		ThursTrigger = @thursTrigger,
		FriTrigger = @friTrigger,
		SatTrigger = @satTrigger,
		SunTrigger = @sunTrigger,
		FrequencyTypeID = @frequencyTypeId,
		TaskTypeID = @taskTypeId
	WHERE Id = @id


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

