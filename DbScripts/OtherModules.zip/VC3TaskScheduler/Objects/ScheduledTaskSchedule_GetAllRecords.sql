if exists (select * from dbo.sysobjects where id = object_id(N'[VC3TaskScheduler].[ScheduledTaskSchedule_GetAllRecords]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3TaskScheduler].[ScheduledTaskSchedule_GetAllRecords]
GO

/*
<summary>
Gets all schedules
</summary>

<returns>
All schedules
</returns>

<model  isGenerated="false" 
        returnType="System.Data.IDataReader" 
        />
*/
CREATE PROCEDURE VC3TaskScheduler.ScheduledTaskSchedule_GetAllRecords
AS
	SELECT *
	FROM VC3TaskScheduler.ScheduledTaskSchedule
GO
