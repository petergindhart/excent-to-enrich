if exists (select * from dbo.sysobjects where id = object_id(N'[VC3TaskScheduler].[ScheduledTask_GetTasks]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3TaskScheduler].[ScheduledTask_GetTasks]
GO


/*
<summary>

</summary>

<returns></returns>

<model  isGenerated="false" 
        returnType="System.Data.IDataReader" 
        />
*/
CREATE PROCEDURE VC3TaskScheduler.ScheduledTask_GetTasks 
	@status char(1)
AS
	select *
	from VC3TaskScheduler.ScheduledTask
	where StatusID = @status and ScheduleID is null
GO
























