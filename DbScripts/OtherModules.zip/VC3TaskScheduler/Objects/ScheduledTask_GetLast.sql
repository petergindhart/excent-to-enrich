

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3TaskScheduler].[ScheduledTask_GetLast]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3TaskScheduler].[ScheduledTask_GetLast]
GO


/*
<summary>
Gets last N history items
</summary>

<returns></returns>

<model  isGenerated="false" 
        returnType="System.Data.IDataReader" 
        />
*/
CREATE PROCEDURE VC3TaskScheduler.ScheduledTask_GetLast
	@taskTypeID uniqueidentifier, 
	@num int
AS
	exec(
		'SELECT TOP ' + @num + ' *
		FROM VC3TaskScheduler.ScheduledTask
		WHERE TaskTypeID = ''' + @taskTypeID + '''
		ORDER BY StartTime DESC')





