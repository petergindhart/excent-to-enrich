SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3TaskScheduler].[ScheduledTaskScheduleFrequency_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3TaskScheduler].[ScheduledTaskScheduleFrequency_InsertRecord]
GO



/*
<summary>
Inserts a new record into the ScheduledTaskScheduleFrequency table with the specified values
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="name">Value to assign to the Name field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Char" />
*/
CREATE PROCEDURE VC3TaskScheduler.ScheduledTaskScheduleFrequency_InsertRecord 
	@id char(1),
	@name varchar(50)
AS
INSERT INTO [VC3TaskScheduler].[ScheduledTaskScheduleFrequency]
	(

		ID,
		Name
	)
	VALUES
	(

		@id,
		@name
	)


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

