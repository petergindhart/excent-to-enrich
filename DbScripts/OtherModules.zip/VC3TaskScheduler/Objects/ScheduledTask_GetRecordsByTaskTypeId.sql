SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3TaskScheduler].[ScheduledTask_GetRecordsByTaskTypeId]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3TaskScheduler].[ScheduledTask_GetRecordsByTaskTypeId]
GO


/*
<summary>
Gets records from the ScheduledTask table for the specified ids 
</summary>
<param name="ids">Ids of the ScheduledTaskType's </param>
<returns>An <see cref="IDataReader"/> containing the requested data</returns>
<model isGenerated="False" returnType="System.Data.IDataReader" />
*/
CREATE PROCEDURE VC3TaskScheduler.ScheduledTask_GetRecordsByTaskTypeId 
	@ids uniqueidentifierarray
AS
	SELECT s.TaskTypeID, s.*
	FROM
		VC3TaskScheduler.ScheduledTask s INNER JOIN
		GetUniqueidentifiers(@ids) AS Keys ON s.TaskTypeID = Keys.Id

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO