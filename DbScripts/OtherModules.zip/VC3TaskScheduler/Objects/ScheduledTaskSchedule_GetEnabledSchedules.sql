
if exists (select * from dbo.sysobjects where id = object_id(N'[VC3TaskScheduler].[ScheduledTaskSchedule_GetEnabledSchedules]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3TaskScheduler].[ScheduledTaskSchedule_GetEnabledSchedules]
GO

/*
<summary>

</summary>

<returns></returns>

<model  isGenerated="false" 
        returnType="System.Data.IDataReader" 
        />
*/
CREATE PROCEDURE VC3TaskScheduler.ScheduledTaskSchedule_GetEnabledSchedules 
AS
	SELECT *
	FROM VC3TaskScheduler.ScheduledTaskSchedule
	WHERE IsEnabled = 1
GO
