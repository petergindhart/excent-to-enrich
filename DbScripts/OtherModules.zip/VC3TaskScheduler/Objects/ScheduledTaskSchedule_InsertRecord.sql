SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3TaskScheduler].[ScheduledTaskSchedule_InsertRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3TaskScheduler].[ScheduledTaskSchedule_InsertRecord]
GO



/*
<summary>
Inserts a new record into the ScheduledTaskSchedule table with the specified values
</summary>
<param name="parameters">Value to assign to the Parameters field of the record</param>
<param name="isEnabled">Value to assign to the IsEnabled field of the record</param>
<param name="enabledDate">Value to assign to the EnabledDate field of the record</param>
<param name="lastRunTime">Value to assign to the LastRunTime field of the record</param>
<param name="frequencyAmount">Value to assign to the FrequencyAmount field of the record</param>
<param name="yearTrigger">Value to assign to the YearTrigger field of the record</param>
<param name="monthTrigger">Value to assign to the MonthTrigger field of the record</param>
<param name="dayTrigger">Value to assign to the DayTrigger field of the record</param>
<param name="hourTrigger">Value to assign to the HourTrigger field of the record</param>
<param name="minuteTrigger">Value to assign to the MinuteTrigger field of the record</param>
<param name="monTrigger">Value to assign to the MonTrigger field of the record</param>
<param name="tuesTrigger">Value to assign to the TuesTrigger field of the record</param>
<param name="wedsTrigger">Value to assign to the WedsTrigger field of the record</param>
<param name="thursTrigger">Value to assign to the ThursTrigger field of the record</param>
<param name="friTrigger">Value to assign to the FriTrigger field of the record</param>
<param name="satTrigger">Value to assign to the SatTrigger field of the record</param>
<param name="sunTrigger">Value to assign to the SunTrigger field of the record</param>
<param name="frequencyTypeId">Value to assign to the FrequencyTypeID field of the record</param>
<param name="taskTypeId">Value to assign to the TaskTypeID field of the record</param>
<returns>The identifiers for the inserted record</returns>
<model isGenerated="True" returnType="System.Guid" />
*/
CREATE PROCEDURE VC3TaskScheduler.ScheduledTaskSchedule_InsertRecord 
	@parameters text,
	@isEnabled bit,
	@enabledDate datetime,
	@lastRunTime datetime,
	@frequencyAmount int,
	@yearTrigger int,
	@monthTrigger int,
	@dayTrigger int,
	@hourTrigger int,
	@minuteTrigger int,
	@monTrigger bit,
	@tuesTrigger bit,
	@wedsTrigger bit,
	@thursTrigger bit,
	@friTrigger bit,
	@satTrigger bit,
	@sunTrigger bit,
	@frequencyTypeId char(1),
	@taskTypeId uniqueidentifier
AS
	DECLARE @id as uniqueidentifier
	SET @id = NewID()
INSERT INTO [VC3TaskScheduler].[ScheduledTaskSchedule]
	(

		ID,
		Parameters,
		IsEnabled,
		EnabledDate,
		LastRunTime,
		FrequencyAmount,
		YearTrigger,
		MonthTrigger,
		DayTrigger,
		HourTrigger,
		MinuteTrigger,
		MonTrigger,
		TuesTrigger,
		WedsTrigger,
		ThursTrigger,
		FriTrigger,
		SatTrigger,
		SunTrigger,
		FrequencyTypeID,
		TaskTypeID
	)
	VALUES
	(

		@id,
		@parameters,
		@isEnabled,
		@enabledDate,
		@lastRunTime,
		@frequencyAmount,
		@yearTrigger,
		@monthTrigger,
		@dayTrigger,
		@hourTrigger,
		@minuteTrigger,
		@monTrigger,
		@tuesTrigger,
		@wedsTrigger,
		@thursTrigger,
		@friTrigger,
		@satTrigger,
		@sunTrigger,
		@frequencyTypeId,
		@taskTypeId
	)

	SELECT @id


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

