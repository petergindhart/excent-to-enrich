SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[VC3TaskScheduler].[ScheduledTask_UpdateRecord]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [VC3TaskScheduler].[ScheduledTask_UpdateRecord]
GO


/*
<summary>
Updates the status of a running task.  Does not access that make be changing so
that it may be called outside of a transaction and not be blocked by transacted
connections.
</summary>
<param name="id">Value to assign to the ID field of the record</param>
<param name="statusMessage">Value to assign to the StatusMessage field of the record</param>
<param name="startTime">Value to assign to the StartTime field of the record</param>
<param name="endTime">Value to assign to the EndTime field of the record</param>
<param name="fullLog">Value to assign to the FullLog field of the record</param>
<param name="statusId">Value to assign to the StatusID field of the record</param>

<model isGenerated="False" returnType="System.Void" />
*/
CREATE PROCEDURE VC3TaskScheduler.ScheduledTask_UpdateRecord 
	@id uniqueidentifier,
	@statusMessage varchar(1000),
	@startTime datetime,
	@endTime datetime,
	@fullLog text,
	@statusId char(1)
AS
	UPDATE [VC3TaskScheduler].[ScheduledTask]
	SET
		StatusMessage = @statusMessage,
		StartTime = @startTime,
		EndTime = @endTime,
		FullLog = @fullLog,
		StatusID = @statusId
	WHERE Id = @id

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

