IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[INFORM].[Transform_ReportCardType]') AND OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [INFORM].[Transform_ReportCardType]
GO

CREATE VIEW INFORM.Transform_ReportCardType
AS
SELECT
	mt.DestID,
	Name = 'Report Cards (' + cast(mpCount as varchar(3)) + ' Marking Periods)',
	NumberOfMarkingPeriods = mpCount
FROM
	(
		select	
			count(distinct gradeType) mpCount
		FROM
			INFORM.GRDDATA			
	) g left join
	INFORM.Map_ReportCardTypeID mt on mt.NumberOfMarkingPeriods = g.mpCount