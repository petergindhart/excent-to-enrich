IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[INFORM].[GetReportCardTypeID]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [INFORM].[GetReportCardTypeID]
GO

CREATE FUNCTION [INFORM].[GetReportCardTypeID](@schoolYear int)
RETURNS uniqueidentifier
AS
BEGIN
RETURN
(
	select top 1 DestID 
	from INFORM.Map_ReportCardTypeID 
	where NumberOfMarkingPeriods = (
		select count(distinct gradeType) 
		from INFORM.GRDDATA 
		WHERE year = [INFORM].[GetYearRange](@schoolYear) )						
)
END