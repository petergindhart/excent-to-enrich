IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[INFORM].[Transform_ReportCardItem]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [INFORM].[Transform_ReportCardItem]
GO

CREATE FUNCTION INFORM.Transform_ReportCardItem
(	
	@schoolYear int
)
RETURNS TABLE
AS
RETURN

--DECLARE @schoolYear int
--SET @schoolYear = 10

SELECT
	mrci.DestID,
	ReportCardTypeID  =  INFORM.GetReportCardTypeID(@schoolYear),
	Name = grd.gradeType,
	Sequence = 0,
	ShortName = substring(grd.gradeType,1,10),
	IsFinal = 0, --we have not yet currently seen a full year worth of report cards, so the final name is unknown
	grd.gradeType
FROM
	(
		SELECT
			gradeType
		FROM
			INFORM.GRDDATA
		GROUP BY
			gradeType	
	) grd left join
	INFORM.Map_ReportCardItemID mrci on grd.gradeType = mrci.GradeType and mrci.ReportCardTypeID = INFORM.GetReportCardTypeID(@schoolYear)