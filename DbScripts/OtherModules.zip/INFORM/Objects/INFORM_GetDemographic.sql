IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[INFORM].[GetDemographic]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [INFORM].[GetDemographic]
GO

CREATE FUNCTION INFORM.GetDemographic(@studentID varchar(15), @demographicName varchar(50))
RETURNS varchar(100)
AS
BEGIN
RETURN
(
	SELECT top 1 response
	FROM
		INFORM.DEMDATA
	WHERE
		StudentID = @studentID
)
END