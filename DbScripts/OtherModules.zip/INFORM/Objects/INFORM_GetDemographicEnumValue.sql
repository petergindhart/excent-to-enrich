IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[INFORM].[GetDemographicEnumValue]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [INFORM].[GetDemographicEnumValue]
GO

CREATE FUNCTION INFORM.GetDemographicEnumValue(@studentID varchar(15), @demographicName varchar(50), @enumTypeName varchar(15)) --, @enumTypeID uniqueidentifier)
RETURNS varchar(100)
AS
BEGIN
RETURN
(
	SELECT top 1 mev.DestID
	FROM
		INFORM.DEMDATA dd left join
		INFORM.Map_EnumValueID mev on mev.Type = @enumTypeName AND mev.Code = dd.response 
	WHERE
		StudentID = @studentID AND
		dd.demographic = @demographicName
		
)
END