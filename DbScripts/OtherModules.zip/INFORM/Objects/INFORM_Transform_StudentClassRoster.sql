IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[INFORM].[Transform_StudentClassRoster]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [INFORM].[Transform_StudentClassRoster]
GO

CREATE FUNCTION [INFORM].[Transform_StudentClassRoster]
(	
	@schoolYear int
)
RETURNS TABLE
AS
RETURN

--DECLARE @schoolYear int
--SET @schoolYear = 10

select
	StudentID = ms.DestID,
	ClassRosterID = mc.DestID
FROM
	(
		select schoolID, courseID, section, studentID
		From INFORM.CLSDATA
		where schoolYear = @schoolYear
		group by schoolID, courseID, section, studentID
	) c join	
	INFORM.Map_StudentID ms on ms.StudentID = c.studentID join
	INFORM.Map_ClassRosterID mc on mc.SchoolID = c.schoolID AND mc.CourseID = c.courseID AND mc.SectionNumber = c.section