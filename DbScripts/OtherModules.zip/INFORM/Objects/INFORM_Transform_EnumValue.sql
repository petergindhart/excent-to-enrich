IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[INFORM].[Transform_EnumValue]') AND OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [INFORM].[Transform_EnumValue]
GO

CREATE VIEW INFORM.Transform_EnumValue
AS

SELECT
	TypeID = met.DestID,
	DisplayValue = dbo.CamelCase(ethGroups.response),
	code = dbo.CreateAcronym(ethGroups.response),
	ethGroups.response,
	[TYPE] = 'ETH',
	DestID = mev.DestID
FROM	
	(
		select distinct response 
		From INFORM.DEMDATA
		where demographic = 'Ethnic Group'
	) ethGroups join
	INFORM.Map_EnumTypeID met on met.Type = 'ETH' left join
	INFORM.Map_EnumValueID mev on mev.Type=met.Type and ethGroups.response = mev.Code
	
UNION ALL

SELECT
	TypeID = met.DestID,
	DisplayValue = dbo.CamelCase(ethGroups.response),
	code = dbo.CreateAcronym(ethGroups.response),
	ethGroups.response,
	[TYPE] = 'GEN',
	DestID = mev.DestID
FROM	
	(
		select distinct response 
		From INFORM.DEMDATA
		where demographic = 'Gender'
	) ethGroups join
	INFORM.Map_EnumTypeID met on met.Type = 'GEN' left join
	INFORM.Map_EnumValueID mev on mev.Type=met.Type and ethGroups.response = mev.Code