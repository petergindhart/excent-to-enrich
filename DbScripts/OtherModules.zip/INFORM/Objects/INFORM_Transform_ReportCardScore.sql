IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[INFORM].[Transform_ReportCardScore]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [INFORM].[Transform_ReportCardScore]
GO

CREATE FUNCTION [INFORM].[Transform_ReportCardScore]
(	
	@schoolYear int
)
RETURNS TABLE
AS
RETURN

--DECLARE @schoolYear int
--SET @schoolYear = 10

SELECT
	mrcs.DestID,
	StudentID = ms.DestID,
	ClassRosterID  = mc.DestID,
	ReportCardItem = mrci.DestID,
	PercentageScore = CASE 
			    WHEN ( isNumeric(grade) = 1) AND grade LIKE '%[0-9]%'--when its a number, make it an int
				then cast( grade as float )
			    ELSE null--when its not a number leave it blank and let LetterScore pick it up					 
			  END,	
	LetterScore =	CASE 
			   WHEN ( (isNumeric(grade) = 0) AND (LEN(grade) > 0))--when its a number, make it an int
				then grade
			   ELSE null--its either a number of its not, this is unreachable			 
			END,
	grd.gradeType
FROM
	(
		SELECT
			schoolid, 
			studentID,
			courseID,
			gradeType,
			sectionID,
			MAX(grade) AS grade-- when grades are issued for the same marking period but different periods they're always the same
		FROM
			INFORM.GRDDATA g
		where
			g.[year] = INFORM.GetYearRange(10)
		GROUP BY
			schoolid, 
			studentID,
			courseID,
			gradeType,
			sectionID
	) grd join	
	INFORM.Map_StudentID ms on grd.StudentID = ms.StudentID join
	INFORM.Map_classROsterID mc on mc.SchoolID = grd.SchoolID and mc.CourseID = grd.CourseID and mc.SectionNUmber = grd.SectionID join
	INFORM.Map_ReportCardItemID mrci on grd.gradeType = mrci.GradeType and mrci.ReportCardTypeID = INFORM.GetReportCardTypeID(@schoolYear) left join
	INFORM.Map_ReportCardScoreID mrcs on mrcs.StudentID = ms.DestID AND mrcs.ClassRosterID = mc.DestID and mrcs.GradeType = grd.gradeType