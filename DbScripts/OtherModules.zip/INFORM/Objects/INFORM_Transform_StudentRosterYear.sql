IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[INFORM].[Transform_StudentRosterYear]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [INFORM].[Transform_StudentRosterYear]
GO

CREATE FUNCTION [INFORM].[Transform_StudentRosterYear] 
(
	@importRosterYear uniqueidentifier	
)
RETURNS TABLE
AS
RETURN
SELECT
	m.DestID,
	StudentID = impstu.DestID,
	RosterYearID = @importRosterYear,
	DailyAbsences = 0, --there is currently no absence data being imported
	DisciplineReferrals = 0 --there is currently no absence data being imported
FROM
	INFORM.Transform_Student impstu left join
	INFORM.Map_StudentRosterYearID m on m.StudentId = impstu.DestID AND m.RosterYearID = @importRosterYear