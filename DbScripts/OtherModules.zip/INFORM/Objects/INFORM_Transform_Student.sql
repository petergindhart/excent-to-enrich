IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[INFORM].[Transform_Student]') AND OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [INFORM].[Transform_Student]
GO

CREATE VIEW INFORM.Transform_Student
AS
SELECT
	stu.studentID,
	ms.DestID,
	DOB = case when ISDATE(birthdate) = 1 then cast(birthdate As datetime) else null end,
	SOCSECNUM_VALIDATED = case when SSN = '000000000' then null else SSN end,
	FirstName = dbo.CamelCase(firstname),
	LastName = dbo.CamelCase(lastname),
	MiddleName = dbo.CamelCase(middlename),
	otherStateID,
	CurrentSchoolID = mss.DestID,
	GradeLevelID = (select top 1 mgl.DestID from INFORM.Map_GradeLevelID mgl where mgl.gradelevelID = stu.gradelevelID), --Grade mgl.DestID,
	EthnicityID = INFORM.GetDemographicEnumValue(stu.StudentID, 'Ethnic Group','ETH'),
	GenderID = INFORM.GetDemographicEnumValue(stu.StudentID, 'Gender','GEN')
FROM
	INFORM.STUDATA stu left join
	INFORM.Map_SchoolID mss on mss.SchoolID = stu.schoolID left join
	INFORM.Map_StudentID ms on ms.StudentID = stu.studentID