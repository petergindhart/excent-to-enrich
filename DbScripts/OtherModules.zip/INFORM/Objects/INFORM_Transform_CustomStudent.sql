IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[INFORM].[Transform_CustomStudent]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [INFORM].[Transform_CustomStudent]
GO

CREATE FUNCTION INFORM.Transform_CustomStudent
(
	@importRosterYear uniqueidentifier,
	@schoolYear int
)
RETURNS TABLE
AS
RETURN

select
	DestID,
	GPA = (select gpa from INFORM.STUGPAPRV stu WHERE stu.studentID = ms.StudentID)
FROM
	INFORM.Map_StudentID ms