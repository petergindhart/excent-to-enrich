IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[INFORM].[Transform_School]') AND OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [INFORM].[Transform_School]
GO

CREATE VIEW INFORM.Transform_School
AS
SELECT
	ms.DestID,
	allSchools.schoolID,
	Name = allSchools.schoolID, --placeholder
	Abbreviation = allSchools.schoolID --placeholder
FROM
	(
		select 
			distinct schoolID  as SchoolID
		From 
			INFORM.STUDATA		
	) allSchools left join
	INFORM.Map_SchoolID ms on ms.SchoolID = allSchools.SchoolID
