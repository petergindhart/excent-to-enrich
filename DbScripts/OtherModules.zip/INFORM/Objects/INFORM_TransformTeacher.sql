IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[INFORM].[Transform_Teacher]') AND OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [INFORM].[Transform_Teacher]
GO

CREATE VIEW INFORM.Transform_Teacher
AS
SELECT
	u.teacherID,
	mt.DestID,
	CurrentSchoolID = ms.DestID,
	FirstName = dbo.CamelCase(firstname),
	LastName = dbo.CamelCase(lastname),
	EmailAddress = lower(emailaddress),
	UserProfileID = isnull((select t.UserProfileID
				from Teacher t
				where t.Id = mt.DestID),
				
				(select top 1 ID -- Emails are mostly unique.  Top 1 to prevent the query from failing.
				from UserProfileView up
				where up.emailaddress = u.EmailAddress and up.Deleted is null
				))
FROM
	INFORM.USRDATA u join
	INFORM.Map_SchoolID ms on ms.SchoolID = u.SchoolID left join
	INFORM.Map_TeacherID mt on u.teacherID = mt.TeacherID
WHERE 
	u.accesslevel ='Teacher' OR --Prevents teacher,s who stop teaching any courses temporarily from beig dropped
	u.teacherID IN
	(
		select teacherID from INFORM.CLSDATA --only include users who actually teach classes, before calling them a teacher
	)
