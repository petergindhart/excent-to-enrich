IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[INFORM].[Transform_ClassRoster]') AND xtype in (N'FN', N'IF', N'TF'))
DROP FUNCTION [INFORM].[Transform_ClassRoster]
GO

CREATE FUNCTION INFORM.[Transform_ClassRoster] 
(
	@importRosterYear uniqueidentifier,
	@schoolYear int
)
RETURNS TABLE
AS
RETURN

--DECLARE
--	@importRosterYear uniqueidentifier,
--	@schoolYear int
	
--SET @importRosterYear = '334840F6-125D-41AD-AB64-0A029298D1F5'
--SET @schoolYear = 10

SELECT	
	DestID = mc.DestID,
	SchoolGUID = ms.DestID,
	RosterYearID = @importRosterYear,
	sectionName= clsRoll.courseID + '-' + section,
	clsRoll.courseID,
	Title,
	ContentAreaId = (	SELECT top 1 ContentAreaID
						FROM ClassRosterContentAreaRule arearule
						WHERE arearule.RosterYearId = @importRosterYear and
							clsRoll.courseID like arearule.CourseCodePattern and
							len( CourseCodePattern ) = (
								select max( len( CourseCodePattern ) )
								from ClassRosterContentAreaRule 
								where RosterYearID = arearule.RosterYearID and clsRoll.courseID like CourseCodePattern 
							)),
	I.MinGrade,
	I.MAxGrade,
	MinGradeID		= lGr.DestID, 
	MaxGradeID		= hGr.DestID,
	GradeBitMask	= BM.BitMask,
	Section,
	ms.SchoolID,
	TeacherID = mt.DestID
FROM
	(
		select schoolID, courseID, section, max(courseDescription) AS Title, MAX(TeacherID) as TeacherID
		From INFORM.CLSDATA
		where schoolYear = @schoolYear
		group by schoolID, courseID, section
	) clsRoll join
	INFORM.Map_SchoolID ms on ms.SchoolID = clsRoll.SchoolID left join
	INFORM.Map_ClassRosterID mc on mc.SchoolID = clsRoll.SchoolID and mc.courseID = clsRoll.courseID and mc.SectionNumber  = clsRoll.section left join
	INFORM.Map_TeacherID mt on mt.teacherID = clsRoll.TeacherID left join
	(	
		SELECT
			c.schoolID, courseID, c.Section AS SectionID,
			MIN(gradeLevelID) AS MinGrade,
			MAX(gradeLevelID) AS MaxGrade			
		FROM
			INFORM.clsdata c join	
			INFORM.studata stu ON stu.studentID = c.studentID	
		group by
			c.schoolID, courseID, section
	) I ON I.SectionID = clsRoll.section and I.courseID = clsRoll.courseID and I.schoolID = clsRoll.schoolID left join
	INFORM.Map_GradeLevelID lgr on lgr.GradeLevelID = I.MinGrade left join
	INFORM.Map_GradeLevelID hgr on hgr.GradeLevelID = I.MaxGrade left join
	GradeRangeBitMask BM on BM.MinGradeID = lGr.DestID and 	BM.MaxGradeID = hGr.DestID